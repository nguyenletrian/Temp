import bpy
import os
import json

def ActiveObject(obj):
    if bpy.context.object and bpy.context.object.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.select_all(action='DESELECT')   
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj

def ModeObject(obj):
    ActiveObject(obj)
    if bpy.context.object:
        bpy.ops.object.mode_set(mode='OBJECT')

def ModeEdit(obj):
    ActiveObject(obj)
    if bpy.context.object:
        bpy.ops.object.mode_set(mode='EDIT')

def ModePose(obj):
    ActiveObject(obj)
    if bpy.context.object:
        bpy.ops.object.mode_set(mode='POSE')

def GetState():
    objs = [obj for obj in bpy.context.selected_objects]
    active_obj = bpy.context.view_layer.objects.active
    mode = bpy.context.object.mode if bpy.context.object else 'OBJECT'
    return {
        "objs": objs,
        "active": active_obj,
        "mode": mode
    }

def BackState(data):
    if bpy.context.object and bpy.context.object.mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')  
    bpy.ops.object.select_all(action='DESELECT')   
    for obj in data["objs"]:
        obj.select_set(True)    
    bpy.context.view_layer.objects.active = data["active"]  
    if data["mode"] != 'OBJECT' and data["active"]:
        bpy.context.view_layer.objects.active = data["active"]
        bpy.ops.object.mode_set(mode=data["mode"])

### COLLECTION
def ColDelete(colName):
    col = bpy.data.collections.get(colName)
    if not col:
        print("Collection not found")
        return
    bpy.data.collections.remove(col)
    bpy.ops.outliner.orphans_purge(do_recursive=True)

def ColAddTemp():
    colName = "NLTA_Temp"
    if colName not in bpy.data.collections:
        col = bpy.data.collections.new(colName)
        bpy.context.scene.collection.children.link(col)

def ColDeleteTemp():
    colName = "NLTA_Temp"
    col = bpy.data.collections.get(colName)
    if not col:
        print("Collection not found")
        return
    bpy.data.collections.remove(col)
    bpy.ops.outliner.orphans_purge(do_recursive=True)


def ImportArm(fbxPath):
    ColAddTemp()
    col = bpy.data.collections["NLTA_Temp"]
    before = set(bpy.data.objects)
    bpy.ops.import_scene.fbx(filepath=fbxPath)
    after = set(bpy.data.objects)
    imported = after - before
    for obj in imported:
        for c in obj.users_collection:
            c.objects.unlink(obj)
        col.objects.link(obj)
    armatures = [o for o in imported if o.type == 'ARMATURE']
    armName = armatures[0].name if armatures else None
    return(armName)

"""
def ImportArm(fbxPath):
    ColAddTemp()
    col = bpy.data.collections["NLTA_Temp"]

    before = set(bpy.data.objects)
    bpy.ops.import_scene.fbx(filepath=fbxPath)
    after = set(bpy.data.objects)

    imported = after - before

    armatures = []

    
    for obj in imported:
        if obj.type == 'MESH':
            pass
            #bpy.data.objects.remove(obj, do_unlink=True)
        elif obj.type == 'ARMATURE':
            armatures.append(obj)
    

    # Move armature vào collection temp
    for arm in armatures:
        for c in arm.users_collection:
            c.objects.unlink(arm)
        col.objects.link(arm)

    return armatures[0].name if armatures else None
"""


def ImportArmScale(fbxPath):
    ColAddTemp()
    col = bpy.data.collections["NLTA_Temp"]
    before = set(bpy.data.objects)
    bpy.ops.wm.fbx_import(
        filepath=fbxPath,
        use_anim=True,
        anim_offset=0,
    )
    after = set(bpy.data.objects)
    imported = after - before
    for obj in imported:
        for c in obj.users_collection:
            c.objects.unlink(obj)
        col.objects.link(obj)
    armatures = [o for o in imported if o.type == 'ARMATURE']
    armName = armatures[0].name if armatures else None
    return(armName)
"""
def ImportArmScale(fbxPath):
    ColAddTemp()
    col = bpy.data.collections["NLTA_Temp"]

    before = set(bpy.data.objects)
    bpy.ops.wm.fbx_import(
        filepath=fbxPath,
        use_anim=True,
        anim_offset=0,
    )
    after = set(bpy.data.objects)

    imported = after - before

    armatures = []

    
    for obj in imported:
        if obj.type == 'MESH':
            pass
            #bpy.data.objects.remove(obj, do_unlink=True)
        elif obj.type == 'ARMATURE':
            armatures.append(obj)

    for arm in armatures:
        for c in arm.users_collection:
            c.objects.unlink(arm)
        col.objects.link(arm)

    return armatures[0].name if armatures else None
"""
 
def ExportLocalJson(dataInput):
    data = dataInput["data"]
    fileName = dataInput["fileName"]
    filePath = bpy.data.filepath
    if not filePath:
        print("⚠️ File chưa được save!")
        return
    folder = os.path.dirname(filePath)
    filePath = os.path.join(folder,fileName)    
    with open(filePath, "w", encoding="utf-8") as f:
        json.dump(data,f, indent=4)
def ImportLocalJson(dataInput):
    fileName = dataInput["fileName"]
    blend_path = bpy.data.filepath
    if not blend_path:
        print("❌ File chưa save")
        return
    folder = os.path.dirname(blend_path)
    file_path = os.path.join(folder,fileName)
    if not os.path.exists(file_path):
        print("❌ File không tồn tại")
        return
    with open(file_path, "r", encoding="utf-8") as f:
        data = json.load(f)
        return(data)
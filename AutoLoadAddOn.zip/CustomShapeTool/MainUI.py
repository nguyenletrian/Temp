import bpy
import importlib
import json
import os
import math
from mathutils import Matrix,Vector
from bpy.types import Operator
from bpy_extras.io_utils import ImportHelper

from . import NLTA_Amature,NLTA_General,NLTA_Mesh
importlib.reload(NLTA_Amature)
importlib.reload(NLTA_General)
importlib.reload(NLTA_Mesh)


import bpy
import math

def CreateShapes(*arr):
    # COLLECTION
    def GetOrCreateCtrlCollection():
        def FindLayerCollection(layer_collection, name):
            if layer_collection.collection.name == name:
                return layer_collection
            for child in layer_collection.children:
                found = FindLayerCollection(child, name)
                if found:
                    return found
            return None
        col_name = "CTRL_Shapes"
        col = bpy.data.collections.get(col_name)
        if not col:
            col = bpy.data.collections.new(col_name)
            bpy.context.scene.collection.children.link(col)
        layer_col = bpy.context.view_layer.layer_collection
        layer = FindLayerCollection(layer_col, col_name)

        if layer:
            layer.exclude = False
            layer.hide_viewport = True
        return col

    # DRAW FUNCTIONS
    def AddLine(curve, p1, p2):
        spline = curve.splines.new("POLY")
        spline.points.add(1)
        spline.points[0].co = (*p1, 1)
        spline.points[1].co = (*p2, 1)

    def AddCircle(curve, center, radius, segments):
        spline = curve.splines.new("POLY")
        spline.points.add(segments)

        for i in range(segments + 1):
            angle = (i / segments) * 2 * math.pi
            x = center[0] + math.cos(angle) * radius
            y = center[1] + math.sin(angle) * radius
            z = center[2]
            spline.points[i].co = (x, y, z, 1)

    def CreateControlShape(data):
        if bpy.data.objects.get(data["name"]):
            return
        curve = bpy.data.curves.new(data["name"], type='CURVE')
        curve.dimensions = '3D'
        # 👉 lines
        for edge in data.get("edges", []):
            AddLine(curve, edge[0], edge[1])
        # 👉 circle
        if "circle" in data:
            c = data["circle"]
            AddCircle(curve, c["center"], c["radius"], c["segments"])
        obj = bpy.data.objects.new(data["name"], curve)
        col = GetOrCreateCtrlCollection()
        col.objects.link(obj)
        if obj.name in bpy.context.scene.collection.objects:
            bpy.context.scene.collection.objects.unlink(obj)
        obj.hide_render = True
        obj.hide_select = True

    # DATA
    datas = [
        {
            "name":"CtrlShape_StickDiamon",
            "edges":[
                [(0,0,0), (0,2,0)],
                [(0,3,0), (-.5,2.5,0)],
                [(0,3,0), (.5,2.5,0)],
                [(0,2,0), (-.5,2.5,0)],
                [(0,2,0), (.5,2.5,0)],
            ]    
        },
        {
            "name":"CtrlShape_Square",
            "edges":[
                [(3,3,0), (-3,3,0)],
                [(3,3,0), (3,-3,0)],
                [(3,-3,0), (-3,-3,0)],
                [(-3,3,0), (-3,-3,0)],
            ]    
        },
        {
            "name":"CtrlShape_StickCircle",
            "edges":[
                [(0,0,0), (0,2.5,0)],
            ],
            "circle":{
                "center": (0,3,0),
                "radius": 0.5,
                "segments": 16
            }
        },
        {
            "name":"CtrlShape_Cross",
            "edges":[
                [(1,3,0), (-1,3,0)],
                [(-1,3,0), (-1,1,0)],
                [(-1,1,0), (-3,1,0)],
                [(-3,1,0), (-3,-1,0)],
                [(-3,-1,0), (-1,-1,0)],
                [(-1,-1,0), (-1,-3,0)],
                [(-1,-3,0), (1,-3,0)],
                [(1,-3,0), (1,-1,0)],
                [(1,-1,0), (3,-1,0)],
                [(3,-1,0), (3,1,0)],
                [(3,1,0), (1,1,0)],
                [(1,1,0), (1,3,0)],
            ]
        }
        
    ]
    for data in datas:
        CreateControlShape(data)

##########################################
def GetShapesData(context):
    arm = context.active_object
    bones = arm.pose.bones
    dataReturn = []
    for bone in bones:
        boneData = {
            "name":bone.name,
            "shapeName":bone.custom_shape.name if bone.custom_shape else None,
            "scale":(bone.custom_shape_scale_xyz[0],bone.custom_shape_scale_xyz[1],bone.custom_shape_scale_xyz[2]),
            "translate":(bone.custom_shape_translation[0],bone.custom_shape_translation[1],bone.custom_shape_translation[2]),
            "rotate":(bone.custom_shape_rotation_euler[0],bone.custom_shape_rotation_euler[1],bone.custom_shape_rotation_euler[2]),
            "useCustom":bone.use_custom_shape_bone_size,
            "color":arm.pose.bones[bone.name].color.palette
        }
        dataReturn.append(boneData)
    return(dataReturn)

def ExportShapesData(context):
    data = GetShapesData(context)
    NLTA_General.ExportLocalJson({
        "data":data,
        "fileName":"ShapesData.json",
    })

def ImportShapesData(context):
    CreateShapes()
    data = NLTA_General.ImportLocalJson({"fileName":"ShapesData.json"})
    arm = context.active_object
    if not arm or arm.type != 'ARMATURE':
        print("No armature selected")
        return
    pbones = arm.pose.bones
    for d in data:
        pb = pbones.get(d["name"])
        if not pb:
            continue
        # 👉 set custom shape
        shape_name = d.get("shapeName")
        if shape_name:
            shape_obj = bpy.data.objects.get(shape_name)
            pb.custom_shape = shape_obj
        else:
            pb.custom_shape = None
        if "scale" in d:
            pb.custom_shape_scale_xyz = d["scale"]
        if "translate" in d:
            pb.custom_shape_translation = d["translate"]
        if "rotate" in d and hasattr(pb, "custom_shape_rotation_euler"):
            pb.custom_shape_rotation_euler = d["rotate"]
        if "useCustom" in d:
            pb.use_custom_shape_bone_size = d["useCustom"]
        if "color" in d and pb.color:
            try:
                pb.color.palette = d["color"]
            except:
                pass
    print("Shapes Imported")


def CopyBoneShape(context):
    arm = context.active_object
    bones = bpy.context.selected_pose_bones
    source = bpy.context.active_pose_bone
    if not source:
        raise Exception("No active bone")
    shape = source.custom_shape
    scale = source.custom_shape_scale_xyz[:]
    transform = source.custom_shape_transform
    for b in bones:
        if b == source:
            continue
        b.custom_shape = shape
        b.custom_shape_scale_xyz = scale
        b.custom_shape_transform = transform
        b.use_custom_shape_bone_size = False
    bpy.context.view_layer.update()

# SCALE
def UpdateBoneShapeScale(self,context):
    arm = context.active_object;
    value = self.shapeScale;
    bones = bpy.context.selected_pose_bones
    for b in bones:
        b.custom_shape_scale_xyz = [value,value,value]

def UpdateBoneShapeScaleX(self,context):
    arm = context.active_object;
    value = self.shapeScaleX;
    bones = bpy.context.selected_pose_bones
    for b in bones:
        b.custom_shape_scale_xyz[0] = value

def UpdateBoneShapeScaleY(self,context):
    arm = context.active_object;
    value = self.shapeScaleY;
    bones = bpy.context.selected_pose_bones
    for b in bones:
        b.custom_shape_scale_xyz[1] = value

def UpdateBoneShapeScaleZ(self,context):
    arm = context.active_object;
    value = self.shapeScaleZ;
    bones = bpy.context.selected_pose_bones
    for b in bones:
        b.custom_shape_scale_xyz[2] = value

# ROTATION
def UpdateBoneShapeRotX(self,context):
    arm = context.active_object;
    value = self.shapeRotX;
    value = math.radians(value)
    bones = bpy.context.selected_pose_bones
    for b in bones:
        b.custom_shape_rotation_euler[0] = value

def UpdateBoneShapeRotY(self,context):
    arm = context.active_object;
    value = self.shapeRotY;
    value = math.radians(value)
    bones = bpy.context.selected_pose_bones
    for b in bones:
        b.custom_shape_rotation_euler[1] = value

def UpdateBoneShapeRotZ(self,context):
    arm = context.active_object;
    value = self.shapeRotZ;
    value = math.radians(value)
    bones = bpy.context.selected_pose_bones
    for b in bones:
        b.custom_shape_rotation_euler[2] = value

# TRANSLATION
def UpdateBoneShapeTranslateX(self,context):
    arm = context.active_object;
    value = self.shapeTranslateX;
    bones = bpy.context.selected_pose_bones
    for b in bones:
        b.custom_shape_translation[0] = value

def UpdateBoneShapeTranslateY(self,context):
    arm = context.active_object;
    value = self.shapeTranslateY;
    bones = bpy.context.selected_pose_bones
    for b in bones:
        b.custom_shape_translation[1] = value

def UpdateBoneShapeTranslateZ(self,context):
    arm = context.active_object
    value = self.shapeTranslateZ
    bones = bpy.context.selected_pose_bones
    for b in bones:
        b.custom_shape_translation[2] = value


def GetShapeTypes(self, context):
    shape_objs = [
        obj for obj in bpy.data.objects
        if obj.type in {'CURVE', 'MESH'}
    ]
    items = []
    for i, obj in enumerate(sorted(shape_objs, key=lambda o: o.name)):
        items.append((obj.name, obj.name, "", i))
    return items

def UpdateBoneShapeType(self,context):
    arm = context.active_object
    value = self.shapeTypes
    bones = bpy.context.selected_pose_bones
    for b in bones:
        b.custom_shape = bpy.data.objects[value]

    

class Properties(bpy.types.PropertyGroup):
    shapeRotX: bpy.props.FloatProperty(name="X",description="Control bone shape size",default=0.0,update=UpdateBoneShapeRotX)
    shapeRotY: bpy.props.FloatProperty(name="Y",description="Control bone shape size",default=0.0,update=UpdateBoneShapeRotY)
    shapeRotZ: bpy.props.FloatProperty(name="Z",description="Control bone shape size",default=0.0,update=UpdateBoneShapeRotZ)
    shapeTranslateX: bpy.props.FloatProperty(name="X",description="Control bone shape size",default=0.0,update=UpdateBoneShapeTranslateX)
    shapeTranslateY: bpy.props.FloatProperty(name="Y",description="Control bone shape size",default=0.0,update=UpdateBoneShapeTranslateY)
    shapeTranslateZ: bpy.props.FloatProperty(name="Z",description="Control bone shape size",default=0.0,update=UpdateBoneShapeTranslateZ)
    shapeScale: bpy.props.FloatProperty(name="All",description="Control bone shape size",min=0.0,default=1.0,update=UpdateBoneShapeScale)
    shapeScaleX: bpy.props.FloatProperty(name="X",description="Control bone shape size",min=0.0,default=1.0,update=UpdateBoneShapeScaleX)
    shapeScaleY: bpy.props.FloatProperty(name="Y",description="Control bone shape size",min=0.0,default=1.0,update=UpdateBoneShapeScaleY)
    shapeScaleZ: bpy.props.FloatProperty(name="Z",description="Control bone shape size",min=0.0,default=1.0,update=UpdateBoneShapeScaleZ)
    shapeTypes: bpy.props.EnumProperty(
        name="Custom Shape",
        items=GetShapeTypes,
        update=UpdateBoneShapeType,
    )

class CopyBoneShape_OP(bpy.types.Operator):
    bl_idname = "bone_shape.copy"
    bl_label = "Do Something"
    def execute(self, context):
        CopyBoneShape(context)
        return {'FINISHED'}

class SetShapeColor_OP(bpy.types.Operator):
    bl_idname = "bone_shape.set_color"
    bl_label = "Do Something"
    color: bpy.props.StringProperty()
    def execute(self, context):
        props = context.scene.props
        arm = context.active_object
        bones = bpy.context.selected_pose_bones
        for bone in bones:
            bone.color.palette = self.color
        return {'FINISHED'}

class GetCurrentShapeRotate_OP(bpy.types.Operator):
    bl_idname = "bone_shape.current_rotate"
    bl_label = "Do Something"
    def execute(self, context):
        props = context.scene.props
        arm = context.active_object
        bones = bpy.context.selected_pose_bones
        if bones:
            bone = bones[0]
            props.shapeRotX = math.degrees(bone.custom_shape_rotation_euler[0])
            props.shapeRotY = math.degrees(bone.custom_shape_rotation_euler[1])
            props.shapeRotZ = math.degrees(bone.custom_shape_rotation_euler[2])
        return {'FINISHED'}

class GetCurrentShapeTranslate_OP(bpy.types.Operator):
    bl_idname = "bone_shape.current_translate"
    bl_label = "Do Something"
    def execute(self, context):
        props = context.scene.props
        arm = context.active_object
        bones = bpy.context.selected_pose_bones
        if bones:
            bone = bones[0]
            props.shapeTranslateX = bone.custom_shape_translation[0]
            props.shapeTranslateY = bone.custom_shape_translation[1]
            props.shapeTranslateZ = bone.custom_shape_translation[2]
        return {'FINISHED'}

class GetCurrentShapeScale_OP(bpy.types.Operator):
    bl_idname = "bone_shape.current_scale"
    bl_label = "Do Something"
    def execute(self, context):
        props = context.scene.props
        arm = context.active_object
        bones = bpy.context.selected_pose_bones
        if bones:
            bone = bones[0]
            props.shapeScaleX = bone.custom_shape_scale_xyz[0]
            props.shapeScaleY = bone.custom_shape_scale_xyz[1]
            props.shapeScaleZ = bone.custom_shape_scale_xyz[2]
        return {'FINISHED'}

class GetCurrentShapeTransform_OP(bpy.types.Operator):
    bl_idname = "bone_shape.current_transform"
    bl_label = "Do Something"
    def execute(self, context):
        props = context.scene.props
        arm = context.active_object
        bones = bpy.context.selected_pose_bones
        if bones:
            bone = bones[0]
            props.shapeRotX = math.degrees(bone.custom_shape_rotation_euler[0])
            props.shapeRotY = math.degrees(bone.custom_shape_rotation_euler[1])
            props.shapeRotZ = math.degrees(bone.custom_shape_rotation_euler[2])
            props.shapeTranslateX = bone.custom_shape_translation[0]
            props.shapeTranslateY = bone.custom_shape_translation[1]
            props.shapeTranslateZ = bone.custom_shape_translation[2]
            props.shapeScaleX = bone.custom_shape_scale_xyz[0]
            props.shapeScaleY = bone.custom_shape_scale_xyz[1]
            props.shapeScaleZ = bone.custom_shape_scale_xyz[2]
        return {'FINISHED'}


class AutoLoadShape_OP(bpy.types.Operator):
    bl_idname = "bone_shape.auto_load_shape"
    bl_label = "Do Something"
    def execute(self, context):

        def SetShape(bone,data,*arr):
            bone.use_custom_shape_bone_size = False
            for attr in data:
                if attr == "custom_shape":
                    value = bpy.data.objects[data[attr]]
                    setattr(bone, attr,value)
                if attr == "scale":
                    for i in range(0,3):
                        bone.custom_shape_scale_xyz[i] = data[attr][i]

                #if attr == "rotate":[90,0,0],

        shapeData = {
            "Root":{"custom_shape":"WGT_transform","scale":[1,1,1],"rotate":[90,0,0]},
            "WaistControl":{"custom_shape":"WGT_waist_control","scale":[1,1,1],"rotate":[90,0,0]},
            "Root_extra":{"custom_shape":"CtrlShape_Square","scale":[1,1,1],"rotate":[0,0,0]},
        }
        props = context.scene.props
        arm = context.active_object


        allExcept = []

        defaultExcept = []
        allExcept.extend(defaultExcept)

        IKData = NLTA_Amature.ArmGetIKData(arm)
        IKExcept = []
        for i in IKData:
            IKExcept.extend(i["bones"])
        allExcept.extend(IKExcept)
        
        bones = bpy.context.object.pose.bones
        for bone in bones:
            if bone.name not in allExcept:
                if bone.name in shapeData:
                    attrData = shapeData[bone.name]
                    SetShape(bone,attrData)
                else:
                    if bone.name.endswith("_IKFK"):
                        defaultShape = {
                            "custom_shape":"CtrlShape_Cross",
                            "scale":[.8,.8,.8],
                        }
                        SetShape(bone,defaultShape)
                    else:
                        defaultShape = {
                            "custom_shape":"WGT_waist_control",
                            "scale":[.25,.25,.25],
                        }
                        SetShape(bone,defaultShape)
        
        return {'FINISHED'}

class CreateShapes_OP(bpy.types.Operator):
    bl_idname = "bone_shape.create_shapes"
    bl_label = "Do Something"
    def execute(self, context):
        CreateShapes()
        return {'FINISHED'}

class ExportShapes_OP(bpy.types.Operator):
    bl_idname = "bone_shape.export_shapes"
    bl_label = "Do Something"
    def execute(self, context):
        ExportShapesData(context)
        return {'FINISHED'}

class ImportShapes_OP(bpy.types.Operator):
    bl_idname = "bone_shape.import_shapes"
    bl_label = "Do Something"
    def execute(self, context):
        ImportShapesData(context)
        return {'FINISHED'}

class MainPanel_PN(bpy.types.Panel):
    bl_label = "Custom Shape Tool"
    bl_idname = "CustomShape_PN"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'CusTom Shape'
    def draw(self, context):
        props = context.scene.props
        layout = self.layout
        layout.scale_y = 1.2
        layout.scale_x = 1
        layout.split(factor=0.1)

        box = layout.box()
        box.label(text="Shape Type")
        box.prop(props,"shapeTypes",text="")

        box = layout.box()
        row = box.row()
        row.label(text="Rotate")
        row.operator("bone_shape.current_rotate", text="Current")
        row = box.row()
        row.prop(props,"shapeRotX")
        row.prop(props,"shapeRotY")
        row.prop(props,"shapeRotZ")

        box = layout.box()
        row = box.row()
        row.label(text="Translate")
        row.operator("bone_shape.current_translate", text="Current")
        row = box.row()
        row.prop(props,"shapeTranslateX")
        row.prop(props,"shapeTranslateY")
        row.prop(props,"shapeTranslateZ")

        
        box = layout.box()
        row = box.row()
        row.label(text="Scale")
        row.operator("bone_shape.current_scale", text="Current")
        row.prop(props,"shapeScale")
        row = box.row()
        row.prop(props,"shapeScaleX")
        row.prop(props,"shapeScaleY")
        row.prop(props,"shapeScaleZ")


        box = layout.box()
        box.label(text="Color")
        row = box.row()
        op = row.operator("bone_shape.set_color", text="Red")
        op.color = "THEME01"
        op = row.operator("bone_shape.set_color", text="Blue")
        op.color = "THEME04"
        op = row.operator("bone_shape.set_color", text="Green")
        op.color = "THEME03"
        op = row.operator("bone_shape.set_color", text="Yellow")
        op.color = "THEME09"
        row = box.row()
        op = row.operator("bone_shape.set_color", text="Pink")
        op.color = "THEME05"
        op = row.operator("bone_shape.set_color", text="Purple")
        op.color = "THEME11"
        op = row.operator("bone_shape.set_color", text="White")
        op.color = "THEME13"
        op = row.operator("bone_shape.set_color", text="Organe")
        op.color = "THEME02"        

        row = layout.row()
        row.operator("bone_shape.create_shapes", text="Add Shape")
        row.operator("bone_shape.auto_load_shape", text="Auto Load Shape")
        row.operator("bone_shape.copy", text="CopyShape")        

        row = layout.row()
        row.operator("bone_shape.export_shapes", text="Export Shapes")
        row.operator("bone_shape.import_shapes", text="Import Shapes")
classes = (
    MainPanel_PN,
    Properties,
    CopyBoneShape_OP,    
    GetCurrentShapeRotate_OP,
    GetCurrentShapeTranslate_OP,
    GetCurrentShapeScale_OP,
    GetCurrentShapeTransform_OP,
    SetShapeColor_OP,
    AutoLoadShape_OP,
    CreateShapes_OP,
    ExportShapes_OP,
    ImportShapes_OP,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.props = bpy.props.PointerProperty(type=Properties)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()


import bpy
import importlib
from mathutils import Matrix,Vector
from math import radians
from . import NLTA_General
importlib.reload(NLTA_General)

### ARMATURE
def GetArm(arm):
    if isinstance(arm, str):
        obj = bpy.data.objects.get(arm)
        if obj and obj.type == 'ARMATURE':
            return(obj)
    if isinstance(arm, bpy.types.Object) and arm.type == 'ARMATURE':
        return(arm)
    return(None)

def GetPoseBone(arm,bone):
    arm = GetArm(arm)
    obj = None
    if isinstance(bone, str):
        boneCheck = arm.pose.bones.get(bone)
        if boneCheck:
            obj = arm.pose.bones[bone]
        else:
            return(None)
    else:
        obj = bone
    return(obj)

def GetEditBone(arm,bone):
    arm = GetArm(arm)
    obj = None
    if isinstance(bone, str):
        boneCheck = arm.data.edit_bones.get(bone)
        if boneCheck:
            obj = arm.data.edit_bones[bone]
        else:
            return(None)
    else:
        obj = bone
    return(obj)

def Duplicate(sourceName,duplicateName):    
    armOrg = bpy.data.objects[sourceName]    
    before = set(bpy.context.scene.objects)
    bpy.ops.object.duplicate_move()
    after = set(bpy.context.scene.objects)
    armDup = list(after - before)[0]
    armDup.name = duplicateName
    collection = bpy.context.scene.collection
    collection.objects.link(armDup)    
    return(armDup)

def ApplyTransform(obj):
    oldState = NLTA_General.GetState()    
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.select_all(action='DESELECT')    
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)    
    NLTA_General.BackState(oldState)

def ModifyParent(arm):
    bones = BoneGetAll(arm)
    for bone in bones:
        children = BoneGetChildren(arm,bone)
        if children!=None and len(children)==1:
            child = children[0]
            BoneParentConnect(arm,child)
def MatchArm(data):
    armSource = data["source"]
    armTarget = data["target"]
    exceptBones = data["exceptBones"] if "exceptBones" in data else []
    onlyBones = data["onlyBones"] if "onlyBones" in data else [bone.name for bone in armTarget.pose.bones]
    endWith = data["endWith"] if "endWith" in data else ""
    startWith = data["startWith"] if "startWith" in data else ""
    for bone in armTarget.pose.bones.items():#arrayBones
        boneTargetName = bone[0]
        boneTargetNode = bone[1]
        if (boneTargetName not in exceptBones) and (boneTargetName in onlyBones):
            boneTargetNameOrigin = boneTargetName
            boneSourceName =boneTargetName
            boneSourceName = startWith + boneSourceName + endWith
            originBoneCheck = armSource.pose.bones.get(boneSourceName)
            if originBoneCheck:
                boneSourceNode = armSource.pose.bones[boneSourceName]
                boneSourceMatrix = armSource.matrix_world @ boneSourceNode.matrix
                boneTargetMatrix = armTarget.matrix_world.inverted() @ boneSourceMatrix
                boneTargetNode.matrix = boneTargetMatrix
                bpy.context.view_layer.update()

def ArmGetOwnerBoneMatrix(data):
    arm = GetArm(data["arm"])
    boneName = data["boneName"]
    boneNode = arm.pose.bones[boneName]
    boneMaxtrix = arm.matrix_world @  boneNode.matrix
    returnMatrix = arm.matrix_world.inverted() @ boneMaxtrix
    return(returnMatrix)

def ArmMatchBones(data):
    bpy.context.view_layer.update()
    armSource = data["srcArm"]
    armTarget = data["desArm"]   
    boneSourceName = data["srcBone"]
    boneTargetName = data["desBone"]
    boneSourceNode = armSource.pose.bones[boneSourceName]
    boneTargetNode = armTarget.pose.bones[boneTargetName]
    boneSourceMatrix = armSource.matrix_world @ boneSourceNode.matrix
    boneTargetMatrix = armTarget.matrix_world.inverted() @ boneSourceMatrix
    boneTargetNode.matrix = boneTargetMatrix
    bpy.context.view_layer.update()

"""
def ArmMatchBones(data):
    bpy.context.view_layer.update()
    print("----ffff-")
    arm = data["arm"]
    src = data["srcBone"]
    tgt = data["desBone"]
    src_p = arm.pose.bones[src]
    tgt_p = arm.pose.bones[tgt]
    # match world matrix
    world_src = arm.matrix_world @ src_p.matrix
    tgt_p.matrix = arm.matrix_world.inverted() @ world_src
    bpy.context.view_layer.update()
"""


def SyncModify(data):
    arm = GetArm(data["target"])
    NLTA_General.ModeEdit(arm)
    if "endWith" in data:
        endWith = data["endWith"] 
    else:
        endWith = ""
    if "startWith" in data:
        startWith = data["startWith"]
    else:
        startWith = ""

    if "poles" in data:
        poles = data["poles"]
    else:
        poles = []
    if "parentExtra" in data:
        for key in data["parentExtra"]:
            if key not in poles:
                NLTA_General.ModeEdit(arm)                
                childBone = GetEditBone(arm,key)
                parentBone = GetEditBone(arm,data["parentExtra"][key])
                if childBone and parentBone:
                    childBone.parent = parentBone
    arm = GetArm(data["target"])
    NLTA_General.ModePose(arm)



    for bone in arm.pose.bones.items():
        boneName = bone[0]
        if endWith in boneName:#(endswith in boneName)
            targetBone = bone[1]
            targetBoneName = boneName
            sourceBoneName = targetBoneName.replace(startWith,"")
            sourceBoneName = sourceBoneName.replace(endWith,"")
            if "parentExtra" in data and targetBoneName in data["parentExtra"]:
                    sourceBoneName = data["parentExtra"][targetBoneName]

            if arm.pose.bones.get(targetBoneName) and arm.pose.bones.get(sourceBoneName):
                axisMatch = BoneFindMatchingAxes(arm,arm,sourceBoneName,targetBoneName)
                pattern = {"X":0,"Y":1,"Z":2}
                for key in axisMatch:
                    fcurve = targetBone.driver_add("scale", pattern[axisMatch[key]["axis"]])
                    driver = fcurve.driver
                    driver.type = 'SCRIPTED'
                    var = driver.variables.new()
                    var.name = "rot"
                    var.type = 'TRANSFORMS'
                    t = var.targets[0]
                    t.id = arm
                    t.bone_target = sourceBoneName
                    t.transform_type = 'SCALE_'+key
                    t.transform_space = 'LOCAL_SPACE'
                    driver.expression = "rot"


    NLTA_General.ModeObject(arm)
        

def SyncArm(data):
    armSource = GetArm(data["source"])
    armTarget = GetArm(data["target"])

    bpy.context.view_layer.objects.active = armSource
    bpy.ops.object.mode_set(mode='EDIT')
    sourceEditBones = armSource.data.edit_bones
    sourceBones = [b.name for b in armSource.data.bones]    

    bpy.context.view_layer.objects.active = armTarget
    bpy.ops.object.mode_set(mode='EDIT')
    targetEditBones = armTarget.data.edit_bones
    targetBones = [b.name for b in armTarget.data.bones]

    bpy.context.view_layer.objects.active = armTarget


    if "endWith" in data:
        endWith = data["endWith"] 
    else:
        endWith = ""
    if "startWith" in data:
        startWith = data["startWith"]
    else:
        startWith = ""

    for sourceBone in sourceBones:
        sourceBoneNode = sourceEditBones[sourceBone]
        targetBoneName = startWith + sourceBone + endWith
        boneNew = targetEditBones.new(targetBoneName)
        boneNew.head = sourceBoneNode.head
        boneNew.tail = sourceBoneNode.tail
        boneNew.roll = sourceBoneNode.roll
        if sourceBone in targetBones:            
            boneNew.parent = targetEditBones[sourceBone]
    bpy.ops.object.mode_set(mode='OBJECT')
    SyncModify(data)

def AnimationRange(armature):
    armature = GetArm(armature)
    ad = armature.animation_data
    if not ad or not ad.action:
        return None
    action = ad.action
    frameMin = float("inf")
    frameMax = float("-inf")
    for curve in action.fcurves:
        for key in curve.keyframe_points:
            frame = key.co.x
            frameMin = min(frameMin, frame)
            frameMax = max(frameMax, frame)
    if frameMin == float("inf"):
        return None
    return {"min": int(frameMin), "max": int(frameMax)}

def SetInheritScale(arm,scaleType):
    arm = GetArm(arm)
    NLTA_General.ModeEdit(arm)
    for bone in arm.data.edit_bones.items():
        boneNode = bone[1]
        boneNode.inherit_scale = scaleType
    NLTA_General.ModeObject(arm)

def SelectBones(arm,bonesArray):
    arm = GetArm(arm)
    NLTA_General.ModePose(arm)
    for pb in arm.data.bones:
        pb.select = False
    for boneName in bonesArray:
        arm.data.bones[boneName].select = True

def ArmUnconnectBones(data):
    arm = data["arm"]
    arm = GetArm(arm)
    if "except" in data:
        exceptBones = data["except"]
    else:
        exceptBones = []
    state = NLTA_General.GetState()
    NLTA_General.ModeEdit(arm)
    for bone in arm.data.edit_bones:
        if bone.name not in exceptBones:
            bone.use_connect = False
    NLTA_General.BackState(state)

def ArmRemoveFirstKeys(arm,count):
    arm = GetArm(arm)
    ad = arm.animation_data
    if not ad or not ad.action:
        return
    action = ad.action
    for fc in action.fcurves:
        kps = fc.keyframe_points
        stt = 0
        for kp in kps:
            if stt < count:
                kps.remove(kp)
                break
            stt += 1

def ArmAddKeyframe(data):
    def Add(arm,boneName,frame):
        pb = GetPoseBone(arm,boneName)
        if pb:
            pb.keyframe_insert(data_path="location", frame=frame)
            if pb.rotation_mode == 'QUATERNION':
                pb.keyframe_insert(data_path="rotation_quaternion", frame=frame)
            else:
                pb.keyframe_insert(data_path="rotation_euler", frame=frame)
            pb.keyframe_insert(data_path="scale", frame=frame)

    arm = GetArm(data["arm"])
    frame = data["frame"]    
    endWith = data["endWith"] if "endWith" in data else ""
    startWith = data["startWith"] if "startWith" in data else ""
    notInName = data["notInName"] if "notInName" in data else ""
    exceptBones = data["exceptBones"] if "exceptBones" in data else []
    onlyBones = data["onlyBones"] if "onlyBones" in data else [bone.name for bone in arm.pose.bones]    
    NLTA_General.ModePose(arm)
    for bone in arm.pose.bones.items():
        boneName = bone[0]
        if (boneName not in exceptBones) and (boneName in onlyBones) and boneName.endswith(endWith) and boneName.startswith(startWith) :
            if notInName == "":
                Add(arm,boneName,frame)   
            else:
                if notInName not in boneName:
                    Add(arm,boneName,frame)   



def ArmGetIK(arm):
    arm = GetArm(arm)
    NLTA_General.ModePose(arm)
    ikData = {
        "bone":[],
        "constraint":[],
        "target":[],
        "subtarget":[],
        "chain_count":[],
        "pole_target":[],
        "pole_subtarget":[],
        "pole_angle":[],
        "use_tail":[],
        "weight":[],
        "kneeChild":{

        },
        "footChildren":{

        }
    }
    for pb in arm.pose.bones:
        for c in pb.constraints:
            if c.type == 'IK':
                ikData["bone"].append(pb.name)
                ikData["constraint"].append(c.name)
                ikData["target"].append(c.target.name if c.target else None)
                ikData["subtarget"].append(c.subtarget)
                ikData["chain_count"].append(c.chain_count)
                ikData["pole_target"].append(c.pole_target.name if c.pole_target else None)
                ikData["pole_subtarget"].append(c.pole_subtarget)
                ikData["pole_angle"].append(c.pole_angle)
                ikData["use_tail"].append(c.use_tail)
                ikData["weight"].append(c.influence)
    return(ikData)

def ArmGetIKData(arm):
    returnData = []
    for pb in arm.pose.bones:
        for c in pb.constraints:
            if c.type == "IK":
                returnData.append({
                    "boneName":pb.name,
                    "constraint":c.name,
                    "constraintNode":c,
                    "target":c.target.name if c.target else None,
                    "subtarget":c.subtarget,
                    "chain_count":c.chain_count,
                    "pole_target":c.pole_target.name if c.pole_target else None,
                    "pole_subtarget":c.pole_subtarget,
                    "pole_angle":c.pole_angle,
                    "use_tail":c.use_tail,
                    "weight":c.influence,
                    "bones":[pb.name,c.subtarget,c.pole_subtarget],
                })
    return(returnData)

def ArmGetBoneTransformValue(arm):
    returnData = {}
    arm = GetArm(arm)
    NLTA_General.ModePose(arm)
    for pb in arm.pose.bones:
        returnData[pb.name] = BoneGetTransformValue(arm,pb)
    return(returnData)

"""
def ArmGetPoleMatrix(data):
    bpy.context.view_layer.update()
    armature = GetArm(data["arm"])
    boneA = data["boneA"]
    boneB = data["boneB"]
    boneC = data["boneC"]
    offset_y = data.get("offset",1)
    pbones = armature.pose.bones
    A = armature.matrix_world @ pbones[boneA].head
    B = armature.matrix_world @ pbones[boneB].head
    C = armature.matrix_world @ pbones[boneC].head
    AB = (B - A).normalized()
    BC = (C - B).normalized()
    normal = AB.cross(BC)
    if normal.length < 1e-6:
        raise ValueError("3 bones are collinear!")

    normal.normalize()

    polePos = (A + C) * 0.5

    z_axis = (C - A).normalized()
    x_axis = normal
    y_axis = z_axis.cross(x_axis).normalized()
    x_axis = y_axis.cross(z_axis).normalized()

    mat = Matrix((
        (x_axis.x, y_axis.x, z_axis.x, polePos.x),
        (x_axis.y, y_axis.y, z_axis.y, polePos.y),
        (x_axis.z, y_axis.z, z_axis.z, polePos.z),
        (0,        0,        0,        1)
    ))

    mat.translation += mat.col[1].to_3d() * offset_y
    
    if "target" in data:
        pb = armature.pose.bones[data["target"]]
        pb.matrix = armature.matrix_world.inverted() @ mat
    bpy.context.view_layer.update()
    return mat
"""
"""
def ArmGetPoleMatrix(data):
    bpy.context.view_layer.update()

    armature = GetArm(data["arm"])
    boneA = data["boneA"]
    boneB = data["boneB"]
    boneC = data["boneC"]
    offset_y = data.get("offset", 1)
    rot = data.get("rot",0)

    pbones = armature.pose.bones

    A = armature.matrix_world @ pbones[boneA].head
    B = armature.matrix_world @ pbones[boneB].head
    C = armature.matrix_world @ pbones[boneC].head

    AB = (B - A).normalized()
    BC = (C - B).normalized()

    normal = AB.cross(BC)
    if normal.length < 1e-6:
        raise ValueError("3 bones are collinear!")

    normal.normalize()

    polePos = (A + C) * 0.5

    z_axis = (C - A).normalized()
    x_axis = normal
    y_axis = z_axis.cross(x_axis).normalized()
    x_axis = y_axis.cross(z_axis).normalized()

    mat = Matrix((
        (x_axis.x, y_axis.x, z_axis.x, polePos.x),
        (x_axis.y, y_axis.y, z_axis.y, polePos.y),
        (x_axis.z, y_axis.z, z_axis.z, polePos.z),
        (0,        0,        0,        1)
    ))
    rot_z = Matrix.Rotation(radians(rot), 4, 'Z')
    mat = mat @ rot_z   # local rotation

    # offset theo local Y
    mat.translation += mat.col[1].to_3d() * offset_y

    # 🎯 APPLY CHỈ TRANSLATION
    if "target" in data:
        pb = armature.pose.bones[data["target"]]

        # target matrix trong armature space
        target_matrix = armature.matrix_world.inverted() @ mat

        # 👉 giữ nguyên rotation + scale
        new_matrix = pb.matrix.copy()
        new_matrix.translation = target_matrix.to_translation()

        pb.matrix = new_matrix

    bpy.context.view_layer.update()
    return mat
"""


def ArmGetPoleMatrix(data):
    bpy.context.view_layer.update()
    offset_y = data.get("offset", 1.0)
    rot = data.get("rot", 0.0)

    if "vecA" in data:
        A = data["vecA"]
        B = data["vecB"]
        C = data["vecC"]
        armature = data.get("arm", None)
    else:
        armature = GetArm(data["arm"])
        pbones = armature.pose.bones
        A = armature.matrix_world @ pbones[data["boneA"]].head
        B = armature.matrix_world @ pbones[data["boneB"]].head
        C = armature.matrix_world @ pbones[data["boneC"]].head

    AB = (B - A).normalized()
    BC = (C - B).normalized()

    normal = AB.cross(BC)
    if normal.length < 1e-6:
        raise ValueError("3 points are collinear!")

    normal.normalize()
    polePos = (A + C) * 0.5

    z_axis = (C - A).normalized()
    x_axis = normal
    y_axis = z_axis.cross(x_axis).normalized()
    x_axis = y_axis.cross(z_axis).normalized()

    mat = Matrix((
        (x_axis.x, y_axis.x, z_axis.x, polePos.x),
        (x_axis.y, y_axis.y, z_axis.y, polePos.y),
        (x_axis.z, y_axis.z, z_axis.z, polePos.z),
        (0,        0,        0,        1)
    ))

    if rot != 0:
        rot_z = Matrix.Rotation(radians(rot), 4, 'Z')
        mat = mat @ rot_z

    mat.translation += mat.col[1].to_3d() * offset_y

    if "target" in data and armature:
        pb = armature.pose.bones.get(data["target"])
        if pb:
            mat_local = armature.convert_space(
                pose_bone=pb,
                matrix=mat,
                from_space='WORLD',
                to_space='POSE'
            )
            new_mat = pb.matrix.copy()
            new_mat.translation = mat_local.to_translation()
            pb.matrix = new_mat
    bpy.context.view_layer.update()
    return mat

def ArmGetPoleMatrixEdit(data):
    armature = GetArm(data["arm"])
    boneA = data["boneA"]
    boneB = data["boneB"]
    boneC = data["boneC"]
    offset_y = data.get("offset", 1.0)
    mode = data.get("mode", "translate")  # 👈 "translate" hoặc "align"
    if not armature:
        raise ValueError("Invalid armature")
    if bpy.context.object.mode != 'EDIT':
        bpy.ops.object.mode_set(mode='EDIT')

    ebones = armature.data.edit_bones
    # World positions
    A = armature.matrix_world @ ebones[boneA].head
    B = armature.matrix_world @ ebones[boneB].head
    C = armature.matrix_world @ ebones[boneC].head
    # Vectors
    AB = (B - A).normalized()
    BC = (C - B).normalized()
    normal = AB.cross(BC)
    if normal.length < 1e-6:
        raise ValueError("3 bones are collinear!")
    normal.normalize()
    polePos = (A + C) * 0.5
    # Axes
    z_axis = (C - A).normalized()
    x_axis = normal
    y_axis = z_axis.cross(x_axis).normalized()
    x_axis = y_axis.cross(z_axis).normalized()

    # Matrix world
    mat = Matrix((
        (x_axis.x, y_axis.x, z_axis.x, polePos.x),
        (x_axis.y, y_axis.y, z_axis.y, polePos.y),
        (x_axis.z, y_axis.z, z_axis.z, polePos.z),
        (0,        0,        0,        1)
    ))

    # Offset theo LOCAL Y
    mat.translation += mat.col[1].to_3d() * offset_y

    # 👉 Apply nếu có target
    print(data)
    if "target" in data:
        eb = ebones[data["target"]]

        # convert world → armature space
        new_head = armature.matrix_world.inverted() @ mat.translation

        if mode == "translate":
            # ✅ chỉ tịnh tiến (giữ nguyên hướng & length)
            delta = new_head - eb.head
            eb.head += delta
            eb.tail += delta

        elif mode == "align":
            # ⚙️ align theo matrix (có thể thay đổi orientation)

            eb.head = new_head

            # direction (convert về local space, loại bỏ scale)
            inv_rot = armature.matrix_world.inverted().to_3x3().normalized()
            direction = inv_rot @ mat.col[2].to_3d()

            length = (eb.tail - eb.head).length
            if length == 0:
                length = 0.1

            eb.tail = eb.head + direction.normalized() * length

            # align roll
            x_axis_local = inv_rot @ mat.col[0].to_3d()
            eb.align_roll(x_axis_local)
    return mat


### BONE 
def BoneGetAll(arm):
    returnData = []
    bones = arm.data.bones
    for bone in bones:
        returnData.append(bone.name)
    return(returnData)

def BoneGetChildren(arm,boneName):
    returnArray = []
    arm = GetArm(arm)
    bone = GetPoseBone(arm,boneName)
    children = bone.children
    if children:
        for child in children:
            returnArray.append(child.name)
        return(returnArray)
    return(None)

def BoneParent(data):
    arm = GetArm(data["arm"])
    parentName = data["parentName"]
    childName = data["childName"]
    connect = data["connect"]
    NLTA_General.ModeEdit(arm)
    child = arm.data.edit_bones[childName]
    parent = arm.data.edit_bones[parentName]    
    child.parent = parent
    child.use_connect = connect
    
    
def BoneParentConnect(arm,boneName):
    state = NLTA_General.GetState()
    NLTA_General.ModeEdit(arm)
    bone = arm.data.edit_bones[boneName]
    if bone.parent: 
        bone.use_connect = True    
    NLTA_General.BackState(state)
    
def BoneUnParent(arm,boneName):
    state = GetState()    
    NLTA_General.ModeEdit(arm)
    child = arm.data.edit_bones[boneName]
    child.parent = None    
    NLTA_General.BackState(state)

def BoneSelected(arm):
    returnData = []
    selectedBones =  None
    if arm.mode == 'EDIT':
        selectedBones = [b for b in arm.data.edit_bones if b.select]
    elif arm.mode == 'POSE':
        selectedBones = [b for b in arm.pose.bones if b.bone.select]
    if selectedBones:
        for bone in selectedBones:
            returnData.append(bone.name)
    return(returnData)

def BoneSetPos(armName,boneName,pos,*arr):
    arm = bpy.data.objects[armName]
    pb = arm.pose.bones[boneName]
    boneLocalPos = arm.matrix_world.inverted() @ v_world
    pb.location = boneLocalPose


def BoneMatchScale(armSource,armTarget,boneSource,boneTarget):
    armSource = GetArm(armSource)
    armTarget = GetArm(armTarget)
    axiss = [0,1,2]
    pbSource = armSource.pose.bones.get(boneSource)
    pbTarget = armTarget.pose.bones.get(boneTarget)
    if pbSource and pbTarget:
        for axis in axiss:
            sourceScaleValue = pbSource.scale[axis]
            pbTarget.scale[axis] = sourceScaleValue

def BoneGetScaleKeyframe(arm,boneName):
    arm = GetArm(arm)
    ad = arm.animation_data
    if not ad or not ad.action:
        return None
    action = ad.action

    result = {"X": [], "Y": [], "Z": []}
    for fc in action.fcurves:
        print(fc.data_path)
        if fc.data_path == f'scale':
            axis = "XYZ"[fc.array_index]
            print(axis)
            for kp in fc.keyframe_points:
                frame = kp.co.x
                value = kp.co.y
                result[axis].append((frame, value))
    return(result)

def BoneGetWorldAxes(arm, boneName):
    arm = GetArm(arm)
    pb = GetPoseBone(arm,boneName)
    m = arm.matrix_world @ pb.matrix
    xAxis = m.to_3x3() @ Vector((1, 0, 0))
    yAxis = m.to_3x3() @ Vector((0, 1, 0))
    zAxis = m.to_3x3() @ Vector((0, 0, 1))
    return {
        "X": xAxis.normalized(),
        "Y": yAxis.normalized(),
        "Z": zAxis.normalized(),
    }

def BoneResolveAxisMapping(dotResults, threshold=0.9):    
    dotResults = sorted(dotResults, key=lambda x: abs(x[2]), reverse=True)
    mapping = {}
    usedA = set()
    used_b = set()
    for aAxis, bAxis, dot in dotResults:
        if abs(dot) < threshold:
            continue
        if aAxis in usedA or bAxis in used_b:
            continue
        mapping[aAxis] = {
            "axis": bAxis,
            "sign": 1 if dot > 0 else -1
        }
        usedA.add(aAxis)
        used_b.add(bAxis)
        if len(mapping) == 3:
            break
    return mapping

def BoneFindMatchingAxes(armA,armB,boneA,boneB):
    axesA = BoneGetWorldAxes(armA, boneA)
    axesB = BoneGetWorldAxes(armB, boneB)
    matches = []
    for aName, aVec in axesA.items():
        for bName, bVec in axesB.items():
            dot = aVec.dot(bVec)
            matches.append((aName, bName, dot))
    matches.sort(key=lambda x: abs(x[2]), reverse=True)    
    return(BoneResolveAxisMapping(matches))

def BoneSmartMatchScale(armSource,armTarget,boneSource,boneTarget):
    pattern = {"X":0,"Y":1,"Z":2}    
    pbSource = armSource.pose.bones[boneSource]
    pbTarget = armTarget.pose.bones[boneTarget]
    axisMatch = BoneFindMatchingAxes(armSource,armTarget,boneSource,boneTarget)
    for axis in axisMatch:
        sourceAxis = pattern[axis]
        targetAxis = pattern[axisMatch[axis]["axis"]]
        sourceScaleValue = pbSource.scale[sourceAxis]
        pbTarget.scale[targetAxis] = sourceScaleValue

def BoneGetScaleValues(arm,bone):
    arm = GetArm(arm)
    pb = GetPoseBone(arm,bone)
    animationRange = AnimationRange(arm)    
    dataReturn = {
        "sx":{},
        "sy":{},
        "sz":{},
    }
    for i in range(animationRange['min'],animationRange['max']):
        dataReturn["sx"][str(i)] = pb.scale[0]
        dataReturn["sy"][str(i)] = pb.scale[1]
        dataReturn["sz"][str(i)] = pb.scale[2]
    return(dataReturn)


def BoneDeleteKeyframe(arm,boneName,type):
    arm = GetArm(arm)
    pb = GetPoseBone(arm,boneName)
    if pb:
        armData = arm.animation_data
        if not armData or not armData.action:
            return()
        action = armData.action
        if type == "rotation":
            paths = [
                f'pose.bones["{boneName}"].rotation_euler',
                f'pose.bones["{boneName}"].rotation_quaternion',
                f'pose.bones["{boneName}"].rotation_axis_angle',
            ]
        elif type == "location":
            paths = [
                f'pose.bones["{boneName}"].location',
            ]
        for fc in list(action.fcurves):
            if fc.data_path in paths:
                action.fcurves.remove(fc)
        
        if type == "rotation":
            pb.rotation_quaternion[0] = 1
            pb.rotation_quaternion[1] = 0
            pb.rotation_quaternion[2] = 0
            pb.rotation_quaternion[3] = 0
        elif type == "location":
            pb.location[0] = 0
            pb.location[1] = 0
            pb.location[2] = 0

def BoneGetChildConnect(arm,bone):
    state = NLTA_General.GetState()

    NLTA_General.ModeEdit(arm)
    arm = GetArm(arm)
    parent = GetEditBone(arm,bone)    
    ebones = arm.data.edit_bones
    connected_children = [
        b for b in ebones
        if b.parent == parent and b.use_connect
    ]
    NLTA_General.BackState(state)
    return([b.name for b in connected_children])

def BoneGetTransformValue(arm,bone):
    arm = GetArm(arm)
    pb = GetPoseBone(arm,bone)

    loc = pb.location
    rot_mode = pb.rotation_mode
    if rot_mode == 'QUATERNION':
        rot = pb.rotation_quaternion
    elif rot_mode == 'AXIS_ANGLE':
        rot = pb.rotation_axis_angle
    else:  # 'XYZ', 'XZY', ...
        rot = pb.rotation_euler
    scale = pb.scale
    return({
        "location":loc,
        "rotation":rot,
        "scale":scale,
    })

def BoneSetTransformValue(data):
    arm = data["arm"]
    bone =data["bone"]
    transform = data["transform"]
    arm = GetArm(arm)
    pb = GetPoseBone(arn,bone)
    pb.location = transform["location"]
    #pb.rotation_mode = 'XYZ'
    #pb.rotation_mode = 'QUATERNION'
    if len(transform["rotation"]) == 3:
        pb.rotation_euler = transform["rotation"]
    else:
        pb.rotation_quaternion = transform["rotation"]
    pb.scale = transform["scale"]

def BoneCreateOffsetGrp(data,*arr):
    arm = GetArm(data["arm"])    
    boneName = data["boneName"]
    offsetName = data["offsetName"]
    NLTA_General.ModeEdit(arm)    
    ebones = arm.data.edit_bones
    bone = ebones.get(boneName)
    if not bone:
        return
    parent = bone.parent
    newBone = ebones.new(offsetName)
    newBone.head = bone.head
    newBone.tail = bone.tail
    newBone.roll = bone.roll
    newBone.parent = parent
    bone.use_connect = False
    bone.parent = newBone 


def BoneGetParent(data,*arr):
    arm = GetArm(data["arm"])
    boneName = data["boneName"]
    if arm.mode == 'EDIT':
        bone = arm.data.edit_bones.get(boneName)
    elif arm.mode == 'POSE':
        bone = arm.pose.bones.get(boneName)
    else:
        bone = arm.data.bones.get(boneName)
    if bone and bone.parent:
        return(bone.parent.name)

def BoneDuplicate(data,*arr):
    arm = GetArm(data["arm"])
    boneName = data["boneName"]
    boneNewName = data["boneNewName"]
    NLTA_General.ModeEdit(arm)    
    ebones = arm.data.edit_bones
    bone = ebones.get(boneName)
    if not bone:
        return
    parent = bone.parent
    newBone = ebones.new(boneNewName)
    newBone.head = bone.head
    newBone.tail = bone.tail
    newBone.roll = bone.roll

    newBone.hide = data.get("hide",False)
    return(newBone)

def BoneGetChildConstraint(data,*arr):
    arm = GetArm(data["arm"])
    boneName = data["boneName"]
    returnData = []
    for pb in arm.pose.bones:
        for c in pb.constraints:
            if c.subtarget == boneName:
                returnData.append(pb.name) 
    return(returnData)




#### BONE COLLECTION
def ColCreate(armature,name):
    armature.data.collections.new(name)

def ColDelete(armature,name):
    boneCollection = armature.data.collections.get(name)
    if boneCollection:
        armature.data.collections.remove(boneCollection)

def ColGetIndex(arm,name):
    cols = arm.data.collections
    colIndex = None
    for i,col in enumerate(cols):
        if col.name == name:
            return(i)
    return(None)

def ColAssign(arm,colName,bones):
    boneCol = arm.data.collections.get(colName)
    if not boneCol:        
        CreateBoneCollection(arm,colName)
        boneCol = arm.data.collections.get(colName)
    for bone in bones:
        if isinstance(bone, str):
            boneTemp = arm.data.bones.get(bone)
        else:
            boneTemp = bone
        boneCol.assign(boneTemp)

def ColGetAll(armature):
    returnArray = []
    collections = armature.data.collections
    for collection in collections:
        returnArray.append(collection.name)
    return(returnArray)
    
def ColDeleteAll(armature):
    collections = armature.data.collections
    for collection in collections:
        if collection:
            DeleteBoneCollection(armature,collection.name)

def ConstraintArmsBone(armSource,armTarget,boneSourceName,boneTargetName):
    boneTarget = armTarget.pose.bones[boneTargetName]
    con = boneTarget.constraints.new(type='COPY_TRANSFORMS')
    con.target = armSource
    con.subtarget = boneSourceName


        

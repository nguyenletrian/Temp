import bpy

import zipfile
import os
from pathlib import Path

def zipFolder(srcFolder, outputZip):
    srcFolder = Path(srcFolder)
    outputZip = Path(outputZip)

    with zipfile.ZipFile(outputZip, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(srcFolder):
            for file in files:
                filePath = Path(root) / file
                arcname = filePath.relative_to(srcFolder.parent)
                zipf.write(filePath, arcname)
    print(f"Đã tạo file zip: {outputZip}")
    
moduleNames = ["CustomRig","CustomShapeTool","SwitchIKFK"]
for moduleName in moduleNames:
    folderPath = rf"D:\code\BLENDER\\{moduleName}"
    zipPath = rf"D:\code\BLENDER\\{moduleName}.zip"
    zipFolder(folderPath,zipPath)

    is_installed = moduleName in bpy.context.preferences.addons.keys()
    if is_installed:
        bpy.ops.preferences.addon_remove(module=moduleName)
        bpy.ops.preferences.addon_refresh()
        bpy.ops.wm.save_userpref()
    bpy.ops.preferences.addon_install(overwrite=True, filepath=str(zipPath))
    bpy.ops.preferences.addon_refresh()
    bpy.ops.preferences.addon_enable(module=moduleName)
    bpy.ops.wm.save_userpref()


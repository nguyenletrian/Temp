import bpy
import importlib
import json
import os
import math
from math import radians,degrees
from mathutils import Matrix,Vector


def GetArm(arm):
    if isinstance(arm, str):
        obj = bpy.data.objects.get(arm)
        if obj and obj.type == 'ARMATURE':
            return(obj)
    if isinstance(arm, bpy.types.Object) and arm.type == 'ARMATURE':
        return(arm)
    return(None)

def ArmGetIKData(arm):
    returnData = []
    for pb in arm.pose.bones:
        for c in pb.constraints:
            if c.type == "IK":
                returnData.append({
                    "boneName":pb.name,
                    "constraint":c.name,
                    "constraintNode":c,
                    "target":c.target.name if c.target else None,
                    "subtarget":c.subtarget,
                    "chain_count":c.chain_count,
                    "pole_target":c.pole_target.name if c.pole_target else None,
                    "pole_subtarget":c.pole_subtarget,
                    "pole_angle":c.pole_angle,
                    "use_tail":c.use_tail,
                    "weight":c.influence,
                    "bones":[pb.name,c.subtarget,c.pole_subtarget],
                })
    return(returnData)

def ArmGetOwnerBoneMatrix(data):
    arm = GetArm(data["arm"])
    boneName = data["boneName"]
    boneNode = arm.pose.bones[boneName]
    boneMaxtrix = arm.matrix_world @  boneNode.matrix
    returnMatrix = arm.matrix_world.inverted() @ boneMaxtrix
    return(returnMatrix)

def ArmGetConstraint(data):
    arm = GetArm(data["arm"])
    source = data["source"]
    target = data["target"]
    consType = data["type"]
    pb = arm.pose.bones.get(target)
    if not pb:
        return None
    for cons in pb.constraints:
        if cons.type == consType:#'COPY_ROTATION':
            if cons.target == arm and cons.subtarget == source:
                return cons
    return None

def ArmSelectBone(data):
    arm = GetArm(data["arm"])
    bones = data["bones"]
    for pb in arm.pose.bones:
        pb.bone.select = False
    for boneName in bones:
        pb = arm.pose.bones.get(boneName)
        if pb:
            pb.bone.select = True

def BoneSelected(arm):
    returnData = []
    selectedBones =  None
    if arm.mode == 'EDIT':
        selectedBones = [b for b in arm.data.edit_bones if b.select]
    elif arm.mode == 'POSE':
        selectedBones = [b for b in arm.pose.bones if b.bone.select]
    if selectedBones:
        for bone in selectedBones:
            returnData.append(bone.name)
    return(returnData)

def BoneGetParent(data,*arr):
    arm = GetArm(data["arm"])
    boneName = data["boneName"]
    if arm.mode == 'EDIT':
        bone = arm.data.edit_bones.get(boneName)
    elif arm.mode == 'POSE':
        bone = arm.pose.bones.get(boneName)
    else:
        bone = arm.data.bones.get(boneName)
    if bone and bone.parent:
        return(bone.parent.name)

def BoneGetChildConstraint(data,*arr):
    arm = GetArm(data["arm"])
    boneName = data["boneName"]
    returnData = []
    for pb in arm.pose.bones:
        for c in pb.constraints:
            if c.subtarget == boneName:
                returnData.append(pb.name) 
    return(returnData)

def CookIKData(data,*arr):
    arm = GetArm(data["arm"])
    IKData = data["IKData"]
    returnData = {
        "boneName":IKData["boneName"],
        "boneNode":arm.pose.bones[IKData["boneName"]],
        "boneMatrix":ArmGetOwnerBoneMatrix({"arm":arm,"boneName":IKData["boneName"]}).copy(),

        "boneParentName":BoneGetParent({"arm":arm,"boneName":IKData["boneName"]}),
        "boneParentNode":arm.pose.bones[BoneGetParent({"arm":arm,"boneName":IKData["boneName"]})],
        "boneParentMatrix":ArmGetOwnerBoneMatrix({"arm":arm,"boneName":BoneGetParent({"arm":arm,"boneName":IKData["boneName"]})}).copy(),

        "IK":IKData["subtarget"],
        "IKNode":arm.pose.bones[IKData["subtarget"]],
        "IKMatrix":ArmGetOwnerBoneMatrix({"arm":arm,"boneName":IKData["subtarget"]}).copy(),

        "IKRef":IKData["subtarget"]+"_SwitchIKFK_ref",
        "IKRefNode":arm.pose.bones[IKData["subtarget"]+"_SwitchIKFK_ref"],
        "IKRefMatrix":ArmGetOwnerBoneMatrix({"arm":arm,"boneName":IKData["subtarget"]+"_SwitchIKFK_ref"}).copy(),

        "IKSwitchName":(IKData["subtarget"]+"_IKFK").replace(".","_"),
        "IKSwitchNode":arm.pose.bones[(IKData["subtarget"]+"_IKFK").replace(".","_")],
        
        "Pole":IKData["pole_subtarget"],
        "PoleNode":arm.pose.bones[IKData["pole_subtarget"]],
        "PoleMatrix":ArmGetOwnerBoneMatrix({"arm":arm,"boneName":IKData["pole_subtarget"]}).copy()
    }
    boneConstraint = None
    boneConstraints = BoneGetChildConstraint({"arm":arm,"boneName":IKData["boneName"]})
    if len(boneConstraints) == 1:        
        boneConstraint = boneConstraints[0]
    else:
        for boneTemp in boneConstraints:
            if boneTemp in ["RFoot","LFoot"]:
                boneConstraint = boneTemp
                break
    if boneConstraint:
        returnData["boneConstraint"] = boneConstraint
        returnData["boneConstraintNode"] = arm.pose.bones[boneConstraint]
        returnData["boneConstraintMatrix"] = ArmGetOwnerBoneMatrix({"arm":arm,"boneName":boneConstraint}).copy()
        returnData["consRotation"] = ArmGetConstraint({
            "arm":arm,
            "source":IKData["boneName"],
            "target":boneConstraint,
            "type":"COPY_ROTATION",
        })
        returnData["boneConstraintRefName"] = boneConstraint+"_BoneConsSwitchIKFK_ref"
        returnData["boneConstraintRefNode"] = arm.pose.bones[boneConstraint+"_BoneConsSwitchIKFK_ref"]
        returnData["boneConstraintRefMatrix"] = ArmGetOwnerBoneMatrix({"arm":arm,"boneName":boneConstraint+"_BoneConsSwitchIKFK_ref"}).copy()
    return(returnData)

def SwitchIKFK(context,*arr):
    arm = context.active_object
    objs = BoneSelected(arm)
    IKDatas = ArmGetIKData(arm)
    currentFrame = context.scene.frame_current
    for IKData in IKDatas:
        cookData = CookIKData({
            "arm":arm,
            "IKData":IKData,
        })
        for obj in objs:
            if obj in [cookData["boneName"],cookData["boneParentName"],cookData["IK"],cookData["Pole"],cookData["boneConstraint"],cookData["IKSwitchName"]]:
                influence = IKData["constraintNode"].influence
                AddSwitchKey({
                    "arm":arm,
                    "context":context,
                    "group":"switch",
                    "frame":currentFrame - 1,
                })

                if influence == 0:
                    AddSwitchKey({
                        "arm":arm,
                        "context":context,
                        "group":"IKs",
                        "frame":currentFrame - 1,
                    })

                    bpy.context.view_layer.update()
                    cookData["IKSwitchNode"]["Switch"] = 1
                    cookData["IKNode"].matrix = cookData["IKRefMatrix"]
                    cookData["boneConstraintNode"].rotation_euler[0] = 0
                    cookData["boneConstraintNode"].rotation_euler[1] = 0
                    cookData["boneConstraintNode"].rotation_euler[2] = 0                     
                    ArmSelectBone({"arm":arm,"bones":[cookData["IK"]]})
                    AddSwitchKey({
                        "arm":arm,
                        "context":context,
                        "group":"IKs",
                        "frame":currentFrame,
                    })
                    

                else:
                    AddSwitchKey({
                        "arm":arm,
                        "context":context,
                        "group":"FKs",
                        "frame":currentFrame - 1,
                    })
                    bpy.context.view_layer.update()
                    cookData["IKSwitchNode"]["Switch"] = 0
                    cookData["boneParentNode"].matrix =  cookData["boneParentMatrix"]  
                    cookData["boneNode"].matrix = cookData["boneMatrix"]
                    cookData["boneConstraintNode"].matrix= cookData["boneConstraintRefMatrix"]                     
                    ArmSelectBone({"arm":arm,"bones":[cookData["boneConstraint"]]})
                    AddSwitchKey({
                        "arm":arm,
                        "context":context,
                        "group":"FKs",
                        "frame":currentFrame,
                    })
                AddSwitchKey({
                    "arm":arm,
                    "context":context,
                    "group":"switch",
                    "frame":currentFrame,
                })
                
                break


class SwitchIKFK_OP(bpy.types.Operator):
    bl_idname = "ikfk.switch_ikfk"
    bl_label = "Do Something"
    def execute(self, context):
        SwitchIKFK(context)
        return {'FINISHED'}


def AddSwitchKey(data):
    frame = data["frame"]
    context = data["context"]
    group = data["group"]
    arm = GetArm(data["arm"])    
    objs = BoneSelected(arm)
    IKDatas = ArmGetIKData(arm)
    for IKData in IKDatas:
        cookData = CookIKData({"arm":arm,"IKData":IKData})
        for obj in objs:
            if obj in [cookData["boneName"],cookData["boneParentName"],cookData["IK"],cookData["Pole"],cookData["boneConstraint"],cookData["IKSwitchName"]]:
                if group == "switch":
                    targets = [cookData["IKSwitchName"]]
                elif group == "FKs":
                    targets = [cookData["boneName"],cookData["boneParentName"],cookData["boneConstraint"]]
                elif group == "IKs":
                    targets = [cookData["IK"],cookData["Pole"]]
                for target in targets:
                    pb = arm.pose.bones[target]
                    if group == "switch":
                        pb.keyframe_insert(data_path='["Switch"]', frame=frame)
                    else:
                        for path in ["location", "scale"]:
                            pb.keyframe_insert(data_path=path, frame=frame)
                        if pb.rotation_mode == 'QUATERNION':
                            pb.keyframe_insert("rotation_quaternion", frame=frame)
                        else:
                            pb.keyframe_insert("rotation_euler", frame=frame)

class AddSwitchKey_OP(bpy.types.Operator):
    bl_idname = "ikfk.add_key"
    bl_label = "Do Something"
    group: bpy.props.StringProperty()
    def execute(self, context):
        arm = context.active_object
        objs = BoneSelected(arm)
        IKDatas = ArmGetIKData(arm)
        currentFrame = bpy.context.scene.frame_current
        AddSwitchKey({
            "arm":arm,
            "context":context,
            "group":self.group,
            "frame":currentFrame,
        })
        """
        for IKData in IKDatas:
            cookData = CookIKData({"arm":arm,"IKData":IKData})
            for obj in objs:
                if obj in [cookData["boneName"],cookData["boneParentName"],cookData["IK"],cookData["Pole"],cookData["boneConstraint"],cookData["IKSwitchName"]]:
                    if self.group == "switch":
                        targets = [cookData["IKSwitchName"]]
                    elif self.group == "FKs":
                        targets = [cookData["boneName"],cookData["boneParentName"],cookData["boneConstraint"]]
                    elif self.group == "IKs":
                        targets = [cookData["IK"],cookData["Pole"]]

                    for target in targets:
                        pb = arm.pose.bones[target]
                        if self.group == "switch":
                            pb.keyframe_insert(data_path='["Switch"]', frame=currentFrame)
                        else:
                            for path in ["location", "scale"]:
                                pb.keyframe_insert(data_path=path, frame=currentFrame)
                            if pb.rotation_mode == 'QUATERNION':
                                pb.keyframe_insert("rotation_quaternion", frame=currentFrame)
                            else:
                                pb.keyframe_insert("rotation_euler", frame=currentFrame)

                    break
        """
        return {'FINISHED'}

class DeleteSwitchKey_OP(bpy.types.Operator):
    bl_idname = "ikfk.delete_key"
    bl_label = "Do Something"
    group: bpy.props.StringProperty()
    def execute(self, context):
        arm = context.active_object
        objs = BoneSelected(arm)
        IKDatas = ArmGetIKData(arm)
        currentFrame = bpy.context.scene.frame_current
        for IKData in IKDatas:
            cookData = CookIKData({"arm": arm, "IKData": IKData})
            for obj in objs:
                if obj in [cookData["boneName"],cookData["boneParentName"],cookData["IK"],cookData["Pole"],cookData["boneConstraint"],cookData["IKSwitchName"]]:
                    if self.group == "switch":
                        targets = [cookData["IKSwitchName"]]
                    elif self.group == "FKs":
                        targets = [cookData["boneName"],cookData["boneParentName"],cookData["boneConstraint"],]
                    elif self.group == "IKs":
                        targets = [cookData["IK"], cookData["Pole"]]
                    for target in targets:
                        pb = arm.pose.bones[target]
                        if self.group == "switch":
                            pb.keyframe_delete(data_path='["Switch"]', frame=currentFrame)
                        else:
                            for path in ["location", "scale"]:
                                pb.keyframe_delete(data_path=path, frame=currentFrame)
                            if pb.rotation_mode == 'QUATERNION':
                                pb.keyframe_delete("rotation_quaternion", frame=currentFrame)
                            else:
                                pb.keyframe_delete("rotation_euler", frame=currentFrame)
                    ArmSelectBone({"arm":arm,"bones":objs})  
                    break
        return {'FINISHED'}


class MainPanel_PN(bpy.types.Panel):
    bl_label = "Switch IKFK Tool"
    bl_idname = "SwitchIKFK_PN"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'SwitchIKFK'
    def draw(self, context):
        layout = self.layout
        layout.scale_y = 1.2
        layout.scale_x = 1
        layout.split(factor=0.1)
        row = layout.row()
        row.operator("ikfk.switch_ikfk", text="Switch IKFK")

        box = layout.box()
        box.label(text="Add Keyframe")
        row = box.row()
        op = row.operator("ikfk.add_key", text="Switch Ctrl")
        op.group = "switch"
        op = row.operator("ikfk.add_key", text="FK Ctrls")
        op.group = "FKs"
        op = row.operator("ikfk.add_key", text="IK Ctrls")
        op.group = "IKs"

        box = layout.box()
        box.label(text="Clear Keyframe")
        row = box.row()
        op = row.operator("ikfk.delete_key", text="Switch Ctrl")
        op.group = "switch"
        op = row.operator("ikfk.delete_key", text="FK Ctrls")
        op.group = "FKs"
        op = row.operator("ikfk.delete_key", text="IK Ctrls")
        op.group = "IKs"



classes = (
    MainPanel_PN,
    SwitchIKFK_OP,
    AddSwitchKey_OP,
    DeleteSwitchKey_OP,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()


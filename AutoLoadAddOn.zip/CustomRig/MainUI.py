import bpy
import importlib
import json
import os
import math
from mathutils import Matrix,Vector
from bpy.types import Operator
from bpy_extras.io_utils import ImportHelper

from . import NLTA_Amature,NLTA_General,NLTA_Mesh
importlib.reload(NLTA_Amature)
importlib.reload(NLTA_General)
importlib.reload(NLTA_Mesh)

def ModifyRig(context,*arr):
    arm = context.active_object
    bones = arm.pose.bones
    IKDatas = NLTA_Amature.ArmGetIKData(arm)

    ## CREATE FLY CONTROL  
    NLTA_Amature.ArmExtraRoot({
        "arm":arm,
        "boneName":"WaistControl",
    })    

    ## OPEN TRANSLATE
    bpy.ops.object.mode_set(mode='EDIT')
    for bone in bones:
        for IKData in IKDatas:
            if bone.name != IKData["boneName"]:
                eb = arm.data.edit_bones.get(bone.name)
                if eb:
                    eb.use_connect = False
    bpy.ops.object.mode_set(mode='POSE')    

    ## SET UP IK
    for IKData in IKDatas:
        #IK
        IKName = IKData["subtarget"]
        IKRefName = IKData["subtarget"]+"_SwitchIKFK_ref"
        IKSwitchName = (IKData["subtarget"]+"_IKFK").replace(".","_")

        PoleName = IKData["pole_subtarget"]
        PoleRefName = IKData["pole_subtarget"]+"_SwitchIKFK_ref"

        # POLE CONSTAINT
        boneConstraints = NLTA_Amature.BoneGetChildConstraint({"arm":arm,"boneName":IKData["boneName"]})
        if len(boneConstraints) == 1:        
            boneConstraint = boneConstraints[0]
        else:
            for boneTemp in boneConstraints:
                if boneTemp in ["RFoot","LFoot"]:
                    boneConstraint = boneTemp
                    break
        boneConstraintNode = arm.pose.bones[boneConstraint]
        boneConstraintNode.bone.use_inherit_rotation = False
        boneConstraintNode.rotation_mode = "XYZ"


        boneConstraintRefName = boneConstraint+"_BoneConsSwitchIKFK_ref"
        boneConstraintParentName = NLTA_Amature.BoneGetParent({"arm":arm,"boneName":boneConstraint})
        IKCons = NLTA_Amature.ArmGetConstraint({
            "arm":arm,
            "source":IKName,
            "target":IKData["boneName"],
            "type":"IK"
        })

        # BONE KNEE
        boneName = IKData["boneName"]
        boneNode = arm.pose.bones[boneName]

        boneParentName = NLTA_Amature.BoneGetParent({"arm":arm,"boneName":IKData["boneName"]})


        ### BONE CONSTRAINT
        NLTA_Amature.BoneParent({
            "arm":arm,
            "parentName":boneName,
            "childName":boneConstraint,
            "connect":False,
        })


        ### BONE CONSTRAINT REF
        boneConsNew = NLTA_Amature.BoneDuplicate({
            "arm":arm,
            "boneName":boneConstraint,
            "boneNewName":boneConstraintRefName,
            "hide":True,
        })
        NLTA_Amature.BoneParent({
            "arm":arm,
            "parentName":IKName,#boneName,
            "childName":boneConstraintRefName,
            "connect":False,
        })
        """        
        NLTA_Amature.ArmConnectBones({
            "arm":arm,
            "source":boneConstraint,
            "target":boneConstraintRefName,
        })
        """
        NLTA_Amature.ArmRotateConstraint({
            "arm":arm,
            "source":IKName,
            "target":boneConstraint,
        })
        rotCons = NLTA_Amature.ArmGetConstraint({
            "arm":arm,
            "source":IKName,
            "target":boneConstraint,
            "type":"COPY_ROTATION"
        })

        """
        CreateGlobalSingle({
            "arm":arm,
            "boneName":IKName,
            "offsetName":IKName+"_offsetGrp",
            "rootName":"Root",
            "value":1.0,
        })
        
        CreateGlobalSingle({
            "arm":arm,
            "boneName":boneConstraintRefName,
            "offsetName":boneConstraintRefName+"_offsetGrp",
            "rootName":"Root",
            "value":1.0,
        })
        """


        
        
        ########### IK REFERENCE
        IKNew = NLTA_Amature.BoneDuplicate({
            "arm":arm,
            "boneName":IKName,
            "boneNewName":IKRefName,
            #"hide":True,
        })        
        NLTA_Amature.BoneParent({
            "arm":arm,
            "parentName":boneConstraint,#boneConstraintRefName
            "childName":IKRefName,
            "connect":False,
        })


        
        #### POLE REFERENCE
        IKNew = NLTA_Amature.BoneDuplicate({
            "arm":arm,
            "boneName":IKData["pole_subtarget"],
            "boneNewName":PoleRefName,
            #"hide":True,
        })        
        NLTA_Amature.BoneParent({
            "arm":arm,
            "parentName":IKRefName,
            "childName":PoleRefName,
            "connect":False,
        })        

        
        
        #### POLE
        NLTA_Amature.BoneParent({
            "arm":arm,
            "parentName":"Root_extra",
            "childName":PoleName,
            "connect":False,
        })
        
        NLTA_Amature.ArmTransformConstraint({
            "arm":arm,
            "source":PoleRefName,
            "target":PoleName,
        })
        
        NLTA_Amature.ArmAddFloatAttribute({
            "arm":arm,
            "attrName":"Global",
            "boneName":PoleName,
            "default":0,
        })
        
        poleCons = NLTA_Amature.ArmGetConstraint({
            "arm":arm,
            "source":PoleRefName,
            "target":PoleName,
            "type":"COPY_TRANSFORMS"
        })
        NLTA_Amature.ArmConnectBoneToConstraint({
            "arm":arm,
            "source":PoleName,
            "sourceAttr":"Global",
            "target":poleCons,
            "targetAttr":"influence",
            "expression":"1 - var"
        })       

        
        
        
        
        ########### IKFK SWITCH
        IKSwitch = NLTA_Amature.BoneDuplicate({
            "arm":arm,
            "boneName":IKData["subtarget"],
            "boneNewName":IKSwitchName,
        })
        
        NLTA_Amature.ArmTranslateConstraint({
            "arm":arm,
            "source":boneConstraint,
            "target":IKSwitchName,
        })

        NLTA_Amature.ArmAddFloatAttribute({
            "arm":arm,
            "attrName":"Switch",
            "boneName":IKSwitchName,
            "default":1.0,
        })
        NLTA_Amature.ArmConnectBoneToConstraint({
            "arm":arm,
            "source":IKSwitchName,
            "sourceAttr":"Switch",
            "target":IKCons,
            "targetAttr":"influence",
        })
        NLTA_Amature.ArmConnectBoneToConstraint({
            "arm":arm,
            "source":IKSwitchName,
            "sourceAttr":"Switch",
            "target":rotCons,
            "targetAttr":"influence",
            "expression":"var"
        })

        """
        NLTA_Amature.ArmPoseBoneDriver({
            "arm":arm,
            "source":IKSwitchName,
            "sourceAttr":"Switch",
            "target":boneConstraint,
            "targetAttr":"use_inherit_rotation",
            "expression":"1-var"
        })
        """

        
        
        for pbTemp in [IKName,PoleName]:
            NLTA_Amature.ArmPoseBoneDriver({
                "arm":arm,
                "source":IKSwitchName,
                "sourceAttr":"Switch",
                "target":pbTemp,
                "targetAttr":"hide",
                "expression":"1 - var"
            })
        
        for pbTemp in [boneConstraint,boneName,boneParentName]:
            NLTA_Amature.ArmPoseBoneDriver({
                "arm":arm,
                "source":IKSwitchName,
                "sourceAttr":"Switch",
                "target":pbTemp,
                "targetAttr":"hide",
                "expression":"var"
            })       
        
        
        
        bpy.ops.object.mode_set(mode='POSE') 
        
        arm.pose.bones[IKRefName].bone.hide = True
        arm.pose.bones[PoleRefName].bone.hide = True
        arm.pose.bones[boneConstraintRefName].bone.hide = True

def CreateGlobalSingle(data):
    arm = NLTA_Amature.GetArm(data["arm"])
    boneName = data["boneName"]
    offsetName = data["offsetName"]
    rootName = data["rootName"]
    value = data.get("value",0.0)
    print(value)
    NLTA_Amature.BoneCreateOffsetGrp({
        "arm":arm,
        "boneName":boneName,
        "offsetName":offsetName,
    })

    bpy.ops.object.mode_set(mode='POSE')    
    arm.data.bones[offsetName].hide = True
    root = arm.pose.bones.get(rootName)
    pbone = arm.pose.bones.get(offsetName)     

    if not pbone or not root:
        return

    # constraint
    con = pbone.constraints.new('COPY_ROTATION')
    con.target = arm
    con.subtarget = root.name
    con.target_space = 'LOCAL_WITH_PARENT'
    con.owner_space = 'LOCAL_WITH_PARENT'

    # custom property
    pbone = arm.pose.bones.get(boneName)
    prop_name = "Global"
    
    if prop_name not in pbone:
        pbone[prop_name] = value
    pbone[prop_name] = value
    pbone.id_properties_ui(prop_name).update(min=0.0, max=1.0)

    # driver
    driver = con.driver_add("influence").driver
    driver.type = 'SCRIPTED'
    var = driver.variables.new()
    var.name = "switch"
    var.type = 'SINGLE_PROP'
    target = var.targets[0]
    target.id = arm
    target.data_path = f'pose.bones["{boneName}"]["{prop_name}"]'
    driver.expression = "switch"        
    
def CreateGlobal(context,*arr):
    def CleanupGlobal(context, boneName, offsetName):
        arm = context.active_object
        bpy.ops.object.mode_set(mode='POSE')
        pbone = arm.pose.bones.get(boneName)
        offset_pbone = arm.pose.bones.get(offsetName)
        if offset_pbone:
            for con in offset_pbone.constraints:
                offset_pbone.constraints.remove(con)
        if pbone:
            for con in pbone.constraints:
                if con.type == 'COPY_ROTATION':
                    pbone.constraints.remove(con)

        bpy.ops.object.mode_set(mode='EDIT')
        ebones = arm.data.edit_bones
        bone = ebones.get(boneName)
        offset = ebones.get(offsetName)
        if offset and bone:
            bone.parent = offset.parent
            ebones.remove(offset)

    arm = context.active_object
    rootName = NLTA_Amature.ArmGetRoot(arm).name
    bones = NLTA_Amature.BoneSelected(arm)
    for boneName in bones:
        offsetName = boneName+"_offsetGrp"
        CleanupGlobal(context,boneName,offsetName)
        CreateGlobalSingle({
            "context":context,
            "arm":arm,
            "offsetName":offsetName,
            "boneName":boneName,
            "rootName":rootName,
        })   
        

        

 

class ModifyRig_OP(bpy.types.Operator):
    bl_idname = "modify_rig.boba"
    bl_label = "Do Something"
    def execute(self, context):
        ModifyRig(context)
        self.report({'WARNING'}, "Custom Rig done!")
        return {'FINISHED'}


class CreateGlobalRun_OP(bpy.types.Operator):
    bl_idname = "modify_rig.create_global"
    bl_label = "Do Something"
    def execute(self, context):
        CreateGlobal(context)

        return {'FINISHED'}

class CreateWorldParent_OP(bpy.types.Operator):
    bl_idname = "modify_rig.create_world_parent"
    bl_label = "Do Something"
    def execute(self, context):
        AddExraRoot(context)
        return {'FINISHED'}



class MainPanel_PN(bpy.types.Panel):
    bl_label = "Custom Rig Tool"
    bl_idname = "NLTA_CustomRig_PN"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Custom Rig'
    def draw(self, context):
        layout = self.layout
        layout.scale_y = 1.2
        layout.scale_x = 1
        layout.split(factor=0.1)        
        box = layout.box()
        row = box.row()
        row.label(text="Attribute")
        row = box.row()
        row.operator("modify_rig.boba", text="ModifyIK")
        row = box.row()
        row.operator("modify_rig.create_global", text="Create Global")

classes = (
    MainPanel_PN,
    ModifyRig_OP,
    CreateGlobalRun_OP,
    CreateWorldParent_OP,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    #bpy.types.Scene.props = bpy.props.PointerProperty(type=Properties)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()


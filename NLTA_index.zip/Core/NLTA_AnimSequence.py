import unreal

def GetSkeleton(asset):
	if isinstance(asset,unreal.AnimSequence):
		skeleton = asset.get_editor_property('skeleton')
		return(skeleton)
	return(None)

def GetAnimSequencesFromSkeleton(skeleton):
	returnArray = []	
	assetRegistry = unreal.AssetRegistryHelpers.get_asset_registry()
	filter = unreal.ARFilter(
	    class_names=["AnimSequence"],
	    package_paths=["/Game"],
	    recursive_paths=True
	)
	animSequences = assetRegistry.get_assets(filter)
	for animSequenceData in animSequences:
		returnArray.append({
			'name':animSequenceData.asset_name,
			'path':animSequenceData.package_name,
		})
	return(returnArray)

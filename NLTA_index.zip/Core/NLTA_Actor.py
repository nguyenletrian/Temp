import unreal

#print(NLTA_Actor.SelectedActors()[0].get_editor_property("skeletal_mesh_component").get_bone_mass("pelvis",True))
#print(NLTA_Actor.SelectedActors()[0].get_editor_property("skeletal_mesh_component").get_current_joint_angles("spine_02"))
#print(NLTA_Actor.SelectedActors()[0].get_editor_property("skeletal_mesh_component").get_bone_index("spine_02"))
#print(NLTA_Actor.SelectedActors()[0].get_editor_property("skeletal_mesh_component").get_bone_name(7))

#location = NLTA_Actor.SelectedActors()[0].get_editor_property("skeletal_mesh_component").get_editor_property("relative_rotation")
#rotation = NLTA_Actor.SelectedActors()[0].get_editor_property("skeletal_mesh_component").get_editor_property("relative_rotation")
#worldTransform = NLTA_Actor.SelectedActors()[0].get_editor_property("skeletal_mesh_component").transform_from_bone_space("spine_02",location,rotation)
#print(worldTransform)
#newCube = NLTA_Actor.AddCube()
#newCube.set_actor_location(worldTransform[0],False,False)
#newCube.set_actor_rotation(worldTransform[1],True)

def SelectedActors():
	actors = list(unreal.EditorActorSubsystem().get_selected_level_actors())
	if len(actors)!=0:
		return(actors)
	else:
		return(None)

def Pilot(actor):
	unreal.EditorLevelLibrary.pilot_level_actor(actor)

def EjectPilot():
	unreal.EditorLevelLibrary.eject_pilot_level_actor()

def SelectActor(array):
	unreal.EditorLevelLibrary.set_selected_level_actors(array)

def ClearSelected():
	unreal.EditorLevelLibrary.select_nothing()

def GetViewportTransform():
	return(unreal.EditorLevelLibrary.get_level_viewport_camera_info())

def GetAllActor():
	actors = unreal.EditorLevelLibrary.get_all_level_actors()


def AddCube():
	cube = unreal.load_asset("/Engine/BasicShapes/Cube")
	cube_location = unreal.Vector(0.0,0.0,0.0)
	cube_actor = unreal.EditorLevelLibrary().spawn_actor_from_object(cube,cube_location)
	cube_actor.set_editor_property("hidden",True)
	cube_actor.static_mesh_component.set_editor_property("visible",False)
	cube_actor.set_mobility(unreal.ComponentMobility.MOVABLE)
	return(cube_actor)

def AttachActor(children,parent,maintain):
	if maintain == True:
		location = unreal.AttachmentRule.SNAP_TO_TARGET
		rotation = unreal.AttachmentRule.SNAP_TO_TARGET
		scale = unreal.AttachmentRule.SNAP_TO_TARGET#unreal.AttachmentRule.SNAP_TO_TARGET
	else:		
		location = unreal.AttachmentRule.KEEP_WORLD
		rotation = unreal.AttachmentRule.KEEP_WORLD
		scale = unreal.AttachmentRule.KEEP_WORLD
	children.attach_to_actor(
		parent,
		"",
		location,
		rotation,
		scale,
		maintain
	)

def DetachActor(actor,type):
	if type == "world":
		actor.detach_from_actor(
			location_rule = unreal.DetachmentRule.KEEP_WORLD,
			rotation_rule = unreal.DetachmentRule.KEEP_WORLD,
			scale_rule = unreal.DetachmentRule.KEEP_WORLD,
		)
	elif type == "relative":
		actor.detach_from_actor(
			location_rule = unreal.DetachmentRule.KEEP_RELATIVE,
			rotation_rule = unreal.DetachmentRule.KEEP_RELATIVE,
			scale_rule = unreal.DetachmentRule.KEEP_RELATIVE,
		)

def GetDistance(data):
	transform1 = data["transform1"]
	transform2 = data["transform2"]
	cube1 = AddCube()	
	cube1.set_actor_transform(transform1,False,False)
	cube2 = AddCube()
	cube2.set_actor_transform(transform2,False,False)	
	distance = cube1.get_distance_to(cube2)
	cube1.destroy_actor()
	cube2.destroy_actor()
	return(distance)

def DeleteActor(label):
	actors = unreal.EditorLevelLibrary.get_all_level_actors()
	for actor in actors:
		if actor.get_actor_label() == label:
			children = actor.get_attached_actors(reset_array=True,recursively_include_attached_actors=True)
			for child in children:
				child.destroy_actor()
			actor.destroy_actor()

def GetActorChildren(actorLabel):
	actors = unreal.EditorLevelLibrary.get_all_level_actors()
	for actor in actors:
		if actor.get_actor_label() == actorLabel:
			children = actor.get_attached_actors(reset_array=True,recursively_include_attached_actors=True)
			children.insert(0,actor)
			return(children)

def GetActorByName(name):
	actors = unreal.EditorLevelLibrary.get_all_level_actors()
	for actor in actors:
		if actor.get_actor_label() == name:
			return(actor)

def SelectActorByName(nameArray):
	actorArray = []
	actors = unreal.EditorLevelLibrary.get_all_level_actors()
	for actor in actors:
		if actor.get_actor_label() in nameArray:
			actorArray.append(actor)
	unreal.EditorLevelLibrary.set_selected_level_actors(actorArray)
			

def CheckActorExist(actorName):
	actors = unreal.EditorLevelLibrary.get_all_level_actors()
	for actor in actors:
		if actor.get_actor_label() == actorName:
			return(True)
	return(False)

def SetLabel(actor):
	actor.set_actor_label("NLTA_RenderGroup")

"""

##### SNAP THEO BOUNDING BOX(NÂNG CAO)
import unreal
SNAP_AXIS = "X" #Có thể là "X", "Y", hoặc "Z"
OFFSET = 10. #Khoảng cách giữa các actor(đơn vị cm)
########

def snap_by_bounding_box_advanced(axis="X",offset=0.0):
	selected_actors = unreal.EditorLevelLibrary.get_selected_level_actors()
	if len(selected_actors) < 2:
		unreal.log_warning("Cần chọn ít nhất 2 actor").
		return()

	#Sort theo vị trí trục được chọn
	axis = axis.upper()
	if axis not in ("X","Y","Z"):
		unreal.log.error("Trục không hợp lệ, Dùng X, Y hoặc Z.")
		return()

	selected_actors.sort(key=lambda a: getattr(a.get_actor_location(),axis.lower()))

	# Lây actor đầu tiên làm gốc
	current_pos = get_bbox_max(selected_actors[0],axis)

	for actor in selected_actors[1:]:
		bbox = get_actor_bbox(actor)
		length = get_bbox_size(bbox,axis)

		#Vị trí mới = cạnh hiện tại + offset + 1/2 chiều dài actor
		new_axis_pos = current_pos +  offset + (length * 0.5)

		#Lấy vị trí hiệ tại và chỉnh sửa trục snap
		location = actor.get_actor_location()
		setattr(location,axis.lower(),new_axis_pos)

		#Di chuyển actor
		actor.set_actor_location(location,False,True)

		#Cập nhật rìa bên phải cho actor này
		current_pos = new_axis_pos + (length * 0.5)

	unreal.log("Done")

def get_actor_bbox(actor):
	return(actor.get_components_bouding_box())

def get_bbox_size(bbox,axis):
	return abs(getattr(bbox.max,axis.lower() - getattr(bbox.min,axis.lower())))

def get_bbox_max(actor,axis):
	bbox = get_actor_bbox(actor)
	return(getattr(bbox.mã,axis,lower()))

### Gọi hàm chính
#snap_by_bouding_box_advanced(snap_axis,offset)
"""

def GetSkeleton(actor):
	components = actor.get_components_by_class(unreal.SkeletalMeshComponent)
	if not components:
		unreal.log_warning('Khong co SkeletalMeshComponent')
		return(None)
	skeletalMeshComponent = components[0]
	skeletalMesh = skeletalMeshComponent.skeletal_mesh
	if not skeletalMesh:
		unreal.log_warning('Khong co skeletalMesh gan vao component')
		return(None)
	skeleton = skeletalMesh.get_editor_property('skeleton')
	return(skeleton)




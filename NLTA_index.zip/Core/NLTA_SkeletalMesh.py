import unreal

def GetAll():
	returnArray = []
	assetRegistry = unreal.AssetRegistryHelpers.get_asset_registry()
	filter = unreal.ARFilter(
		class_names =['/Script/Engine.SkeletalMesh'],
		package_paths =['/Game'],
		recursive_paths=True,
	)
	assetDatas = assetRegistry.get_assets(filter)
	for assetData in assetDatas:
		returnArray.append({
			'name':str(assetData.asset_name),
			'path':assetData.package_name,
		})
	return(returnArray)

def GetAssetByName(inputName):
	assets = GetAll()
	for i in range(len(assets)):
		name = assets[i]["name"]
		if inputName == name:			
			return(unreal.load_asset(assets[i]['path']))
	return(None)

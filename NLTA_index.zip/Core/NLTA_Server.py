
import socket
import threading
import json
import maya.cmds as cmds
import maya.utils

def process_json_command(data):
	if 'currentTime' in data:
		#autoKey = cmds.autoKeyframe(query=True, state=True)
		cmds.currentTime(data['currentTime'], edit=True)
	if 'controls' in data:
		for key in data['controls']:
			if cmds.objExists(key):
				keyData = data['controls'][key]
				for attr in keyData:
					if cmds.attributeQuery(attr, node=key, exists=True):
						cmds.setAttr(key+'.'+attr,keyData[attr])
						#cmds.setKeyframe(key, attribute=attr)
	#cmds.autoKeyframe(state=autoKey)
	
def socket_server():
	host = '127.0.0.1'
	port = 9999
	server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	server.bind((host, port))
	server.listen(1)
	while True:
		client, addr = server.accept()
		data = client.recv(2048).decode("utf-8")
		if data is not None:
			data_dict = json.loads(data)
			result = maya.utils.executeInMainThreadWithResult(lambda: process_json_command(data_dict))
			#client.send(result.encode("utf-8"))
		client.close()

threading.Thread(target=socket_server, daemon=True).start()
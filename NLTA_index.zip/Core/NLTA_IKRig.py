

##### TAO IK RIG
import unreal
asset_tools = unreal.AssetToolsHelpers.get_asset_tools()
skeletal_mesh_path = "/Game/Characters/Hero/HeroMesh"
skeletal_mesh = unreal.EditorAssetLibrary.load_asset(skeletal_mesh_path)
ik_rig_factory = unreal.IKRigFactory()
ik_rig_asset = asset_tools.create_asset('IK_Hero','/Game/IKRigs',unreal.IKRigDefinition,ik_rig_factory)




#Gan skeletal mesh vao trong IK Rig
ik_rig_asset.set_editor_property('preview_mesh',skeletal_mesh)

#Lay Skeleton
skeleton = ik_rig_asset.get_editor_property('preview_mesh').get_editor_property('skeleton')
bone_names = skeleton.get_reference_skeleton().get_raw_bone_names()

#Them retarget root
ik_rig_asset.set_editor_property('retarget_root','root') 

unreal.EditorAssetLibrary.save_asset(ik_rig_asset.get_path_name())

#### THEM CHAIN
chain_controller = unreal.IKRigEditorController.get_editor_controller(ik_rig_asset)
#Them bone chain: LeftLeg (tuwf thigh_L -> foot_L)
chain_controller.add_new_retarget_chain('LeftLeg','thigh_L','foot_L')

#Them RightLeg
chain_controller.add_new_retarget_chain('RightLeg','thigh_r','foot_r')

#Them Spine
chain_controller.add_new_retarget_chain('Spine','spine_01','spine_03')

#Them Arms
chain_controller.add_new_retarget_chain('LeftArm','upperarm_l','hand_l')
chain_controller.add_new_retarget_chain('RightArm','upperarm_r','hand_r')

#Luu la
unreal.EditorAssetLibrary.save_asset(ik_rig_asset.get_path_name())


### DUNG IK RIG TRONG IK RETARGET
ik_retarget_factory = unreal.IKRetargeterFactory()
ik_retargeter =asset_tools.create_asset('RTG_HeroToEnemy','/Game/IKRigs',unreal.IKRetargeter,ik_retarget_factory)
ik_retargeter.set_editor_property("source_ik_rig",ik_rig_asset)




## CREATE FULL BODY IK SOLVER
import unreal
ik_rig_asset = unreal.EditorAssetLibrary.load_asset("/Game/IKRigs/IK_Hero")

#Lay solver array tu IK Rig
solvers = ik_rig_asset.get_editor_property('solvers')

#Tao solver moi
new_solver = unreal.IKRigSolverFullBodyIK()
new_solver.set_editor_property('root_bone','root') #hoac pelvis neu can

## Dat ten cho solver
new_solver.set_editor_property('name','FullBodyIK')

#Them solver vafo stack
solver.append(new_solver)
ik_rig_asset.set_editor_property('solvers',solvers)

#Save lai
unreal.EditorAssetLibrary.save_asset(ik_rig_asset.get_path_name())
print("Da them FullBodyIK vao solver stack")

# THEM GOALS CHO SOLVER
goal = unreal.IKRigGoal()
goal.set_editor_property('name','ik_hand_l')
goal.set_editor_property('bone_name','hand_l')
goal.set_editor_property('goal_type',unreal.IKRigGoalType.POSITION_AND_ROTATION)
#lay danh sach hien co
goals = ik_rig_asset.get_editor_property('goals')
goals.append(goal)
ik_rig_asset.set_editor_property('goals',goals)

unreal.EditorAssetLibrary.save_asset(ik_rig_asset.get_path_name())
print('Da them goal "Ik_hand_l"')


### ADD SETTING TO SELETED BONE
import unreal
ik_rig = unreal.EditorAssetLibrary.load_asset('/Game/IKRigs/IK_Hero')

#Lay solver list va tim solver kieu FullBodyIK
solvers = ik_rig.get_editor_property('solvers')

#Tim solver FullBodyIK(by name)
fbi_solver = None
for solver in solvers:
	if isinstance(solver,unreal.IKRigSolverFullBodyIK):
		fbi_solver = solver
		break

if not fbi_solver:
	print('Khong tim thay FullBodyIK Solver')
else:
	#Tao setting cho bone: foot_l
	setting = unreal.IKRigFBIKBoneSetting()
	setting.bone = 'foot_l'
	setting.stiffness.translation = unreal.Vector(1.0,1.0,1.0) #Cung chac ve vi tri
	setting.stiffness.rotation = 0.5 #do cung quay
	setting.pull_chain_alpha = 0.8 #do anh huong chuoi
	setting.rotation_mode = unreal.IKRigFBRotationMode.BONE #dung rotation tu bone

	#Them setting vao list
	bone_settings = fbi_solver.get_editor_property('bone_settings')
	bone_settings.append(setting)
	fbi_solver.set_editor_property('bone_settings',bone_settings)

	#luu lai
	unreal.EditorAssetLibrary.save_asset(ik_rig.get_path_name())
	print("Da them setting cho bone 'foot_L'")

import unreal

#Create Blueprint Interface
interface_name = 'BPI_MyInterface'
package_path = '/Game/Blueprints'

factory = unreal.BlueprintInterfaceFactory()
asset_tools = unreal.AssetToolHelpers.get_asset_tools()
interface_asset = asset_tools.create_asset(interface_name,package_path,None,factory)
print("Done")

bp_actor = unreal.load_asset("/Game/Blueprints/BP_MyActor")
bp_generated_class = bp_actor.generated_class

#Load the interface
interface = unreal.load_asset("/Game/Blueprints/BPI_MyInterface")

#Get current interfaces
current_interfaces = list(bp_actor.get_editor_property('interfaces'))

#Check if already added
if not any(i.interface == interface for i in current_interfaces):
	new_interface = unreal.BlueprintInterfaceDescription()
	new_interface.interface = interface
	current_interfaces.append(new_interface)
	bp_actor.set_editor_property("interfaces",current_interfaces)
	bp_actor.mark_package_dirty()
	unreal.EditorAssetLibrary.save_asset(bp_actor.get_path_name())
	print("Interface added to Blueprint")
else:
	print("Interface already present.")


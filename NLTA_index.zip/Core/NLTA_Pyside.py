from PySide2 import QtWidgets
import inspect
def WidgetInput(widget):
    typeArray = [
        QtWidgets.QLineEdit,
        QtWidgets.QPushButton,
        QtWidgets.QTextEdit,
        QtWidgets.QPlainTextEdit,
        QtWidgets.QComboBox,
        QtWidgets.QCheckBox,
        QtWidgets.QSpinBox,
        QtWidgets.QDoubleSpinBox,
        QtWidgets.QRadioButton,
        QtWidgets.QVBoxLayout,
        QtWidgets.QLabel,
        QtWidgets.QGroupBox,
    ]
    dataReturn = {}
    for type_ in typeArray:
        widgetTemp = widget.findChildren(type_)
        for order in range(len(widgetTemp)):
            input_ = widgetTemp[order]
            inputName = input_.objectName()
            dataReturn[inputName] = input_
    return(dataReturn)

def WidgetSet(inputData):
    widgetInput =  inputData["widget"]
    arrayValue = inputData["value"]
    for inputName in widgetInput:
        inputElement = widgetInput[inputName]
        inputType = widgetInput[inputName].__class__.__name__
        if inputName in arrayValue:
            if str(inputType) == "QLineEdit":
                inputElement.setText(arrayValue[inputName])            
            if str(inputType) == "QTextEdit":
                inputElement.setPlainText(arrayValue[inputName])
            if str(inputType) == "QComboBox":
                inputElement.setCurrentText(arrayValue[inputName])
            if str(inputType) == "QCheckBox":
                inputElement.setChecked(arrayValue[inputName])
            if str(inputType) == "QSpinBox":
                inputElement.setValue(arrayValue[inputName])
            if str(inputType) == "QDoubleSpinBox":
                inputElement.setValue(arrayValue[inputName])                
            if str(inputType) == "QRadioButton":
                inputElement.setChecked(arrayValue[inputName]) 


def WidgetGet(widget):
    dataReturn = {}
    typeArray = [
        QtWidgets.QLineEdit,
        QtWidgets.QPushButton,
        QtWidgets.QTextEdit,
        QtWidgets.QComboBox,
        QtWidgets.QCheckBox,
        QtWidgets.QSpinBox,
        QtWidgets.QDoubleSpinBox,
        QtWidgets.QRadioButton,
    ]
    for type_ in typeArray:
        widgetTemp = widget.findChildren(type_)
        for order in range(len(widgetTemp)):
            input_ = widgetTemp[order]
            inputName = input_.objectName()
            inputType = input_.__class__.__name__
            value = None
            if str(inputType) in ["QLineEdit"]:
                value = input_.text()
            if str(inputType) in ["QTextEdit"]:
                value = input_.toPlainText()
            if str(inputType) in ["QComboBox"]:
                value = input_.currentText()
            if str(inputType) in ["QCheckBox"]:
                value = input_.isChecked()
            if str(inputType) in ["QSpinBox"]:
                value = input_.value()
            if str(inputType) in ["QDoubleSpinBox"]:
                value = input_.value()
            if str(inputType) in ["QRadioButton"]:
                value = input_.isChecked()
            dataReturn[inputName] = value
    return(dataReturn)

def LoadModule():
	import unreal,sys,os,shutil,subprocess,json,time
	from PySide2 import QtUiTools, QtWidgets, QtCore, QtGui
	from PySide2.QtWidgets import QMessageBox, QMenu, QTreeWidgetItem,QTreeWidgetItemIterator
	from functools import partial

	frame = inspect.currentframe()
	outer_frame = frame.f_back
	outer_globals = outer_frame.f_globals
	dataReturn = {
		'QtUiTools':QtUiTools,
		'QtWidgets':QtWidgets,
		'QWidget':QtWidgets.QWidget,
		'QtCore':QtCore,
		'QtGui':QtGui,
		'partial':partial,
		'QMessageBox':QMessageBox,
		'QMenu':QMenu,
		'QTreeWidgetItem':QTreeWidgetItem,
		'QTreeWidgetItemIterator':QTreeWidgetItemIterator,
		'WidgetGet':WidgetGet,
		'WidgetInput':WidgetInput,
		'WidgetSet':WidgetSet,
	}
	for key in dataReturn:
		outer_globals[key] = dataReturn[key]

def ClearWidget(widget):
    for i in reversed(range(widget.count())):
        widgetCurrnet = widget.itemAt(i).widget()
        widget.removeWidget(widgetCurrnet)
        widgetCurrnet.setParent(None)
        widgetCurrnet.deleteLater()

def ReloadComboBox(comboBox,comboBoxArray):
    comboBox.clear()
    comboBox.addItems(comboBoxArray)




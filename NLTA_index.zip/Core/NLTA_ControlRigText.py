import unreal
import re
unreal.load_module('ControlRigDeveloper')
factory = unreal.ControlRigBlueprintFactory
basicTransform = unreal.EulerTransform(location=[0.000000,0.000000,0.000000],rotation=[0.000000,0.000000,0.000000],scale=[1.000000,1.000000,1.000000])


def CreateParentControl(inputData):
	name = inputData['name']
	parent = inputData['parent']
	color = inputData['color']
	offset = inputData['offset']
	setting =  unreal.RigControlSettings()
	setting.animation_type = unreal.RigControlAnimationType.PROXY_CONTROL
	setting.control_type = unreal.RigControlType.EULER_TRANSFORM
	setting.draw_limits = True
	setting.shape_color = color
	setting.shape_name = 'Default'
	setting.shape_visible = True
	control = hierarchyController.add_control(name,parent,setting, unreal.RigHierarchy.make_control_value_from_euler_transform(basicTransform))
	hierarchy.set_control_shape_transform(control, unreal.Transform(location=[0.000000,0.000000,0.000000],rotation=[0.000000,0.000000,0.000000],scale=[0.200000,0.200000,0.200000]), True)
	hierarchy.set_control_offset_transform(control, unreal.Transform(location=[offset,0.000000,0.000000],rotation=[0.000000,0.000000,-0.000000],scale=[1.000000,1.000000,1.000000]), True, True)
	hierarchy.set_control_value(control, unreal.RigHierarchy.make_control_value_from_euler_transform(unreal.EulerTransform(location=[0.000000,0.000000,0.000000],rotation=[0.000000,0.000000,-0.000000],scale=[1.000000,1.000000,1.000000])), unreal.RigControlValueType.CURRENT)
	currentOffset = offset
	return(control)

def CreateChildControl(inputData):
	name = inputData['name']
	parent = inputData['parent']
	color = inputData['color']
	offsetTransform = inputData['offsetTransform']
	setting = unreal.RigControlSettings()
	setting.animation_type = unreal.RigControlAnimationType.VISUAL_CUE
	for key in inputData['setting']:
		setting.set_editor_property(key,inputData['setting'][key])

	if inputData['setting']['control_type'] == unreal.RigControlType.VECTOR2D:
		setting.limit_enabled = [unreal.RigControlLimitEnabled(True, True), unreal.RigControlLimitEnabled(True, True)]
		controlValue = unreal.RigHierarchy.make_control_value_from_vector2d(unreal.Vector2D(0.000000, 0.000000))
	elif inputData['setting']['control_type'] == unreal.RigControlType.FLOAT:
		setting.limit_enabled = [unreal.RigControlLimitEnabled(True, True)]
		controlValue = unreal.RigHierarchy.make_control_value_from_float(0.000000)
	setting.shape_color =  color	
	control = hierarchyController.add_control(name,parent,setting,controlValue)
	hierarchy.set_control_shape_transform(control, unreal.Transform(location=[0.000000,0.000000,0.000000],rotation=[0.000000,0.000000,0.000000],scale=[0.000000,0.000000,0.000000]), True)
	hierarchy.set_control_offset_transform(control,offsetTransform, True, True)

def GetColor(colorName):
	data = {
		'rdb_Red':unreal.LinearColor(1.000000, 0.000000, 0.000000, 1.000000),
		'rdb_Blue':unreal.LinearColor(0.000000, 0.000000, 1.000000, 1.000000),
		'rdb_Green':unreal.LinearColor(0.000000, 1.000000, 0.000000, 1.000000),
		'rdb_Yellow':unreal.LinearColor(1.000000, 1.000000, 0.000000, 1.000000),
		'rdb_Pink':unreal.LinearColor(1.000000, 0.000000, 1.000000,0.000000),
		'rdb_Orange':unreal.LinearColor(1.000000, 0.500000, 0.000000,1.000000),
	}
	if colorName in data:
		return(data[colorName])
	else:
		return(None)


def CreateChar(inputData):
	global currentOffset
	char = inputData['char']
	color = inputData['color']
	pattern = GetPattern(char)
	if pattern:
		currentOffset = currentOffset + pattern['offset'] + distance
		parent = CreateParentControl({'name':char,'parent':parentAll,'color':color,'offset':currentOffset})
		currentOffset = currentOffset + pattern['offset']
		stt = 0
		for i in range(len(pattern['children'])):
			childData = pattern['children'][i]
			childData['parent'] = parent
			childData['color'] = color
			childData['name'] = str(parent.name)+str(stt)		
			CreateChildControl(childData)
			stt+=1

def Create(inputData):
	global controlRig
	global hierarchy
	global hierarchyController
	global distance
	global currentOffset
	global parentAll
	text = re.sub(r'\W','_',inputData['text'])
	print(text)
	color = GetColor(inputData['color'])	
	controlRig = inputData['controlRig']
	distance = 30
	currentOffset = 0
	hierarchy = controlRig.hierarchy
	hierarchyController = hierarchy.get_controller()
	selectedObject = hierarchy.get_selected_keys()
	if selectedObject:
		parentAll = CreateParentControl({'name':text,'parent':selectedObject[0],'color':color,'offset':0})		
	else:
		parentAll = CreateParentControl({'name':text,'parent':'','color':color,'offset':0}) 
	for char in text:
		if char != "_":
			CreateChar({
				'char':char,
				'color':color,
				'controlRig':controlRig
			})
		else:
			currentOffset = currentOffset + (4*distance)


def GetPattern(char):
	def CreateFloat(value):
		return(unreal.RigHierarchy.make_control_value_from_float(value))
	
	def Create2D(value):
		return(unreal.RigHierarchy.make_control_value_from_vector2d(unreal.Vector2D(value[0],value[1])))
	
	def CreateOffset(value):
		return(unreal.Transform(location=[value[0],value[1],value[2]],rotation=[value[3],value[4],value[5]],scale=[1.000000,1.000000,1.000000]))
	type2D = unreal.RigControlType.VECTOR2D
	typeFloat = unreal.RigControlType.FLOAT
	data = {
		"A":{
			'offset':50,
			'children':[
				{'setting':{'control_type':type2D,'minimum_value':Create2D([0,0]),'maximum_value':Create2D([100,100])},'offsetTransform':CreateOffset([50,-100,0,90,90,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([50,-100,0,0,90,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-100,0,0,90,0])},
			]
		},
		"B":{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-80),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([-50,-100,0,0,180,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-100,0,0,-90,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(60),},'offsetTransform':CreateOffset([50,-120,0,0,-90,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-80),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([-50,-200,0,0,180,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(28.299999),},'offsetTransform':CreateOffset([30,-200,0,0,45,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(80),},'offsetTransform':CreateOffset([-50,0,0,0,0,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(60),},'offsetTransform':CreateOffset([50,-80,0,0,90,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(28.299999),},'offsetTransform':CreateOffset([30,-100,0,0,-45,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(28.299999),},'offsetTransform':CreateOffset([30,-100,0,0,45,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(28.299999),},'offsetTransform':CreateOffset([50,-20,0,0,135,0])},
			]
		},
		"C":{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-100,0,0,90,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,-200,0,0,0,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,0,0,0,0,0])},
			]
		},
		"D":{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-100,0,0,90,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-80),'maximum_value':CreateFloat(80),},'offsetTransform':CreateOffset([50,-100,0,0,90,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(83),},'offsetTransform':CreateOffset([-50,-200,0,0,0,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(83),},'offsetTransform':CreateOffset([-50,0,0,0,0,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(26.3),},'offsetTransform':CreateOffset([50,-180,0,0,-130,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(26.3),},'offsetTransform':CreateOffset([50,-20,0,0,130,0])},
			]
		},
		"E":{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-100,0,0,0,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-100,0,0,90,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,0,0,0,0,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-200,0,0,0,0])},
			]
		},
		"F":{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-100,0,0,90,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-100,0,0,0,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-200,0,0,0,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-200,0,0,0,0])},
			]
		},
		"G":{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-100,0,0,90,0])},#1
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-200,0,0,0,0])},#2
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,0,0,0,0,0])},#3
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([50,-100,0,0,90,0])},#4
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-30),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,-100,0,0,0,0])},#5
			]
		},
		"H":{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([50,-100,0,0,90,0])},#1
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-100,0,0,90,0])},#2
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,-100,0,0,0,0])},#3
			]
		},
		'I':{
			'offset':0,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([0,-100,0,0,90,0])},#1
			]
		},
		'J':{
			'offset':25,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([25,-100,0,0,90,0])},#1
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-50),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([25,0,0,0,0,0])},#2
			]
		},
		'K':{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-100,0,0,90,0])},#1
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-140),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,-200,0,0,-45,0])},#2
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-140),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,0,0,0,45,0])},#3
			]
		},
		'L':{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-100,0,0,90,0])},#1
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,0,0,0,0,0])},#2
			]
		},
		'M':{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([50,-100,0,0,90,0])},#1
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-100,0,0,90,0])},#2
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-71),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,-200,0,0,-45,0])},#3
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(71),},'offsetTransform':CreateOffset([-50,-200,0,0,45,0])},#4
			]
		},
		'N':{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([50,-100,0,0,90,0])},#1
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-100,0,0,90,0])},#2
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-224),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,0,0,0,63.5,0])},#3
			]
		},
		'O':{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([50,-100,0,0,90,0])},#1
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-100,0,0,90,0])},#2
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,0,0,0,0,0])},#3
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,-200,0,0,0,0])},#4
			]
		},
		'P':{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,-100,0,0,90,0])},#1
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-100,0,0,90,0])},#2
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,-100,0,0,0,0])},#3
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,-200,0,0,0,0])},#4
			]
		},
		'Q':{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([50,-100,0,0,90,0])},#1
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-100,0,0,90,0])},#2
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,0,0,0,0,0])},#3
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,-200,0,0,0,0])},#4
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-20),'maximum_value':CreateFloat(20),},'offsetTransform':CreateOffset([50,0,0,0,45,0])},#5
			]
		},
		'R':{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,-100,0,0,90,0])},#1
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-100,0,0,90,0])},#2
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,-100,0,0,0,0])},#3
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,-200,0,0,0,0])},#4
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-141),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,0,0,0,45,0])},#5
			]
		},
		'S':{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([50,-100,0,0,90,0])},#1
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([-50,-100,0,0,90,0])},#2
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,0,0,0,0,0])},#3
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,-200,0,0,0,0])},#4
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,-100,0,0,0,0])},#5
			]
		},
		'T':{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,-200,0,0,0,0])},#1
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(200),},'offsetTransform':CreateOffset([0,-200,0,0,90,0])},#2
			]
		},
		'U':{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([50,-100,0,0,90,0])},#1
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-100,0,0,90,0])},#2
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,0,0,0,0,0])},#3
			]
		},
		'V':{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(207),},'offsetTransform':CreateOffset([50,-200,0,0,104,0])},#1
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(207),},'offsetTransform':CreateOffset([-50,-200,0,0,76,0])},#2
			]
		},
		'W':{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([50,-100,0,0,90,0])},#1
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-100,0,0,90,0])},#2
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-71),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,0,0,0,45,0])},#3
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(71),},'offsetTransform':CreateOffset([-50,0,0,0,-45,0])},#4
			]
		},
		'X':{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(224),},'offsetTransform':CreateOffset([-50,0,0,0,-63.5,0])},#1
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-224),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,0,0,0,63.5,0])},#2
			]
		},
		'Y':{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([0,-100,0,0,90,0])},#1
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-112),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,-200,0,0,-63.5,0])},#2
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(112),},'offsetTransform':CreateOffset([-50,-200,0,0,63.5,0])},#2
			]
		},
		'Z':{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-112),'maximum_value':CreateFloat(112),},'offsetTransform':CreateOffset([0,-100,0,0,116.5,0])},#1
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([50,0,0,0,0,0])},#2
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-200,0,0,0,0])},#2
			]
		},
		"a":{
			'offset':50,
			'children':[
				{'setting':{'control_type':type2D,'minimum_value':Create2D([0,0]),'maximum_value':Create2D([50,100])},'offsetTransform':CreateOffset([50,-50,0,90,0,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,-100,0,0,0,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([50,-100,0,0,90,0])},
			]
		},
		"b":{
			'offset':50,
			'children':[
				{'setting':{'control_type':type2D,'minimum_value':Create2D([0,0]),'maximum_value':Create2D([100,100])},'offsetTransform':CreateOffset([50,-100,0,-90,-90,180])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-100,0,0,-90,0])},
			]
		},
		"c":{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([50,-100,0,0,180,-90])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,0,0,0,0,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-100,0,0,90,0])},
			]
		},
		"d":{
			'offset':50,
			'children':[
				{'setting':{'control_type':type2D,'minimum_value':Create2D([0,0]),'maximum_value':Create2D([100,100])},'offsetTransform':CreateOffset([50,-100,0,-90,-90,180])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([50,-100,0,0,-90,0])},
			]
		},
		"e":{
			'offset':50,
			'children':[
				{'setting':{'control_type':type2D,'minimum_value':Create2D([0,0]),'maximum_value':Create2D([100,50])},'offsetTransform':CreateOffset([50,-100,0,-90,-90,180])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,0,0,0,-90,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-50),'maximum_value':CreateFloat(50),},'offsetTransform':CreateOffset([0,0,0,0,0,0])},
			]
		},
		"f":{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(50),},'offsetTransform':CreateOffset([50,-200,0,0,180,-90])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-100,0,0,0,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([0,-100,0,0,-90,0])},
			]
		},
		"g":{
			'offset':50,
			'children':[
				{'setting':{'control_type':type2D,'minimum_value':Create2D([0,0]),'maximum_value':Create2D([100,100])},'offsetTransform':CreateOffset([50,-100,0,-90,-90,180])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([50,0,0,0,90,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,100,0,0,0,0])},
			]
		},
		"h":{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,-100,0,0,0,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,0,0,0,90,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-100,0,0,90,0])},
			]
		},
		"i":{
			'offset':0,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([0,-100,0,0,90,0])},
			]
		},
		"j":{
			'offset':25,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(200),},'offsetTransform':CreateOffset([0,-100,0,0,90,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-50),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([0,100,0,0,0,0])},
			]
		},
		"k":{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-100,0,0,90,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-112),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,-100,0,0,-26.3,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-112),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,0,0,0,26.3,0])},
			]
		},
		"l":{
			'offset':0,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([0,-100,0,0,90,0])},
			]
		},
		"m":{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([50,-100,0,0,90,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([0,-100,0,0,90,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-100,0,0,90,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-110),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,-100,0,0,0,0])},
			]
		},
		'n':{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([50,-100,0,0,90,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-100,0,0,90,0])},			
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-110),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,-100,0,0,0,0])},
			]
		},
		'o':{
			'offset':50,
			'children':[
				{'setting':{'control_type':type2D,'minimum_value':Create2D([0,0]),'maximum_value':Create2D([100,100])},'offsetTransform':CreateOffset([50,-100,0,90,180,180])},
			]
		},
		'p':{
			'offset':50,
			'children':[
				{'setting':{'control_type':type2D,'minimum_value':Create2D([0,0]),'maximum_value':Create2D([100,100])},'offsetTransform':CreateOffset([50,-100,0,90,0,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,0,0,0,90,0])},
			]
		},
		'q':{
			'offset':50,
			'children':[
				{'setting':{'control_type':type2D,'minimum_value':Create2D([0,0]),'maximum_value':Create2D([100,100])},'offsetTransform':CreateOffset([50,-100,0,90,0,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([50,0,0,0,90,0])},
			]
		},
		'r':{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-100,0,0,0,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(110),},'offsetTransform':CreateOffset([-50,-110,0,0,90,0])},
			]
		},
		's':{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-100,0,0,0,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,0,0,0,0,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(50),},'offsetTransform':CreateOffset([50,-50,0,0,90,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-50,0,0,0,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(50),},'offsetTransform':CreateOffset([-50,-100,0,0,90,0])},
			]
		},
		't':{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-100,0,0,0,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(200),},'offsetTransform':CreateOffset([0,-200,0,0,90,0])},
			]
		},
		'u':{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-100,0,0,90,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([50,-100,0,0,90,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,0,0,0,0,0])},
			]
		},
		'v':{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(112),},'offsetTransform':CreateOffset([-50,-100,0,0,63,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(112),},'offsetTransform':CreateOffset([50,-100,0,0,117,0])},
			]
		},
		'w':{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-100,0,0,90,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([50,-100,0,0,90,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-71),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,0,0,0,45,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(71),},'offsetTransform':CreateOffset([-50,0,0,0,-45,0])},
			]
		},
		'x':{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(142),},'offsetTransform':CreateOffset([-50,-100,0,0,45,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-142),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,-100,0,0,-45,0])},
			]
		},
		'y':{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(112),},'offsetTransform':CreateOffset([-50,-100,0,0,63.5,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-225),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,-100,0,0,-63.5,0])},
			]
		},
		'z':{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-100,0,0,0,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,0,0,0,0,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-141),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,-100,0,0,-45,0])},
			]
		},
		'1':{
			'offset':25,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([0,-100,0,0,90,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-50),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([0,-200,0,0,-45,0])},
			]
		},
		'2':{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,0,0,0,0,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-100,0,0,90,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,-100,0,0,0,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([50,-100,0,0,-90,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,-200,0,0,0,0])},
			]
		},
		'3':{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,0,0,0,0,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,-100,0,0,0,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([50,-100,0,0,-90,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,-200,0,0,0,0])},
			]
		},
		'4':{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([-50,-100,0,0,90,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,-100,0,0,0,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([50,-100,0,0,-90,0])},
			]
		},
		'5':{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,0,0,0,90,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([-50,-100,0,0,90,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,-100,0,0,0,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,-200,0,0,0,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,0,0,0,0,0])},
			]
		},
		'6':{
			'offset':50,
			'children':[
				{'setting':{'control_type':type2D,'minimum_value':Create2D([0,0]),'maximum_value':Create2D([100,100])},'offsetTransform':CreateOffset([50,-100,0,90,180,180])},		
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([-50,-100,0,0,90,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,-200,0,0,0,0])},
			]
		},
		'7':{
			'offset':50,
			'children':[	
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([50,-100,0,0,90,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,-200,0,0,0,0])},
			]
		},
		'8':{
			'offset':50,
			'children':[	
				{'setting':{'control_type':type2D,'minimum_value':Create2D([0,0]),'maximum_value':Create2D([100,100])},'offsetTransform':CreateOffset([50,-100,0,90,0,0])},	
				{'setting':{'control_type':type2D,'minimum_value':Create2D([0,0]),'maximum_value':Create2D([100,100])},'offsetTransform':CreateOffset([50,-200,0,90,180,180])},	
			]
		},
		'9':{
			'offset':50,
			'children':[
				{'setting':{'control_type':type2D,'minimum_value':Create2D([0,0]),'maximum_value':Create2D([100,100])},'offsetTransform':CreateOffset([50,-200,0,90,0,0])},		
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(0),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([50,-100,0,0,90,0])},
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,0,0,0,0,0])},
			]
		},
		'0':{
			'offset':50,
			'children':[
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([50,-100,0,0,90,0])},#1
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(100),},'offsetTransform':CreateOffset([-50,-100,0,0,90,0])},#2
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,0,0,0,0,0])},#3
				{'setting':{'control_type':typeFloat,'minimum_value':CreateFloat(-100),'maximum_value':CreateFloat(0),},'offsetTransform':CreateOffset([50,-200,0,0,0,0])},#4
			]
		},


	}
	if char in data:
		return(data[char])
	else:
		return(None)
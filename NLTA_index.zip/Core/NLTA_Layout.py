### CREATE NEW SEQUECE
import unreal
#Get the selected folder in Content Browser
selectedPaths = unreal.EditorUtilityLibrary.get_selected_asset_data()
#Fallback if no folder is selected default to /Game
folderPath = selected_path[0].package_path
#Set asset name
assetName = 'NewLevelSequece'
#Create asset using AssetTools
assetTools = unreal.AssetToolsHelpers.get_asset_tools()
sequence = assetTools.create_asset(
	asset_name = assetName,
	package_path = folderPath,
	asset_class = unreal.LevelSequece,
	factory = unreal.LevelSequeceFactoryNew() 
)
#Open the sequencer for the new asset
if sequence:
	unreal.AssetEditorSubsystem().open_editor_for_assets(['sequence'])


### BONE Constraint to camera
import unreal
selectedActors = unreal.EditorLevelLibrary.get_selected_level_actors()
skeletalActor = None
for actor in selectedActors:
	if isinstance(actor,unreal.SkeletalMeshActor):
		skeletalActor = actor
		break

if not skeletalActor:
	print("Khong tim thay SkeletalMeshAcor duoc chon")
else:
	camera_actor = unreal.EditorLevelLibrary.spawn_actor_from_class(unreal.CineCameraActor,[0,0,0])
	#Ten bone can gan, vi du head hoac lay bone cuoi bang cach khac
	boneName = "head"

	#
	bones = skeletal_comp.get_bone_names()
	print(bones)
	#

	#Attach camera vao bone
	skeletalComp = skeletalActor.get_editor_property('skeletal_mesh_component')
	cameraActor.attach_to_actor(
		parent_actor =skeletalActor,
		attachment_rude = unreal.AttachmentRule.SNAP_TO_TARGET,
		socket_name=boneName
	)
import unreal
import os
import shutil
import NLTA_general
from importlib import *


def OpenWindowByPath(assetPath):
	asset = unreal.EditorAssetLibrary.load_asset(assetPath)
	asset_tools = unreal.AssetToolsHelpers.get_asset_tools()
	asset_tools.open_editor_for_assets([asset])

def CloseWindow(asset):
	asset_editor_subsystem = unreal.get_editor_subsystem(unreal.AssetEditorSubsystem)
	asset_editor_subsystem.close_all_editors_for_asset(asset)

def SaveAssetByPath(assetPath):
	asset = unreal.EditorAssetLibrary.load_asset(assetPath)
	asset.modify(True)
	unreal.EditorAssetLibrary.save_asset(assetPath)

def SaveAsset(asset):
	assetPath = asset.get_path_name()
	asset.modify(True)
	unreal.EditorAssetLibrary.save_asset(assetPath)

def Selected():
	assets = unreal.EditorUtilityLibrary.get_selected_assets()
	if len(assets)!=0:
		return(assets)
	else:
		return(None)

def SelectedAsset():
	assets = unreal.EditorUtilityLibrary.get_selected_assets()
	if len(assets)!=0:
		return(assets)
	else:
		return(None)

def DeleteLocalAsset(asset_path):
    content_dir = unreal.Paths.convert_relative_path_to_full(unreal.Paths.project_content_dir())
    relative = asset_path.replace("/Game/", "").replace("/", os.sep)
    uasset = os.path.join(content_dir, relative + ".uasset")
    uexp = os.path.join(content_dir, relative + ".uexp")
    for f in [uasset, uexp]:
        if os.path.exists(f):
            os.remove(f)

def Delete(asset):
	assetPath = asset.get_path_name()
	unreal.EditorAssetLibrary.delete_asset(assetPath)
	DeleteLocalAsset(assetPath)

def FindAsset(name):
	assets = unreal.EditorAssetLibrary.list_assets("/Game/", recursive=True, include_folder=True)
	foundAsset = None
	for asset in assets:
		if asset.endswith(name):
			foundAsset = asset
			break
	return(foundAsset)

def FindAssetInPath(name,path):
	assets = unreal.EditorAssetLibrary.list_assets(path, recursive=True, include_folder=True)
	foundAsset = None
	for asset in assets:
		if asset.endswith(name):
			foundAsset = unreal.load_asset(asset)
			break
	return(foundAsset)

def Rename(inputData):
	asset = inputData["asset"]
	newName = inputData["newName"]
	path = inputData["path"]
	if asset:
		renameData = unreal.AssetRenameData(asset,path,newName)
		asset_tools = unreal.AssetToolsHelpers.get_asset_tools()
		result = asset_tools.rename_assets([renameData])

def GetAllAsset(type):
	assetRegistry = unreal.AssetRegistryHelpers.get_asset_registry()
	filter = unreal.ARFilter(
	    class_names=["AnimSequence"],
	    package_paths=["/Game"],
	    recursive_paths=True
	)
	return(assetRegistry.get_assets(filter))

def GetProjectPath():
	return(unreal.Paths.project_dir())

def ReloadBrowser(path):
	registry = unreal.AssetRegistryHelpers.get_asset_registry()
	registry.scan_paths_synchronous([path],True)
	unreal.EditorAssetLibrary.sync_browser_to_objects([path])

def GetLocalPath(asset):
	projectPath = GetProjectPath()
	assetPath = unreal.EditorAssetLibrary.get_path_name_for_loaded_asset(asset)
	assetPath = assetPath.replace('/Game','Content')
	assetPath = assetPath.split('.')[0]
	assetRealPath = projectPath + assetPath +'.uasset'
	return(assetRealPath)

def ReImportAll(inputData):
	fileType = inputData["fileType"]
	assets = GetAllAsset(fileType)
	for assetData in assets:
		assetPath = str(assetData.get_editor_property("package_path"))
		assetName = str(assetData.get_editor_property("asset_name"))
		assetPathTemp = assetPath+"/NLTA_Temp"
		asset = assetData.get_asset()
		fbxPath = asset.get_editor_property("asset_import_data").get_first_filename()

		if "NLTA_Fbxs" in fbxPath:
			if os.path.exists(fbxPath):
				unreal.EditorAssetLibrary.delete_directory(assetPathTemp)
				skeleton = asset.get_editor_property("skeleton")
				task = unreal.AssetImportTask()
				task.filename = fbxPath
				task.destination_path = assetPath+"/NLTA_Temp"
				task.destination_name = assetName+"_Temp"
				task.replace_existing = True
				task.replace_existing_settings = True
				task.automated = True
				task.save = True

				options = unreal.FbxImportUI()
				options.import_as_skeletal = False  # Set to True if importing a skeletal mesh
				options.import_materials = False
				options.import_textures = False		
				options.import_rigid_mesh = False
				options.import_mesh = False
				options.create_physics_asset = False
				options.import_animations = True
				options.skeleton = skeleton
				task.options = options
				unreal.AssetToolsHelpers.get_asset_tools().import_asset_tasks([task])
				anim1 = unreal.load_asset(FindAsset(assetName))
				anim2 = unreal.load_asset(FindAsset(assetName+"_Temp_Anim"))
				unreal.EditorAssetLibrary.consolidate_assets(anim2,[anim1])		
				unreal.EditorAssetLibrary.delete_asset(assetName)				
				Rename({
					"asset":anim2,
					"newName":assetName,
					"path":assetPath,
				})
				unreal.EditorAssetLibrary.save_asset(anim2, only_if_is_dirty=False)
				unreal.EditorAssetLibrary.delete_directory(assetPathTemp)
				os.remove(fbxPath)

def FindSkeletalMeshFromSkeleton(skeleton):
	asset_registry = unreal.AssetRegistryHelpers.get_asset_registry()
	class_path = unreal.TopLevelAssetPath('/Script/Engine','SkeletalMesh')
	skeletal_mesh_assets = asset_registry.get_assets_by_class(class_path,True)
	for asset_data in skeletal_mesh_assets:
		asset  = asset_data.get_asset()
		if asset.get_editor_property('skeleton') == skeleton:
			return(asset)
	return(None)

def ExportPattern(data):
	task = unreal.AssetExportTask()
	task.object =  data['asset']
	task.filename = data['filename']
	task.automated = True
	task.replace_identical = True
	task.prompt = False
	task.options = unreal.FbxExportOption()
	task.options.ascii = False
	task.options.level_of_detail = False
	return(task)

def ExportStaticMesh(data):
	data['filename'] = data['exportPath']+"/"+data['assetName']+'.fbx'
	task = ExportPattern(data)
	unreal.Exporter.run_asset_export_task(task)

def ExportAnimation(data):
	jsonPath = data['exportPath']+"/"+data['assetName']+'_NLTA_Json.json'
	skeleton = data['asset'].get_editor_property('skeleton')
	skeletonPath = unreal.EditorAssetLibrary.get_path_name_for_loaded_asset(skeleton)
	preview_mesh = FindSkeletalMeshFromSkeleton(skeleton)	
	skeletalMeshPath = unreal.EditorAssetLibrary.get_path_name_for_loaded_asset(preview_mesh)
	NLTA_general.writeJson(jsonPath,{
		'animation':data['assetPath'],
		'skeleton':skeletonPath,
		'skeletalMesh':skeletalMeshPath
	})

	#Export Animation
	data['filename'] = data['exportPath']+"/"+data['assetName']+'_NLTA_Animation.fbx'
	task = ExportPattern(data)
	unreal.Exporter.run_asset_export_task(task)

	#Export skeletalmesh
	data['asset'] = preview_mesh
	data['filename'] = data['exportPath']+"/"+data['assetName']+'_NLTA_SkeletalMesh.fbx'
	task = ExportPattern(data)
	unreal.Exporter.run_asset_export_task(task)
	
def CreateFolderFromPath(path):
	parts = path.strip('/').split('/')[0:-1]	
	currentPath = '/Game'
	for path in parts[1:]: #bo phan game vi no luon ton tai
		currentPath = currentPath+"/"+path
		if not unreal.EditorAssetLibrary.does_directory_exist(currentPath):
			unreal.EditorAssetLibrary.make_directory(currentPath)

def ExportAsset(path):
	exportFolder = path+"/ExportData"
	os.makedirs(exportFolder,exist_ok=True)
	assets = SelectedAsset()
	filterAsset = {}
	for asset in assets:	
		assetPath = unreal.EditorAssetLibrary.get_path_name_for_loaded_asset(asset)
		assetName = asset.get_name()
		if isinstance(asset,unreal.StaticMesh):
			exportPath = exportFolder+"/"+assetName+"_NLTA_StaticMesh"
		elif isinstance(asset,unreal.SkeletalMesh):
			exportPath = exportFolder+"/"+assetName+"_NLTA_SkeletalMesh"
		elif isinstance(asset,unreal.Texture):
			exportPath = exportFolder+"/"+assetName+"_NLTA_Texture"
		elif isinstance(asset,unreal.SoundWave):
			exportPath = exportFolder+"/"+assetName+"_NLTA_SoundWave"
		elif isinstance(asset,unreal.AnimSequence):
			exportPath = exportFolder+"/"+assetName+"_NLTA_AnimSequence"
		os.makedirs(exportPath,exist_ok=True)
		exportData = {
			'asset':asset,
			'assetName':assetName,
			'assetPath':assetPath,
			'exportPath':exportPath,
		}
		if isinstance(asset,unreal.StaticMesh):
			ExportStaticMesh(exportData)
		elif isinstance(asset,unreal.SkeletalMesh):
			ExportSkeletalMesh(exportData)
		elif isinstance(asset,unreal.Texture):
			ExportTexture(exportData)
		elif isinstance(asset,unreal.SoundWave):
			ExportSoundWave(exportData)
		elif isinstance(asset,unreal.AnimSequence):
			ExportAnimation(exportData)
		

def ImportPattern():
	task = unreal.AssetImportTask()
	task.automated = True
	task.replace_existing = True
	options = unreal.FbxImportUI()
	options.skeleton = None
	options.import_mesh = False
	options.import_as_skeletal = False
	options.import_animations = False
	options.import_materials = False
	options.create_physics_asset = False
	task.options = options
	return(task)

def ImportSkeletalMesh(data):
	task = ImportPattern()
	task.filename = data['fbx']
	task.destination_path = data['destination']
	task.destination_name = data['name']

	task.options.skeleton = None #Vi sao Skeletal moi
	task.options.import_mesh = True
	task.options.import_as_skeletal = True

	asset_tools = unreal.AssetToolsHelpers.get_asset_tools()
	asset_tools.import_asset_tasks([task])


def ImportAnimation(data):
	projectPath = GetProjectPath()

	jsonPath =  data['path']+'/'+data['folder']+'/'+data['name']+'_NLTA_Json.json'
	animationPath =  data['path']+'/'+data['folder']+'/'+data['name']+'_NLTA_Animation.fbx'
	skeletalPath = data['path']+'/'+data['folder']+'/'+data['name']+'_NLTA_SkeletalMesh.fbx'
	uassetPath = data['path']+'/'+data['folder']+'/'+data['name']+'.uasset'
	jsonData = NLTA_general.readJson(jsonPath)
	for key in jsonData:
		CreateFolderFromPath(jsonData[key])
	
	asset_tools = unreal.AssetToolsHelpers.get_asset_tools()
	skeleton_exists = unreal.EditorAssetLibrary.does_asset_exist(jsonData['skeleton'])
	if not skeleton_exists:
		ImportSkeletalMesh({
			'fbx':skeletalPath,
			'destination':("/").join(jsonData['skeletalMesh'].split('/')[0:-1]),
			'name':jsonData['skeletalMesh'].split('.')[-1]
		})

	destination_path = ("/").join(jsonData['animation'].split('/')[0:-1])
	destination_name = jsonData['animation'].split('.')[-1]
	skeleton = unreal.EditorAssetLibrary.load_asset(jsonData['skeleton'])

	task = ImportPattern()
	task.filename = animationPath
	task.destination_path = destination_path
	task.destination_name = destination_name
	task.options.skeleton = skeleton
	task.options.import_animations = True

	asset_tools = unreal.AssetToolsHelpers.get_asset_tools()
	asset_tools.import_asset_tasks([task])


def ImportAsset(path):
	folders = NLTA_general.getFolders(path)
	for folder in folders:
		if "_NLTA_" in folder:
			importType = folder.split("_NLTA_")[-1]
			name = folder.split("_NLTA_")[0]
			data = {
				'path':path,
				'folder':folder,
				'name':name
			}
			if importType == "AnimSequence":
				ImportAnimation(data)

def CloseAllEditorForAsset():
	#Đóng tất cả aset
	level_sequence = unreal.load_asset('/Game/MetaHumans/Taro/Audio/NLTATemp/NLTA_LevelSequence')
	subsystem = unreal.get_editor_subsystem(unreal.AssetEditorSubsystem)
	subsystem.close_all_editors_for_asset(level_sequence)
	
def OpenAllEditorForAsset():
	empty_sequence = unreal.load_asset("/Game/Cinematics/Empty")
	subsystem = unreal.get_editor_subsystem(unreal.AssetEditorSubsystem)
	subsystem.open_editor_for_assets([empty_sequence])



"""

def ImportAsset(fbx_file_path,destination_path,skeleton_path,anim_name):
	
	Import animation FBX vao Unreal, gan voi Skeleton da co	
	:param fbx_file_path: Duong dan toi file FBX (VD: D:/Export/Run.fbx)
	:param destination_path: Content path Unreal (VD: /Game/Animations)
	:param skeleton_path: Content path toi Skeleton (VD: /Game/Characters/Hero_Skeleton)
	:param anim_name: Ten file moi trong content browser (neu khong se lay theo ten file)

	

	asset_tools = unreal.AssetToolsHelpers.get_asset_tools()
	skeleton = unreal.EditorAssetLibrary.load_asset(skeleton_path)
	if not isinstance(skeleton.unreal.Skeleton):
		print(f'Skeleton khong hop le:{skeleton_path}')

	#Tao task
	task = unreal.AssetImportTask()
	task.filename = fbx_file_path
	task.destination_path = destination_path
	task.automated = True
	task.replace_existing = True
	task.prompt = False
	task.options = unreal.FbxImportUI()

	#Cau hinh import
	task.options.automated_import_should_detect_type = False
	task.options.import_animations = True
	task.options.import_mesh = False
	task.options.import_as_skeletal = True
	task.options.skeleton = skeleton

	if anim_name:
		task.destination_name = anim_name

	asset_tools.import_asset_tasks([task])

def smart_import_animation(fbx_file,destination_path,skeleton_path,asset_name):
	
	Import animation FBX, Nu skeleton da ton tai -> dung lai
	Neu khong co skeleton -> import ca mesh de tao moi
	:param fbx_files: File FBX animation (tren o dia)
	:param destination_path: Content folder der luu asset (VD: '/Game/Animations')
	:param skeleton_path: Path den Skeleton neu co (VD: '/Game/Characters/Hero_Skeleton')
	:param asset_name: ten dat cho animation asset (optional)
	
	asset_tools = unreal.AssetToolsHelpers.get_asset_tools()
	skeleton_exists = unreal.EditorAssetLibrary.does_asset_exist(skeleton_path)

	task = unreal.AssetImportTask()
	task.filename = fbx_file
	task.destination_path = destination_path
	task.automated = True
	task.replace_existing = True
	task.prompt = False
	task.options = unreal.FbxImportUI()

	#Cau hinh tuy theo skeleton co hay khong
	task.options.automated_import_should_detect_type = False
	task.options.import_as_skeletal = True
	task.options.import_animations = True

	if skeleton_exists:
		#Dung skeletal co san khong import mesh
		taks.options.import_mesh = False
		skeleton_asset = unreal.EditorAssetLibrary.load_asset(skeleton_path)
		task_options.skeleton = skeleton_asset
	else:
		#Import ca mesh de tao skeleton moi
		task.options.import_mesh = True
		task.options.skeleton = None

	if asset_name:
		task.destination_name = asset_name

	#Thuc thi import
	asset_tools.import_asset_tasks([task])


def export_anim_and_skeletal_mesh(anim_path:str,mesh_path:str,export_dir:str):
	
	Export car AnimSequce va SkeletalMesh ra FBX
	:param aim_path: Path den AnimSequence (VD: "/Game/Animations/Idle")
	:param mesh_path: Path den SkeletalMesh (VD: "/Game/Character/HeroMesh")
	:param export_dir: Folder export ra o cung (VD: "D:/Exports/Idle")
	
	os.makedirs(export_dir,exist_ok=True)
"""



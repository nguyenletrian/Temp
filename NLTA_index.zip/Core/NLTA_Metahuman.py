import unreal

calibration_generator = unreal.MetaHumanCalibrationGenerator()
calibration_generator.process(capture_data_asset, calibration_generator_options)

calibration_generator_options = unreal.MetaHumanCalibrationGeneratorOptions()
calibration_generator_options.package_path.path = '/Game/GenerateCalibration/'
calibration_generator_options.auto_save_assets = True   # Set by default
calibration_generator_options.sample_rate = 30          # Set by default
calibration_generator_options.board_pattern_width = 15  # Set by default
calibration_generator_options.board_pattern_height = 10 # Set by default
calibration_generator_options.board_square_size = 0.75  # Set by default
calibration_generator_options.sharpness_threshold = 5.0 # Set by default

#".\UnrealEditor.exe "MyProject.uproject" -ExecutePythonScript="<path-to_ue-installation>/Engine/Plugins/MetaHuman/MetaHumanAnimator/Content/DepthGenerator/depth_generator_example.py --cd-package-path /Game/CaptureManager/Imports/ExampleTake/CD_Example"




















"""

#Code có sai
captureSource = unreal.load_asset('/Game/MH_CS')
captureSource.set_target_path('/Game/MH_CS_Ingested/','/Game/MH_CS_Ingested')
takesList = [0]
MHA_GetTakesCallback = unreal.MetaHumanCaptureSource_GetTakesCallbackPerTake()
captureSource.get_takes(takesList,MHA_GetTakesCallback)
captureSource.startup(mode=unreal.TakeIngestMode.ASYNC)

captureSource = unreal.load_asset('/Game/MH_CS')
captureSource.set_target_path('/Game/MH_CS_Ingested/','/Game/MH_CS_Ingested')
takesList = [0]

def process_takes(takes):
	for take in takes:
		take_index = take.get_editor_property('take_index')
		take_info = captureSource.get_take_info(take_index=take_index)
		#Then you can use take_info to create a CaptureData
#Register a callback that will be called when takes are ready
captureSource.on_get_takes_finished_dynamic_delegate.add_callable(process_takes)
#Call startup to parse the folder you have set in the capture source
captureSource.startup(mode=unreal.TakeIngestMode.SYNC)#unreal.TakeIngestMode.BLOCKING
#This will call the function process_takes
captureSource.get_takes(takesList)

##############
captureSource = unreal.load_asset('/Game/MH_CS')
takesList = [0]

def process_takes():
	print('Takes ingested')

captureSource.startup(mode=unreal.TakeIngestMode.ASYNC)
captureSource.set_target_path('c:/Unreal Projects/ProjectName/Content/MH_CS_Ingested','/Game/MH_CS_Ingested/')
captureSource.on_get_takes_finished_dynamic_delegate.add_callable(process_takes)
captureSource.get_takes(takesList,unreal.MetaHumanCaptureSource_GetTakesCallbackPerTake())


import unreal

# Path to your MetaHuman Performance asset
metahuman_performance_path = "/Game/YourProject/YourMetaHumanPerformanceAsset" 

# Load the MetaHuman Performance asset
metahuman_performance = unreal.load_asset(metahuman_performance_path)

# Define the export range (e.g., whole sequence)
export_range = unreal.WHOLE_SEQUENCE 

if metahuman_performance:
    try:
        # Export the animation
        metahuman_performance.export_animation(export_range)
        unreal.log("MetaHuman performance animation exported successfully.")
    except Exception as e:
        unreal.log_error(f"Error exporting MetaHuman performance animation: {e}")
else:
    unreal.log_error(f"MetaHuman Performance asset not found at: {metahuman_performance_path}")


import unreal

# Load Level Sequence and MetaHuman actor
sequence = unreal.load_asset("/Game/Cinematics/MySequence")
metahuman_actor = unreal.EditorLevelLibrary.get_actor_reference("MetaHuman_BP_C_0")

# Bind actor to sequence
binding = sequence.add_possessable(metahuman_actor)
sequence.set_binding_display_name(binding, "MetaHuman_Performance")

# Access the movie scene
movie_scene = sequence.get_movie_scene()

# Add a control rig track to the binding
control_rig_track = movie_scene.add_control_rig_track(binding)

# Optionally assign a facial control rig asset
facial_rig = unreal.load_asset("/Game/MetaHumans/Common/ControlRigs/Face_ControlRig")
control_rig_track.set_control_rig(facial_rig)

# Get facial controls
for section in control_rig_track.get_sections():
    for channel in section.get_channels():
        print("Control:", channel.get_name())
        for key in channel.get_keys():
            print(f"    Time: {key.time.frame_number.value}, Value: {key.value}")

# Load sequence
sequence = unreal.load_asset("/Game/Cinematics/MySequence")

# Evaluate sequence at every frame (e.g. 0 to 300)
for frame in range(0, 300):
    time = unreal.FrameNumber(frame)
    unreal.SequencerTools.evaluate_sequence_at_frame(sequence, time)

import json

export_data = {}
for binding in sequence.get_bindings():
    for track in binding.get_tracks():
        if isinstance(track, unreal.MovieSceneControlRigParameterTrack):
            for section in track.get_sections():
                for channel in section.get_channels():
                    keys = channel.get_keys()
                    export_data[channel.get_name()] = [
                        {"time": key.time.frame_number.value, "value": key.value}
                        for key in keys
                    ]

# Write to JSON
with open("C:/UnrealExports/facial_performance.json", "w") as f:
    json.dump(export_data, f, indent=2)
"""
import unreal

#Đường dẫn đến Niagara System (asset path phải đúng!)
NIAGARA_ASSET_PATH  = "/Game/FX/RainSystem.RainSystem"

def spawn_niagara_effect(location=unreal.Vector(0,0,200),scale=unreal.Vector(1,1,1)):
	#Load Niagara asset
	niagara_asset = unreal.load_asset(NIAGARA_ASSET_PATH)
	if not niagara_asset:
		print("Lỗi")
		return()

	#Spawn Niagara actor vào level
	niagara_actor = unreal.EditorLevelLibrary.spaw_actor_from_class(unreal.NiagaraActor,location)

	#Gán Niagara system vào actor
	niagara_component = niagara_actor.get_editor_property("niagara_component")
	niagara_component.set_editor_property("asset",niagara_asset)
	niagara_component.set_editor_property("auto_active",True)
	niagara_component.active()

	#Set scale
	niagara_actor.set_actor_scale3d(scale)

	unreal.log("Done")
#spawn_niagara_effect(unreal.Vector(0,0,300))
import unreal

def GetAll():
	returnArray = []
	assetRegistry = unreal.AssetRegistryHelpers.get_asset_registry()
	filter = unreal.ARFilter(
		class_names =['/Script/Engine.Material'],
		package_paths =['/Game'],
		recursive_paths=True,
	)
	assetDatas = assetRegistry.get_assets(filter)
	for assetData in assetDatas:
		returnArray.append({
			'name':str(assetData.asset_name),
			'path':assetData.package_name,
		})
	return(returnArray)

def GetAssetByName(inputName):
	assets = GetAll()
	for i in range(len(assets)):
		name = assets[i]["name"]
		if inputName == name:			
			return(unreal.load_asset(assets[i]['path']))
	return(None)

def CheckExist(inputName):
	assets = GetAll()
	for i in range(len(assets)):
		name = assets[i]["name"]
		if inputName == name:			
			return(True)
	return(None)


def SetByPath(assetPath,materialPath):
	asset = unreal.load_asset(assetPath)
	material = unreal.load_asset(materialPath)
	asset.set_material_interface(0, material)
	unreal.EditorAssetLibrary.save_loaded_asset(asset)

def SetByAsset(skeletalMesh,materialAsset):
	material_array = unreal.Array(unreal.SkeletalMaterial)
	materials = skeletalMesh.materials	
	for material in materials:
		oldSlotName = material.get_editor_property("material_slot_name")
		newMaterial = unreal.SkeletalMaterial()
		newMaterial.set_editor_property("material_interface",materialAsset)
		newMaterial.set_editor_property("material_slot_name",oldSlotName)
		material_array.append(newMaterial)
	skeletalMesh.set_editor_property("materials",material_array)

def SetByName(skeletalMesh,materialName):
	materialAsset = unreal.load_asset(GetAssetByName(materialName))
	material_array = unreal.Array(unreal.SkeletalMaterial)
	materials = skeletalMesh.materials
	for material in materials:
		oldSlotName = material.get_editor_property("material_slot_name")
		newMaterial = unreal.SkeletalMaterial()
		newMaterial.set_editor_property("material_interface",materialAsset)
		newMaterial.set_editor_property("material_slot_name",oldSlotName)
		material_array.append(newMaterial)
	skeletalMesh.set_editor_property("materials",material_array)

def CopyStaticToSkeletalMesh(assetSource,assetTarget):
	material_array = unreal.Array(unreal.SkeletalMaterial)
	materials = assetSource.static_materials
	for material in materials:
		materialInterface = material.material_interface
		oldSlotName = material.get_editor_property("material_slot_name")
		newMaterial = unreal.SkeletalMaterial()
		newMaterial.set_editor_property("material_interface",materialInterface)
		newMaterial.set_editor_property("material_slot_name",oldSlotName)
		material_array.append(newMaterial)
	assetTarget.set_editor_property("materials",material_array)

def CopyStaticToSkeletalMeshEye(assetSource,assetTarget):
	material_array = unreal.Array(unreal.SkeletalMaterial)
	materials = assetSource.static_materials
	for material in materials:
		oldSlotName = material.get_editor_property("material_slot_name")
		oldSlotNameString = str(oldSlotName)
		if ("Eye_line_" in oldSlotNameString) or ("Eye_Iris_" in oldSlotNameString):
			materialInterface = material.material_interface		
			newMaterial = unreal.SkeletalMaterial()
			newMaterial.set_editor_property("material_interface",materialInterface)
			newMaterial.set_editor_property("material_slot_name",oldSlotName)
			material_array.append(newMaterial)
	assetTarget.set_editor_property("materials",material_array)
	



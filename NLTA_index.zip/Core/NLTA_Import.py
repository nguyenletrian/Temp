"""
unreal.FbxImportUI
unreal.FbxMeshImportData.normal_import_method
unreal.FbxAssetImportData
unreal.FBXNormalImportMethod
unreal.FbxSkeletalMeshImportData
"""
import unreal
def ImportPattern():
	task = unreal.AssetImportTask()
	task.automated = True
	task.replace_existing = True
	options = unreal.FbxImportUI()	
	options.import_mesh = False
	options.import_as_skeletal = False
	options.import_animations = False
	options.import_materials = False
	options.import_textures = False
	options.create_physics_asset = False
	options.skeleton = None
	task.options = options
	return(task)

def ImportSkeletalMesh(data):
	task = ImportPattern()
	task.filename = data['fbx']
	task.destination_path = data['destination']
	task.destination_name = data['name']
	if 'skeleton' in data:
		pass
		#task.options.skeleton = 	

	#task.options.skeleton = False #Vi sao Skeletal moi
	task.options.import_mesh = True
	task.options.import_as_skeletal = True

	task.options.skeletal_mesh_import_data = unreal.FbxSkeletalMeshImportData()
	task.options.skeletal_mesh_import_data.normal_generation_method = unreal.FBXNormalGenerationMethod.MIKK_T_SPACE
	task.options.skeletal_mesh_import_data.vertex_color_import_option = unreal.VertexColorImportOption.REPLACE
	task.options.skeletal_mesh_import_data.normal_import_method = unreal.FBXNormalImportMethod.FBXNIM_IMPORT_NORMALS

	asset_tools = unreal.AssetToolsHelpers.get_asset_tools()
	asset_tools.import_asset_tasks([task])


def ImportAnimation(data):
	projectPath = GetProjectPath()

	jsonPath =  data['path']+'/'+data['folder']+'/'+data['name']+'_NLTA_Json.json'
	animationPath =  data['path']+'/'+data['folder']+'/'+data['name']+'_NLTA_Animation.fbx'
	skeletalPath = data['path']+'/'+data['folder']+'/'+data['name']+'_NLTA_SkeletalMesh.fbx'
	uassetPath = data['path']+'/'+data['folder']+'/'+data['name']+'.uasset'
	jsonData = NLTA_general.readJson(jsonPath)
	for key in jsonData:
		CreateFolderFromPath(jsonData[key])
	
	asset_tools = unreal.AssetToolsHelpers.get_asset_tools()
	skeleton_exists = unreal.EditorAssetLibrary.does_asset_exist(jsonData['skeleton'])
	if not skeleton_exists:
		ImportSkeletalMesh({
			'fbx':skeletalPath,
			'destination':("/").join(jsonData['skeletalMesh'].split('/')[0:-1]),
			'name':jsonData['skeletalMesh'].split('.')[-1]
		})

	destination_path = ("/").join(jsonData['animation'].split('/')[0:-1])
	destination_name = jsonData['animation'].split('.')[-1]
	skeleton = unreal.EditorAssetLibrary.load_asset(jsonData['skeleton'])

	task = ImportPattern()
	task.filename = animationPath
	task.destination_path = destination_path
	task.destination_name = destination_name
	task.options.skeleton = skeleton
	task.options.import_animations = True

	asset_tools = unreal.AssetToolsHelpers.get_asset_tools()
	asset_tools.import_asset_tasks([task])


def ImportAsset(path):
	folders = NLTA_general.getFolders(path)
	for folder in folders:
		if "_NLTA_" in folder:
			importType = folder.split("_NLTA_")[-1]
			name = folder.split("_NLTA_")[0]
			data = {
				'path':path,
				'folder':folder,
				'name':name
			}
			if importType == "AnimSequence":
				ImportAnimation(data)
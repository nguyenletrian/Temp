import unreal
import os
import shutil
import math
from datetime import datetime
from importlib import *
import NLTA_general as NLTA_general
reload(NLTA_general)
import NLTA_Actor as NLTA_Actor
reload(NLTA_Actor)

session = {}

NLTA_general.CheckVersion()

def getSequenceData():
	data = {}
	sequence = unreal.LevelSequenceEditorBlueprintLibrary.get_current_level_sequence()
	if sequence:
		tracksSelected = unreal.LevelSequenceEditorBlueprintLibrary.get_selected_tracks()
		data["sequence"] = sequence
		data["bindings"] = []
		data["tracks"] = []
		data["sections"] = []
		data["channels"] = []
		data["keys"] = []
		data["controlRigs"] = []
		rigs = unreal.ControlRigSequencerLibrary.get_control_rigs(sequence)
		bindings = sequence.get_bindings()
		for binding in bindings:
			data["bindings"].append(
				{
					"data":binding
				}
			)
			#DATA FOR TRACK
			tracks = binding.get_tracks()
			for track in tracks:
				trackTemp = {
					"binding":binding,
					"data":track
				}
				controlRig = None
				selectedControls = None
				for rig in rigs:
					if track == rig.get_editor_property("track"):
						controlRig = rig.control_rig
						selectedControls = rig.control_rig.current_control_selection()	
				if controlRig:
					trackTemp["controlRig"] = controlRig
					trackTemp["controls"] = controlRig.get_hierarchy().get_controls()
				if selectedControls:
					trackTemp["selectedControls"] = selectedControls					
					trackTemp["selected"] = True
				if track in tracksSelected:
					trackTemp["selected"] = True
				data["tracks"].append(trackTemp)

				#DATA FOR SECTIONS
				sections = track.get_sections()
				for section in sections:
					data["sections"].append(
						{							
							"binding":binding,
							"track":track,
							"data":section
						}
					)

					#DATA FOR CHANNEL
					channels = section.get_all_channels()
					for channel in channels:						
						channelName = str(channel.get_editor_property("channel_name"))
						controlName = channelName.split(".")[0]
						channelTemp = {
							"binding":binding,
							"track":track,
							"section":section,
							"channelName":channelName,
							"controlName":controlName,
							"data":channel,
						}
						channelSelected = None
						if selectedControls:
							if controlName in selectedControls:
								channelSelected = True
								channelTemp["selected"] = True
						data["channels"].append(channelTemp)

						#DATA FOR KEY
						keys = channel.get_keys()
						for key in keys:
							keyTemp = {
								"binding":binding,
								"track":track,
								"controlRig":controlRig,
								"section":section,
								"channel":channel,								
								"channelName":channelName,
								"control":controlName,
								"data":key,
							}							
							if isinstance(key,unreal.MovieSceneScriptingActualFloatKey):
								keyTemp["type"]="float"
							elif  isinstance(key,unreal.MovieSceneScriptingBoolKey):
								keyTemp["type"]="bool"
							if channelSelected:
								keyTemp["selected"]=True
							data["keys"].append(keyTemp)
		return(data)
	else:
		return(None)

def ExportAnimationToMaya():
	data = getSequenceData()
	frameStart = data["sequence"].get_playback_start()
	frameEnd = data["sequence"].get_playback_end()
	animationData={}

	for order in range(len(data["keys"])):
		key = data["keys"][order]
		if "selected" in key:
			channelName = data["keys"][order]["channelName"]
			if channelName not in animationData:
				animationData[channelName]={
					"keyOrder":[],
					"keyValue":{}
				}
			frame = key["data"].get_time().get_editor_property("frame_number").get_editor_property("value")
			if (frame >= frameStart) and (frame <= frameEnd):
				if frame not in animationData[channelName]["keyOrder"]:
					animationData[channelName]["keyOrder"].append(frame)
				if key["type"]=="float":
					animationData[channelName]["type"] = "float"				
					animationData[channelName]["keyValue"][frame] = {
						"value":key["data"].get_value(),
						"arrive_tangent":key["data"].get_arrive_tangent(),
						"arrive_tangent_weight":key["data"].get_arrive_tangent_weight(),
						"interpolation_mode":str(key["data"].get_interpolation_mode().get_display_name()),
						"leave_tangent":key["data"].get_leave_tangent(),
						"leave_tangent_weight":key["data"].get_leave_tangent_weight(),
						"tangent_mode":str(key["data"].get_tangent_mode().get_display_name()),
						"tangent_weight_mode":str(key["data"].get_tangent_weight_mode().get_display_name())
					}			
				elif key["type"]=="bool":
					animationData[channelName]["type"] = "bool"
					animationData[channelName]["keyValue"][frame] = {
						"value":key["data"].get_value()
					}	
			animationData[channelName]["keyOrder"].sort()
	return({
		"data":animationData,
		"controls":GetControlSelected()
	})

def DeleteBindingByName(name):
	data = getSequenceData()
	if data!=None:
		if "bindings" in data:
			for order in range(len(data["bindings"])):
				binding = data["bindings"][order]["data"]
				if binding.get_display_name() == name:
					NLTA_general.DeleteObj(binding)

def findMirrorControl(data):
	controlRig = data["controlRig"]
	controlName = data["controlName"]
	right = data["right"]
	left = data["left"]
	mirrorControlName = False
	if right in controlName:
		mirrorControlName = controlName.replace(right,left)
	if left in controlName:
		mirrorControlName = controlName.replace(left,right)
	allControls =  controlRig.get_hierarchy().get_controls()
	for control in allControls:
		if mirrorControlName == control.name:
			return(control)
	return(False)

def SelectBindingControls():
	data = getSequenceData() 
	unreal.LevelSequenceEditorBlueprintLibrary.empty_selection()
	for order in range(len(data["tracks"])):
		if ("selected" in data["tracks"][order]) or ("selectedControls" in data["tracks"][order]):
			controlRig =  data["tracks"][order]["controlRig"]
			controls = data["tracks"][order]["controls"]
			for control in controls:
				controlRig.select_control(control.get_editor_property("name"))

def ZeroTransform():
	data = getSequenceData()
	current_frame = unreal.FrameNumber(unreal.LevelSequenceEditorBlueprintLibrary.get_current_time())

	for order in range(len(data["tracks"])):
		if "selectedControls" in data["tracks"][order]:
			for control in data["tracks"][order]["selectedControls"]:
				controlRig = data["tracks"][order]["controlRig"]
				controlRigHierarchy = controlRig.get_hierarchy().get_controller()				
				controlType = controlRigHierarchy.get_control_settings(unreal.RigElementKey(type=unreal.RigElementType.CONTROL, name=control)).control_type
				if controlType == unreal.RigControlType.EULER_TRANSFORM:
					transform = unreal.EulerTransform(location=[0.0,0.0,0.0],rotation=[0.0,0.0,0.0],scale=[1,1,1])
					unreal.ControlRigSequencerLibrary.set_local_control_rig_euler_transform(
						data["sequence"],controlRig,control,current_frame,transform,set_key=False
					)
				elif controlType == unreal.RigControlType.FLOAT:
					unreal.ControlRigSequencerLibrary.set_local_control_rig_float(
						data["sequence"],controlRig,control,current_frame,0,set_key=False
					)
				elif controlType == unreal.RigControlType.VECTOR2D:
					unreal.ControlRigSequencerLibrary.set_local_control_rig_vector2d(
						data["sequence"],controlRig,control,current_frame,unreal.Vector2D(x=0,y=0),set_key=False
					)

def GetControlWorldTransform(control):
	data = getSequenceData()
	controlRig = GetControlRigFromSeletedControl()
	current_frame = unreal.FrameNumber(unreal.LevelSequenceEditorBlueprintLibrary.get_current_time())
	return(
		unreal.ControlRigSequencerLibrary.get_control_rig_world_transform(
			data["sequence"],controlRig,control,current_frame
		)
	)

def AddKeyWorldTransform(control,transform):
	data = getSequenceData()
	controlRig = GetControlRigFromSeletedControl()
	current_frame = unreal.FrameNumber(unreal.LevelSequenceEditorBlueprintLibrary.get_current_time())
	unreal.ControlRigSequencerLibrary.set_control_rig_world_transform(
		data["sequence"],controlRig,control,current_frame,transform,set_key=True
	)

def GetBoolValue(control):
	data = getSequenceData()
	controlRig = GetControlRigFromSeletedControl()
	current_frame = unreal.FrameNumber(unreal.LevelSequenceEditorBlueprintLibrary.get_current_time())
	return(
		unreal.ControlRigSequencerLibrary.get_local_control_rig_bool(
			data["sequence"],controlRig,control,current_frame
		)
	)

def AddKeyBool(control,value):
	data = getSequenceData()
	controlRig = GetControlRigFromSeletedControl()
	current_frame = unreal.FrameNumber(unreal.LevelSequenceEditorBlueprintLibrary.get_current_time())
	return(
		unreal.ControlRigSequencerLibrary.set_local_control_rig_bool(
			data["sequence"],controlRig,control,current_frame,value,set_key=True
		)
	)

def SelectControls(controlArray):
	data = getSequenceData()
	for order in range(len(data["tracks"])):
		if "selectedControls" in data["tracks"][order]:
			controlRig = data["tracks"][order]["controlRig"]
			controlRig.clear_control_selection()
			for control in controlArray:
				controlRig.select_control(control)


def GetControlSelected():
	data = getSequenceData()
	allControl = []
	for order in range(len(data["tracks"])):
		trackData = data["tracks"][order]
		if "selectedControls" in trackData:
			for control in trackData["selectedControls"]:
				if control not in allControl:
					if str(control) not in allControl:
						allControl.append(str(control))
	if len(allControl)!=0:
		return(allControl)
	else:
		return(None)

def GetBindingFromSeletedControl():
	data = getSequenceData()
	if data['tracks']:
		for order in range(len(data["tracks"])):
			trackData = data["tracks"][order]
			if "selectedControls" in trackData:
				return(data['tracks'][order]['binding'])
	return(None)

def GetActorFromSeletedControl():
	data = getSequenceData()
	if data['tracks']:
		for order in range(len(data["tracks"])):
			trackData = data["tracks"][order]
			if "selectedControls" in trackData:
				binding = data['tracks'][order]['binding']
				return(NLTA_Actor.GetActorByName(binding.get_display_name()))
	return(None)

def GetControlRigFromSeletedControl():
	data = getSequenceData()
	if data['tracks']:
		for order in range(len(data["tracks"])):
			trackData = data["tracks"][order]
			if "selectedControls" in trackData:
				return(data['tracks'][order]['controlRig'])
	return(None)

def GetBonesFromSelectedControl():
	controlRig = GetControlRigFromSeletedControl()
	hierarchy = controlRig.get_hierarchy()
	bonesArray = []
	bones = hierarchy.get_bones()
	for bone in bones:
		boneName = unreal.StringLibrary.conv_name_to_string(bone.name)
		bonesArray.append(boneName)
	return(bonesArray)

def GetControlsFromSelectedControl():
	controlRig = GetControlRigFromSeletedControl()
	hierarchy = controlRig.get_hierarchy()
	controlsArray = []
	controls = hierarchy.get_controls()
	for control in controls:
		controlName = unreal.StringLibrary.conv_name_to_string(control.name)
		controlsArray.append(controlName)
	return(controlsArray)

def GetTrackFromSeletedControl():
	data = getSequenceData()
	if data['tracks']:
		for order in range(len(data["tracks"])):
			trackData = data["tracks"][order]
			if "selectedControls" in trackData:
				return(data['tracks'][order]['data'])
	return(None)


def Constraint(data):
	world = unreal.EditorLevelLibrary().get_editor_world()
	constraintLib = unreal.ConstraintsScriptingLibrary()	
	parentData = data["parent"]
	childData = data["child"]
	maintain = data["maintain"]	

	if "control" in parentData:
		parent_handle = parentData["controlRig"].create_transformable_control_handle(world,parentData["control"])
	else:
		parent_handle = constraintLib.create_transformable_component_handle(world,parentData["object"].root_component,"")
	if "control" in childData:
		child_handle = childData["controlRig"].create_transformable_control_handle(world,childData["control"])
	else:
		child_handle = constraintLib.create_transformable_component_handle(world,childData["object"].root_component,"")

	if data["type"] == "parent":
		parentConstraint = constraintLib.create_from_type(world,unreal.TransformConstraintType.PARENT)
	elif data["type"] == "rotation":
		parentConstraint = constraintLib.create_from_type(world,unreal.TransformConstraintType.ROTATION)
	elif data["type"] == "scale":
		parentConstraint = constraintLib.create_from_type(world,unreal.TransformConstraintType.SCALE)
	elif data["type"] == "translation":
		parentConstraint = constraintLib.create_from_type(world,unreal.TransformConstraintType.TRANSLATION)
	elif data["type"] == "arm":
		parentConstraint = constraintLib.create_from_type(world,unreal.TransformConstraintType.LOOK_AT)

	constraintLib.add_constraint(world,parent_handle,child_handle,parentConstraint,maintain)
	return({
		"world":world,
		"constraintLib":constraintLib,
		"constraint":parentConstraint
	})

	"""
	constraintData = ConstraintParent({
		"parent":{"object":rotataOrderCube},
		"child":{"control":mirrorControl,"controlRig":controlRig},
		"maintain":True
	})
	#constaint["constraint"].set_editor_property("active",False)
	#constraintData["constraintLib"].remove_this_constraint(constraintData["world"],constraintData["constraint"])
	#parentTransform = resultOffset.get_actor_transform()
	#childTransform = rotataOrderCube.get_actor_transform()
	#childOffset = unreal.Transform.make_relative(childTransform,parentTransform)
	"""


def GetCurrentViewTransform(data):
	if "sequence" in data:
		version = NLTA_general.CheckVersion()
		if version ==  "5.3":
			sequence =  data["sequence"]
			masterTrackExist = sequence.get_master_tracks()
			sequenceEditor = unreal.get_editor_subsystem(unreal.LevelSequenceEditorSubsystem)
			cameraDistance = sequenceEditor.create_camera(spawnable = True)	
			cameraDistanceBinding = cameraDistance[0]
			cameraDistanceActor = cameraDistance[1]
			cameraDistanceTransform = cameraDistanceActor.get_actor_transform()		
			cameraDistanceActor.destroy_actor()
			cameraDistanceBinding.remove()
			if len(masterTrackExist)==0:
				sequence.remove_master_track(sequence.get_master_tracks()[0])
			return(cameraDistanceTransform)
		elif version == "5.5":
			sequence =  data["sequence"]
			sequenceEditor = unreal.get_editor_subsystem(unreal.LevelSequenceEditorSubsystem)
			cameraDistance = sequenceEditor.create_camera(spawnable = True)	
			cameraDistanceBinding = cameraDistance[0]
			cameraDistanceActor = cameraDistance[1]
			cameraDistanceTransform = cameraDistanceActor.get_actor_transform()		
			cameraDistanceActor.destroy_actor()
			cameraDistanceBinding.remove()
			return(cameraDistanceTransform)


def GetControlData(data):
	currentTime = unreal.LevelSequenceEditorBlueprintLibrary.get_current_time()
	currentFrame = unreal.FrameNumber(currentTime)
	sequence = data["sequence"]
	for order in range(len(data["tracks"])):
		trackData = data["tracks"][order]
		if "selectedControls" in trackData:
			control =  trackData["selectedControls"][0]
			controlRig = trackData["controlRig"]
			controlTransform = unreal.ControlRigSequencerLibrary.get_control_rig_world_transform(
				sequence,
				controlRig,
				control,
				currentFrame,
				NLTA_general.TimeUnit()
			)
			return({
				"transform":controlTransform,
				"controlRig":controlRig,
				"name":str(control)
			})
	return(None)



def RemoveConstraintParent(data):
	data["constraintLib"].remove_this_constraint(data["world"],data["constraint"])

def GetMirrorPlane(inputData):
	right = inputData["right"]
	left = inputData["left"]

	world = unreal.EditorLevelLibrary().get_editor_world()
	data = getSequenceData()	
	SelectBindingControls()
	ZeroTransform()
	if data["sequence"]:
		sequence = data["sequence"]
		currentTime = unreal.LevelSequenceEditorBlueprintLibrary.get_current_time()
		currentFrame = unreal.FrameNumber(currentTime)
		mirrorControl = None
		for order in range(len(data["tracks"])):
			if "selected" in data["tracks"][order]:
				trackData = data["tracks"][order]
				bindingName = trackData["binding"].get_display_name()
				if bindingName:
					actors = unreal.EditorLevelLibrary.get_all_level_actors()
					for actor in actors:
						actorName = actor.get_actor_label()
						if actorName == bindingName:
							ControlRigActor = actor

					if "selectedControls" in  trackData:
						control = trackData["selectedControls"][0]
						if control:
							controlRig = trackData["controlRig"]
							controlTransform = unreal.ControlRigSequencerLibrary.get_control_rig_world_transform(
								sequence,
								controlRig,
								control,
								currentFrame
							)					
							mirrorControl = findMirrorControl({
								"controlRig":controlRig,
								"controlName":str(control),
								"right":right,
								"left":left
							})
		if mirrorControl:
			mirrorTransform = unreal.ControlRigSequencerLibrary.get_control_rig_world_transform(
				sequence,
				controlRig,
				mirrorControl.name,
				currentFrame,
				NLTA_general.TimeUnit()
			)
			MirrorCube = NLTA_Actor.AddCube()
			NLTA_Actor.AttachActor(MirrorCube,ControlRigActor,True)
			offsetMirrorCube = NLTA_Actor.AddCube()
			offsetMirrorCube.set_actor_transform(controlTransform,False,False)
			offsetMirrorCube.set_actor_label("offsetMirrorCube")
			NLTA_Actor.AttachActor(offsetMirrorCube,MirrorCube,False)
			mirrorCube = NLTA_Actor.AddCube()
			mirrorCube.set_actor_transform(controlTransform,False,False)
			mirrorCube.set_actor_label("mirrorCube")
			NLTA_Actor.AttachActor(mirrorCube,offsetMirrorCube,False)

			mirrorPlane = None
			difference = 1
			for axis in [
				unreal.Vector(-1,1,1),
				unreal.Vector(1,-1,1),
				unreal.Vector(1,1,-1)
			]:
				MirrorCube.set_actor_scale3d(axis)
				transformTemp = mirrorCube.get_actor_transform()
				if (
					mirrorTransform.translation.x - difference <= transformTemp.translation.x <= mirrorTransform.translation.x + difference and
					mirrorTransform.translation.y - difference <= transformTemp.translation.y <= mirrorTransform.translation.y + difference and
					mirrorTransform.translation.z - difference <= transformTemp.translation.z <= mirrorTransform.translation.z + difference
				):
					mirrorPlane = axis
					break
			MirrorCube.destroy_actor()
			offsetMirrorCube.destroy_actor()	
			mirrorCube.destroy_actor()
			SelectControls([control])
			return([axis.x,axis.y,axis.z])
		else:
			return(False)

def AddMirrorSetting(inputData):
	right = inputData["right"]
	left = inputData["left"]
	url = inputData["url"]
	mirrorData = NLTA_general.readJson(url)
	mirrorPlane = inputData["mirrorPlane"]
	axisArray = ["X","Y","Z","X","Y","Z"]
	cbxArray = ["+X","+Y","+Z","-X","-Y","-Z"]
	channelArray = ["Location.X","Location.Y","Location.Z","Rotation.X","Rotation.Y","Rotation.Z"]
	if mirrorPlane:
		data = getSequenceData()
		sequence = data["sequence"]
		currentTime = unreal.LevelSequenceEditorBlueprintLibrary.get_current_time()
		currentFrame = unreal.FrameNumber(currentTime)		
		SelectBindingControls()
		ZeroTransform()
		for order in range(len(data["tracks"])):
			if "selected" in data["tracks"][order]:
				trackData = data["tracks"][order]
				if "selectedControls" in  trackData:
					bindingName = trackData["binding"].get_display_name()
					if bindingName:
						actors = unreal.EditorLevelLibrary.get_all_level_actors()
						for actor in actors:
							actorName = actor.get_actor_label()
							if actorName == bindingName:
								ControlRigActor = actor

								controlRig = trackData["controlRig"]
								controlsArray = trackData["selectedControls"]
								controlDone = []
								for control in controlsArray:
									if control not in controlDone:
										controlTransform = unreal.ControlRigSequencerLibrary.get_control_rig_world_transform(
											sequence,
											controlRig,
											control,
											currentFrame,
											NLTA_general.TimeUnit()
										)

										mirrorControl = findMirrorControl({
											"controlRig":controlRig,
											"controlName":str(control),
											"right":right,
											"left":left
										})
										if mirrorControl:
											mirrorControlName = mirrorControl.name
											mirrorTransform = unreal.ControlRigSequencerLibrary.get_control_rig_world_transform(
												sequence,
												controlRig,
												mirrorControlName,
												currentFrame,
												NLTA_general.TimeUnit()
											)
										else:
											mirrorControlName = control
											mirrorTransform = controlTransform

										MirrorCube = NLTA_Actor.AddCube()
										NLTA_Actor.AttachActor(MirrorCube,ControlRigActor,True)
										offsetMirrorCube = NLTA_Actor.AddCube()
										offsetMirrorCube.set_actor_transform(controlTransform,False,False)
										offsetMirrorCube.set_actor_label("offsetMirrorCube")
										NLTA_Actor.AttachActor(offsetMirrorCube,MirrorCube,False)
										mirrorCube = NLTA_Actor.AddCube()
										mirrorCube.set_actor_transform(controlTransform,False,False)
										mirrorCube.set_actor_label("mirrorCube")
										mirrorCubeTransform = mirrorCube.get_actor_transform()
										NLTA_Actor.AttachActor(mirrorCube,offsetMirrorCube,False)
										MirrorCube.set_actor_scale3d(mirrorPlane)
										rotataOrderCube = NLTA_Actor.AddCube()
										rotataOrderCube.set_actor_label("rotataOrderCube")					
										if mirrorControl:
											rotataOrderCube.set_actor_transform(mirrorTransform,False,False)
										else:
											rotataOrderCube.set_actor_transform(mirrorCubeTransform,False,False)
										NLTA_Actor.AttachActor(rotataOrderCube,mirrorCube,False)

										
										transformArray = (
											unreal.Transform(location=[90,0,0],rotation=[0,0,0],scale=[1,1,1]),
											unreal.Transform(location=[0,90,0],rotation=[0,0,0],scale=[1,1,1]),
											unreal.Transform(location=[0,0,90],rotation=[0,0,0],scale=[1,1,1]),		
											unreal.Transform(location=[0,0,0],rotation=[0,0,90],scale=[1,1,1]),
											unreal.Transform(location=[0,0,0],rotation=[90,0,0],scale=[1,1,1]),
											unreal.Transform(location=[0,0,0],rotation=[0,90,0],scale=[1,1,1]),
										)
										tempMirrorSetting = {
											"axis":["","","","","",""],
											"neg":[1,1,1,1,1,1],
											"comboboxValue":[0,0,0,0,0,0]
										}
										axisName = ""
										flagTrue = 0
										for transformIndex in range(len(transformArray)):
											transformValue = transformArray[transformIndex]
											mirrorCube.set_actor_relative_transform(transformValue,False,False)
											currentTransform = rotataOrderCube.get_actor_transform()
											unreal.ControlRigSequencerLibrary.set_control_rig_world_transform(
												sequence,
												controlRig,
												mirrorControlName,
												currentFrame,
												currentTransform,
												NLTA_general.TimeUnit(),
												True
											)
											dataNew = getSequenceData()
											for order in range(len(dataNew["keys"])):
												key = dataNew["keys"][order]
												if mirrorControlName == key["control"]:
													time = key["data"].get_time().get_editor_property("frame_number").get_editor_property("value")
													if time == currentTime:
														value = key["data"].get_value()
														channelName = key["channelName"]
														if "." in channelName:
															channelName = channelName.split(".")[-2]+"."+channelName.split(".")[-1]													
															if channelName in channelArray:
																index = channelArray.index(channelName)
																if 89 <= value <= 91 :
																	tempMirrorSetting["axis"][transformIndex] = axisArray[index]
																	tempMirrorSetting["neg"][transformIndex] = 1
																	tempMirrorSetting["comboboxValue"][transformIndex] = cbxArray.index("+"+axisArray[index])
																	axisName += "   +"+axisArray[index]
																	flagTrue += 1
																if -91 <= value <= -90:
																	tempMirrorSetting["axis"][transformIndex] = axisArray[index]
																	tempMirrorSetting["neg"][transformIndex] = -1
																	tempMirrorSetting["comboboxValue"][transformIndex] = cbxArray.index("-"+axisArray[index])
																	axisName += "   -"+axisArray[index]
																	flagTrue += 1
											
											mirrorCube.set_actor_relative_transform(unreal.Transform(location=[0,0,0],rotation=[0,0,0],scale=[1,1,1]),False,False)
											currentTransform = rotataOrderCube.get_actor_transform()
											unreal.ControlRigSequencerLibrary.set_control_rig_world_transform(
												sequence,
												controlRig,
												mirrorControlName,
												currentFrame,
												currentTransform,
												NLTA_general.TimeUnit(),
												True
											)

										MirrorCube.destroy_actor()
										offsetMirrorCube.destroy_actor()	
										mirrorCube.destroy_actor()
										rotataOrderCube.destroy_actor()
										controlDone.append(control)
										if mirrorControlName != control:
											controlDone.append(mirrorControlName)
										if flagTrue >=6:
											### DELETE EXIST
											if axisName!="":
												for axisNameTemp in mirrorData["data"]:
													if control in mirrorData["data"][axisNameTemp]["controls"]:
														mirrorData["data"][axisNameTemp]["controls"].remove(control)
													if mirrorControlName in mirrorData["data"][axisNameTemp]["controls"]:
														mirrorData["data"][axisNameTemp]["controls"].remove(mirrorControlName)

												### ADD DATA
												if axisName not in mirrorData["data"]:
													mirrorData["data"][axisName] = {
														"mirrorSetting":{},
														"controls":[]
													}
													mirrorData["data"][axisName]["mirrorSetting"] =  tempMirrorSetting
													mirrorData["data"][axisName]["controls"].append(str(control))
												else:
													mirrorData["data"][axisName]["controls"].append(str(control))


					SelectControls(trackData["selectedControls"])
	NLTA_general.writeJson(url,mirrorData)

def selectMirrorControl(right,left):
	data = getSequenceData()
	for order in range(len(data["tracks"])):
		if "selectedControls"in data["tracks"][order]:
			controlRig = data["tracks"][order]["controlRig"]
			controlRig.clear_control_selection()
			for control in data["tracks"][order]["selectedControls"]:
				mirrorControl = findMirrorControl({
					"controlRig":controlRig,
					"controlName":str(control),
					"right":right,
					"left":left
				})
				if mirrorControl:
					controlRig.select_control(mirrorControl.name)

def getFrameData():
	data = getSequenceData()
	frameArray = []
	for order in range(len(data["keys"])):
		if "selected" in data["keys"][order]:
			key = data["keys"][order]["data"] 
			frame = key.get_time().get_editor_property("frame_number").get_editor_property("value")
			frameArray += [frame]
	frameArray = list(dict.fromkeys(frameArray))
	frameArray.sort()
	return({
		"frameArray":frameArray,
		"frameCurrent":unreal.LevelSequenceEditorBlueprintLibrary.get_current_time()
	})

def nextKeyframe():
	frameData = getFrameData()
	frameArray = frameData["frameArray"]
	frameCurrent = frameData["frameCurrent"]	
	frameNext = None
	for order in range(len(frameArray)):
		if frameArray[order] > frameCurrent:
			frameNext = frameArray[order]
			break
		elif frameArray[order] == frameArray[len(frameArray) - 1]:
			frameNext = frameArray[0]
			break
	if frameNext != None:
		unreal.LevelSequenceEditorBlueprintLibrary.set_current_time(frameNext)

def previousKeyframe():
	frameData = getFrameData()
	frameArray = frameData["frameArray"][::-1]
	frameCurrent = frameData["frameCurrent"]	
	frameNext = None
	for order in range(len(frameArray)):
		if frameCurrent == frameArray[-1]:
			frameNext = frameArray[0]
		elif frameCurrent > frameArray[order]:
			frameNext = frameArray[order]
			break
	if frameNext != None:
		unreal.LevelSequenceEditorBlueprintLibrary.set_current_time(frameNext)

def ExportPose(data):
	name = data["name"]
	path = data["path"]
	now = datetime.now().strftime("%Y-%m-%d %H-%M-%S")
	folderName = now+"-NLTA-Pose-"+name
	folderPath = path +"/"+folderName 
	os.makedirs(folderPath)
	os.makedirs(folderPath+"/-NLTA-Capture")
	NLTA_general.ScreenCapture({
		"name":"ScreenCapture",
		"path":folderPath+"/-NLTA-Capture",
		"resolution":[192,108],
		"wait":1,
	})
	poseData = SavePose()
	url = folderPath+"/Data.json"
	NLTA_general.writeJson(url,poseData)

def SaveClipboardPose(toolPath):
	data = SavePose()
	url = toolPath+"/Clipboard/TempPose.json"
	NLTA_general.writeJson(url,data)

def SavePose():
	poseData = {}
	data = getSequenceData()
	current_frame = unreal.FrameNumber(unreal.LevelSequenceEditorBlueprintLibrary.get_current_time())
	for order in range(len(data["tracks"])):
		if "selectedControls" in data["tracks"][order]:
			for control in data["tracks"][order]["selectedControls"]:
				controlRig = data["tracks"][order]["controlRig"]
				controlRigHierarchy = controlRig.get_hierarchy().get_controller()				
				controlType = controlRigHierarchy.get_control_settings(unreal.RigElementKey(type=unreal.RigElementType.CONTROL, name=control)).control_type

				if controlType == unreal.RigControlType.FLOAT:
					controlValue = unreal.ControlRigSequencerLibrary.get_local_control_rig_float(
						data["sequence"],controlRig,control,current_frame
					)
					poseData[str(control)] = controlValue
				elif controlType == unreal.RigControlType.VECTOR2D:
					value = unreal.ControlRigSequencerLibrary.get_local_control_rig_vector2d(
						data["sequence"],controlRig,control,current_frame
					)
					poseData[str(control)] = [value.x,value.y]
				elif controlType == unreal.RigControlType.EULER_TRANSFORM:
					controlTransform = unreal.ControlRigSequencerLibrary.get_local_control_rig_euler_transform(
						data["sequence"],controlRig,control,current_frame
					)
					if controlTransform:
						poseData[str(control)] = [
							[
								controlTransform.get_editor_property("location").x,
								controlTransform.get_editor_property("location").y,
								controlTransform.get_editor_property("location").z,
							],
							[
								controlTransform.get_editor_property("rotation").pitch,
								controlTransform.get_editor_property("rotation").yaw,
								controlTransform.get_editor_property("rotation").roll
							],
							[
								controlTransform.get_editor_property("scale").x,
								controlTransform.get_editor_property("scale").y,
								controlTransform.get_editor_property("scale").z,
							]					
						]
	return({
		"data":poseData,
		"controls":GetControlSelected()
	})


def PastePose(url):
	poseData = NLTA_general.readJson(url)["data"]
	data = getSequenceData()
	current_frame = unreal.FrameNumber(unreal.LevelSequenceEditorBlueprintLibrary.get_current_time())
	for order in range(len(data["tracks"])):
		if "selectedControls" in data["tracks"][order]:
			for control in data["tracks"][order]["selectedControls"]:				
				controlName = str(control)
				if controlName in poseData:
					controlRig = data["tracks"][order]["controlRig"]
					controlRigHierarchy = controlRig.get_hierarchy().get_controller()				
					controlType = controlRigHierarchy.get_control_settings(unreal.RigElementKey(type=unreal.RigElementType.CONTROL, name=control)).control_type
					if controlType == unreal.RigControlType.EULER_TRANSFORM:
						value = unreal.EulerTransform(location=poseData[controlName][0],rotation=poseData[controlName][1],scale=poseData[controlName][2])
						unreal.ControlRigSequencerLibrary.set_local_control_rig_euler_transform(
							data["sequence"],data["tracks"][order]["controlRig"],control,current_frame,value
						)
					elif controlType == unreal.RigControlType.FLOAT:
						unreal.ControlRigSequencerLibrary.set_local_control_rig_float(
							data["sequence"],data["tracks"][order]["controlRig"],control,current_frame,poseData[controlName]
						)
					elif controlType == unreal.RigControlType.VECTOR2D:
						value = unreal.Vector2D(x= poseData[controlName][0],y = poseData[controlName][1])
						unreal.ControlRigSequencerLibrary.set_local_control_rig_vector2d(
							data["sequence"],data["tracks"][order]["controlRig"],control,current_frame,value
						)

def ExportAnimation(inputData):
	name = inputData["name"]
	path = inputData["path"]
	now = datetime.now().strftime("%Y-%m-%d %H-%M-%S")
	folderName = now+"-NLTA-Animation-"+name
	folderPath = path +"/"+folderName 
	os.makedirs(folderPath)
	os.makedirs(folderPath+"/-NLTA-Capture")
	NLTA_general.ScreenCapture({
		"name":"ScreenCapture",
		"path":folderPath+"/-NLTA-Capture",
		"resolution":[192,108],
		"wait":1,
	})
	data = SaveAnimation()
	url = folderPath+"/Data.json"
	NLTA_general.writeJson(url,data)

def SaveClipboardAnimation(toolPath):
	data = SaveAnimation()
	url = toolPath+"/Clipboard/TempAnimation.json"
	NLTA_general.writeJson(url,data)

def SaveAnimation():
	data = getSequenceData()
	frameStart = data["sequence"].get_playback_start()
	frameEnd = data["sequence"].get_playback_end()
	animationData={}

	for order in range(len(data["keys"])):
		key = data["keys"][order]
		if "selected" in key:
			channelName = data["keys"][order]["channelName"]
			if channelName not in animationData:
				animationData[channelName]={
					"keyOrder":[],
					"keyValue":{}
				}
			frame = key["data"].get_time().get_editor_property("frame_number").get_editor_property("value")
			if (frame >= frameStart) and (frame <= frameEnd):
				if frame not in animationData[channelName]["keyOrder"]:
					animationData[channelName]["keyOrder"].append(frame)
				if key["type"]=="float":
					animationData[channelName]["type"] = "float"				
					animationData[channelName]["keyValue"][frame] = {
						"value":key["data"].get_value(),
						"arrive_tangent":key["data"].get_arrive_tangent(),
						"arrive_tangent_weight":key["data"].get_arrive_tangent_weight(),
						"interpolation_mode":str(key["data"].get_interpolation_mode().get_display_name()),
						"leave_tangent":key["data"].get_leave_tangent(),
						"leave_tangent_weight":key["data"].get_leave_tangent_weight(),
						"tangent_mode":str(key["data"].get_tangent_mode().get_display_name()),
						"tangent_weight_mode":str(key["data"].get_tangent_weight_mode().get_display_name())
					}			
				elif key["type"]=="bool":
					animationData[channelName]["type"] = "bool"
					animationData[channelName]["keyValue"][frame] = {
						"value":key["data"].get_value()
					}	
			animationData[channelName]["keyOrder"].sort()
	return({
		"data":animationData,
		"controls":GetControlSelected()
	})



def PasteAnimation(path):
	if os.path.exists(path):
		data = getSequenceData()
		animationData = NLTA_general.readJson(path)["data"]
		currentFrame = unreal.LevelSequenceEditorBlueprintLibrary.get_current_time()
		for order in range(len(data["channels"])):
			channelData = data["channels"][order]
			if "selected" in channelData:
				channel = channelData["data"]
				channelName = channelData["channelName"]
				if channelName in animationData:
					keyOrder = animationData[channelName]["keyOrder"]
					for i in range(len(keyOrder)):
						if i == 0:
							frameGap = 0
						else:
							frameGap = keyOrder[i] - keyOrder[0]
						oldFrame = keyOrder[i]
						newFrame = currentFrame + frameGap
						FNumber = unreal.FrameNumber(newFrame)
						Event = unreal.MovieSceneEvent()
						keyData = animationData[channelName]["keyValue"][str(oldFrame)]
						if animationData[channelName]["type"] == "float":
							if keyData["interpolation_mode"] == "Constant":
								intepMode = unreal.RichCurveInterpMode.RCIM_CONSTANT # 1
							if keyData["interpolation_mode"] == "Cubic":
								intepMode = unreal.RichCurveInterpMode.RCIM_CUBIC # 1
							if keyData["interpolation_mode"] == "Linear":
								intepMode = unreal.RichCurveInterpMode.RCIM_LINEAR # 1

							if keyData["tangent_mode"] == "Auto":
								tangentMode = unreal.RichCurveTangentMode.RCTM_AUTO
							if keyData["tangent_mode"] == "Break":
								tangentMode = unreal.RichCurveTangentMode.RCTM_BREAK
							if keyData["tangent_mode"] == "User":
								tangentMode = unreal.RichCurveTangentMode.RCTM_USER

							if keyData["tangent_weight_mode"] == "Arrive":
								tangentWeightMode = unreal.RichCurveTangentWeightMode.RCTWM_WEIGHTED_ARRIVE
							if keyData["tangent_weight_mode"] == "Both":
								tangentWeightMode = unreal.RichCurveTangentWeightMode.RCTWM_WEIGHTED_BOTH
							if keyData["tangent_weight_mode"] == "Leave":
								tangentWeightMode = unreal.RichCurveTangentWeightMode.RCTWM_WEIGHTED_LEAVE
							if keyData["tangent_weight_mode"] == "None":
								tangentWeightMode = unreal.RichCurveTangentWeightMode.RCTWM_WEIGHTED_NONE							
							newKey = channel.add_key(FNumber,keyData["value"])
							newKey.set_arrive_tangent(keyData["arrive_tangent"])
							newKey.set_arrive_tangent_weight(keyData["arrive_tangent_weight"])
							newKey.set_interpolation_mode(intepMode)
							newKey.set_leave_tangent(keyData["leave_tangent"])
							newKey.set_leave_tangent_weight(keyData["arrive_tangent_weight"])
							newKey.set_tangent_mode(tangentMode)
							newKey.set_tangent_weight_mode(tangentWeightMode)
						elif animationData[channelName]["type"] == "bool":
							newKey = channel.add_key(FNumber,keyData["value"])

def PasteMayaAnimation(path):
	if os.path.exists(path):
		data = getSequenceData()
		animationData = NLTA_general.readJson(path)
		currentFrame = unreal.LevelSequenceEditorBlueprintLibrary.get_current_time()
		for order in range(len(data["channels"])):
			channelData = data["channels"][order]
			if "selected" in channelData:
				channel = channelData["data"]
				channelName = channelData["channelName"]
				if channelName in animationData:
					keyOrder = animationData[channelName]["keyOrder"]
					for i in range(len(keyOrder)):
						
						if i == 0:
							frameGap = 0
						else:
							frameGap = keyOrder[i] - keyOrder[0]
						oldFrame = keyOrder[i]
						newFrame = currentFrame + frameGap
						FNumber = unreal.FrameNumber(newFrame)
						Event = unreal.MovieSceneEvent()
						
						keyData = animationData[channelName]["keyValue"][str(oldFrame)]

						inTangentType = keyData["inTangentType"]
						outTangentType = keyData["outTangentType"]
						inWeight = keyData["inWeight"]						
						outWeight = keyData["outWeight"]
						inAngle = keyData["inAngle"]
						outAngle = keyData["outAngle"]

						#intepMode = unreal.RichCurveInterpMode.RCIM_CUBIC

						if inTangentType == "linear" and outTangentType == "linear":
							intepMode = unreal.RichCurveInterpMode.RCIM_LINEAR
						
						#tangentMode = unreal.RichCurveTangentMode.RCTM_USER

						#leaveTangent = tan(y/x)



						"""
						if inTangentType == "spline" and outTangentType == "spline":
							intepMode = unreal.RichCurveInterpMode.RCIM_CUBIC
						if inTangentType == "fixed" and outTangentType == "fixed":
							intepMode = unreal.RichCurveInterpMode.RCIM_CUBIC
						if outTangentType == "step":
							intepMode = unreal.RichCurveInterpMode.RCIM_CONSTANT

							if keyData["interpolation_mode"] == "Constant":
								intepMode = unreal.RichCurveInterpMode.RCIM_CONSTANT # 1
							if keyData["interpolation_mode"] == "Cubic":
								intepMode = unreal.RichCurveInterpMode.RCIM_CUBIC # 1
							if keyData["interpolation_mode"] == "Linear":
								intepMode = unreal.RichCurveInterpMode.RCIM_LINEAR # 1

							if keyData["tangent_mode"] == "Auto":
								tangentMode = unreal.RichCurveTangentMode.RCTM_AUTO
							if keyData["tangent_mode"] == "Break":
								tangentMode = unreal.RichCurveTangentMode.RCTM_BREAK
							if keyData["tangent_mode"] == "User":
								tangentMode = unreal.RichCurveTangentMode.RCTM_USER

							if keyData["tangent_weight_mode"] == "Arrive":
								tangentWeightMode = unreal.RichCurveTangentWeightMode.RCTWM_WEIGHTED_ARRIVE
							if keyData["tangent_weight_mode"] == "Both":
								tangenttWeightMode = unreal.RichCurveTangentWeightMode.RCTWM_WEIGHTED_BOTH
							if keyData["tangent_weight_mode"] == "Leave":
								tangenttWeightMode = unreal.RichCurveTangentWeightMode.RCTWM_WEIGHTED_LEAVE
							if keyData["tangent_weight_mode"] == "None":
								tangenttWeightMode = unreal.RichCurveTangentWeightMode.RCTWM_WEIGHTED_NONE							

						"""
						newKey = channel.add_key(FNumber,keyData["value"])
						#newKey.set_arrive_tangent(keyData["arrive_tangent"])
						#newKey.set_arrive_tangent_weight(keyData["arrive_tangent_weight"])
						#newKey.set_interpolation_mode(intepMode)
						#newKey.set_leave_tangent(keyData["leave_tangent"])
						#newKey.set_leave_tangent_weight(keyData["arrive_tangent_weight"])
						#newKey.set_tangent_mode(unreal.RichCurveTangentMode.RCTM_USER)#tangentMode
						#newKey.set_tangent_weight_mode(tangenttWeightMode)


def clearKeyframe(frameArray):
	data = getSequenceData()
	for order in range(len(data["keys"])):
		key = data["keys"][order]
		if "selected" in key:
			frame = key["data"].get_time().get_editor_property("frame_number").get_editor_property("value")
			if frame in frameArray:
				key["channel"].remove_key(key["data"])

def clearCurrentKeyframe():
	currentFrame = unreal.LevelSequenceEditorBlueprintLibrary.get_current_time()
	clearKeyframe([currentFrame])

def playPlayback():		
	unreal.LevelSequenceEditorBlueprintLibrary.play()

def pausePlayback():		
	unreal.LevelSequenceEditorBlueprintLibrary.pause()

def goStartFrame():
	sequence = unreal.LevelSequenceEditorBlueprintLibrary.get_current_level_sequence()
	if sequence:
		unreal.LevelSequenceEditorBlueprintLibrary.set_current_time(sequence.get_playback_start())

def goEndFrame():
	sequence = unreal.LevelSequenceEditorBlueprintLibrary.get_current_level_sequence()
	if sequence:
		unreal.LevelSequenceEditorBlueprintLibrary.set_current_time(sequence.get_playback_end())


def addKey(sequence,controlRig,control,current_time):	
	unreal.LevelSequenceEditorBlueprintLibrary.set_current_time(current_time)
	current_frame = unreal.FrameNumber(current_time)
	currentTransform = unreal.ControlRigSequencerLibrary.get_control_rig_world_transform(
		sequence,
		controlRig,
		control,
		current_frame,
		NLTA_general.TimeUnit(),
	)
	unreal.ControlRigSequencerLibrary.set_control_rig_world_transform(
		sequence,
		controlRig,
		control,
		current_frame,
		currentTransform,
		NLTA_general.TimeUnit(),
		True
	)

def addMiddleKeyframe():
	frameData =	getFrameData()
	frameArray = frameData["frameArray"]
	frameCurrent = frameData["frameCurrent"]	
	frameFrom = frameCurrent
	frameTo = frameCurrent
	if len(frameArray) >= 2:
		for order in range(len(frameArray)):
			if frameArray[order] > frameCurrent:
				frameTo = frameArray[order]
				frameFrom = frameArray[order - 1]
				break	
		if frameTo == frameArray[-1]:
			frameFrom = frameArray[-2] 
		middleFrame = (frameFrom + frameTo)/2
	unreal.LevelSequenceEditorBlueprintLibrary.set_current_time(middleFrame)
	addCurrentKeyframe()
	
def addCurrentKeyframe():
	data = getSequenceData()
	current_time = unreal.LevelSequenceEditorBlueprintLibrary.get_current_time()
	for order in range(len(data["tracks"])):
		trackData = data["tracks"][order]
		if "selectedControls" in trackData:
			for control in trackData["selectedControls"]:
				addKey(data["sequence"],trackData["controlRig"],control,current_time)


def getCurrentValue(sequence,control_rig,control,current_frame):
	currentTransform = unreal.ControlRigSequencerLibrary.get_local_control_rig_euler_transform(
		sequence,
		control_rig,
		control,
		current_frame							
	)
	return({
		"rotation":{
			"X":currentTransform.get_editor_property("rotation").get_editor_property("roll"),
			"Y":currentTransform.get_editor_property("rotation").get_editor_property("pitch"),
			"Z":currentTransform.get_editor_property("rotation").get_editor_property("yaw")
		},
		"translation":{
			"X":currentTransform.get_editor_property("location").get_editor_property("x"),
			"Y":currentTransform.get_editor_property("location").get_editor_property("y"),
			"Z":currentTransform.get_editor_property("location").get_editor_property("z")
		}
	})

def getMirrorTransform(value,mirrorSetting):
	return(unreal.EulerTransform(
		unreal.Vector(
			value["translation"][mirrorSetting["axis"][0]] * mirrorSetting["neg"][0],
			value["translation"][mirrorSetting["axis"][1]] * mirrorSetting["neg"][1],
			value["translation"][mirrorSetting["axis"][2]] * mirrorSetting["neg"][2],
		),
		unreal.Rotator(
			value["rotation"][mirrorSetting["axis"][3]] * mirrorSetting["neg"][3],
			value["rotation"][mirrorSetting["axis"][4]] * mirrorSetting["neg"][4],
			value["rotation"][mirrorSetting["axis"][5]] * mirrorSetting["neg"][5],
		),
		unreal.Vector(1,1,1)
	))

def Mirror(mirrorAllData,type):
	mirrorData =  mirrorAllData["data"]
	sequence = unreal.LevelSequenceEditorBlueprintLibrary.get_current_level_sequence()
	right = mirrorAllData["right"]
	left = mirrorAllData["left"]
	current_time = unreal.LevelSequenceEditorBlueprintLibrary.get_current_time()
	current_frame = unreal.FrameNumber(current_time)
	data = getSequenceData()
	for order in range(len(data["tracks"])):
		trackData = data["tracks"][order]
		if "selectedControls" in trackData:
			sequence = data["sequence"]
			controlRig = trackData["controlRig"]
			controls = trackData["selectedControls"]
			controlDone = []
			for control in controls:
				if control not in controlDone:
					controlDone.append(control)
					mirrorControl = findMirrorControl({
						"controlRig":controlRig,
						"controlName":str(control),
						"right":right,
						"left":left
					})
					if mirrorControl:
						mirrorControlName = mirrorControl.name
						controlDone.append(mirrorControlName)
					else:
						mirrorControlName = None
					for axisPattern in mirrorData:
						if (control in mirrorData[axisPattern]["controls"]) or (mirrorControlName  in mirrorData[axisPattern]["controls"]):
							mirrorSetting = mirrorData[axisPattern]["mirrorSetting"]
							selectOriginTransform = getCurrentValue(sequence,controlRig,control,current_frame)
							selectMirrorTransform = getMirrorTransform(selectOriginTransform,mirrorSetting)
							
							if mirrorControl:
								if type == "flip":
									addKey(sequence,controlRig,mirrorControl.name,current_time)
									mirrorOriginTransform = getCurrentValue(sequence,controlRig,mirrorControl.name,current_frame)
									mirrorMirrorTransform = getMirrorTransform(mirrorOriginTransform,mirrorSetting)
									unreal.ControlRigSequencerLibrary.set_local_control_rig_euler_transform(sequence,controlRig,control,current_frame,mirrorMirrorTransform)
									unreal.ControlRigSequencerLibrary.set_local_control_rig_euler_transform(sequence,controlRig,mirrorControl.name,current_frame,selectMirrorTransform)
								else:
									unreal.ControlRigSequencerLibrary.set_local_control_rig_euler_transform(sequence,controlRig,mirrorControl.name,current_frame,selectMirrorTransform)
							else:
								unreal.ControlRigSequencerLibrary.set_local_control_rig_euler_transform(sequence,controlRig,control,current_frame,selectMirrorTransform)



def SelectKeyframe(frameArray):
	data = getSequenceData()
	for order in range(len(data["keys"])):
		key = data["keys"][order]
		if "selected" in key:
			frame = key["data"].get_time().get_editor_property("frame_number").get_editor_property("value")
			#if frame in frameArray:
				#key["channel"].remove_key(key["data"])

def AnimationFromFile():
	print("-----")

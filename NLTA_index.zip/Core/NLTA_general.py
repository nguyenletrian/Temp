import unreal
import os,json,sys
import importlib
import shutil
import math
import threading
from datetime import datetime
from importlib import *
from PySide2 import QtUiTools, QtWidgets, QtCore
from PySide2.QtWidgets import QMessageBox, QFileDialog, QLineEdit
from functools import partial

def openWindow(windowDict):
    titleArray = {
        "NLTA_Ctrl_Animation":"Animation Tool",
        "NLTA_Ctrl_AnimationAddSource":"Add Animation Source",
        "NLTA_Ctrl_AnimationExportPose":"Export Pose",
        "NLTA_Ctrl_AnimationExportAnimation":"Export Animation",
        "NLTA_Ctrl_NewMirrorSetting":"New Mirror Setting",
        "NLTA_Ctrl_ItemsMirrorSetting":"Mirror Setting",
        'NLTA_Ctrl_AnimationItemRename':"Rename Item",
        'NLTA_Ctrl_AnimationNewFolder':"New Folder",
        "NLTA_Ctrl_RenderWindow":"Render Setting",
        "NLTA_Ctrl_RigTool":"Rig Tool",
        "NLTA_Ctrl_PhysicAsset":"Physic Asset Tool",
        "NLTA_Ctrl_AnimMa2UE":"Maya Anim to Unreal",
        "NLTA_Ctrl_SettingSnapIKFK":"Setting Snap IKFK",
        "NLTA_Ctrl_SettingSnapIKFK_AddItem":"Add New",
        "NLTA_Ctrl_SnapIKFK":"Snap IKFK Tool",
        "NLTA_Ctrl_SnapIKFK_AddItem":"Add New",
        'NLTA_Ctrl_Asset':'Asset Tool',
        'NLTA_Ctrl_AnimationManager':'Animation Manager',
        'NLTA_Ctrl_ControlRigText':'ControlRig Text',
        'NLTA_Ctrl_Drive_MayaRig':'Drive Maya Rig',
        'NLTA_Ctrl_MBNG':'MBNG',
    }
    if QtWidgets.QApplication.instance():
        if "popup" not in windowDict:
            for win in (QtWidgets.QApplication.allWindows()):
                try:
                    win.destroy()
                except:pass
    else:
        QtWidgets.QApplication(sys.argv)
    module = importlib.import_module(windowDict["controller"])
    importlib.reload(module)
    module.window = module.CreateWindow()
    module.window.setObjectName(windowDict["controller"])
    module.window.setWindowTitle(titleArray[windowDict["controller"]])
    if "posX" in windowDict and "posY" in windowDict:
        module.window.move(windowDict["posX"],windowDict["posY"])
    module.window.show()
    unreal.parent_external_window_to_slate(module.window.winId())

def ClearScene():
    import NLTA_Actor, NLTA_SequenceNew
    reload(NLTA_Actor)
    reload(NLTA_SequenceNew)
    NLTA_Actor.DeleteActor("NLTA_RenderGroup")
    NLTA_SequenceNew.DeleteBindingByName("NLTA_Offset_360Around")

def CheckVersion():
    string = unreal.SystemLibrary.get_engine_version()
    version = string.split("-")[-1]
    return(version)

def TimeUnit():
    version = CheckVersion()
    if version == "5.3":
        timeUnit = unreal.SequenceTimeUnit.DISPLAY_RATE
    elif version == '5.5':
        timeUnit = unreal.MovieSceneTimeUnit.DISPLAY_RATE
    return(timeUnit)

def selected():
	selectedAsset = unreal.EditorUtilityLibrary.get_selected_assets()
	if selectedAsset:
		return(selectedAsset)
	else:
		return(False)

def readJson(url,*arr):
    if os.path.exists(url):
        myFile =  open(url,'r')
        myObject = myFile.read()
        myFile.close()
        #if int(cmds.about(version=True)) < 2022:
            #data = json.loads(myObject,'utf-8')
        #else:
        data = json.loads(myObject)
        return(data)
    else:
        print("!: File is not exists!")

def writeJson(url,data,*arr):
    with open(url,"w") as json_file:
        json.dump(data,json_file,sort_keys=True)

def readTxtFile(url,*arr):
    if os.path.exists(url):
        #filePath = cmds.encodeString(url)
        myFile =  open(url,'r')
        myObject = myFile.read()
        myFile.close()
        return(myObject)
    else:
        print("!: File is not exists!")

def writeTxtFile(url,data,*arr):
    with open(url,"w") as text_file:
        text_file.write(data)    

def getToolPath():
    currentFile = os.path.normpath(__file__)
    path,ext = os.path.splitext(currentFile)
    return(("/").join(path.split("\\")[0:-2])+"/")

def LoadToolPath(name):
    toolPath = getToolPath()
    tools = getFolders(toolPath+"Tools")
    for tool in tools:
        for path in [
            toolPath+"Tools/"+tool+"/",
            toolPath+"Tools/"+tool+"/"+"Controller",
            toolPath+"Tools/"+tool+"/"+"Module",
            toolPath+"Tools/"+tool+"/"+"View"
        ]:
            if path in sys.path:
                sys.path.remove(path)     
    for path in [
        toolPath+"Tools/"+name+"/",
        toolPath+"Tools/"+name+"/"+"Controller",
        toolPath+"Tools/"+name+"/"+"Module",
        toolPath+"Tools/"+name+"/"+"View"
    ]:
        sys.path.append(path)

def GetCurrentToolPath():
    toolPath = getToolPath()
    tools = getFolders(toolPath+"Tools")
    for tool in tools:
        pathTemp = toolPath+"Tools/"+tool+"/"
        for path in sys.path:
            if pathTemp == path:
                return(pathTemp)


def getDataPath():
    user = os.environ.get("USERNAME")
    return("C:/Users/"+user+"/Documents/NLTA_UnrealData/")

def getDesktopPath():
    user = os.environ.get("USERNAME")
    return("C:/Users/"+user+"/Desktop/")

def createDataFolders():
    dataPath = getDataPath()
    if not os.path.exists(dataPath):
        os.makedirs(dataPath)
    for folder in ["Animation","Clipboard","Mirror","Temp","RenderPlayback","ControlRig"]:
        folderPath = dataPath+"/"+folder        
        if not os.path.exists(folderPath):
            os.makedirs(folderPath)

def modifyUnreal():
    oldPath = GetUnrealPath()+'Engine/Content/Sequencer'
    backupPath = GetUnrealPath()+'Engine/Content/NLTA_Sequencer'
    sourcePath = getToolPath()+"Library/Pattern/Sequencer"
    if not os.path.exists(backupPath):
        try:
            os.rename(oldPath,backupPath)
            shutil.copytree(sourcePath,oldPath)
        except:pass
    else:
        try:
            shutil.rmtree(oldPath)  
            shutil.copytree(sourcePath,oldPath)
        except:pass

def GetUnrealPath():
    BurnInUnrealPath = unreal.Paths
    return(BurnInUnrealPath.launch_dir().replace("Engine\Binaries\Win64/",""))

def reloadComboBox(comboBox,comboBoxArray):
    comboBox.clear()
    #comboBoxArray.sort()
    comboBox.addItems(comboBoxArray)

def getFolders(url):
    stringArray = []
    if os.path.isdir(url):
        for folder in sorted(os.scandir(url),key=os.path.getmtime)[::-1]:
            if folder.is_dir():
                stringArray.append(folder.path.split("\\")[-1])
    stringArray.sort()
    return(stringArray)

def getFiles(url,fileType):
    files = os.listdir(url)
    nameArray = []
    for file in files:
        if file.endswith("."+fileType):
            fileName = file.split(".")[0]
            nameArray.append(fileName)
    nameArray.sort()
    return(nameArray)

def DeleteAllFiles(url):
    for fileName in os.listdir(url):
        filePath = os.path.join(folderPath, fileName)
        if os.path.isfile(filePath):
            os.remove(filePath)
            print(f"Deleted: {filePath}")





def setSession(sessionName,sessionValue):
    url = getDataPath() + "Temp/session.py"
    if not os.path.exists(url):
        data = {sessionName:sessionValue}
    else:
        data = readJson(url)
        data[sessionName] = sessionValue
    writeJson(url,data)

def getSession(sessionName):
    url = getDataPath() + "Temp/session.py"
    if os.path.exists(url): 
        data = readJson(url)
        if sessionName in data:
            return(data[sessionName])
        else:
            return(False)
    else:
        return(False)

def createMessageBox(dict):
    msg = QMessageBox()
    msg.setIcon(QMessageBox.Information) #Critical #Warning #Question
    if "text" in dict:
        msg.setText(dict["text"])
    if "title" in dict:      
        msg.setWindowTitle(dict["title"])
    if "buttons" in dict:
        if dict["buttons"] == ["Ok","Cancel"]:
            msg.setStandardButtons(QMessageBox.Ok | QMessageBox.Cancel)#Ok #Open #Save #Cancel #Close #Yes #No #About #Retry #Ignore
            msg.setDefaultButton(QMessageBox.Ok)
        if dict["buttons"] == ["Cancel"]:
            msg.setStandardButtons(QMessageBox.Cancel)
            msg.setDefaultButton(QMessageBox.Cancel)
    if "detail" in dict:
        msg.setDetailedText(dict["detail"])      
    #msg.setInformativeText("This is additional information")
    if "function" in dict:
        msg.buttonClicked.connect(dict["function"])
    retval = msg.exec_()

def DeleteObj(obj):
    sequence = unreal.LevelSequenceEditorBlueprintLibrary.get_current_level_sequence()
    if isinstance(obj,unreal.MovieSceneCameraCutTrack):
        sequence.remove_track(obj)
    elif isinstance(obj,unreal.MovieSceneCameraCutSection):
        version = CheckVersion()
        if version == "5.3":
            cameraCutTrack = sequence.get_master_tracks()[0]
            cameraCutTrack.remove_section(obj)
        elif version == '5.5':
            tracks =  sequence.get_tracks()
            for track in tracks:
                sections = track.get_sections()
                for section in sections:
                    if section == obj:
                        track.remove_section(obj)        
    elif isinstance(obj,unreal.MovieSceneBindingProxy):
        obj.remove()
    elif isinstance(obj,unreal.StaticMeshActor) or isinstance(obj,unreal.CineCameraActor):
        obj.destroy_actor()
    elif isinstance(obj,unreal.ControlRigBlueprint):
        unreal.EditorAssetLibrary.delete_asset(obj.get_path_name())

def DirectoryDialog(self):
    dialog = QFileDialog()
    dialog.setFileMode(QFileDialog.Directory)
    folder = dialog.getExistingDirectory(self,"Select an awesome directory")
    return(folder)
    
def FileDialog(self):
    dialog = QFileDialog()
    dialog.setFileMode(QFileDialog.ExistingFile)
    file = dialog.getOpenFileName(self,"Open file")
    return(file)

def FilesDialog(self):
    dialog = QFileDialog()
    dialog.setFileMode(QFileDialog.ExistingFiles)
    files, _ = QFileDialog.getOpenFileNames(self, "Open files")
    return(files)

def ScreenCapture(inputData):
    name = inputData["name"]
    path = inputData["path"]
    resolution = inputData["resolution"]
    wait = inputData["wait"]
    now = datetime.now().strftime("%Y-%m-%d_%H%M%S")
    screenshot_dir = os.path.abspath(unreal.Paths.screen_shot_dir())
    screenshot_filename = name+".png"
    screenshot_path = os.path.join(screenshot_dir,screenshot_filename)
    unreal.AutomationLibrary.take_high_res_screenshot(resolution[0],resolution[1],screenshot_filename,capture_hdr=True)
    def threadFunction():
        shutil.move(screenshot_path,path)
    t = threading.Timer(wait,threadFunction)
    t.start()

def VideoCapture(inputData):
    sequence = unreal.LevelSequenceEditorBlueprintLibrary.get_current_level_sequence()
    if sequence:
        #import NLTA_SequenceNew
        #reload(NLTA_SequenceNew)
        frameStart = sequence.get_playback_start()
        frameEnd = sequence.get_playback_end()

        name = inputData["name"]
        path = inputData["path"]
        resolution = inputData["resolution"]
        wait = inputData["wait"]
        now = datetime.now().strftime("%Y-%m-%d_%H%M%S")
        screenshot_dir = os.path.abspath(unreal.Paths.screen_shot_dir())
        for frame in range(frameStart,frameEnd):
            unreal.LevelSequenceEditorBlueprintLibrary.set_current_time(frame)
            screenshot_filename = name+str(frame)+".png"
            screenshot_path = os.path.join(screenshot_dir,screenshot_filename)
            print(screenshot_path)            
            
            def threadFunction(functionData):
                x = functionData["x"]
                y = functionData["y"]
                outName = functionData["outName"]
                unreal.AutomationLibrary.take_high_res_screenshot(x,y,outName,capture_hdr=False)
            t = threading.Timer(wait,partial(threadFunction,{
                "x":resolution[0],
                "y":resolution[1],
                "outName":screenshot_filename
            }))
            t.start()
            """
            def threadFunction():
                shutil.move(screenshot_path,path)
            t = threading.Timer(wait,threadFunction)
            t.start()
            """


def GetDistance(s,d):
    distance = math.sqrt(
        math.pow(d[0]-s[0],2)+
        math.pow(d[1]-s[1],2)+
        math.pow(d[2]-s[2],2)*1.0
    )
    return(distance);

def BasicTransform():
    return(unreal.Transform(location=[0.000000,0.000000,0.000000],rotation=[0.000000,0.000000,0.000000],scale=[1.000000,1.000000,1.000000]))



def WidgetInput(widget):
    typeArray = [
        QtWidgets.QLineEdit,
        QtWidgets.QPushButton,
        QtWidgets.QTextEdit,
        QtWidgets.QPlainTextEdit,
        QtWidgets.QComboBox,
        QtWidgets.QCheckBox,
        QtWidgets.QSpinBox,
        QtWidgets.QDoubleSpinBox,
        QtWidgets.QRadioButton,
        QtWidgets.QVBoxLayout,
        QtWidgets.QLabel,
    ]
    dataReturn = {}
    for type_ in typeArray:
        widgetTemp = widget.findChildren(type_)
        for order in range(len(widgetTemp)):
            input_ = widgetTemp[order]
            inputName = input_.objectName()
            dataReturn[inputName] = input_
    return(dataReturn)

def WidgetSet(inputData):
    widgetInput =  inputData["widget"]
    arrayValue = inputData["value"]
    for inputName in widgetInput:
        inputElement = widgetInput[inputName]
        inputType = widgetInput[inputName].__class__.__name__
        if inputName in arrayValue:
            if str(inputType) == "QLineEdit":
                inputElement.setText(arrayValue[inputName])            
            if str(inputType) == "QTextEdit":
                inputElement.setPlainText(arrayValue[inputName])
            if str(inputType) == "QComboBox":
                inputElement.setCurrentText(arrayValue[inputName])
            if str(inputType) == "QCheckBox":
                inputElement.setChecked(arrayValue[inputName])
            if str(inputType) == "QSpinBox":
                inputElement.setValue(arrayValue[inputName])
            if str(inputType) == "QDoubleSpinBox":
                inputElement.setValue(arrayValue[inputName])                
            if str(inputType) == "QRadioButton":
                inputElement.setChecked(arrayValue[inputName]) 


def WidgetGet(widget):
    dataReturn = {}
    typeArray = [
        QtWidgets.QLineEdit,
        QtWidgets.QPushButton,
        QtWidgets.QTextEdit,
        QtWidgets.QComboBox,
        QtWidgets.QCheckBox,
        QtWidgets.QSpinBox,
        QtWidgets.QDoubleSpinBox,
        QtWidgets.QRadioButton,        
    ]
    for type_ in typeArray:
        widgetTemp = widget.findChildren(type_)
        for order in range(len(widgetTemp)):
            input_ = widgetTemp[order]
            inputName = input_.objectName()
            inputType = input_.__class__.__name__
            value = None
            if str(inputType) in ["QLineEdit"]:
                value = input_.text()
            if str(inputType) in ["QTextEdit"]:
                value = input_.toPlainText()
            if str(inputType) in ["QComboBox"]:
                value = input_.currentText()
            if str(inputType) in ["QCheckBox"]:
                value = input_.isChecked()
            if str(inputType) in ["QSpinBox"]:
                value = input_.value()
            if str(inputType) in ["QDoubleSpinBox"]:
                value = input_.value()
            if str(inputType) in ["QRadioButton"]:
                value = input_.isChecked()
            dataReturn[inputName] = value
    return(dataReturn)




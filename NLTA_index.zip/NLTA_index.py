import sys
import os
import unreal
from importlib import *

for link in sys.path:
	if "PySide2" in link:
		sys.path.remove(link)

currentFile = os.path.normpath(__file__)
path,ext = os.path.splitext(currentFile)
toolPath = ("/").join(path.split("\\")[0:-1])+"/"
folders= ["Library","Library/PySide2","Library/shiboken2","Tools","Core","ControlRigPattern"]
for folder in folders:
	link  = toolPath + folder + "/"
	if link not in sys.path:
		sys.path.append(link)

import NLTA_general
reload(NLTA_general)
"""
NLTA_general.createDataFolders()
NLTA_general.modifyUnreal()
"""
tools = NLTA_general.getFolders(toolPath +"Tools")
def CreateFunction():
	menus = unreal.ToolMenus.get()
	edit = menus.find_menu("LevelEditor.MainMenu.Edit")
	main_menu = menus.find_menu("LevelEditor.MainMenu")
	my_menu = main_menu.add_sub_menu("My.Menu","Python","My Menu","Rigging Tools")
	for tool in tools:
		if tool not in  ["AnimMa2UE"]:
			entry = unreal.ToolMenuEntry(
				name = tool,
				type = unreal.MultiBlockType.MENU_ENTRY,
			)
			scriptString = "from importlib import *;import NLTA_general;reload(NLTA_general);NLTA_general.ClearScene();NLTA_general.LoadToolPath('{}');".format(tool)
			scriptString += "import index;reload(index);"
			entry.set_label(tool)
			entry.set_string_command(unreal.ToolMenuStringCommandType.PYTHON,'',string=scriptString)
			my_menu.add_menu_entry("Items",entry)
		if tool == "AnimMa2UE":
			entry = unreal.ToolMenuEntry(
				name = tool,
				type = unreal.MultiBlockType.MENU_ENTRY,
			)
			scriptString = "from importlib import *;import NLTA_Asset;reload(NLTA_Asset);NLTA_Asset.ReImportAll({'fileType':'AnimSequence'});"
			entry.set_label(tool)
			entry.set_string_command(unreal.ToolMenuStringCommandType.PYTHON,'',string=scriptString)
			my_menu.add_menu_entry("Items",entry)
	menus.refresh_all_widgets()
	if "AnimMa2UE" in tools:
		import NLTA_Asset;reload(NLTA_Asset);NLTA_Asset.ReImportAll({'fileType':'AnimSequence'});
CreateFunction()

import unreal
import os
import socket
import re
import shutil
from importlib import *
import NLTA_Pyside, NLTA_general,NLTA_Import,NLTA_Skeleton, NLTA_PhysicAsset,NLTA_Material,NLTA_SkeletalMesh,NLTA_Asset,NLTA_StaticMesh

NLTA_Pyside.LoadModule()
reload(NLTA_Pyside)
reload(NLTA_general)
reload(NLTA_Import)
reload(NLTA_Skeleton)
reload(NLTA_PhysicAsset)
reload(NLTA_Material)
reload(NLTA_SkeletalMesh)
reload(NLTA_Asset)
reload(NLTA_StaticMesh)


session = {}
class CreateWindow(QtWidgets.QWidget):
	window = None
	def __init__(self,parent=None):
		super(CreateWindow,self).__init__(parent)		
		self.currentToolPath = NLTA_general.GetCurrentToolPath()
		self.settingPath = self.currentToolPath+"/Data/Setting.json"
		self.fbxDataPath = self.currentToolPath+"/Data/FbxData.json"
		self.settingArray = [
			"txt_CharacterFolder_Character",
			"txt_CharacterFolder_Monster",
			"txt_PartFolder_Body",
			"txt_PartFolder_Hair",
			"txt_PartFolder_Wig",
			"txt_PartFolder_Shoes",
			"txt_PartFolder_Helmet",
			"txt_PartFolder_Gloves",
		]
		self.widget = QtUiTools.QUiLoader().load(self.currentToolPath+"View/MBNG_Main.ui")
		self.widget.setParent(self)
		self.widgetInput = NLTA_general.WidgetInput(self.widget)
		
		self.widgetInput['btn_LoadFbxs'].clicked.connect(self.SelectFbxs)
		#self.widgetInput['btn_SaveSetting'].clicked.connect(self.SaveSetting)
		self.widgetInput['btn_SocketToZero'].clicked.connect(self.ModifyFloor)
		self.widgetInput['btn_Clear'].clicked.connect(self.ClearFbxs)
		
	def resizeEvent(self,event):
		self.widget.resize(self.width(),self.height())
	
	def closeEvent(self, event):
		self.destroy()

	def SaveSetting(self):
		data = {}
		for inputName in self.settingArray:
			data[inputName] = self.widgetInput[inputName].text()
		NLTA_general.writeJson(self.settingPath,data)


	def LoadSetting(self):
		data = NLTA_general.readJson(self.settingPath)
		if data:
			for inputName in self.settingArray:
				self.widgetInput[inputName].setText(data[inputName])

	def LoadShoesPattern(*arr):
		folderPath = NLTA_general.GetUnrealPath()+'Engine/Content/NLTA_Temp'
		filePath = NLTA_general.GetCurrentToolPath()+"Library/Socket_Skeleton.uasset"
		if not os.path.exists(folderPath):
			os.makedirs(folderPath, exist_ok=True)
			shutil.copy2(filePath,folderPath)

	def ModifyFloor(self):
		assets = NLTA_Asset.Selected()
		for asset in assets:
			if isinstance(asset, unreal.SkeletalMesh):
				importData = asset.get_editor_property("asset_import_data")
				fbxPath = importData.get_first_filename()
				jsonPath = fbxPath.replace(".fbx",".json")
				data = NLTA_general.readJson(jsonPath)
				socket = asset.get_socket_by_index(0)
				socketName = socket.socket_name
				asset.rename_socket(socketName,"Floor_Socket")
				socket.set_editor_property("relative_location",unreal.Vector(0.0,0.0,float(data["distance"])))
				skeleton = asset.skeleton
				NLTA_Asset.SaveAsset(asset)
				NLTA_Asset.SaveAsset(skeleton)

	def CheckMaterial(self,name):
		materialName = name
		exist = NLTA_Material.CheckExist(materialName)
		if exist:
			return(materialName)
		else:
			return(None)

	def CheckSkeleton(self,data):
		characterType  = data["characterType"]
		partType = data["partType"]
		fbxName = data["fbxName"]
		fbxNameArray = fbxName.split("_")
		destinationPath =  data["destinationPath"]
		skeletons = []
		if characterType == "Character":
			#CHECK SKELETON WITH NAME
			skeleton = NLTA_Asset.FindAssetInPath(fbxName + "_Skeleton",destinationPath)
			
			#FOR SHOES, GLOVES
			if partType in ["Shoes","Gloves"]:
				if fbxNameArray[-1] == "L":
					skeleton = NLTA_Asset.FindAssetInPath(fbxName[:-2] + "_Skeleton",destinationPath)
					if skeleton:
						skeletons.append(str(skeleton.get_name()))
			
			#FOR HELMET
			if partType in ["Helmet"]:
				skeletonOriginName = ("_").join((fbxNameArray[0:-1]))+"_Skeleton"
				skeleton = NLTA_Asset.FindAssetInPath(skeletonOriginName,destinationPath)
				if skeleton:
					skeletons.append(str(skeleton.get_name()))

			#FOR HAIR
			if partType in ["Hair"]:
				if "H" in fbxNameArray[-1]:
					skeletonOriginName =  ("_").join(fbxNameArray[0:-1])+"_H1_Skeleton"
					skeleton = NLTA_Asset.FindAssetInPath(skeletonOriginName,destinationPath)
					if skeleton:
						print(skeleton)
						skeletons.append(str(skeleton.get_name()))

			#FOR WIG
			if partType in ["Wig"]:
				middle = fbxNameArray[-2]
				newMiddle = re.sub(r'\d+$', '01', middle)
				parts = fbxNameArray
				parts[2] = newMiddle
				skeletonOriginName = "_".join(parts)+"_Skeleton"
				skeleton = NLTA_Asset.FindAssetInPath(skeletonOriginName,destinationPath)
				if skeleton:
					skeletons.append(str(skeleton.get_name()))
		if characterType == "Monster":
			skeletons = NLTA_Skeleton.GetAllAsArray()
			skeletons.sort(key=str.lower)
		return(skeletons)

	def MonsterModify(self,data):
		fbxName = data["name"]
		destination = data["destination"]
		partType = data["partType"]

		skeletalMesh =  NLTA_Asset.FindAssetInPath(fbxName,destination)

		physicName = fbxName + "_PhysicsAsset"
		physic = NLTA_Asset.FindAssetInPath(physicName,destination)
		if physic:
			physicPath =  physic.get_path_name()
			physicNewName = physicName.replace("PhysicsAsset","Physics")
			physicNewPath = physicPath.replace(physicName,physicNewName)
			unreal.EditorAssetLibrary.rename_asset(physicPath,physicNewPath)
		
		#MATERIAL
		staticMesh = NLTA_StaticMesh.GetAssetByName("SM_"+fbxName)
		skeletalMesh =  NLTA_SkeletalMesh.GetAssetByName(fbxName)
		if staticMesh:
			NLTA_Material.CopyStaticToSkeletalMesh(staticMesh,skeletalMesh)
			unreal.EditorAssetLibrary.save_asset(data["skeletalMesh"])
			
		NLTA_Asset.SaveAssetByPath(skeletalMesh.get_path_name())
		NLTA_Asset.SaveAssetByPath(physicNewPath)

	def CharacterModify(self,data):
		fbxName = data["name"]
		destination = data["destination"]
		partType = data["partType"]

		#MATERIAL
		staticMesh = NLTA_StaticMesh.GetAssetByName("SM_"+fbxName)
		skeletalMesh =  NLTA_SkeletalMesh.GetAssetByName(fbxName)
		if staticMesh:
			if data["partType"] != "Eye":			
				NLTA_Material.CopyStaticToSkeletalMesh(staticMesh,skeletalMesh)
			else:
				NLTA_Material.CopyStaticToSkeletalMeshEye(staticMesh,skeletalMesh)
			NLTA_Asset.SaveAssetByPath(data["skeletalMesh"])
			#unreal.EditorAssetLibrary.save_asset(data["skeletalMesh"])
		
		skeletonName = fbxName + "_Skeleton"
		skeleton = NLTA_Asset.FindAssetInPath(skeletonName,destination)
		if skeleton:
			skeletonPath =  skeleton.get_path_name()			
			if partType in ["Gloves","Shoes"]:
				for size in ["_S","_L"]:
					if size in skeletonName:
						skeletonNewName = skeletonName.replace(size+"_Skeleton","_Skeleton")
						skeletonNewPath = skeletonPath.replace(skeletonName,skeletonNewName)
						unreal.EditorAssetLibrary.rename_asset(skeletonPath,skeletonNewPath)
						NLTA_Asset.SaveAssetByPath(skeletonNewPath)

	def SaveFbxData(self,data):
		fbxData = NLTA_general.readJson(self.fbxDataPath)
		if not fbxData:
			fbxData = {}
		fbxData[data['name']] = data
		NLTA_general.writeJson(self.fbxDataPath,fbxData)

	def ImportFbx(self,data):
		folderDes = data['destination']
		folderTemp = data['destination']
		skeletalMeshPath = folderTemp + "/"+data['name']
		
		unreal.EditorAssetLibrary.make_directory(folderTemp)

		task = NLTA_Import.ImportPattern()
		task.filename = data['fbxPath']
		task.destination_path = folderTemp
		task.destination_name = data['name']		
		task.options.import_mesh = True
		task.options.import_as_skeletal = True

		if data['skeleton']:
			skeleton = NLTA_Skeleton.GetAssetByName(data["skeleton"])
			task.options.skeleton = skeleton
			skeletonPath = skeleton.get_path_name()			
		else:
			task.options.skeleton = None
			skeletonPath = folderTemp+"/"+data['name']+"_Skeleton"
			if data["characterType"] == "Character" and data["partType"] in ["Shoes","Gloves"]  and (data['name'].endswith("_L")):
				skeletonName = data['name'].replace("_L","") +"_Skeleton"
				skeleton = NLTA_Skeleton.GetAssetByName(skeletonName)
				task.options.skeleton = skeleton
				skeletonPath = skeleton.get_path_name()


		if data["characterType"] == "Character":
			task.options.create_physics_asset = False
		else:
			task.options.create_physics_asset = True

		task.options.skeletal_mesh_import_data.set_editor_property("import_morph_targets", True)
		task.options.skeletal_mesh_import_data.normal_generation_method = unreal.FBXNormalGenerationMethod.MIKK_T_SPACE
		task.options.skeletal_mesh_import_data.vertex_color_import_option = unreal.VertexColorImportOption.REPLACE
		task.options.skeletal_mesh_import_data.normal_import_method = unreal.FBXNormalImportMethod.FBXNIM_IMPORT_NORMALS
		if data["partType"] == "Hair":
			task.options.skeletal_mesh_import_data.normal_import_method = unreal.FBXNormalImportMethod.FBXNIM_IMPORT_NORMALS_AND_TANGENTS

		if data["partType"] == "Eye":
			skeletonPath = "/Game/Gfx/Char/BaseBody/HF_BaseBody01_Skeleton.HF_BaseBody01_Skeleton"
			skeleton = unreal.load_asset(skeletonPath)
			task.options.skeleton = skeleton

		asset_tools = unreal.AssetToolsHelpers.get_asset_tools()
		asset_tools.import_asset_tasks([task])
		
		
		if data["partType"] != "Hair":
			NLTA_Asset.SaveAssetByPath(skeletonPath)
		NLTA_Asset.SaveAssetByPath(skeletalMeshPath)

		data["skeletalMesh"] = skeletalMeshPath		
		if data["characterType"] == "Character":
			self.CharacterModify(data)
		elif data["characterType"] == "Monster":
			self.MonsterModify(data)
		
		self.SaveFbxData(data)	
		
		
	def LoadFbxItem(self,fbxPath):
		def TypeChange(ui,*arr):
			characterType = ui["cbx_CharacterType"].currentText()
			partType = ui["cbx_PartType"].currentText()
			fbxName = ui['lb_Name'].text()
			skeletons = self.CheckSkeleton({
				"characterType":characterType,
				"partType":partType,
				"fbxName":fbxName,
				"destinationPath":ui["txt_DestinationPath"].toPlainText(),
			})
			NLTA_Pyside.ReloadComboBox(ui["cbx_Skeletons"],skeletons)

		def SkeletonChange(ui,*arr):
			skeletonName = ui["cbx_Skeletons"].currentText()
			ui["txt_SkeletonName"].setText(skeletonName)

		def GetCurrentFolder(ui,*arr):
			currentPath = unreal.EditorUtilityLibrary.get_current_content_browser_path()
			if currentPath:
				if currentPath.startswith("/All/"):
					currentPath = currentPath.replace("/All", "")
				ui["txt_DestinationPath"].setText(currentPath)
				TypeChange(ui)
			else:
				print("Please select a folder.")

		def DeleteOK(ui):
			ui.deleteLater()


		def ImportOK(ui,*arr):
			data = {
				"name":ui["lb_Name"].text(),
				"fbxPath":ui["txt_FbxPath"].toPlainText(),
				"destination":ui["txt_DestinationPath"].toPlainText(),
				"skeleton":ui["txt_SkeletonName"].text(),
				"characterType":ui["cbx_CharacterType"].currentText(),
				"partType":ui["cbx_PartType"].currentText(),			
			}			
			self.ImportFbx(data)


		UIPath = self.currentToolPath+"View/MBNG_FbxItem.ui"
		fbxUI = QtUiTools.QUiLoader().load(UIPath)
		fbxInput = NLTA_general.WidgetInput(fbxUI)

		fbxName = (fbxPath.split("/")[-1]).split(".")[0]
		fbxInput['lb_Name'].setText(fbxName)
		fbxInput['txt_FbxPath'].setText(fbxPath)		
		fbxInput['cbx_CharacterType'].currentTextChanged.connect(partial(TypeChange,fbxInput))
		fbxInput['cbx_PartType'].currentTextChanged.connect(partial(TypeChange,fbxInput))
		fbxInput['cbx_Skeletons'].currentTextChanged.connect(partial(SkeletonChange,fbxInput))
		fbxInput['txt_DestinationGetPath'].clicked.connect(partial(GetCurrentFolder,fbxInput))
		fbxInput["btn_Import"].clicked.connect(partial(ImportOK,fbxInput))
		fbxInput["btn_Delete"].clicked.connect(partial(DeleteOK,fbxUI))

		TypeChange(fbxInput)

		fbxData = NLTA_general.readJson(self.fbxDataPath)
		if fbxData and fbxName in fbxData:
			fbxInput['lb_Name'].setText(fbxData[fbxName]["name"])
			fbxInput['cbx_CharacterType'].setCurrentText(fbxData[fbxName]["characterType"])	
			fbxInput['cbx_PartType'].setCurrentText(fbxData[fbxName]["partType"])			
			fbxInput["txt_DestinationPath"].setText(fbxData[fbxName]["destination"])
			fbxInput['cbx_Skeletons'].setCurrentText(fbxData[fbxName]["skeleton"])
			fbxInput["txt_SkeletonName"].setText(fbxData[fbxName]["skeleton"])

		self.widgetInput['list_Fbxs'].addWidget(fbxUI)

	def ClearFbxs(self):		
		ui = self.widgetInput['list_Fbxs']
		for i in reversed(range(ui.count())):
			ui.itemAt(i).widget().deleteLater()

	def SelectFbxs(self):
		fbxPaths = NLTA_general.FilesDialog(self)
		if fbxPaths:
			for fbxPath in fbxPaths:
				self.LoadFbxItem(fbxPath)

	"""
		fbxItem = QtUiTools.QUiLoader().load(fbxPattern)
		fbxInput = NLTA_general.WidgetInput(fbxItem)
		fbxInput['lb_Name'].setText(fbx)
		fbxInput['btn_Import'].clicked.connect(partial(self.ImportSingle,fbx))

		### XU LY SKELETON
		fbxInput['cbx_Skeleton'].currentTextChanged.connect(partial(SkeletonChange,fbx,fbxInput['cbx_Skeleton']))
		session["fbxsSkeleton"][fbx] = fbxInput['cbx_Skeleton'].currentText()
		if session['folderType'] == "Charcter":					
			pass
		elif session['folderType'] == "Monster":
			pattern = re.compile(r"([A-Za-z_]+)\d+_mesh")
			match = pattern.match(fbx)
			if match:
				mainName = match.group(1)
				skeletonArray = []					
				skeletons = NLTA_Skeleton.GetAll()
				for skeleton in skeletons:
					if skeleton["name"].startswith(mainName):
						skeletonArray.append(skeleton["name"])
				if len(skeletonArray)!=0:
					skeletonArray.insert(0,"")
				NLTA_Pyside.ReloadComboBox(fbxInput['cbx_Skeleton'],skeletonArray)
		if data:
			if fbx in data["fbxsSkeleton"]:
				session["fbxsSkeleton"][fbx] = data["fbxsSkeleton"][fbx]
				index = fbxInput['cbx_Skeleton'].findText(data["fbxsSkeleton"][fbx])
				if index != -1:
				    fbxInput['cbx_Skeleton'].setCurrentIndex(index)

		### XU LY FBX TYPE
		fbxInput['cbx_Type'].currentTextChanged.connect(partial(FbxTypeChange,fbx,fbxInput['cbx_Type']))				
		session['fbxsType'][fbx] = fbxInput['cbx_Type'].currentText()
		if data:
			if fbx in data['fbxsType']:
				session['fbxsType'][fbx] = data['fbxsType'][fbx]
				index = fbxInput['cbx_Type'].findText(data['fbxsType'][fbx])
				if index != -1:
				    fbxInput['cbx_Type'].setCurrentIndex(index)

		self.widgetInput['list_Fbxs'].addWidget(fbxItem)
		self.widgetInput['btn_LoadFbxs']
		"""
	"""


	def SearchFolders(self):
		currentText = self.widgetInput['txt_TextSearch'].text()
		self.LoadFolders(currentText.lower())

	def UpdateFolderType(self):
		global session
		folderType =self.widgetInput['cbx_FolderType'].currentText()
		session["folderType"] = folderType		
		self.SaveFolderData()

	def ClearList(self,ui):
		for i in reversed(range(ui.count())):
			ui.itemAt(i).widget().deleteLater()

	def LoadFolderSinge(self):
		pass

	def LoadFolders(self,textSearch):		

		def LoadFolderFbxs(inputPath,inputFolder,*arr):
			global session
			session = {}
			session["path"] = inputPath
			session["folderName"] = inputFolder

			folderPath = inputPath+"/"+inputFolder
			folderDataPath = folderPath+"/folderData.json"
			data = NLTA_general.readJson(folderPath+"/folderData.json")

			def FbxTypeChange(fbxName,typeUI,*arr):
				fbxType = typeUI.currentText()
				session["fbxsType"][fbxName] = fbxType
				self.SaveFolderData()

			def SkeletonChange(fbxName,skeletonUI,*arr):
				val = skeletonUI.currentText()
				session["fbxsSkeleton"][fbxName] = val
				self.SaveFolderData()

			##### XU LY FOLDER
			self.widgetInput["lb_FolderName"].setText(inputFolder)
			if data:
				index = self.widgetInput["cbx_FolderType"].findText(data['folderType'])
				if index != -1:
				    self.widgetInput["cbx_FolderType"].setCurrentIndex(index)
			session["folderType"] = self.widgetInput["cbx_FolderType"].currentText()


			##### XU LY FBXS			
			self.ClearList(self.widgetInput['list_Fbxs'])
			session["fbxsType"] = {}
			session["fbxsSkeleton"] = {}
			fbxs = NLTA_general.getFiles(folderPath,"fbx")			
			for fbx in fbxs:
				fbxPattern = self.currentToolPath+"View/MBNG_FbxItems.ui"
				fbxItem = QtUiTools.QUiLoader().load(fbxPattern)
				fbxInput = NLTA_general.WidgetInput(fbxItem)
				fbxInput['lb_Name'].setText(fbx)
				fbxInput['btn_Import'].clicked.connect(partial(self.ImportSingle,fbx))

				### XU LY SKELETON
				fbxInput['cbx_Skeleton'].currentTextChanged.connect(partial(SkeletonChange,fbx,fbxInput['cbx_Skeleton']))
				session["fbxsSkeleton"][fbx] = fbxInput['cbx_Skeleton'].currentText()
				if session['folderType'] == "Charcter":					
					pass
				elif session['folderType'] == "Monster":
					pattern = re.compile(r"([A-Za-z_]+)\d+_mesh")
					match = pattern.match(fbx)
					if match:
						mainName = match.group(1)
						skeletonArray = []					
						skeletons = NLTA_Skeleton.GetAll()
						for skeleton in skeletons:
							if skeleton["name"].startswith(mainName):
								skeletonArray.append(skeleton["name"])
						if len(skeletonArray)!=0:
							skeletonArray.insert(0,"")
						NLTA_Pyside.ReloadComboBox(fbxInput['cbx_Skeleton'],skeletonArray)
				if data:
					if fbx in data["fbxsSkeleton"]:
						session["fbxsSkeleton"][fbx] = data["fbxsSkeleton"][fbx]
						index = fbxInput['cbx_Skeleton'].findText(data["fbxsSkeleton"][fbx])
						if index != -1:
						    fbxInput['cbx_Skeleton'].setCurrentIndex(index)

				### XU LY FBX TYPE
				fbxInput['cbx_Type'].currentTextChanged.connect(partial(FbxTypeChange,fbx,fbxInput['cbx_Type']))				
				session['fbxsType'][fbx] = fbxInput['cbx_Type'].currentText()
				if data:
					if fbx in data['fbxsType']:
						session['fbxsType'][fbx] = data['fbxsType'][fbx]
						index = fbxInput['cbx_Type'].findText(data['fbxsType'][fbx])
						if index != -1:
						    fbxInput['cbx_Type'].setCurrentIndex(index)

				self.widgetInput['list_Fbxs'].addWidget(fbxItem)			
			self.SaveFolderData()


		path = "D:/TASK/MBNG/Export"
		self.ClearList(self.widgetInput['list_Folders'])
		folders = NLTA_general.getFolders(path)
		for folder in folders:
			if textSearch in folder.lower():
				pattern = self.currentToolPath+"View/MBNG_FolderItem.ui"
				item = QtUiTools.QUiLoader().load(pattern)
				itemInput = NLTA_general.WidgetInput(item)
				itemInput['lb_Name'].setText(folder)
				itemInput['btn_Load'].clicked.connect(partial(LoadFolderFbxs,path,folder))
				self.widgetInput['list_Folders'].addWidget(item)


	def SaveFolderData(self):
		jsonPath = session["path"]+"/"+session["folderName"]+"/folderData.json"
		NLTA_general.writeJson(jsonPath,session)

	def ClearFolder(self):
		NLTA_general.DeleteAllFiles(session["path"]+"/"+session["folderName"])



	def CharacterImport(self,data):
		task = NLTA_Import.ImportPattern()
		task.filename = data['fbx']
		task.destination_path = data['destination']
		task.destination_name = data['name']
		if data['skeleton']:			
			task.options.skeleton = NLTA_Skeleton.GetAssetByName(data["skeleton"])
		task.options.import_mesh = True
		task.options.import_as_skeletal = True
		#task.options.create_physics_asset = True
		task.options.skeletal_mesh_import_data.set_editor_property("import_morph_targets", True)
		task.options.skeletal_mesh_import_data.normal_generation_method = unreal.FBXNormalGenerationMethod.MIKK_T_SPACE
		task.options.skeletal_mesh_import_data.vertex_color_import_option = unreal.VertexColorImportOption.REPLACE
		task.options.skeletal_mesh_import_data.normal_import_method = unreal.FBXNormalImportMethod.FBXNIM_IMPORT_NORMALS
		asset_tools = unreal.AssetToolsHelpers.get_asset_tools()
		asset_tools.import_asset_tasks([task])

	def CharacterModify(self,data):
		pass

	def MonsterImport(self,data):
		task = NLTA_Import.ImportPattern()
		task.filename = data['fbx']
		task.destination_path = data['destination']
		task.destination_name = data['name']
		if data['skeleton']:			
			task.options.skeleton = NLTA_Skeleton.GetAssetByName(data["skeleton"])
		task.options.import_mesh = True
		task.options.import_as_skeletal = True
		task.options.create_physics_asset = True
		task.options.skeletal_mesh_import_data.set_editor_property("import_morph_targets", True)
		task.options.skeletal_mesh_import_data.normal_generation_method = unreal.FBXNormalGenerationMethod.MIKK_T_SPACE
		task.options.skeletal_mesh_import_data.vertex_color_import_option = unreal.VertexColorImportOption.REPLACE
		task.options.skeletal_mesh_import_data.normal_import_method = unreal.FBXNormalImportMethod.FBXNIM_IMPORT_NORMALS
		asset_tools = unreal.AssetToolsHelpers.get_asset_tools()
		asset_tools.import_asset_tasks([task])

	def MonsterModify(self,fbxName):
		materialAsset = NLTA_Material.GetAssetByName("SM_"+fbxName)
		physicAsset = NLTA_PhysicAsset.GetAssetByName(fbxName+"_PhysicsAsset")
		skeletalMesh =  NLTA_SkeletalMesh.GetAssetByName(fbxName)
		skeleton = NLTA_Skeleton.GetAssetByName(fbxName+"_Skeleton")

		
		oldPath = physicAsset.get_path_name()
		newPath = oldPath.replace("_PhysicsAsset","_Physics")
		if physicAsset:			
			unreal.EditorAssetLibrary.rename_asset(oldPath,newPath)	
		
		#physicAsset = unreal.load_asset(newPath)

		if skeletalMesh and materialAsset:
			NLTA_Material.SetByAsset(skeletalMesh,materialAsset)
		

	def ImportSingle(self,fbx):
		dataPath = {
			"Character":"/Game/NLTA/Character",
			"Monster":"/Game/NLTA/Monster"
		}
		fbxPath = session["path"]+"/"+session["folderName"]+"/"+fbx+".fbx"
		destinationPath = dataPath[session["folderType"]] +"/"+session["folderName"]
		if not unreal.EditorAssetLibrary.does_directory_exist(destinationPath):
			unreal.EditorAssetLibrary.make_directory(destinationPath)

		importData = {
			"fbx":fbxPath,
			"name":fbx,
			"destination":destinationPath,
			"skeleton":session["fbxsSkeleton"][fbx]
		}
		fbxName = fbx
		fbxType = session['fbxsType'][fbx]
		if session["folderType"] == "Character":
			self.CharacterImport(importData)
		elif session["folderType"] == "Monster":
			self.MonsterImport(importData)
			self.MonsterModify(fbx)

	def ImportFolder(self):
		if session:
			for fbx in session['fbxsType']:
				print(fbx)
				self.ImportSingle(fbx)

	"""
import unreal
import os
from importlib import *
import NLTA_Pyside, NLTA_general, NLTA_Asset,NLTA_Actor,NLTA_AnimSequence,NLTA_Skeleton

NLTA_Pyside.LoadModule()

reload(NLTA_Pyside)
reload(NLTA_general)
reload(NLTA_Asset)
reload(NLTA_Skeleton)
reload(NLTA_AnimSequence)

session = {
	'tags':[],
	'items':{},
	'tagEdit':None,
	'skeletons':[],
	'currentItem':None,
	'ui':{
		'tags':{},
		'items':{},
		'currentItem':None,
	}
}


class CreateWindow(QtWidgets.QWidget):
	window = None
	def __init__(self,parent=None):
		super(CreateWindow,self).__init__(parent)		
		self.currentToolPath = NLTA_general.GetCurrentToolPath()
		self.sessionPath = unreal.SystemLibrary.get_project_directory()+'Content/Session.json'
		if not os.path.exists(self.sessionPath):
			NLTA_general.writeJson(self.sessionPath,{})
		self.widget = QtUiTools.QUiLoader().load(self.currentToolPath+"View/AnimationManager.ui")
		self.widget.setParent(self)
		self.widgetInput = NLTA_general.WidgetInput(self.widget)
		self.widgetInput['cbx_Skeletons'].currentIndexChanged.connect(self.FilterOk)
		self.widgetInput['txt_FilterName'].textChanged.connect(self.FilterOk)
		self.widgetInput['btn_TagOk'].clicked.connect(self.TagOk)		
		self.Detect()	


	def resizeEvent(self,event):
		self.widget.resize(self.width(),self.height())
	
	def closeWindow(self):
		self.destroy()

	def SaveData(self):
		sessionData = session.copy()
		del sessionData['ui']
		NLTA_general.writeJson(self.sessionPath,sessionData)

	def Detect(self):
		global session
		skeletons = NLTA_Skeleton.GetAll()
		for i in range(len(skeletons)):
			session['skeletons'].append({'name':str(skeletons[i]['name']),'path':str(skeletons[i]['path'])})			
			skeleton = unreal.load_asset(skeletons[i]['path'])
			animSequences = NLTA_AnimSequence.GetAnimSequencesFromSkeleton(skeleton)
			for animSequence in animSequences:
				session['items'][str(animSequence['path'])] = {
					'name':str(animSequence['name']),
					'tags':[],
					'group':[],
					'skeleton':str(skeletons[i]['path']),
					'show':1,
					'hide':0,
				}
			jsonData = NLTA_general.readJson(self.sessionPath)
			for key in jsonData:
				if key == 'items':
					for item in jsonData[key]:
						if item in session[key]:		
							for subKey in ['tags','group','hide']:#####
								session[key][item][subKey] = jsonData[key][item][subKey]
				if key == 'tags':
					session['tags'] = jsonData['tags']
		self.LoadItems()
		self.LoadSkeleton()
		self.ListCheckTags()			

	def LoadSkeleton(self):
		widget = self.widgetInput['cbx_Skeletons']
		skeletonArray = []
		for i in range(len(session['skeletons'])):
			skeletonArray.append(session['skeletons'][i]['name'])
		NLTA_general.reloadComboBox(widget,skeletonArray)

	def AssignTags(self):
		tagsArray = []
		for key in session['ui']['tags']:
			widget = session['ui']['tags'][key]
			widgetInput = NLTA_Pyside.WidgetInput(widget)
			if widgetInput['chx_Select'].isChecked():
				tagsArray.append(key)
		print(tagArray)

	def LoadItemTags(self):
		tags = session['items'][session['currentItem']]['tags']
		for tag in tags:
			ui = session['ui']['tags'][tag]

	def ListFilterTags(self):
		pass

	def ListCheckTags(self):
		global session
		widget = self.widgetInput['list_SelectTags']

		def Edit(name):
			global session
			session['tagEdit'] = name
			self.widgetInput['txt_NewTag'].setText(name)

		def Delete(data):
			name = data[0]
			widget =  data[1]
			global session
			for item in session['items']:
				if name in session['items'][item]['tags']:
					session['items'][item]['tags'].remove(name)
			session['tags'].remove(name)
			del session['ui']['tags'][name]
			widget.deleteLater()

		NLTA_Pyside.ClearWidget(widget)
		for key in session['tags']:
			pattern = self.currentToolPath+"View/AnimationManager_TagItem.ui"
			item = QtUiTools.QUiLoader().load(pattern)
			session['ui']['tags'][key] = item
			itemInput = NLTA_general.WidgetInput(item)
			itemInput['lb_Name'].setText(key)
			itemInput['btn_Edit'].clicked.connect(partial(Edit,key))
			itemInput['btn_Delete'].clicked.connect(partial(Delete,[key,item]))
			widget.addWidget(item)

	def TagOk(self):
		global session
		if session['tagEdit']==None:
			name = self.widgetInput['txt_NewTag'].text()
			if name:
				if name not in session['tags']:
					session['tags'].append(name)
					self.SaveData()
					self.ListCheckTags()
		else:
			oldTag = session['tagEdit']
			name = self.widgetInput['txt_NewTag'].text()
			if name:
				if name not in session['tags']:
					index = session['tags'].index(oldTag)
					session['tags'][index] = name
					self.SaveData()
					self.ListCheckTags()
					session['tagEdit'] = None
		self.widgetInput['txt_NewTag'].setText("")

	def ItemListCheckTags(self):
		tags = session['items'][session['currentItem']]['tags']
		for tag in tags:
			ui = session['ui']['tags'][tag]

	def ItemAssignTags(self):
		tagsArray = []
		for key in session['ui']['tags']:
			widget = session['ui']['tags'][key]
			widgetInput = NLTA_Pyside.widgetInput(widget)
			if widgetInput['chx_Select'].isChecked():
				tagsArray.append(key)

	def LoadItems(self):
		global session
		def SetActive(widget):
			pass

		def Watch(data):
			path = data[0]
			widget = data[1]
			if session['currentItem'] != path:
				currentWidget = session['ui']['widget']
				if currentWidget:
					currentWidget.setStyleSheet('background-color:none;')
				session['currentItem'] = path
				session['ui']['currentItem'] = widget
				widget.setStyleSheet('background-color: rgb(230, 230, 240);')
				asset = unreal.EditorAssetLibrary.load_asset(path)
				unreal.AssetToolsHelpers.get_asset_tools().open_editor_for_assets([asset])
			else:
				widget.setStyleSheet('background-color:none;')
				session['currentItem'] = None
				session['ui']['currentItem'] = None

		def Delete(data):
			path = data[0]
			widget = data[1]
			NLTA_Asset.Delete(path)
			widget.deleteLater()
			del session['items'][path]
			del session['ui']['items'][path]

		def HideData(data):
			global session
			path = data[0]
			widget = data[1]
			widget.deleteLater()
			session['items'][path]['hide'] = 1
			writeData = session.copy()
			del writeData['ui']
			self.SaveData()

		widget = self.widgetInput['list_AllItems']
		NLTA_Pyside.ClearWidget(widget)	
		for key in session['items']:
			if session['items'][key]['show'] == 1:
				pattern = self.currentToolPath+"View/AnimationManager_Item.ui"
				item = QtUiTools.QUiLoader().load(pattern)
				itemInput = NLTA_general.WidgetInput(item)
				itemInput['lb_Name'].setText(session['items'][key]['name'])
				itemInput['lb_Path'].setText(key)
				itemInput['btn_Watch'].clicked.connect(partial(Watch,[key,item]))
				itemInput['btn_Delete'].clicked.connect(partial(Delete,[key,item]))
				itemInput['btn_HideData'].clicked.connect(partial(HideData,[key,item]))
				itemInput['btn_Assign'].clicked.connect(partial(self.Assign,[key,item]))
				session['ui']['items'][key] = item				
				widget.addWidget(item)
	


	def FilterOk(self):
		global session
		if session['ui']['items']!={}:			
			name = self.widgetInput['txt_FilterName'].text()
			skeleton =  self.widgetInput['cbx_Skeletons'].currentText()

			for i in range(len(session['skeletons'])):
				if session['skeletons'][i]['name'] == skeleton:
					skeletonPath =  session['skeletons'][i]['path']		

			for key in session['items']:
				session['items'][key]['show'] = 0

			for key in session['items']:
				if (
					(session['items'][key]['skeleton'] == skeletonPath) and 
					(name.lower() in session['items'][key]['name'].lower()) and
					(session['items'][key]['hide'] == 0)
				):
					session['items'][key]['show'] = 1
			
			if session['ui']['items']:
				for key in session['items']:
					if session['items'][key]['show'] == 1:
						session['ui']['items'][key].show()
					else:
						session['ui']['items'][key].hide()
			
"""
#INSERT ANIMSEQUENCE INTRO SEQUENCER
import unreal
#paths (change these to your own)
sequencePath = '/Game/Cinematics/MySequence'
actorName = 'MyCharacter' #The name of the actor in the level
animPath = '/Game/Animations/MyAnimSequence'#Your AnimSequence
#Load assets
levelSequence =  unreal.EditorAssetLibrary.load_asset(sequencePath)
animSequence = unreal.EditorAssetLibrary.load_asset(animPath)

#Find actor in the Level
allActors = unreal.EditorLevelLibrary.get_all_level_actors()
targetActor = next((a for a in allActors if a.get_fname() == actorName),None)

if not levelSequence or not animSequence or not targetActor:
	print('Missing required asset or actor')
else:
	#Add actor to sequencer
	binding = levelSequence.add_possessable(targetActor)

	#Add animation track
	animTrack = binding.add_track(unreal.MovieSceneSkeletalAnimationTrack)

	#Add animation section
	animSection = animTrack.add_section()
	animSection.set_range_seconds(0,animSequence.sequence_length)
	animSection.params.animation = animSequence
	animSection.params.start_frame_offset = 0
	animSection.params.end_frame_offset = 0


#INSERT ANIMSEQUENCER AFTER OF ANIMATION SEQUENCE
import unreal

#Paths and actor name

sequencePath = '/Game/Cinematics/MySequence'
actorName = 'MyCharacter'
newAnimPath = '/Game/Animation/NewAnimSequence'

#Load Assets
levelSequence = unreal.EditorAssetLibrary.load_asset(sequencePath)
newAnim = unreal.EditorAssetLibrary.load_asset(newAnimPath)
#Get Actor
allActors = unreal.EditorLevelLibrary.get_all_level_actors()
targetActor = next((a for a in allActors if a.get_fname() == actorName),None)

if not levelSequence or not newAnim or not targetActor:
	print("Missing required asset or actor.")
else:
	#Find the existing binding or add a new one
	possessables = levelSequence.get_bindings()
	binding = None
	for b in possessables:
		if a.get_name() == actorName:
			binding = b
			break
	if not binding:
		binding = levelSequence.add_possessable(targetActor)

	#Find the skeletal animation track (create if not exist)
	tracks = binding.get_tracks()
	animTrack = None
	for track in tracks:
		if isinstance(track,unreal.MovieSceneSkeletalAnimationTrack):
			animTrack = track
			break
	if not animTrack:
		animTrack = binding.add_track(unreal.MovieSceneSkeletalAnimationTrack)

	#Find the end of the last animation section
	sections = animTrack.get_sections()
	if sections:
		lastSection = sections[-1]
		startFrame = lastSection.get_end_frame().value
	else:
		start_frame = 0

	#Convert frame to seconds
	framRate = levelSequence.get_display_rate()
	startTimeSec = unreal.TimeManagementLibrary.transform_time(
		source_time = unreal.FrameTime(startFrame),
		source_rate = framRate,
		destination_rate = framRate
	).as_seconds()

	#Add new animation section
	newSection = animTrack.add_section()
	newSection.set_range_seconds(startTimeSec,startTimeSec+newAnim.sequence_length)
	newSection.params.animation = newAnim
	newSection.params.start_frame_offset = 0
	newSection.params.end_frame_offset = 0





#MATCH WITH THIS BONE IN PREVIOUS CLIP
import unreal
#Your inputs
sequencePath = '/Game/Cinematics/MySequence'
actorName = 'MyCharacter'
boneName = 'Root' # or 'pelvis',etc

#load Sequence
sequence = unreal.EditorAssetLibrary.load_asset(sequencePath)
#Get Actor
actor = next(a for a in unreal.EditorLevelLibrary.get_all_level_actors() if a.get_fname() == actorName)
#Get Skeletal animation track
bindings = sequence.find_binding_by_name(actor.get_name())
if not bindings:
	print('No binding found.')
else:
	animTrack = None
	for track in bindings.get_tracks():
		if isinstance(track,unreal.MovieSceneSkeletalAnimationTrack):
			animTrack = track
			break
	if animTrack:
		sections = animTrack.get_sections()
		if len(sections) >=2:
			#Get previous and new sections
			prevSection = sections[-2]
			newSection = sections[-1]
			#Get bone transform at end of previous and start of new
			animPrev = prev_section_params.animation
			animNew = newSection.params.animation
			#Use engine's animation libraries (limited in python)
			animLib = unreal.AnimationBlueprintLibrary
			skeleton = animPrev.get_skeleton()

			#Sample transforms
			timePrev = animPrev.sequence_length
			timeNew = 0.0

			tPrev = animLib.get_bone_pose_for_time(animPrev,skeleton,boneName,timePrev,use_raw_data=False)
			tNew = animLib.get_bone_pose_for_time(animNew,skeleton,boneName,timePrev,use_raw_data=False)

			#Compute offset (simplified)
			deltaLoc = tPrev.translation = tNew.translation
			deltaRot = tPrev.rotation * tNew.rotation.inverse()

			#Apply offset to new section
			newSectionParams = newSection.params
			newSectionParams.translation = deltaLoc
			newSectionParams.rotation = deltaRot
			newSectionParams = newSectionParams

"""

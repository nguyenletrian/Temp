import NLTA_general
from importlib import *
reload(NLTA_general)
NLTA_general.openWindow({
	"controller":"NLTA_Ctrl_AnimationManager"
})
import unreal
import sys
import os
import shutil
import subprocess
from importlib import *
from PySide2 import QtUiTools, QtWidgets
from PySide2.QtWidgets import QMessageBox, QMenu
from functools import partial

import time

import NLTA_general
reload(NLTA_general)
import NLTA_SequenceNew
reload(NLTA_SequenceNew)


class CreateWindow(QtWidgets.QWidget):
	window = None
	def __init__(self,parent=None):
		super(CreateWindow,self).__init__(parent)
		
		self.dataPath = NLTA_general.getDataPath()
		self.toolPath = NLTA_general.getToolPath()
		self.currentToolPath = NLTA_general.GetCurrentToolPath()
		self.widget = QtUiTools.QUiLoader().load(self.currentToolPath+"View/NLTA_AnimationExportPose.ui")
		self.widget.setParent(self)

		self.btn_Ok = self.widget.findChild(QtWidgets.QPushButton,'btn_Ok')
		self.btn_Ok.clicked.connect(self.Ok)

		self.txt_Name = self.widget.findChild(QtWidgets.QLineEdit,'txt_Name')
		self.txt_Name.returnPressed.connect(self.btn_Ok.click)


	def resizeEvent(self,event):
		self.widget.resize(self.width(),self.height())
	
	def closeWindow(self):
		self.destroy()
		NLTA_general.openWindow({
			"controller":"NLTA_Ctrl_Animation",
			"posX":self.pos().x(),
			"posY":self.pos().y()
		})		

	def Ok(self):
		name = self.txt_Name.text()
		if name:
			path = NLTA_general.getSession("SelectedFolder")["path"]
			NLTA_SequenceNew.ExportPose({
				"name":name,
				"path":path
			})
			self.closeWindow()








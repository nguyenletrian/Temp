import unreal
import sys
import os
from importlib import *
from PySide2 import QtUiTools, QtWidgets
from PySide2.QtWidgets import QMessageBox

import NLTA_general
reload(NLTA_general)
import NLTA_SequenceNew
reload(NLTA_SequenceNew)

class CreateWindow(QtWidgets.QWidget):
	window = None
	def __init__(self,parent=None):
		super(CreateWindow,self).__init__(parent)

		self.dataPath = NLTA_general.getDataPath()
		self.toolPath = NLTA_general.getToolPath()
		self.currentToolPath = NLTA_general.GetCurrentToolPath()
		
		self.widget = QtUiTools.QUiLoader().load(self.currentToolPath+"View/NLTA_NewMirrorControlRig.ui")
		self.widget.setParent(self)

		self.widget.setFixedWidth(270)
		self.widget.setFixedHeight(150)
		self.btn_Submit = self.widget.findChild(QtWidgets.QPushButton,'btn_Submit')
		self.txt_Name = self.widget.findChild(QtWidgets.QLineEdit,'txt_Name')
		self.txt_Right = self.widget.findChild(QtWidgets.QLineEdit,'txt_Right')
		self.txt_Left = self.widget.findChild(QtWidgets.QLineEdit,'txt_Left')

		self.btn_Submit.clicked.connect(self.Submit)

	def resizeEvent(self,event):
		self.widget.resize(self.width(),self.height())
	
	def closeWindow(self):
		self.destroy()

	def closeEvent(self,event):
		NLTA_general.openWindow({
			"controller":"NLTA_Ctrl_Animation",
			"posX":self.pos().x(),
			"posY":self.pos().y()
		})

	def Submit(self):
		name = self.txt_Name.text()
		folder = self.dataPath+"/Mirror/"+str(name)+".json"
		if (name != ""):
			if os.path.exists(folder):
				NLTA_general.createMessageBox({
					"text":"This name is exist, do you want to replace it!?",
					"title":"Delete Confirm",
					"buttons":["Ok","Cancel"],
					"function":self.SubmitConfirm
				})
			else:
				self.SubmitComplete()

	def SubmitConfirm(self,i):
		if i.text() == "OK":
			self.SubmitComplete()

	def SubmitComplete(self):
		name = self.txt_Name.text()
		right = self.txt_Right.text()
		left = self.txt_Left.text()
		mirrorPlane = NLTA_SequenceNew.GetMirrorPlane({"right":right,"left":left})
		if mirrorPlane:
			data = {
				"name":name,
				"right":right,
				"left":left,
				"mirrorPlane":mirrorPlane,
				"data":{}
			}
			url = self.dataPath+"/Mirror/"+str(name)+".json"
			NLTA_general.writeJson(url,data)
			NLTA_general.openWindow({
				"controller":"NLTA_Ctrl_Animation",
				"posX":self.pos().x(),
				"posY":self.pos().y()
			})
			NLTA_general.setSession("collectionName",name)
		else:
			NLTA_general.createMessageBox({
				"text":"Couldn't find mirror setting with the inputs.",
				"title":"Warning"
			})


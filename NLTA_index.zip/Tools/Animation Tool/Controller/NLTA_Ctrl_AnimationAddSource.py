import unreal
import sys
import os
import shutil
import subprocess
from importlib import *
from PySide2 import QtUiTools, QtWidgets
from PySide2.QtWidgets import QMessageBox, QMenu
from functools import partial

import NLTA_general
reload(NLTA_general)


class CreateWindow(QtWidgets.QWidget):
	window = None
	def __init__(self,parent=None):
		super(CreateWindow,self).__init__(parent)
				
		self.dataPath = NLTA_general.getDataPath()
		self.toolPath = NLTA_general.getToolPath()
		self.currentToolPath = NLTA_general.GetCurrentToolPath()
		self.widget = QtUiTools.QUiLoader().load(self.currentToolPath+"View/NLTA_AnimationAddSource.ui")
		self.widget.setParent(self)

		self.btn_Ok = self.widget.findChild(QtWidgets.QPushButton,'btn_Ok')
		self.btn_Ok.clicked.connect(self.Ok)

		self.txt_Path = self.widget.findChild(QtWidgets.QLineEdit,'txt_Path')
		self.txt_Path.returnPressed.connect(self.btn_Ok.click)

		self.btn_ChoosePath = self.widget.findChild(QtWidgets.QPushButton,'btn_ChoosePath')
		self.btn_ChoosePath.clicked.connect(self.ChoosePath)



	def resizeEvent(self,event):
		self.widget.resize(self.width(),self.height())
	
	def closeWindow(self):
		self.destroy()
		NLTA_general.openWindow({
			"controller":"NLTA_Ctrl_Animation",			
			"posX":self.pos().x(),
			"posY":self.pos().y()
		})
	
	def ChoosePath(self):
		path = NLTA_general.DirectoryDialog(self)
		self.txt_Path.setText(path)

	def Ok(self):
		path = self.txt_Path.text()
		animationPaths = NLTA_general.getSession("AnimationPaths")
		if animationPaths:
			animationPaths.append(path)
			NLTA_general.setSession("AnimationPaths",animationPaths)
		else:
			NLTA_general.setSession("AnimationPaths",[path])
		self.closeWindow()








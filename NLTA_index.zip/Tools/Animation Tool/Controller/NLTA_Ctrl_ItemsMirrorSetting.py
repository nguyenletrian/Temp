import unreal
import sys
import os
from importlib import *
from functools import partial
from PySide2 import QtUiTools, QtWidgets
from PySide2.QtWidgets import QMessageBox

import NLTA_general
reload(NLTA_general)
import NLTA_SequenceNew
reload(NLTA_SequenceNew)

class CreateWindow(QtWidgets.QWidget):
	window = None
	def __init__(self,parent=None):
		super(CreateWindow,self).__init__(parent)
		self.dataPath = NLTA_general.getDataPath()
		self.toolPath = NLTA_general.getToolPath()
		self.currentToolPath = NLTA_general.GetCurrentToolPath()
		self.widget = QtUiTools.QUiLoader().load(self.currentToolPath+"View/NLTA_ItemsMirrorControlRig.ui")
		self.widget.setParent(self)
		self.widget.setFixedWidth(411)
		self.widget.setFixedHeight(441)

		self.id = NLTA_general.getSession("collectionName")
		self.url = self.dataPath+"Mirror/"+self.id+".json"
		self.data = NLTA_general.readJson(self.url)

		"""
		self.cbx_TranslateX = self.widget.findChild(QtWidgets.QComboBox,'cbx_TranslateX')
		self.cbx_TranslateY = self.widget.findChild(QtWidgets.QComboBox,'cbx_TranslateY')
		self.cbx_TranslateZ = self.widget.findChild(QtWidgets.QComboBox,'cbx_TranslateZ')
		self.cbx_RotateX = self.widget.findChild(QtWidgets.QComboBox,'cbx_RotateX')
		self.cbx_RotateY = self.widget.findChild(QtWidgets.QComboBox,'cbx_RotateY')
		self.cbx_RotateZ = self.widget.findChild(QtWidgets.QComboBox,'cbx_RotateZ')
		"""
		self.list_Axises = self.widget.findChild(QtWidgets.QVBoxLayout,'list_Axises')
		self.loadAxises()
		#self.btn_Add = self.widget.findChild(QtWidgets.QPushButton,'btn_Add')
		self.btn_ZeroTransform = self.widget.findChild(QtWidgets.QPushButton,'btn_ZeroTransform')
		self.btn_SwitchControl = self.widget.findChild(QtWidgets.QPushButton,'btn_SwitchControl')	
		#self.btn_Add.clicked.connect(self.Add)
		self.btn_ZeroTransform.clicked.connect(self.zeroTransform)
		self.btn_SwitchControl.clicked.connect(self.switchMirror)

	def resizeEvent(self,event):
		self.widget.resize(self.width(),self.height())
	
	def closeWindow(self):
		self.destroy()

	def closeEvent(self,event):
		NLTA_general.openWindow({
			"controller":"NLTA_Ctrl_Animation",			
			"posX":self.pos().x(),
			"posY":self.pos().y()
		})

	def switchMirror(self):
		NLTA_SequenceNew.selectMirrorControl(self.data["right"],self.data["left"])

	def zeroTransform(self):
		NLTA_SequenceNew.ZeroTransform()

	def loadControls(self,widget,axis,name):
		pattern = self.currentToolPath+"View/NLTA_ControlItemMirrorControlRig.ui"
		controlWidget = QtUiTools.QUiLoader().load(pattern)
		lb_name = controlWidget.findChild(QtWidgets.QLabel,"lb_name")		
		lb_name.setText(name)
		btn_remove = controlWidget.findChild(QtWidgets.QPushButton,"btn_remove")
		btn_remove.clicked.connect(partial(self.deleteControl,{"axis":axis,"name":name}))	
		widget.addWidget(controlWidget)
		
	def addItem(self,axisName):
		data = NLTA_general.readJson(self.url)
		sequenceData = NLTA_SequenceNew.getSequenceData()
		selectedControls = NLTA_SequenceNew.GetControlSelected(sequenceData)
		data["data"][axisName]["controls"] += selectedControls
		NLTA_general.writeJson(self.url,data)
		self.loadAxises()
	

	def loadAxises(self):	
		self.data = NLTA_general.readJson(self.url)
		for i in reversed(range(self.list_Axises.count())):
			self.list_Axises.itemAt(i).widget().deleteLater()

		for axisName in self.data["data"]:
			axisPattern = self.currentToolPath+"View/NLTA_AxisItemMirrorControlRig.ui"
			axisWidget = QtUiTools.QUiLoader().load(axisPattern)
			cbx_TranslateX = axisWidget.findChild(QtWidgets.QComboBox,"cbx_TranslateX")
			cbx_TranslateY = axisWidget.findChild(QtWidgets.QComboBox,"cbx_TranslateY")
			cbx_TranslateZ = axisWidget.findChild(QtWidgets.QComboBox,"cbx_TranslateZ")
			cbx_RotateX = axisWidget.findChild(QtWidgets.QComboBox,"cbx_RotateX")
			cbx_RotateY = axisWidget.findChild(QtWidgets.QComboBox,"cbx_RotateY")
			cbx_RotateZ = axisWidget.findChild(QtWidgets.QComboBox,"cbx_RotateZ")

			cbx_TranslateX.setCurrentIndex(self.data["data"][axisName]["mirrorSetting"]["comboboxValue"][0])
			cbx_TranslateY.setCurrentIndex(self.data["data"][axisName]["mirrorSetting"]["comboboxValue"][1])
			cbx_TranslateZ.setCurrentIndex(self.data["data"][axisName]["mirrorSetting"]["comboboxValue"][2])
			cbx_RotateX.setCurrentIndex(self.data["data"][axisName]["mirrorSetting"]["comboboxValue"][3])
			cbx_RotateY.setCurrentIndex(self.data["data"][axisName]["mirrorSetting"]["comboboxValue"][4])
			cbx_RotateZ.setCurrentIndex(self.data["data"][axisName]["mirrorSetting"]["comboboxValue"][5])
			
			cbx_TranslateX.currentIndexChanged.connect(partial(self.editAxises,axisName,axisWidget))
			cbx_TranslateY.currentIndexChanged.connect(partial(self.editAxises,axisName,axisWidget))
			cbx_TranslateZ.currentIndexChanged.connect(partial(self.editAxises,axisName,axisWidget))
			cbx_RotateX.currentIndexChanged.connect(partial(self.editAxises,axisName,axisWidget))
			cbx_RotateY.currentIndexChanged.connect(partial(self.editAxises,axisName,axisWidget))
			cbx_RotateZ.currentIndexChanged.connect(partial(self.editAxises,axisName,axisWidget))

			btn_AddItem = axisWidget.findChild(QtWidgets.QPushButton,"btn_AddItem")
			btn_DeleteAxis = axisWidget.findChild(QtWidgets.QPushButton,"btn_DeleteAxis")
			btn_AddItem.clicked.connect(partial(self.addItem,axisName))
			btn_DeleteAxis.clicked.connect(partial(self.deleteAxis,axisName))
			for control in self.data["data"][axisName]["controls"]:
				list_Controls = axisWidget.findChild(QtWidgets.QVBoxLayout,"list_Controls")				
				self.loadControls(list_Controls,axisName,control)
			self.list_Axises.addWidget(axisWidget)

	def editAxises(self,name,axisWidget,i):
		cbx_TranslateX = axisWidget.findChild(QtWidgets.QComboBox,"cbx_TranslateX")
		cbx_TranslateY = axisWidget.findChild(QtWidgets.QComboBox,"cbx_TranslateY")
		cbx_TranslateZ = axisWidget.findChild(QtWidgets.QComboBox,"cbx_TranslateZ")
		cbx_RotateX = axisWidget.findChild(QtWidgets.QComboBox,"cbx_RotateX")
		cbx_RotateY = axisWidget.findChild(QtWidgets.QComboBox,"cbx_RotateY")
		cbx_RotateZ = axisWidget.findChild(QtWidgets.QComboBox,"cbx_RotateZ")
		newName = ("   ").join([
			cbx_TranslateX.currentText(),
			cbx_TranslateY.currentText(),
			cbx_TranslateZ.currentText(),
			cbx_RotateX.currentText(),
			cbx_RotateY.currentText(),
			cbx_RotateZ.currentText(),
		])
		self.settingAxis({
			"name":name,
			"newName":newName,
			"axisSetting":[
				cbx_TranslateX.currentIndex(),
				cbx_TranslateY.currentIndex(),
				cbx_TranslateZ.currentIndex(),
				cbx_RotateX.currentIndex(),
				cbx_RotateY.currentIndex(),
				cbx_RotateZ.currentIndex(),
			]
		})
		

	def settingAxis(self,axisSetting):		
		data = NLTA_general.readJson(self.url)
		name = axisSetting["name"]
		settingData = axisSetting["axisSetting"] 
		axisArray = ["X","Y","Z","X","Y","Z"]
		negOprtionArray = [+1,+1,+1,-1,-1,-1]
		mirrorSetting = {
			"comboboxValue":settingData,
			"neg":[
				negOprtionArray[settingData[0]],
				negOprtionArray[settingData[1]],
				negOprtionArray[settingData[2]],
				negOprtionArray[settingData[3]],
				negOprtionArray[settingData[4]],
				negOprtionArray[settingData[5]]
			],
			"axis":[
				axisArray[settingData[0]],
				axisArray[settingData[1]],
				axisArray[settingData[2]],
				axisArray[settingData[3]],
				axisArray[settingData[4]],
				axisArray[settingData[5]]
			]
		}

		data["data"][name]["mirrorSetting"] = mirrorSetting
		if "newName" in axisSetting:
			newName = axisSetting["newName"]	
			if newName in data["data"]:
				controls = data["data"][newName]["controls"]
				data["data"][name]["controls"] = controls + data["data"][name]["controls"]
			data["data"][newName] = data["data"].pop(name)

		NLTA_general.writeJson(self.url,data)
		self.loadAxises()

	"""
	def Add(self):
		axisName = ("   ").join([
			self.cbx_TranslateX.currentText(),
			self.cbx_TranslateY.currentText(),
			self.cbx_TranslateZ.currentText(),
			self.cbx_RotateX.currentText(),
			self.cbx_RotateY.currentText(),
			self.cbx_RotateZ.currentText(),
		])
		if axisName not in self.data["data"]:
			self.data["data"][axisName] = {
				"controls":[],
				"mirrorSetting":{},
				"comboboxValue":[]
			}
		controls = []
		selectData = NLTA_SequenceNew.GetControlSelected()
		for controlRig in selectData:
			controls.extend(selectData[controlRig]["controls"])
		for control in controls:
			if control not in self.data["data"][axisName]["controls"]:
				self.data["data"][axisName]["controls"].append(control)
		NLTA_general.writeJson(self.url,self.data)

		self.settingAxis({
			"name":axisName,
			"axisSetting":[
				self.cbx_TranslateX.currentIndex(),
				self.cbx_TranslateY.currentIndex(),
				self.cbx_TranslateZ.currentIndex(),
				self.cbx_RotateX.currentIndex(),
				self.cbx_RotateY.currentIndex(),
				self.cbx_RotateZ.currentIndex(),
			]
		})
		self.loadAxises()
	"""

	def deleteAxis(self,name):
		del self.data["data"][name]
		NLTA_general.writeJson(self.url,self.data)
		self.loadAxises()

	def deleteControl(self,data):
		axis = data["axis"]
		name = data["name"]
		self.data = NLTA_general.readJson(self.url)
		self.data["data"][axis]["controls"].remove(name)
		if len(self.data["data"][axis]["controls"])==0:
			del self.data["data"][axis]
		NLTA_general.writeJson(self.url,self.data)
		self.loadAxises()
	

		
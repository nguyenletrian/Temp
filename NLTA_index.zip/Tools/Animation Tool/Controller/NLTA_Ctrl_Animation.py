import unreal
import sys
import os
import shutil
import subprocess
import threading
from importlib import *
from PySide2 import QtUiTools, QtWidgets
from PySide2.QtWidgets import QMessageBox, QMenu, QTreeView, QTreeWidgetItem,QTreeWidgetItemIterator
from PySide2 import QtCore
from PySide2 import QtGui
from PySide2.QtGui import QPixmap


from functools import partial

import NLTA_general
reload(NLTA_general)
import NLTA_SequenceNew
reload(NLTA_SequenceNew)
import NLTA_Actor
reload(NLTA_Actor)


class CreateWindow(QtWidgets.QWidget):
	window = None
	def __init__(self,parent=None):
		super(CreateWindow,self).__init__(parent)

		self.dataPath = NLTA_general.getDataPath()
		self.toolPath = NLTA_general.getToolPath()
		self.currentToolPath = NLTA_general.GetCurrentToolPath()
		self.widget = QtUiTools.QUiLoader().load(self.currentToolPath+"View/NLTA_AnimationMain.ui")
		
		self.ac_AddSource = self.widget.findChild(QtWidgets.QAction,'ac_AddSource')
		self.ac_AddSource.triggered.connect(self.AddSource)

		self.widget.setParent(self)

		self.tree_Folders = self.widget.findChild(QtWidgets.QTreeWidget,'tree_Folders')
		self.tree_Folders.setHeaderHidden(True)
		self.tree_Folders.itemClicked.connect(self.FolderClick)
		self.tree_Folders.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
		self.tree_Folders.customContextMenuRequested.connect(self.FolderRightClick)

		self.txt_SearchName = self.widget.findChild(QtWidgets.QLineEdit,'txt_SearchName')
		self.txt_SearchName.textChanged.connect(self.LoadItems)
		self.chek_TypeAnim = self.widget.findChild(QtWidgets.QCheckBox,'chek_TypeAnim')
		self.chek_TypeAnim.stateChanged.connect(self.LoadItems)
		self.chek_TypePose = self.widget.findChild(QtWidgets.QCheckBox,'chek_TypePose')
		self.chek_TypePose.stateChanged.connect(self.LoadItems)

		self.list_Items = self.widget.findChild(QtWidgets.QFormLayout,'list_Items')
		self.LoadFolders()


		self.btn_ExportPose = self.widget.findChild(QtWidgets.QPushButton,'btn_ExportPose')
		self.btn_ExportPose.clicked.connect(self.ExportPose)
		self.btn_ExportAnimation = self.widget.findChild(QtWidgets.QPushButton,'btn_ExportAnimation')
		self.btn_ExportAnimation.clicked.connect(self.ExportAnimation)

		########################################******


		self.btn_SavePose = self.widget.findChild(QtWidgets.QPushButton,'btn_SavePose')
		self.btn_SavePose.clicked.connect(self.SaveClipboardPose)
		self.btn_PastePose = self.widget.findChild(QtWidgets.QPushButton,'btn_PastePose')		
		self.btn_PastePose.clicked.connect(self.PasteClipboardPose)
		self.btn_SelectBindingControls = self.widget.findChild(QtWidgets.QPushButton,'btn_SelectBindingControls')
		self.btn_SelectBindingControls.clicked.connect(self.SelectBindingControls)
		self.btn_ZeroTransform = self.widget.findChild(QtWidgets.QPushButton,'btn_ZeroTransform')
		self.btn_ZeroTransform.clicked.connect(self.ZeroTransform)

		

		self.btn_SaveAnimation = self.widget.findChild(QtWidgets.QPushButton,'btn_SaveAnimation')
		self.btn_SaveAnimation.clicked.connect(self.SaveClipboardAnimation)
		self.btn_PasteAnimation = self.widget.findChild(QtWidgets.QPushButton,'btn_PasteAnimation')
		self.btn_PasteAnimation.clicked.connect(self.PasteClipboardAnimation)

		self.btn_NewMirrorSetting = self.widget.findChild(QtWidgets.QPushButton,'btn_NewMirrorSetting')
		self.btn_NewMirrorSetting.clicked.connect(self.NewMirrorSetting)
		self.btn_AddMirrorSetting = self.widget.findChild(QtWidgets.QPushButton,'btn_AddMirrorSetting')
		self.btn_AddMirrorSetting.clicked.connect(self.AddMirrorSetting)
		self.btn_ItemsMirrorSetting = self.widget.findChild(QtWidgets.QPushButton,'btn_ItemsMirrorSetting')
		self.btn_ItemsMirrorSetting.clicked.connect(self.ItemsMirrorSetting)
		self.btn_DeleteMirrorSetting = self.widget.findChild(QtWidgets.QPushButton,'btn_DeleteMirrorSetting')
		self.btn_DeleteMirrorSetting.clicked.connect(self.DeleteMirrorSetting)
		self.cbx_MirrorControlRig = self.widget.findChild(QtWidgets.QComboBox,'cbx_MirrorControlRig')		
		self.cbx_MirrorControlRig.currentIndexChanged.connect(partial(self.createCollectionSession))


		self.btn_Mirror = self.widget.findChild(QtWidgets.QPushButton,'btn_Mirror')
		self.btn_Mirror.clicked.connect(self.Mirror)
		self.btn_Flip = self.widget.findChild(QtWidgets.QPushButton,'btn_Flip')
		self.btn_Flip.clicked.connect(self.Flip)
		self.btn_SwitchMirror = self.widget.findChild(QtWidgets.QPushButton,'btn_SwitchMirror')
		self.btn_SwitchMirror.clicked.connect(self.SwitchMirror)
		self.btn_PlayPausePlayback = self.widget.findChild(QtWidgets.QPushButton,'btn_PlayPausePlayback')
		self.btn_PlayPausePlayback.clicked.connect(self.PlayPausePlayback)
		self.btn_ClearKeyframe = self.widget.findChild(QtWidgets.QPushButton,'btn_ClearKeyframe')
		self.btn_ClearKeyframe.clicked.connect(self.ClearKeyframe)
		self.btn_AddKeyframe = self.widget.findChild(QtWidgets.QPushButton,'btn_AddKeyframe')
		self.btn_AddKeyframe.clicked.connect(self.AddKeyframe)
		self.btn_AddMiddleKeyframe = self.widget.findChild(QtWidgets.QPushButton,'btn_AddMiddleKeyframe')
		self.btn_AddMiddleKeyframe.clicked.connect(self.AddMiddleKeyframe)
		self.btn_GoStartFrame = self.widget.findChild(QtWidgets.QPushButton,'btn_GoStartFrame')
		self.btn_GoStartFrame.clicked.connect(self.GoStartFrame)
		self.btn_NextKeyframe = self.widget.findChild(QtWidgets.QPushButton,'btn_NextKeyframe')
		self.btn_NextKeyframe.clicked.connect(self.NextKeyframe)
		self.btn_PreviousKeyframe = self.widget.findChild(QtWidgets.QPushButton,'btn_PreviousKeyframe')
		self.btn_PreviousKeyframe.clicked.connect(self.PreviousKeyframe)
		self.btn_GoEndFrame = self.widget.findChild(QtWidgets.QPushButton,'btn_GoEndFrame')
		self.btn_GoEndFrame.clicked.connect(self.GoEndFrame)



		NLTA_general.reloadComboBox(
			self.cbx_MirrorControlRig,
			NLTA_general.getFiles(self.dataPath+"Mirror/","json")
		)

		if NLTA_general.getSession("collectionName"):
			index = self.cbx_MirrorControlRig.findText(NLTA_general.getSession("collectionName"))
			self.cbx_MirrorControlRig.setCurrentIndex(index)


	def resizeEvent(self,event):
		self.widget.resize(self.width(),self.height())
	
	def closeWindow(self):
		self.destroy()

	def AddSource(self):
		NLTA_general.openWindow({
			"controller":"NLTA_Ctrl_AnimationAddSource",
			"popup":True,
			"posX":self.pos().x(),
			"posY":self.pos().y()
		})

	def FolderClick(self,item,col):
		path = item.toolTip(0)
		NLTA_general.setSession("SelectedFolder",{
			"path":path
		})
		self.LoadItems()

	def FolderRightClick(self,point):
		toolTip = self.tree_Folders.selectedItems()[0].toolTip(0)
		NLTA_general.setSession("SelectedFolder",{
			"path":toolTip
		})
		menu = QMenu(self)
		action_1 = menu.addAction("New Folder",self.NewFolder)
		action_2 = menu.addAction("Delete Folder",self.DeleteFolderConfirm)
		AnimationPaths = NLTA_general.getSession("AnimationPaths")
		if toolTip in AnimationPaths:
			action_3 = menu.addAction("Remove Source",self.RemoveSource)	
		menu.exec_(QtGui.QCursor.pos())

	def NewFolder(self):
		NLTA_general.openWindow({
			"controller":"NLTA_Ctrl_AnimationNewFolder",
			"popup":True,
			"posX":self.pos().x(),
			"posY":self.pos().y()
		})

	def RemoveSource(self):
		path = NLTA_general.getSession("SelectedFolder")["path"]
		AnimationPaths = NLTA_general.getSession("AnimationPaths")
		AnimationPaths.remove(path)
		NLTA_general.setSession("AnimationPaths",AnimationPaths)
		NLTA_general.openWindow({
			"controller":"NLTA_Ctrl_Animation",
			"posX":self.pos().x(),
			"posY":self.pos().y()
		})


	def DeleteFolder(self,i):
		if i.text() == "OK":
			path = NLTA_general.getSession("SelectedFolder")["path"]
			parentFolder = ("/").join(path.split("/")[0:-1])
			NLTA_general.setSession("SelectedFolder",{"path":parentFolder})
			if os.path.isdir(path):
				shutil.rmtree(path)
			AnimationPaths = NLTA_general.getSession("AnimationPaths")
			if path in AnimationPaths:
				AnimationPaths.remove(path)
			NLTA_general.setSession("AnimationPaths",AnimationPaths)	
			NLTA_general.openWindow({
				"controller":"NLTA_Ctrl_Animation",
				"posX":self.pos().x(),
				"posY":self.pos().y()
			})

	def DeleteFolderConfirm(self):
		NLTA_general.createMessageBox({
			"text":"Are you sure you want to delete it?",
			"title":"Delete Confirm",
			"buttons":["Ok","Cancel"],
			"function":partial(self.DeleteFolder)
		})	


	def createCollectionSession(self,i):
		NLTA_general.setSession("collectionName",self.cbx_MirrorControlRig.currentText())
	
	def contextMenuEvent(self,event):
		pass
		#context_menu = QMenu(self)
		#action1 = context_menu.addAction("Action 1",self.Test)
		#action = context_menu.exec_(self.mapToGlobal(event.pos()))

	def LoadFolder(self,inputData):
		path = inputData["path"]		
		items = inputData["items"]
		parent = inputData["parent"]

		name = path.split("/")[-1]
		item = QTreeWidgetItem([name])
		item.setToolTip(0,path)
		if parent != None:
			parent.addChild(item)
		folders = NLTA_general.getFolders(path)
		for folder in folders:
			if ("-NLTA-Pose-" not in folder) and ("-NLTA-Animation-" not in folder): 
				self.LoadFolder({
					"path":path+"/"+folder,
					"parent":item,
					"items":items
				})
		items.append(item)
		return(items)

	def LoadFolders(self):
		paths = NLTA_general.getSession("AnimationPaths")
		if paths:
			for path in paths:
				items = self.LoadFolder({
					"path":path,
					"parent":None,
					"items":[]
				})
				self.tree_Folders.insertTopLevelItems(0,items)

		SelectedFolder = NLTA_general.getSession("SelectedFolder")
		if SelectedFolder:
			it = QTreeWidgetItemIterator(self.tree_Folders,QTreeWidgetItemIterator.NotHidden) 
			while it.value():
				item = it.value()
				toolTip = item.toolTip(0)
				if toolTip == SelectedFolder["path"]:
					self.tree_Folders.setCurrentItem(item)
					self.LoadItems()
					break
				it+=1

	def DeleteItem(self,inputData,i):
		if i.text() == "OK":
			if os.path.exists(inputData["path"]):
				shutil.rmtree(inputData["path"])
				self.LoadItems()
		
	def DeleteItemConfirm(self,inputData):
		NLTA_general.createMessageBox({
			"text":"Are you sure you want to delete it?",
			"title":"Delete Confirm",
			"buttons":["Ok","Cancel"],
			"function":partial(self.DeleteItem,inputData)
		})

	def SelectDataControls(self,inputData):
		path = inputData["path"]+"/Data.json"
		data = NLTA_general.readJson(path)
		NLTA_SequenceNew.SelectControls(data["controls"])

	def RenameAnimationItem(self,inputData):
		NLTA_general.setSession("SelectedFolder",inputData)
		NLTA_general.openWindow({
			"controller":"NLTA_Ctrl_AnimationItemRename",
			"popup":True,
			"posX":self.pos().x(),
			"posY":self.pos().y()
		})


	def LoadItems(self):
		typeArray = []
		searchName = self.txt_SearchName.text()
		if self.chek_TypeAnim.isChecked() == True:
			typeArray.append("-NLTA-Animation-")
		if self.chek_TypePose.isChecked() == True:
			typeArray.append("-NLTA-Pose-")
		
		path = self.tree_Folders.selectedItems()[0].toolTip(0)		
		for i in reversed(range(self.list_Items.count())):
			self.list_Items.itemAt(i).widget().deleteLater()

		##### url = toolPath+"/Clipboard/TempAnimation.json"####

		folders = NLTA_general.getFolders(path)
		for folder in folders:
			flag = False
			for typeEach in typeArray:
				if typeEach in folder:
					flag = True
			if flag ==  True:
				if searchName in folder:
					pattern = self.currentToolPath+"View/NLTA_AnimationItem.ui"
					item = QtUiTools.QUiLoader().load(pattern)

					btn_Import = item.findChild(QtWidgets.QPushButton,"btn_Import")
					btn_Import.setToolTip(path+"/"+folder)

					styleSheet = """					
						.QPushButton{
							border:1px solid rgba(0,0,0,0.1);
							width:70px;
							border-radius:3px;
							background-color:rgba(255,255,255,.5);
							cursor:pointer;
						}
						.QPushButton:hover{
							background-color:rgba(255,255,255,1);
						}
						.QLabel{
							background-color:rgba(0,0,0,0);
						}
					"""
					if "-NLTA-Pose-" in folder:
						splitFix = "-NLTA-Pose-"
						itemType = "Pose"
						styleSheet += """
							.QWidget{
								background-color:rgba(0,0,0,.05);
								border-radius:3px;
								border:1px solid rgba(0,0,0,0.1);
							}
						"""
						btn_Import.clicked.connect(partial(NLTA_SequenceNew.PastePose,path+"/"+folder+"/Data.json"))

					elif "-NLTA-Animation-" in folder:
						splitFix = "-NLTA-Animation-"
						itemType = "Animation"
						styleSheet += """
							.QWidget{
								background-color:rgba(0,255,0,.05);
								border-radius:3px;
								border:1px solid rgba(0,0,0,0.1);
							}
						"""
						btn_Import.clicked.connect(partial(NLTA_SequenceNew.PasteAnimation,path+"/"+folder+"/Data.json"))

					
					item.setStyleSheet(styleSheet)

					lb_Capture = item.findChild(QtWidgets.QLabel,"lb_Capture")
					capturePath = path+"/"+folder+"/-NLTA-Capture/ScreenCapture.png"
					if not os.path.exists(capturePath):
						def threadFunction(dataTemp):
							dataTemp["lb_Capture"].setPixmap(dataTemp["capturePath"])
						t = threading.Timer(1,partial(threadFunction,
							{
								"lb_Capture":lb_Capture,
								"capturePath":capturePath
							}))
						t.start()
					else:
						lb_Capture.setPixmap(capturePath)

					
					lb_Name = item.findChild(QtWidgets.QLabel,"lb_Name")
					name = folder.split(splitFix)[-1]
					lb_Name.setText(name)

					lb_Type = item.findChild(QtWidgets.QLabel,"lb_Type")
					lb_Type.setText(itemType)
					

					btn_SelectControls = item.findChild(QtWidgets.QPushButton,"btn_SelectControls")
					#btn_SelectControls.setToolTip(path+"/"+folder)
					btn_SelectControls.clicked.connect(partial(self.SelectDataControls,{
						"path":path+"/"+folder
					}))

					btn_Delete = item.findChild(QtWidgets.QPushButton,"btn_Delete")
					#btn_Delete.setToolTip(path+"/"+folder)
					btn_Delete.clicked.connect(partial(self.DeleteItemConfirm,{
						"path":path+"/"+folder,
						"name":name,
					}))

					btn_Rename = item.findChild(QtWidgets.QPushButton,"btn_Rename")
					#btn_Rename.setToolTip(path+"/"+folder)
					btn_Rename.clicked.connect(partial(self.RenameAnimationItem,{
						"path":path,
						"item":folder,
						"splitFix":splitFix
					}))

					self.list_Items.addWidget(item)
	


		
	def SelectBindingControls(self):
		NLTA_SequenceNew.SelectBindingControls()

	def ZeroTransform(self):
		NLTA_SequenceNew.ZeroTransform()

	def ExportPose(self):
		if len(self.tree_Folders.selectedItems()) == 0:
			NLTA_general.createMessageBox({
				"text":"Please select a folder",
				"title":"Warning",
				"buttons":["Ok"]
			})
		else:			
			NLTA_general.openWindow({
				"controller":"NLTA_Ctrl_AnimationExportPose",
				"popup":True,
				"posX":self.pos().x(),
				"posY":self.pos().y()
			})
	def ExportAnimation(self):
		if len(self.tree_Folders.selectedItems()) == 0:
			NLTA_general.createMessageBox({
				"text":"Please select a folder",
				"title":"Warning",
				"buttons":["Ok"]
			})
		else:			
			NLTA_general.openWindow({
				"controller":"NLTA_Ctrl_AnimationExportAnimation",
				"popup":True,
				"posX":self.pos().x(),
				"posY":self.pos().y()
			})


	def SaveClipboardPose(self):
		NLTA_SequenceNew.SaveClipboardPose(self.dataPath)

	def PasteClipboardPose(self):
		NLTA_SequenceNew.PastePose(self.dataPath+"Clipboard/TempPose.json")

	def SaveClipboardAnimation(self):
		NLTA_SequenceNew.SaveClipboardAnimation(self.dataPath)

	def PasteClipboardAnimation(self):
		NLTA_SequenceNew.PasteAnimation(self.dataPath+"Clipboard/TempAnimation.json")
		
	def NewMirrorSetting(self):
		sequenceData = NLTA_SequenceNew.getSequenceData()
		if sequenceData:
			NLTA_general.openWindow({
				"controller":"NLTA_Ctrl_NewMirrorSetting",
				"popup":True,
				"posX":self.pos().x(),
				"posY":self.pos().y()
			})
		else:		
			NLTA_general.createMessageBox({
				"text":"Please open a sequence and select a side control.",
				"title":"Warning!~"
			})


	def ItemsMirrorSetting(self):
		NLTA_general.openWindow({
			"controller":"NLTA_Ctrl_ItemsMirrorSetting",
			"popup":True,
			"posX":self.pos().x(),
			"posY":self.pos().y()
		})

	def AddMirrorSetting(self):
		name = self.cbx_MirrorControlRig.currentText()
		url = self.dataPath+"/Mirror/"+str(name)+".json"
		data = NLTA_general.readJson(url)
		NLTA_SequenceNew.AddMirrorSetting({
			"right":data["right"],
			"left":data["left"],
			"mirrorPlane":data["mirrorPlane"],
			"url":url
		})

	def DeleteMirrorSetting(self):
		name = self.cbx_MirrorControlRig.currentText()
		url = self.dataPath+"/Mirror/"+str(name)+".json"
		os.remove(url)
		NLTA_general.reloadComboBox(
			self.cbx_MirrorControlRig,
			NLTA_general.getFiles(self.dataPath+"Mirror/","json")
		)

	def Mirror(self):
		name = self.cbx_MirrorControlRig.currentText()
		url = self.dataPath+"/Mirror/"+str(name)+".json"
		NLTA_SequenceNew.Mirror(NLTA_general.readJson(url),"mirror")

	def Flip(self):
		name = self.cbx_MirrorControlRig.currentText()
		url = self.dataPath+"/Mirror/"+str(name)+".json"
		NLTA_SequenceNew.Mirror(NLTA_general.readJson(url),"flip")

	def SwitchMirror(self):
		name = self.cbx_MirrorControlRig.currentText()
		url = self.dataPath+"/Mirror/"+str(name)+".json"
		data = NLTA_general.readJson(url)
		NLTA_SequenceNew.selectMirrorControl(data["right"],data["left"])

	def ClearKeyframe(self):
		NLTA_SequenceNew.clearCurrentKeyframe()
	
	def AddKeyframe(self):
		NLTA_SequenceNew.addCurrentKeyframe()
	
	def AddMiddleKeyframe(self):
		NLTA_SequenceNew.addMiddleKeyframe()

	def GoStartFrame(self):
		NLTA_SequenceNew.goStartFrame()

	def PreviousKeyframe(self):
		NLTA_SequenceNew.previousKeyframe()

	def NextKeyframe(self):
		NLTA_SequenceNew.nextKeyframe()

	def GoEndFrame(self):
		NLTA_SequenceNew.goEndFrame()

	def PlayPausePlayback(self):
		if unreal.LevelSequenceEditorBlueprintLibrary.is_playing():
			NLTA_SequenceNew.pausePlayback()
		else:
			NLTA_SequenceNew.playPlayback()

	def GetMirrorTransform(self):
		NLTA_SequenceNew.GetMirrorTransform()

	def OpenRenderPlayback(self):
		NLTA_general.openWindow({
			"controller":"NLTA_Ctrl_RenderPlayback",
			"title":"Render Playback"
		})







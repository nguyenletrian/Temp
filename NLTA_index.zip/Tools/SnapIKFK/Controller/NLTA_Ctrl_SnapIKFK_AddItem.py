import unreal
import sys
import os
import shutil
import subprocess
import json
from importlib import *
from PySide2 import QtUiTools, QtWidgets
from PySide2.QtWidgets import QMessageBox, QMenu
from functools import partial

import time

import NLTA_general, NLTA_Asset, NLTA_ControlRigCore, NLTA_Actor, NLTA_SequenceNew
reload(NLTA_general)
reload(NLTA_Asset)
reload(NLTA_Actor)
reload(NLTA_ControlRigCore)
reload(NLTA_SequenceNew)

session = {}

class CreateWindow(QtWidgets.QWidget):
	window = None
	def __init__(self,parent=None):
		super(CreateWindow,self).__init__(parent)		
		self.dataPath = NLTA_general.getDataPath()
		self.toolPath = NLTA_general.getToolPath()
		self.currentToolPath = NLTA_general.GetCurrentToolPath()
		self.widget = QtUiTools.QUiLoader().load(self.currentToolPath+"View/NLTA_SnapIKFK_AddItem.ui")
		self.widget.setParent(self)
		widgetData = NLTA_general.WidgetInput(self.widget)
		widgetData['btn_Ok'].clicked.connect(self.Ok)
		widgetData['btn_SelectFK'].clicked.connect(partial(self.selectElement,widgetData['txt_FK']))
		widgetData['btn_SelectIK'].clicked.connect(partial(self.selectElement,widgetData['txt_IK']))
		widgetData['btn_SelectRef'].clicked.connect(partial(self.selectElement,widgetData['txt_Ref']))
		self.Detect()

	def resizeEvent(self,event):
		self.widget.resize(self.width(),self.height())
	
	def closeWindow(self):
		self.destroy()
		NLTA_general.openWindow({
			"controller":"NLTA_Ctrl_SnapIKFK",
			"posX":self.pos().x(),
			"posY":self.pos().y()
		})

	def Detect(self):
		global session
		assets = NLTA_Asset.Selected()
		for asset in assets:
			if isinstance(asset,unreal.ControlRigBlueprint):
				path = asset.get_path_name()
				self.controlRig = asset
				unreal.AssetToolsHelpers.get_asset_tools().open_editor_for_assets([asset])
				session["controlRig"] = path

	def selectElement(self,input):
		seletedElements = NLTA_ControlRigCore.GetSelectedElements(self.controlRig)
		string = ";".join(seletedElements)
		input.setPlainText(string)

	def Ok(self):
		string = NLTA_ControlRigCore.GetVariable({"controlRig":self.controlRig,"variable":"NLTA_SnapIKFK"})
		data = json.loads(string)
		widgetData = NLTA_general.WidgetGet(self.widget)
		data[widgetData['txt_Name']] = {
			"fk":widgetData['txt_FK'],
			"ik":widgetData['txt_IK'],
			"ref":widgetData['txt_Ref'],
		}
		string = json.dumps(data, indent=4)
		self.controlRig.remove_member_variable('NLTA_SnapIKFK')
		self.controlRig.add_member_variable('NLTA_SnapIKFK', 'FString',True,False,string)
		unreal.BlueprintEditorLibrary.compile_blueprint(self.controlRig)		
		unreal.EditorAssetLibrary.save_loaded_asset(self.controlRig)
		NLTA_general.openWindow({
			"controller":"NLTA_Ctrl_SnapIKFK",
			"posX":self.pos().x(),
			"posY":self.pos().y()
		})






import unreal
import sys
import os
import shutil
import subprocess
import json
import time
from importlib import *
from PySide2 import QtUiTools, QtWidgets
from PySide2.QtWidgets import QMessageBox, QMenu, QTreeWidgetItem,QTreeWidgetItemIterator
from PySide2 import QtCore
from PySide2 import QtGui
from functools import partial



import NLTA_general, NLTA_Asset, NLTA_ControlRigCore, NLTA_Actor, NLTA_SequenceNew
reload(NLTA_general)
reload(NLTA_Asset)
reload(NLTA_Actor)
reload(NLTA_ControlRigCore)
reload(NLTA_SequenceNew)

session = {}

class CreateWindow(QtWidgets.QWidget):
	window = None
	def __init__(self,parent=None):
		super(CreateWindow,self).__init__(parent)		
		self.toolPath = NLTA_general.GetCurrentToolPath()
		self.dataPath = NLTA_general.getDataPath()
		self.currentToolPath = NLTA_general.GetCurrentToolPath()	
		self.widget = QtUiTools.QUiLoader().load(self.currentToolPath+"View/NLTA_SnapIKFK.ui")
		self.widget.setParent(self)
		self.widgetInput = NLTA_general.WidgetInput(self.widget)	
		self.Detect()
		self.LoadItems(self.widgetInput['list_Items'])

	def resizeEvent(self,event):
		self.widget.resize(self.width(),self.height())
	
	def closeWindow(self):
		self.destroy()

	def Detect(self):
		controlRig = NLTA_SequenceNew.GetControlRigFromSeletedControl()
		controlRigBluePrint = NLTA_ControlRigCore.GetBlueprintFromControlRig(controlRig)
		actor = NLTA_SequenceNew.GetActorFromSeletedControl()
		"""
		boneTransform = component.get_bone_transform("Hip_L",unreal.RelativeTransformSpace.RTS_WORLD)
		parentCube = NLTA_Actor.AddCube()
		parentCube.set_actor_label("NLTA_RenderGroup")
		parentCube.set_actor_transform(boneTransform,False,False)
		"""

		self.controlRigBluePrintData = {
			"bones": NLTA_SequenceNew.GetBonesFromSelectedControl(),
			"controls":NLTA_SequenceNew.GetControlsFromSelectedControl(),
			"snapSetting":json.loads(NLTA_ControlRigCore.GetVariable({'controlRig':controlRigBluePrint,'variable':'NLTA_SnapIKFK'})),
			"actorComponent":actor.skeletal_mesh_component
		}

	def DeleteItem(self,name):
		self.snapIKFKSetting.pop(name)
		string = json.dumps(self.snapIKFKSetting, indent=4)
		self.controlRigBluePrint.remove_member_variable('NLTA_SnapIKFK')
		self.controlRigBluePrint.add_member_variable('NLTA_SnapIKFK', 'FString',True,False,string)
		unreal.BlueprintEditorLibrary.compile_blueprint(self.controlRigBluePrint)		
		unreal.EditorAssetLibrary.save_loaded_asset(self.controlRigBluePrint)
		self.LoadItems(self.widgetInput['list_Items'])

	def LoadItems(self,widget):
		for i in reversed(range(widget.count())):
			widget.itemAt(i).widget().deleteLater()

		for key in self.controlRigBluePrintData['snapSetting']:
			pattern = self.currentToolPath+"View/NLTA_SnapIKFK_Item.ui"
			item = QtUiTools.QUiLoader().load(pattern)
			itemInput = NLTA_general.WidgetInput(item)
			itemInput['lb_Name'].setText(key)
			itemInput['btn_Snap'].clicked.connect(partial(self.Snap,key))
			widget.addWidget(item)

	def Snap(self,key):
		snapSetting =  self.controlRigBluePrintData['snapSetting'][key]
		controls = NLTA_SequenceNew.GetControlSelected()
		for key in snapSetting:
			arrayTemp = snapSetting[key].split(";")
			for control in controls:
				if control in arrayTemp:
					if "FK" in key:
						current = key.replace("FK","IK")
					else:
						current = key.replace("IK","FK")
					destination = current.replace('Source','Target')
					sourceArray = snapSetting[current].split(";")
					destinationArray = snapSetting[destination].split(";")
					for i in range(len(destinationArray)):
						if destinationArray[i] in self.controlRigBluePrintData['controls']:
							destinationTransform = NLTA_SequenceNew.GetControlWorldTransform(destinationArray[i])
						else:
							destinationTransform = self.controlRigBluePrintData['actorComponent'].get_bone_transform(destinationArray[i],unreal.RelativeTransformSpace.RTS_WORLD)
						NLTA_SequenceNew.AddKeyWorldTransform(sourceArray[i],destinationTransform)
					state =  NLTA_SequenceNew.GetBoolValue(snapSetting["SwitchControl"])
					if state:
						NLTA_SequenceNew.AddKeyBool(snapSetting["SwitchControl"],False)
					else:
						NLTA_SequenceNew.AddKeyBool(snapSetting["SwitchControl"],True)
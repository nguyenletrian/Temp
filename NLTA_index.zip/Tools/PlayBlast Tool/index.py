import unreal
from importlib import *
import NLTA_general
reload(NLTA_general)
import NLTA_SequenceNew
reload(NLTA_SequenceNew)

data = NLTA_SequenceNew.getSequenceData()
if data!=None:
	NLTA_general.openWindow({
		"controller":"NLTA_Ctrl_RenderWindow"
	})
else:
	unreal.EditorDialog.show_message("Warning","Please open a sequence!~ :D",unreal.AppMsgType.OK)

import unreal
import sys
import os
import shutil
import subprocess
import math
from importlib import *
from PySide2 import QtUiTools, QtWidgets, QtCore
from PySide2.QtWidgets import QMessageBox, QMenu
from PySide2.QtCore import  QPropertyAnimation
from functools import partial

import NLTA_general
reload(NLTA_general)
import NLTA_Actor
reload(NLTA_Actor)
import NLTA_RenderPlayback
reload(NLTA_RenderPlayback)
import NLTA_SequenceNew
reload(NLTA_SequenceNew)

session = {
	"currentCameraIndex":0
}

class CreateWindow(QtWidgets.QWidget):
	window = None
	def __init__(self,parent=None):
		super(CreateWindow,self).__init__(parent)
		
		self.dataPath = NLTA_general.getDataPath()
		self.toolPath = NLTA_general.getToolPath()
		self.currentToolPath = NLTA_general.GetCurrentToolPath()	
		self.widget = QtUiTools.QUiLoader().load(self.currentToolPath+"View/NLTA_RenderWindow.ui")
		self.widget.setParent(self)
		self.setMaximumHeight(520)
	
		NLTA_RenderPlayback.CheckRenderSetting()

		self.renderSetting = NLTA_general.getSession("renderSetting")

		self.btn_Resolution3840_2160 = self.widget.findChild(QtWidgets.QPushButton,'btn_Resolution3840_2160')
		self.btn_Resolution3840_2160.clicked.connect(partial(self.Resolution,[3840,2160]))

		self.btn_Resolution2560_1440 = self.widget.findChild(QtWidgets.QPushButton,'btn_Resolution2560_1440')
		self.btn_Resolution2560_1440.clicked.connect(partial(self.Resolution,[2560,1440]))

		self.btn_Resolution1920_1080 = self.widget.findChild(QtWidgets.QPushButton,'btn_Resolution1920_1080')
		self.btn_Resolution1920_1080.clicked.connect(partial(self.Resolution,[1920,1080]))

		self.btn_Resolution1280_720 = self.widget.findChild(QtWidgets.QPushButton,'btn_Resolution1280_720')
		self.btn_Resolution1280_720.clicked.connect(partial(self.Resolution,[1280,720]))

		self.txt_Name = self.widget.findChild(QtWidgets.QLineEdit,'txt_Name')
		self.txt_Name.setText(self.renderSetting["name"])

		self.txt_Path = self.widget.findChild(QtWidgets.QLineEdit,'txt_Path')
		self.txt_Path.setText(self.renderSetting["outputFolder"])

		self.btn_ChoosePath = self.widget.findChild(QtWidgets.QPushButton,'btn_ChoosePath')
		self.btn_ChoosePath.clicked.connect(self.ChoosePath)

		self.btn_OpenRendered = self.widget.findChild(QtWidgets.QPushButton,'btn_OpenRendered')
		self.btn_OpenRendered.clicked.connect(self.OpenRendered)

		self.spin_FrameStart = self.widget.findChild(QtWidgets.QSpinBox,'spin_FrameStart')
		self.spin_FrameStart.setValue(self.renderSetting["frameStart"])
		self.spin_FrameStart.valueChanged.connect(self.Update360Around)
		self.spin_FrameEnd = self.widget.findChild(QtWidgets.QSpinBox,'spin_FrameEnd')
		self.spin_FrameEnd.setValue(self.renderSetting["frameEnd"])
		self.spin_FrameEnd.valueChanged.connect(self.Update360Around)

		self.spin_ResolutionWidth = self.widget.findChild(QtWidgets.QSpinBox,'spin_ResolutionWidth')
		self.spin_ResolutionWidth.setValue(self.renderSetting["resolution"][0])
		self.spin_ResolutionHeight= self.widget.findChild(QtWidgets.QSpinBox,'spin_ResolutionHeight')
		self.spin_ResolutionHeight.setValue(self.renderSetting["resolution"][1])


		self.spin_FrameRate= self.widget.findChild(QtWidgets.QSpinBox,'spin_FrameRate')
		self.spin_FrameRate.setValue(self.renderSetting["frameRate"])

		self.cbx_Type = self.widget.findChild(QtWidgets.QComboBox,'cbx_Type')
		self.cbx_Type.setCurrentText(self.renderSetting["outputType"])

		self.chx_BurnIn = self.widget.findChild(QtWidgets.QCheckBox,'chx_BurnIn')
		if self.renderSetting["burnIn"] == "True":
			self.chx_BurnIn.setChecked(True)
		else:
			self.chx_BurnIn.setChecked(False)		

		self.btn_PreviewRight = self.widget.findChild(QtWidgets.QPushButton,'btn_PreviewRight')
		self.btn_PreviewRight.clicked.connect(partial(self.Preview,"right"))
		self.btn_PreviewLeft = self.widget.findChild(QtWidgets.QPushButton,'btn_PreviewLeft')
		self.btn_PreviewLeft.clicked.connect(partial(self.Preview,"left"))
		self.btn_PreviewTop = self.widget.findChild(QtWidgets.QPushButton,'btn_PreviewTop')
		self.btn_PreviewTop.clicked.connect(partial(self.Preview,"top"))
		self.btn_PreviewFront = self.widget.findChild(QtWidgets.QPushButton,'btn_PreviewFront')
		self.btn_PreviewFront.clicked.connect(partial(self.Preview,"front"))
		self.btn_PreviewBack = self.widget.findChild(QtWidgets.QPushButton,'btn_PreviewBack')
		self.btn_PreviewBack.clicked.connect(partial(self.Preview,"back"))
		self.btn_PreviewBot = self.widget.findChild(QtWidgets.QPushButton,'btn_PreviewBot')
		self.btn_PreviewBot.clicked.connect(partial(self.Preview,"bot"))
		self.btn_PreviewPerspective = self.widget.findChild(QtWidgets.QPushButton,'btn_PreviewPerspective')
		self.btn_PreviewPerspective.clicked.connect(partial(self.Preview,"perspective"))
		self.btn_Preview360Around = self.widget.findChild(QtWidgets.QPushButton,'btn_Preview360Around')
		self.btn_Preview360Around.clicked.connect(partial(self.Preview,"360Around"))
		self.btn_CameraAnimatedReview = self.widget.findChild(QtWidgets.QPushButton,'btn_CameraAnimatedReview')
		self.btn_CameraAnimatedReview.clicked.connect(self.CameraAnimatedReview)	

		self.cbx_CheckRight = self.widget.findChild(QtWidgets.QCheckBox,'cbx_CheckRight')
		self.cbx_CheckLeft = self.widget.findChild(QtWidgets.QCheckBox,'cbx_CheckLeft')
		self.cbx_CheckTop = self.widget.findChild(QtWidgets.QCheckBox,'cbx_CheckTop')
		self.cbx_CheckFront = self.widget.findChild(QtWidgets.QCheckBox,'cbx_CheckFront')
		self.cbx_CheckBack = self.widget.findChild(QtWidgets.QCheckBox,'cbx_CheckBack')
		self.cbx_CheckBot = self.widget.findChild(QtWidgets.QCheckBox,'cbx_CheckBot')
		self.cbx_CheckPerspective = self.widget.findChild(QtWidgets.QCheckBox,'cbx_CheckPerspective')
		self.cbx_Check360Around = self.widget.findChild(QtWidgets.QCheckBox,'cbx_Check360Around')
		self.cbx_CheckSelected = self.widget.findChild(QtWidgets.QCheckBox,'cbx_CheckSelected')


		self.btn_Ok = self.widget.findChild(QtWidgets.QPushButton,'btn_Ok')
		self.btn_Ok.clicked.connect(self.Ok)

		self.btn_PlaybackPivot = self.widget.findChild(QtWidgets.QPushButton,'btn_PlaybackPivot')
		self.btn_PlaybackPivot.clicked.connect(self.PlaybackPivot)
		self.btn_PlaybackSave = self.widget.findChild(QtWidgets.QPushButton,'btn_PlaybackSave')
		self.btn_PlaybackSave.clicked.connect(self.PlaybackSave)
		self.btn_PlaybackLoad = self.widget.findChild(QtWidgets.QPushButton,'btn_PlaybackLoad')
		self.btn_PlaybackLoad.clicked.connect(self.PlaybackLoad)
		self.btn_PlaybackMatch = self.widget.findChild(QtWidgets.QPushButton,'btn_PlaybackMatch')
		self.btn_PlaybackMatch.clicked.connect(self.PlaybackMatch)

		"""
		self.PlaybackSettingMenu = QtWidgets.QMenu()
		self.PlaybackSettingMenu.addAction("Match Root To Selected Object",self.PlaybackPivot)
		self.PlaybackSettingMenu.addAction("Show Root Pivot",self.PlaybackPivot)
		self.PlaybackSettingMenu.addAction("Save Cameras's Transform",self.SavePlayBack)
		self.PlaybackSettingMenu.addAction("Load Cameras's Transform",self.LoadPlayBack)
		self.btn_PlaybackSetting.setMenu(self.PlaybackSettingMenu)
		"""


		NLTA_RenderPlayback.CreateRenderEnvironment()

		self.btn_Expand = self.widget.findChild(QtWidgets.QPushButton,'btn_Expand_2')
		self.frame_Expand = self.widget.findChild(QtWidgets.QFrame,'frame_Expand')
		self.btn_Expand.clicked.connect(partial(
			self.Animation,
			{
				"button":self.btn_Expand,
				"target":self.frame_Expand,
				"attribute":"maximumHeight",
				"minValue":0,
				"maxValue":130
			}
		))

	def Animation(self,inputData):
		button =  inputData["button"]
		target = inputData["target"]
		attribute = inputData["attribute"]

		checked = button.isChecked()
		if checked == True:
			minValue = inputData["minValue"]
			maxValue = inputData["maxValue"]
			windowMin = self.maximumHeight() + inputData["maxValue"]
		else:
			minValue = inputData["maxValue"]
			maxValue = inputData["minValue"]
			windowMin = self.maximumHeight() - inputData["maxValue"]		

		self.animation = QPropertyAnimation(target,b"maximumHeight")
		self.animation.setDuration(150)
		self.animation.setStartValue(minValue)
		self.animation.setEndValue(maxValue)
		self.animation.setEasingCurve(QtCore.QEasingCurve.Linear)
		self.animation.start()			
		
		self.animationWindow = QPropertyAnimation(self,b"size")
		self.animationWindow.setDuration(150)
		#self.animationWindow.setStartValue(QtCore.QSize(self.width(),self.maximumHeight()))
		self.animationWindow.setEndValue(QtCore.QSize(self.width(),windowMin))
		self.animationWindow.setEasingCurve(QtCore.QEasingCurve.Linear)
		self.animationWindow.start()
		self.setMaximumHeight(windowMin)

	def resizeEvent(self,event):
		self.widget.resize(self.width(),self.height())
	
	def closeWindow(self):		
		self.destroy()

	def closeEvent(self,event):		
		NLTA_RenderPlayback.ClearScene()

	def OpenRendered(self):
		url = self.txt_Path.text()
		os.startfile(url)

	def Preview(self,view):
		NLTA_RenderPlayback.Pilot(view)

	def ChoosePath(self):
		path = NLTA_general.DirectoryDialog(self)
		if path!="":
			self.txt_Path.setText(path)

	def Resolution(self,inputData):
		self.spin_ResolutionWidth.setValue(inputData[0])
		self.spin_ResolutionHeight.setValue(inputData[1])
		pass

	def UpdateSetting(self):
		renderSetting = NLTA_general.getSession("renderSetting").copy()
		renderSetting["name"] = self.txt_Name.text()
		renderSetting["frameStart"] = self.spin_FrameStart.value()
		renderSetting["frameEnd"] = self.spin_FrameEnd.value()
		renderSetting["frameRate"] = self.spin_FrameRate.value()
		renderSetting["resolution"] = [self.spin_ResolutionWidth.value(),self.spin_ResolutionHeight.value()]
		renderSetting["outputFolder"] = self.txt_Path.text()
		renderSetting["outputType"] = self.cbx_Type.currentText()		
		if self.chx_BurnIn.isChecked() == True:
			renderSetting["burnIn"] = "True"
		else:
			renderSetting["burnIn"] = "False"
		NLTA_general.setSession("renderSetting",renderSetting)

	def Preview(self,view):
		NLTA_RenderPlayback.Pilot(view)

	def PlaybackSave(self):
		folder = NLTA_general.DirectoryDialog(self)
		if folder !="":
			NLTA_RenderPlayback.Save(folder)

	def PlaybackLoad(self):
		file = NLTA_general.FileDialog(self)
		if len(file)!=0:
			NLTA_RenderPlayback.Load(file[0])

	def PlaybackMatch(self):
		referenceTransform = False
		

		if NLTA_Actor.SelectedActors()!=None:
			referenceTransform = NLTA_Actor.SelectedActors()[0].get_actor_transform()
		else:
			referenceTransform = unreal.Transform(location=[0,0,0],rotation=[0,0,0],scale=[1,1,1])
		data = NLTA_SequenceNew.getSequenceData()	

		if data != None:
			controlData = NLTA_SequenceNew.GetControlData(data)
			if controlData !=None:
				referenceTransform = controlTransform = controlData["transform"]

		if referenceTransform != False:
			referenceTransform.rotation.x = 0
			referenceTransform.rotation.y = 0
			referenceTransform.rotation.z = 0
			parentCube = NLTA_Actor.GetActorByName("NLTA_RenderGroup")
			parentCube.set_actor_transform(referenceTransform,False,False)


	def Ok(self):
		self.UpdateSetting()
		data = {
			"view":{
				"right":self.cbx_CheckRight.isChecked(),
				"left":self.cbx_CheckLeft.isChecked(),
				"top":self.cbx_CheckTop.isChecked(),
				"front":self.cbx_CheckFront.isChecked(),
				"back":self.cbx_CheckBack.isChecked(),
				"bot":self.cbx_CheckBot.isChecked(),
				"perspective":self.cbx_CheckPerspective.isChecked(),
				"360Around":self.cbx_Check360Around.isChecked(),	
			},
			"renderSelected":self.cbx_CheckSelected.isChecked(),	
		}
		NLTA_RenderPlayback.RenderPlayback(data)

	def CameraAnimatedOk(self):
		self.UpdateSetting()
		data = NLTA_SequenceNew.getSequenceData()
		if data != None:
			actors = NLTA_Actor.SelectedActors()
			print(actors)
			if actors!=None and isinstance(actors[0],unreal.CineCameraActor):
				NLTA_RenderPlayback.RenderAnimatedCameraOk()
			else:
				NLTA_general.createMessageBox({
					"text":"Please Open a sequence and Select a animated camera!~",
					"title":"Warning",
					"buttons":["Cancel"]
				})	

	def Update360Around(self):
		renderSetting = NLTA_general.getSession("renderSetting").copy()
		renderSetting["frameStart"] = self.spin_FrameStart.value()
		renderSetting["frameEnd"] = self.spin_FrameEnd.value()
		NLTA_general.setSession("renderSetting",renderSetting)
		NLTA_RenderPlayback.RenderPlaybackUpdate360Around()
	
	def PlaybackPivot(self):
		NLTA_Actor.EjectPilot()
		NLTA_Actor.SelectActorByName(["NLTA_RenderGroup"])

	def CameraAnimatedReview(self):
		global session
		currentCameraIndex = session["currentCameraIndex"]
		cameraArray = []
		actors = NLTA_Actor.SelectedActors()
		if actors !=None:
			for order in range(len(actors)):
				actor = actors[order]
				if isinstance(actor,unreal.CineCameraActor):
					cameraName = actor.get_actor_label()
					if "NLTA_" not in cameraName:
						cameraArray.append(actor)
			if len(cameraArray)!=0:
				if currentCameraIndex < len(cameraArray) - 1:				
					session["currentCameraIndex"]+=1
				else:
					session["currentCameraIndex"]=0
				NLTA_Actor.Pilot(cameraArray[currentCameraIndex])











import unreal
import os
import time
import threading
import shutil
import subprocess
from datetime import datetime
from importlib import *
from functools import partial

import NLTA_general as NLTA_general
reload(NLTA_general)
import NLTA_SequenceNew as NLTA_SequenceNew
reload(NLTA_SequenceNew)
import NLTA_Actor as NLTA_Actor
reload(NLTA_Actor)

session = {}
sessionSequence = NLTA_SequenceNew.getSequenceData()

def ClearScene():
	NLTA_Actor.DeleteActor("NLTA_RenderGroup")
	NLTA_SequenceNew.DeleteBindingByName("NLTA_Offset_360Around")

def UpdateSequenData():
	global sessionSequence
	sessionSequence = NLTA_SequenceNew.getSequenceData()

def CheckRenderSetting():
	renderSetting = NLTA_general.getSession("renderSetting")
	if not renderSetting:
		NLTA_general.setSession("renderSetting",{
			"frameStart":30,
			"frameEnd":90,
			"frameRate":30,
			"resolution":[1980,1280],
			"sensor":[23.76,13.365],
			"outputFolder":NLTA_general.getDataPath()+"RenderPlayback",
			"outputType":"avi",
			"name":"OutputRender",
			"burnIn":False
		})

def GetCameraCutTrack():
	sequence = sessionSequence["sequence"]
	masterTracExist = sequence.get_master_tracks()		
	if len(masterTracExist)==0:
		cameraCutTrack = sequence.add_master_track(unreal.MovieSceneCameraCutTrack)
	else:
		cameraCutTrack = masterTracExist[0]
	UpdateSequenData()
	return(cameraCutTrack)		

def RestoreSectionRange():
	data = session["AbsoluteRenderSection"]["RangeData"]
	for order in range(len(data)):
		sectionData = data[order]
		sectionData[0].set_range(sectionData[1],sectionData[2])

def AbsoluteRenderSection(inputData):
	global session
	version = NLTA_general.CheckVersion()
	if version == "5.3":
		setting = NLTA_general.getSession("renderSetting")	
		session["AbsoluteRenderSection"] = {}
		session["AbsoluteRenderSection"]["RangeData"] = []
		section = inputData["section"]
		cameraCutTrack = GetCameraCutTrack()	
		for sectionTemp in cameraCutTrack.get_sections():
			if section != sectionTemp:
				frameStart = sectionTemp.get_start_frame()
				frameEnd = sectionTemp.get_end_frame()
				session["AbsoluteRenderSection"]["RangeData"].append([sectionTemp,frameStart,frameEnd])
				sectionTemp.set_range(-1000,-1000)
			else:
				section.set_range(
					setting["frameStart"] - 5,
					setting["frameEnd"] + 5
				)
		sessionSequence["sequence"].set_playback_start(int(setting["frameStart"]) - 5)
		sessionSequence["sequence"].set_playback_end(int(setting["frameEnd"]) + 5)
	elif version == "5.5":
		setting = NLTA_general.getSession("renderSetting")	
		session["AbsoluteRenderSection"] = {}
		session["AbsoluteRenderSection"]["RangeData"] = []
		track = inputData["track"]
		section = inputData["section"]		
		for sectionTemp in track.get_sections():
			if section != sectionTemp:
				frameStart = sectionTemp.get_start_frame()
				frameEnd = sectionTemp.get_end_frame()
				session["AbsoluteRenderSection"]["RangeData"].append([sectionTemp,frameStart,frameEnd])
				sectionTemp.set_range(-1000,-1000)
			else:
				section.set_range(
					setting["frameStart"] - 5,
					setting["frameEnd"] + 5
				)
		sessionSequence["sequence"].set_playback_start(int(setting["frameStart"]) - 5)
		sessionSequence["sequence"].set_playback_end(int(setting["frameEnd"]) + 5)

def GetBoundObject():
	dataReturn = {
		"names":[],
		"bindings":[],
		"objects":[]
	}
	sequence = sessionSequence["sequence"]
	world = unreal.EditorLevelLibrary.get_editor_world()
	boundObjects = unreal.SequencerTools().get_bound_objects(
		world,
		sequence,
		sequence.get_bindings(),
		sequence.get_playback_range()
	)
	for boundObject in boundObjects:
		if len(boundObject.bound_objects)!=0:
			objectTemp = boundObject.bound_objects[0]
			if isinstance(objectTemp,unreal.CineCameraActor):
				dataReturn["names"].append(str(boundObject.binding_proxy.get_display_name()))
				dataReturn["bindings"].append(boundObject.binding_proxy)
	return(dataReturn)

def GetCameraBindingId(inputData):
	global session	
	cameraName = inputData["cameraName"]
	for bindingTemp in sessionSequence["bindings"]:
		binding = bindingTemp["data"]
		bindingName = binding.get_name()
		if cameraName == bindingName:
			bindingId = binding.get_id()
			return(bindingId)

def AddSectionFromBinding(inputData):
	bindingId = GetCameraBindingId(inputData)
	cameraCutTrack = GetCameraCutTrack()
	section = cameraCutTrack.add_section()	
	temp = unreal.MovieSceneObjectBindingID()
	temp.set_editor_property("Guid",bindingId)
	section.set_camera_binding_id(temp)
	unreal.LevelSequenceEditorBlueprintLibrary.refresh_current_level_sequence()
	UpdateSequenData()
	return(section)

def AddSectionFromCamera(inputData):
	version = NLTA_general.CheckVersion()
	if version == "5.3":
		camera = inputData["camera"]
		cameraCutTrack = GetCameraCutTrack()
		section = cameraCutTrack.add_section()
		binding = sessionSequence["sequence"].add_possessable(camera)
		camera_binding_id = unreal.MovieSceneObjectBindingID()
		camera_binding_id.set_editor_property("Guid",binding.get_id())
		section.set_editor_property("camera_binding_id",camera_binding_id)
		component = sessionSequence["sequence"].add_possessable(camera.get_cine_camera_component())
		component.set_parent(binding)
		unreal.LevelSequenceEditorBlueprintLibrary.refresh_current_level_sequence()
		return({
			"track":cameraCutTrack,
			"section":section,
			"binding":binding,
			"component":component
		})
	elif version == "5.5":
		camera = inputData["camera"]
		binding = sessionSequence["sequence"].add_possessable(camera)
		track = binding.add_track(unreal.MovieSceneCameraCutTrack)
		section =  track.add_section()
		camera_binding_id = unreal.MovieSceneObjectBindingID()
		camera_binding_id.set_editor_property("Guid",binding.get_id())
		section.set_editor_property("camera_binding_id",camera_binding_id)
		component = sessionSequence["sequence"].add_possessable(camera.get_cine_camera_component())
		component.set_parent(binding)
		unreal.LevelSequenceEditorBlueprintLibrary.refresh_current_level_sequence()
		return({
			"track":track,
			"section":section,
			"binding":binding,
			"component":component
		})

		"""
		camera = inputData["camera"]
		section = unreal.MovieSceneTrack.add_section()
		binding = sessionSequence["sequence"].add_possessable(camera)
		camera_binding_id = unreal.MovieSceneObjectBindingID()
		camera_binding_id.set_editor_property("Guid",binding.get_id())
		section.set_editor_property("camera_binding_id",camera_binding_id)
		component = sessionSequence["sequence"].add_possessable(camera.get_cine_camera_component())
		component.set_parent(binding)
		unreal.LevelSequenceEditorBlueprintLibrary.refresh_current_level_sequence()
		return({
			"section":section,
			"binding":binding,
			"component":component
		})
		"""

def EndRender():
	global session
	setting = NLTA_general.getSession("renderSetting")
	folderTemp = session["currentOutputFolder"]+"/NLTA_Temp"
	if os.path.exists(folderTemp):

		videoNameTemp = setting["name"] + session["RenderBasic"]["endFix"]
		videoNameAvi = videoNameTemp + ".avi"
		videoNameTo = videoNameTemp + "." + setting["outputType"]
		outputAvi = session["currentOutputFolder"]+"/"+videoNameAvi
		outputTo = session["currentOutputFolder"]+"/"+videoNameTo
		imageName = NLTA_general.getFiles(folderTemp,"png")[0].split(".")[0]
		imagePattern = folderTemp +"/"+imageName+".%d"+".png"
		ffmpeg = NLTA_general.getToolPath()+"Library/ffmpeg/ffmpeg.exe"
		subprocess.run([
			ffmpeg,
			'-start_number',
			str(setting["frameStart"]),
			'-y',
			'-i',
			imagePattern,
			'-frames:v',
			str((setting["frameEnd"] - setting["frameStart"])),
			'-r',
			str(setting["frameRate"]),
			'-c:v',
			"libx264",
			"-crf",
			"18",
			"-flags",
			"low_delay",
			outputAvi
		])

		if setting["outputType"] != "avi":
			subprocess.run([
				ffmpeg,
				'-y',
				'-i',
				outputAvi,
				'-c:v',
				"libx264",
				"-crf",
				"18",
				"-flags",
				"low_delay",
				outputTo
			])
			os.remove(outputAvi)
		shutil.rmtree(folderTemp)
		RestoreSectionRange()		
		for obj in session["RenderBasic"]["remove"]:
			NLTA_general.DeleteObj(obj)		
		session["RenderBasic"]["remove"] = []		
		sessionSequence["sequence"].set_playback_start(session["RenderBasic"]["frameStart"])
		sessionSequence["sequence"].set_playback_end(session["RenderBasic"]["frameEnd"])

		UpdateSequenData()	

def RenderBasic(inputData):
	global session
	sequence = sessionSequence["sequence"]
	section = inputData["section"]
	track =  inputData["track"]

	session["RenderBasic"] = {}
	session["RenderBasic"]["frameStart"] = sequence.get_playback_start()
	session["RenderBasic"]["frameEnd"] = sequence.get_playback_end()
	if "remove" in inputData:
		session["RenderBasic"]["remove"] = inputData["remove"]
	if "endFix" in inputData:
		session["RenderBasic"]["endFix"] = inputData["endFix"]
	else:
		session["RenderBasic"]["endFix"] = ""	

	AbsoluteRenderSection({"section":section,"track":track})
	
	setting = NLTA_general.getSession("renderSetting")
	outputFolder = session["currentOutputFolder"]+"/NLTA_Temp"	
	if not os.path.exists(outputFolder):
		os.makedirs(outputFolder)

	callBackFunction = inputData["callBackFunction"]

	capture =  unreal.AutomatedLevelSequenceCapture()
	capture.set_image_capture_protocol_type(unreal.load_class(None,"/Script/MovieSceneCapture.ImageSequenceProtocol_PNG"))
	capture.get_image_capture_protocol().compression_quality = 100
	capture.level_sequence_asset = unreal.SoftObjectPath(sequence.get_path_name())
	capture.settings.resolution = setting["resolution"]
	capture.settings.output_directory = unreal.DirectoryPath(outputFolder)
	capture.settings.use_custom_frame_rate = True
	capture.settings.custom_frame_rate = unreal.FrameRate(setting["frameRate"],1)
	capture.settings.game_mode_override = None
	capture.settings.overwrite_existing = True
	capture.settings.enable_texture_streaming = True
	capture.settings.use_relative_frame_numbers = False
	capture.settings.handle_frames = 0
	capture.settings.zero_pad_frame_numbers = 0
	capture.settings.enable_texture_streaming = False
	capture.settings.cinematic_engine_scalability = True
	capture.settings.cinematic_mode = True
	capture.settings.allow_movement = False 	# Requires cinematic_mode = True
	capture.settings.allow_turning = False 		# Requires cinematic_mode = True
	capture.settings.show_player = False 		# Requires cinematic_mode = True
	capture.settings.show_hud = False 			# Requires cinematic_mode = True
	capture.use_separate_process = False
	capture.close_editor_when_capture_starts = False				# Requires use_separate_process = True
	capture.additional_command_line_arguments = "-NOSCREENMESSAGES"	# Requires use_separate_process = True
	capture.inherited_command_line_arguments = ""						# Requires use_separate_process = True
	capture.use_custom_start_frame = False
	capture.use_custom_end_frame = False
	capture.custom_start_frame = unreal.FrameNumber(setting["frameStart"])
	capture.custom_end_frame = unreal.FrameNumber(setting["frameEnd"])
	capture.warm_up_frame_count = 0.0
	capture.delay_before_warm_up = 1
	capture.delay_before_shot_warm_up = 0.1
	capture.write_edit_decision_list = True	
	
	if setting["burnIn"]=="True":
		burn_in_options = unreal.LevelSequenceBurnInOptions()
		burn_in_options.use_burn_in = True
		burn_in_options.set_burn_in(unreal.SoftClassPath("/Engine/Sequencer/DefaultBurnIn.DefaultBurnIn_C"))
		burn_in_options.settings.set_editor_property('TopCenterText', str(setting["resolution"][0])+" x "+str(setting["resolution"][1]))
		burn_in_options.settings.set_editor_property('TopLeftText', "")
		burn_in_options.settings.set_editor_property('TopRightText', "{Date}")
		burn_in_options.settings.set_editor_property('BottomLeftText', "Frame rate: "+str(setting["frameRate"]))
		burn_in_options.settings.set_editor_property('BottomRightText', "{hh}:{mm}:{ss}:{ff}")		
		burn_in_options.settings.set_editor_property('BottomCenterText', "Camera "+setting["name"]+" | Frame: {ShowFrame}")	
		capture.burn_in_options = burn_in_options
	else:
		burn_in_options = unreal.LevelSequenceBurnInOptions()
		burn_in_options.use_burn_in = False
		capture.burn_in_options = burn_in_options
	unreal.SequencerTools.render_movie(capture,callBackFunction)

def RenderAnimatedCamera(success):
	EndRender()
	renderSession = NLTA_general.getSession("RenderAnimatedCamera")
	cameraArray = renderSession["cameras"]
	index = renderSession["currentIndex"]
	if index < len(cameraArray):
		renderSession["currentIndex"] += 1
		NLTA_general.setSession("RenderAnimatedCamera",renderSession)
		cameraName = cameraArray[index]
		if len(cameraArray)>1:
			endFix = "_"+cameraName
		else:
			endFix = ""

		section = AddSectionFromBinding({"cameraName":cameraName})
		capture = RenderBasic({
			"sequence":sessionSequence["sequence"],
			"section":section,
			"remove":[section],
			"callBackFunction":RenderAnimatedCamera_callback,
			"endFix":endFix
		})

RenderAnimatedCamera_callback = unreal.OnRenderMovieStopped()
RenderAnimatedCamera_callback.bind_callable(RenderAnimatedCamera)

def RenderPlaybackUpdate360Around():
	global session
	sessionData = session["RenderPlayback"]

	for camera in sessionData["CamerasData"]:
		if sessionData["CamerasData"][camera]["View"] == "360Around":
			cameraName = camera			
	for obj in sessionData["CamerasData"][cameraName]["remove"]:
		NLTA_general.DeleteObj(obj)

	setting = NLTA_general.getSession("renderSetting")
	frameStart = setting["frameStart"]
	frameEnd = setting["frameEnd"]

	sequence = unreal.LevelSequenceEditorBlueprintLibrary.get_current_level_sequence()

	childrenCube = NLTA_Actor.GetActorByName("NLTA_Offset_360Around")
	
	childrenCubeBinding = sequence.add_possessable(childrenCube)
	childrenCubeTrack = childrenCubeBinding.add_track(unreal.MovieScene3DTransformTrack)
	childrenCubeSection = childrenCubeTrack.add_section()
	childrenCubeSection.set_range(frameStart,frameEnd)
	unreal.LevelSequenceEditorBlueprintLibrary.refresh_current_level_sequence()
	allChannel = childrenCubeSection.get_all_channels()
	for channelTemp in allChannel:
		if "Rotation.Z" in str(channelTemp.get_editor_property("channel_name")):
			key = channelTemp.add_key(unreal.FrameNumber(frameStart),0)
			key = channelTemp.add_key(unreal.FrameNumber(frameEnd),360)
	sessionData["CamerasData"][cameraName]["remove"] = [
		childrenCubeBinding,
		childrenCubeTrack,
		childrenCubeSection
	]

def RenderPlaybackCamera(success):
	global session
	sessionData = session["RenderPlayback"]
	if sessionData["CurrentRenderIndex"] > 0:
		EndRender()
	if sessionData["CurrentRenderIndex"] < len(sessionData["CamerasOrder"]):
		camera = sessionData["CamerasOrder"][sessionData["CurrentRenderIndex"]]
		cameraName = camera.get_fname()
		view = sessionData["CamerasData"][cameraName]["View"]
		endFix = "_"+view
		sectionData = AddSectionFromCamera({"camera":camera})
		section = sectionData["section"]
		track = sectionData["track"] 
		removeArray = [
			sectionData["track"],
			sectionData["section"],
			sectionData["binding"],
			sectionData["component"],
		]
		capture = RenderBasic({
			"callBackFunction":RenderPlaybackCallback,
			"track":track,
			"section":section,
			"remove":removeArray,
			"endFix":endFix
		})
		sessionData["CurrentRenderIndex"] +=  1
	else:
		sessionTemp = NLTA_general.getSession("RenderAnimatedCamera")
		if sessionTemp["renderRequire"] == 1:
			RenderAnimatedCamera(None)
RenderPlaybackCallback = unreal.OnRenderMovieStopped()
RenderPlaybackCallback.bind_callable(RenderPlaybackCamera)


def RenderPlayback(inputData):
	global session
	UpdateSequenData()
	setting = NLTA_general.getSession("renderSetting")
	folders = NLTA_general.getFolders(setting["outputFolder"])
	workingFolder = setting["outputFolder"]+"/NLTA_Videos_"+datetime.now().strftime("%Y-%m-%d_%H%M%S")
	os.makedirs(workingFolder)
	session["currentOutputFolder"] = workingFolder

	sessionData = session["RenderPlayback"]
	sessionData["CamerasOrder"] = []	
	sessionData["CurrentRenderIndex"] = 0
	for view in inputData["view"]:
		if inputData["view"][view] == True:
			for camera in sessionData["CamerasData"]:
				if sessionData["CamerasData"][camera]["View"] == view:
					sessionData["CamerasOrder"].append(sessionData["CamerasData"][camera]["Camera"])
	data = {
		"cameras":[],
		"currentIndex":0,
		"renderRequire":inputData["renderSelected"]
	}
	actors = NLTA_Actor.SelectedActors()
	if actors !=None:
		for actor in actors:
			if isinstance(actor,unreal.CineCameraActor):
				data["cameras"].append(actor.get_actor_label())
	NLTA_general.setSession("RenderAnimatedCamera",data)
	RenderPlaybackCamera(None)


def CreateRenderEnvironment():
	global session
	session["RenderPlayback"] = {
		"CamerasData":{},
		"RenderRemove":[],
		"FinalRemove":[],
		"controlData":None
	}
	sessionData = session["RenderPlayback"]	

	flag = False
	data = NLTA_SequenceNew.getSequenceData()
	if data != None:
		controlData = NLTA_SequenceNew.GetControlData(data)
		if controlData !=None:
			referenceTransform = controlTransform = controlData["transform"]
			flag = True

	if flag != True:
		if NLTA_Actor.SelectedActors()!=None:
			referenceTransform = NLTA_Actor.SelectedActors()[0].get_actor_transform()
		else:
			referenceTransform = unreal.Transform(location=[0,0,0],rotation=[0,0,0],scale=[1,1,1])
	
	if data != None:
		sequence = data["sequence"]
		cameraDistanceTransform = NLTA_SequenceNew.GetCurrentViewTransform(data)
		referenceTransform.rotation.x = 0
		referenceTransform.rotation.y = 0
		referenceTransform.rotation.z = 0

		parentCube = NLTA_Actor.AddCube()
		parentCube.set_actor_label("NLTA_RenderGroup")
		parentCube.set_actor_transform(referenceTransform,False,False)
		distance = NLTA_Actor.GetDistance({"transform1":referenceTransform,"transform2":cameraDistanceTransform})
			
		parentCubeTransform = parentCube.get_actor_transform()
		parentCubeTransform.translation.x = parentCubeTransform.translation.x - distance
		distanceTransform = parentCubeTransform

		cameraAxisDict = {
			"right":[0,0,0],
			"left":[180,0,0],
			"back":[0,90,0],
			"top":[-90,0,0],
			"bot":[90,0,0],
			"front":[0,-90,0],
			"perspective":"",
			"360Around":"",
		}
		for view in cameraAxisDict:
			axis = cameraAxisDict[view]
			rotateTransform = unreal.Transform(location=[0,0,0],rotation=axis,scale=[1,1,1])
			childrenCube = NLTA_Actor.AddCube()
			childrenCube.set_actor_label("NLTA_Offset_"+view)
			NLTA_Actor.AttachActor(childrenCube,parentCube,True)
			camera = unreal.EditorLevelLibrary().spawn_actor_from_class(unreal.CineCameraActor,unreal.Vector(0.0,0.0,0))
			camera.set_actor_label("NLTA_Camera_"+view)
			camera.scene_component.set_visibility(False,True)
			cameraName = camera.get_fname()
			NLTA_Actor.DetachActor(camera,"world")

			if view == "perspective" or view == "360Around":						
				camera.set_actor_transform(cameraDistanceTransform,False, False)
			else:						
				camera.set_actor_transform(distanceTransform,False, False)
			NLTA_Actor.AttachActor(camera,childrenCube,False)
			
			sessionData["CamerasData"][cameraName] = {
				"Camera":camera,
				"View":view
			}

			if view == "left":
				camera.set_actor_relative_rotation([0,0,-180],False,False)			
			if view not in ["perspective","360Around"]:
				childrenCube.set_actor_relative_transform(rotateTransform,False,False)
			if view == "360Around":
				sessionData["CamerasData"][cameraName]["remove"] = []	
				RenderPlaybackUpdate360Around()
		Pilot("perspective")			

def Pilot(view):
	sessionData = session["RenderPlayback"]
	for camera in sessionData["CamerasData"]:
		if sessionData["CamerasData"][camera]["View"] == view:
			NLTA_Actor.Pilot(sessionData["CamerasData"][camera]["Camera"])

def Save(url):
	data = {}
	children = NLTA_Actor.GetActorChildren("NLTA_RenderGroup")
	for actor in children:
		actorLabel = actor.get_actor_label()
		data[actorLabel] = {}
		actorTransform =  actor.get_actor_transform()
		data[actorLabel]["transform"] = {
			"translation":{
				"x":actorTransform.translation.x,
				"y":actorTransform.translation.y,
				"z":actorTransform.translation.z,
			},
			"rotation":{
				"x":actorTransform.rotation.x,
				"y":actorTransform.rotation.y,
				"z":actorTransform.rotation.z,
				"w":actorTransform.rotation.w,
			},
			"scale3d":{
				"x":actorTransform.scale3d.x,
				"y":actorTransform.scale3d.y,
				"z":actorTransform.scale3d.z,
			}
		}
	NLTA_general.writeJson(
		url+"/RenderSetting.json",
		data
	)	

def Load(url):
	data = NLTA_general.readJson(url)
	children = NLTA_Actor.GetActorChildren("NLTA_RenderGroup")
	for actor in children:
		actorLabel = actor.get_actor_label()
		actorData = data[actorLabel]
		transformTemp = unreal.Transform()
		transformTemp.translation.x = actorData["transform"]["translation"]["x"]
		transformTemp.translation.y = actorData["transform"]["translation"]["y"]
		transformTemp.translation.z = actorData["transform"]["translation"]["z"]
		transformTemp.rotation.x = actorData["transform"]["rotation"]["x"]
		transformTemp.rotation.y = actorData["transform"]["rotation"]["y"]
		transformTemp.rotation.z = actorData["transform"]["rotation"]["z"]
		transformTemp.rotation.w = actorData["transform"]["rotation"]["w"]
		transformTemp.scale3d.x = actorData["transform"]["scale3d"]["x"]
		transformTemp.scale3d.y = actorData["transform"]["scale3d"]["y"]
		transformTemp.scale3d.z = actorData["transform"]["scale3d"]["z"]
		actor.set_actor_transform(
			transformTemp,
			False,
			False
		)


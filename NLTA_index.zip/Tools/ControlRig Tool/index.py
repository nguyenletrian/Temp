import unreal
from importlib import *
import NLTA_general
reload(NLTA_general)
import NLTA_Asset
reload(NLTA_Asset)

NLTA_general.openWindow({
	"controller":"NLTA_Ctrl_RigTool"
})

"""
assets = NLTA_Asset.SelectedAsset()
if assets:
	if isinstance(assets[0],unreal.ControlRigBlueprint):
		NLTA_general.openWindow({
			"controller":"NLTA_Ctrl_RigTool"
		})
	else:
		unreal.EditorDialog.show_message("Warning","Please select a control rig asset!~ :D",unreal.AppMsgType.OK)
else:
	unreal.EditorDialog.show_message("Warning","Please select a control rig asset!~ :D",unreal.AppMsgType.OK)
"""
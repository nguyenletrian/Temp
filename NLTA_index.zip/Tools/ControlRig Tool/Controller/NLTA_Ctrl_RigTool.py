import unreal
import sys
import os
import shutil
import subprocess
import time
from importlib import *
from PySide2 import QtUiTools, QtWidgets
from PySide2.QtWidgets import QMessageBox, QMenu, QTreeWidgetItem,QTreeWidgetItemIterator
from PySide2 import QtCore
from PySide2 import QtGui
from functools import partial

import NLTA_general, NLTA_Asset, NLTA_ControlRig, NLTA_ControlRigGeneral, NLTA_ControlRigSupport, NLTA_ControlRigCore
reload(NLTA_general)
reload(NLTA_Asset)
reload(NLTA_ControlRig)
reload(NLTA_ControlRigGeneral)
reload(NLTA_ControlRigSupport)
reload(NLTA_ControlRigCore)

session = {
	"parent":None,
	"currentItem":"root",
	"items":{},
	"shapes":{}
}

class CreateWindow(QtWidgets.QWidget):
	window = None
	def __init__(self,parent=None):
		super(CreateWindow,self).__init__(parent)
		
		self.toolPath = NLTA_general.GetCurrentToolPath()
		self.dataPath = NLTA_general.getDataPath()
		self.shapeTemp = self.dataPath + "ControlRig/shapeTemp.json"
		NLTA_general.setSession("NLTA_ControlRig_CurrentModule","")

		self.widget = QtUiTools.QUiLoader().load(self.toolPath+"View/NLTA_RigTool.ui")
		self.widget.setParent(self)


		self.tree_Items = self.widget.findChild(QtWidgets.QTreeWidget,'tree_Items')
		self.tree_Items.setHeaderHidden(True)
		self.tree_Items.itemClicked.connect(self.ItemClick)
		self.tree_Items.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
		self.tree_Items.customContextMenuRequested.connect(self.ItemRightClick)
		self.LoadItems()

		self.list_Form = self.widget.findChild(QtWidgets.QVBoxLayout,'list_Form')

		self.txt_Name = self.widget.findChild(QtWidgets.QLineEdit,'txt_Name')
		self.txt_Right = self.widget.findChild(QtWidgets.QLineEdit,'txt_Right')
		self.txt_Left = self.widget.findChild(QtWidgets.QLineEdit,'txt_Left')
		self.Detect()

		self.btn_Ok = self.widget.findChild(QtWidgets.QPushButton,'btn_Ok')
		self.btn_Ok.clicked.connect(self.Ok)
		self.btn_Clear = self.widget.findChild(QtWidgets.QPushButton,'btn_Clear')
		self.btn_Clear.clicked.connect(self.Clear)
		self.btn_Export = self.widget.findChild(QtWidgets.QPushButton,'btn_Export')
		self.btn_Export.clicked.connect(self.Export)
		self.btn_Import = self.widget.findChild(QtWidgets.QPushButton,'btn_Import')
		self.btn_Import.clicked.connect(self.Import)
		
		self.btn_CreateMorphCurve = self.widget.findChild(QtWidgets.QPushButton,'btn_CreateMorphCurve')
		self.btn_CreateMorphCurve .clicked.connect(self.CreateMorphCurve)


		self.btn_MirrorShape = self.widget.findChild(QtWidgets.QPushButton,'btn_MirrorShape')
		self.btn_MirrorShape.clicked.connect(self.MirrorShape)

		self.btn_ImportCurve = self.widget.findChild(QtWidgets.QPushButton,'btn_ImportCurve')
		self.btn_ImportCurve.clicked.connect(self.ImportCurve)

	def resizeEvent(self,event):
		self.widget.resize(self.width(),self.height())
	
	def closeWindow(self):
		self.destroy()
		NLTA_general.openWindow({
			"controller":"NLTA_MainWindow",
			"posX":self.pos().x(),
			"posY":self.pos().y()
		})

	def Detect(self):
		global session
		assets = NLTA_Asset.SelectedAsset()
		for asset in assets:
			if isinstance(asset,unreal.ControlRigBlueprint):
				path = asset.get_path_name()
				self.txt_Name.setText(path)
				self.controlRig = asset
				unreal.AssetToolsHelpers.get_asset_tools().open_editor_for_assets([asset])
				session["controlRig"] = path

	def ClearForm(self):
		for i in reversed(range(self.list_Form.count())):
			self.list_Form.itemAt(i).widget().deleteLater()

	def Choice(self,inputArray):
		hierarchy = self.controlRig.hierarchy
		controller = hierarchy.get_controller()
		selectedObject = hierarchy.get_selected_keys()
		for order in range(len(selectedObject)):
			selectedName = str(selectedObject[order].name)
			inputArray[order].setText(selectedName)

	def GetPosition(self,inputArray):
		hierarchy = self.controlRig.hierarchy
		controller = hierarchy.get_controller()
		selectedObject = hierarchy.get_selected_keys()[0]
		globalTransform = hierarchy.get_global_transform(selectedObject)
		inputArray[0].setText(str(globalTransform.translation.x))
		inputArray[1].setText(str(globalTransform.translation.y))
		inputArray[2].setText(str(globalTransform.translation.z))
		inputArray[3].setText(str(globalTransform.rotation.x))
		inputArray[4].setText(str(globalTransform.rotation.y))
		inputArray[5].setText(str(globalTransform.rotation.z))
		inputArray[6].setText(str(globalTransform.rotation.w))

	def ChoiceList(self,input_):
		hierarchy = self.controlRig.hierarchy
		controller = hierarchy.get_controller()
		selectedObject = hierarchy.get_selected_keys()
		nameArray = []
		for order in range(len(selectedObject)):
			selectedName = str(selectedObject[order].name)
			nameArray.append(selectedName)
		input_.setText((";").join(nameArray))

	def ChoiceAdd(self,input_):
		hierarchy = self.controlRig.hierarchy
		controller = hierarchy.get_controller()
		selectedObject = hierarchy.get_selected_keys()
		nameArray = []
		for order in range(len(selectedObject)):
			selectedName = str(selectedObject[order].name)
			nameArray.append(selectedName)
		currentText = input_.toPlainText()
		currentText += "\n"+(";").join(nameArray)
		input_.setText(currentText)

	def LoadItems(self):
		self.tree_Items.clear()
		items = []
		currentItem = None
		for item in session["items"]:
			session["items"][item]["treeWidget"] = QTreeWidgetItem([item])
			if item == session["currentItem"]:
				currentItem = session["items"][item]["treeWidget"]
		for item in session["items"]:
			if session["items"][item]["parent"]!=None:
				parent = session["items"][item]["parent"]
				session["items"][parent]["treeWidget"].addChild(session["items"][item]["treeWidget"])
			items.append(session["items"][item]["treeWidget"])
		self.tree_Items.insertTopLevelItems(0,items)
		if currentItem!=None:
			self.tree_Items.setCurrentItem(currentItem)

	def ItemClick(self,item,col):
		currentItem = self.tree_Items.currentItem()
		if currentItem != None:
			text = currentItem.text(0)
			if text == session["currentItem"]:
				self.tree_Items.setItemSelected(currentItem,False)
				self.ClearForm()
				session["parent"] = None
				session["currentItem"] = None
			else:
				session["parent"]=session["items"][text]["parent"]
				session["currentItem"] = text
				type_ =  session["items"][text]["type"]
				session["action"] = "detail"
				self.Detail(type_)

	def ItemRightClick(self,point):
		global session
		session["action"] = "add"
		selectedItems = self.tree_Items.selectedItems()

		if len(selectedItems) != 0:
			text = self.tree_Items.selectedItems()[0].text(0)
			session["parent"] = text
			session["currentItem"] = text
		else:
			session["parent"] = None
			session["currentItem"] = None
		menu = QMenu(self)
		menu.addAction("Single/Chain",partial(self.Add,"Single"))
		menu.addAction("IK",partial(self.Add,"IK"))
		menu.addAction("IK Roll",partial(self.Add,"IKRoll"))
		menu.addAction("Finger",partial(self.Add,"Finger"))
		menu.addAction("Aim",partial(self.Add,"Aim"))
		menu.addAction("One Space",partial(self.Add,"SwitchOne"))
		menu.addAction("Two Space",partial(self.Add,"SwitchTwo"))
		menu.addAction("Track Circle",partial(self.Add,"TrackCircle"))
		menu.addAction("Track Spline",partial(self.Add,"TrackSpline"))
		menu.addSeparator()
		menu.addAction("Build/Rebuild",self.BuildSingleModule)
		menu.addAction("Delete",self.DeleteModule)
		menu.exec_(QtGui.QCursor.pos())

	def DeleteModule(self):
		global session
		itemData =  session["items"][session["currentItem"]]
		itemType = itemData["type"]
		session["items"].pop(session["currentItem"])
		children = []
		for item in session["items"]:
			if session["items"][item]["parent"]==session["currentItem"]:
				children.append(item)
		for item in children:
			session["items"].pop(item)
		self.ClearForm()
		self.LoadItems()

	def BuildSingleModule(self):
		if self.controlRig!=None:
			sessionClone = session.copy()
			sessionClone["items"] = {}
			sessionClone["items"][session["currentItem"]] = session["items"][session["currentItem"]]
			session["shapes"] = NLTA_ControlRigGeneral.GetAllCurveData({"controlRig":self.controlRig})
			NLTA_ControlRig.CreateSingleModule(sessionClone)
			self.SetAllCurveData()

	def ItemOk(self,inputData):		
		global session
		widget = inputData["widget"]
		type_ = inputData["type"]
		valueData = NLTA_general.WidgetGet(widget)
		name = valueData["txt_Name"]
		currentItem = session["currentItem"]
		if name!="":
			valueTemp = {}
			for inputElement in valueData:
				if valueData[inputElement] != None:
					valueTemp[inputElement] = valueData[inputElement]
			if session["action"] == "detail":
				if name != currentItem:
					session["items"].pop(currentItem)
					for item in session["items"]:
						if session["items"][item]["parent"] == currentItem:
							session["items"][item]["parent"] = name
			session["items"][name] = {
				"parent":session["parent"],
				"type":type_,
				"value":valueTemp,				
			}
			session["currentItem"] = name
			widget.deleteLater()
			self.ClearForm()
			self.LoadItems()
		else:
			print("Please fille the name!~ ")

	def Add(self,type_):
		exec('self.'+type_+'Form()')

	def Detail(self,type_):
		if type_ == "IK":
			widgetData = self.IKForm()
		if type_ == "Single":
			widgetData = self.SingleForm()
		if type_ == "SwitchTwo":
			widgetData = self.SwitchTwoForm()
		if type_ == "SwitchOne":
			widgetData = self.SwitchOneForm()
		if type_ == "Aim":
			widgetData = self.AimForm()
		if type_ == "Finger":
			widgetData = self.FingerForm()
		if type_ == "IKRoll":
			widgetData = self.IKRollForm()
		if type_ == "TrackCircle":
			widgetData = self.TrackCircleForm()
		if type_ == "TrackSpline":
			widgetData = self.TrackSplineForm()
		value = session["items"][session["currentItem"]]["value"]
		NLTA_general.WidgetSet({"widget":widgetData,"value":value})

	def IKForm(self):
		self.ClearForm()
		pattern = self.toolPath+"View/NLTA_RigTool_Ik.ui"
		widget = QtUiTools.QUiLoader().load(pattern)
		widgetData = NLTA_general.WidgetInput(widget)
		
		controls = [None,"Root_Control_NLTA"]
		if session["parent"]!=None:
			controls = NLTA_ControlRigSupport.GetParentControls(session["items"][session["parent"]])		
		NLTA_general.reloadComboBox(widgetData["cbx_BeforeParent"],controls)
		
		widgetData["btn_ChoiceBone1"].clicked.connect(partial(self.Choice,[widgetData["txt_Bone1"],widgetData["txt_Bone2"],widgetData["txt_Bone3"],]))
		widgetData["btn_ChoiceBone2"].clicked.connect(partial(self.Choice,[widgetData["txt_Bone2"],widgetData["txt_Bone3"],]))
		widgetData["btn_ChoiceBone3"].clicked.connect(partial(self.Choice,[widgetData["txt_Bone3"],]))		
		widgetData["btn_Ok"].clicked.connect(partial(self.ItemOk,{"widget":widget,"type":"IK"}))
		self.list_Form.addWidget(widget)
		return(widgetData)

	def IKRollForm(self):
		self.ClearForm()
		pattern = self.toolPath+"View/NLTA_RigTool_IkRoll.ui"
		widget = QtUiTools.QUiLoader().load(pattern)
		widgetData = NLTA_general.WidgetInput(widget)
		
		controls = [None,"Root_Control_NLTA"]
		if session["parent"]!=None:
			controls = NLTA_ControlRigSupport.GetParentControls(session["items"][session["parent"]])		
		NLTA_general.reloadComboBox(widgetData["cbx_IKControl"],controls)

		widgetData["btn_GetPositionInner"].clicked.connect(partial(
			self.GetPosition,
			[
				widgetData["txt_TranslationXInner"],widgetData["txt_TranslationYInner"],widgetData["txt_TranslationZInner"],
				widgetData["txt_RotationXInner"],widgetData["txt_RotationYInner"],widgetData["txt_RotationZInner"],widgetData["txt_RotationWInner"]
			]
		))
		widgetData["btn_GetPositionOuter"].clicked.connect(partial(
			self.GetPosition,
			[
				widgetData["txt_TranslationXOuter"],widgetData["txt_TranslationYOuter"],widgetData["txt_TranslationZOuter"],
				widgetData["txt_RotationXOuter"],widgetData["txt_RotationYOuter"],widgetData["txt_RotationZOuter"],widgetData["txt_RotationWOuter"]
			]
		))

		widgetData["btn_GetPositionHeel"].clicked.connect(partial(
			self.GetPosition,
			[
				widgetData["txt_TranslationXHeel"],widgetData["txt_TranslationYHeel"],widgetData["txt_TranslationZHeel"],
				widgetData["txt_RotationXHeel"],widgetData["txt_RotationYHeel"],widgetData["txt_RotationZHeel"],widgetData["txt_RotationWHeel"]
			]
		))

		widgetData["btn_GetPositionToe"].clicked.connect(partial(
			self.GetPosition,
			[
				widgetData["txt_TranslationXToe"],widgetData["txt_TranslationYToe"],widgetData["txt_TranslationZToe"],
				widgetData["txt_RotationXToe"],widgetData["txt_RotationYToe"],widgetData["txt_RotationZToe"],widgetData["txt_RotationWToe"]
			]
		))

		widgetData["btn_GetPositionBall"].clicked.connect(partial(
			self.GetPosition,
			[
				widgetData["txt_TranslationXBall"],widgetData["txt_TranslationYBall"],widgetData["txt_TranslationZBall"],
				widgetData["txt_RotationXBall"],widgetData["txt_RotationYBall"],widgetData["txt_RotationZBall"],widgetData["txt_RotationWBall"]
			]
		))
		widgetData["btn_Ok"].clicked.connect(partial(self.ItemOk,{"widget":widget,"type":"IKRoll"}))
		self.list_Form.addWidget(widget)
		return(widgetData)

	def SingleForm(self):
		self.ClearForm()
		pattern = self.toolPath+"View/NLTA_RigTool_Single.ui"
		widget = QtUiTools.QUiLoader().load(pattern)
		widgetData = NLTA_general.WidgetInput(widget)
		
		controls = [None,"Root_Control_NLTA"]
		if session["parent"]!=None:
			controls = NLTA_ControlRigSupport.GetParentControls(session["items"][session["parent"]])
		NLTA_general.reloadComboBox(widgetData["cbx_BeforeParent"],controls)

		widgetData["btn_Choice"].clicked.connect(partial(self.ChoiceList,widgetData["txt_Bone"]))
		widgetData["btn_Ok"].clicked.connect(partial(self.ItemOk,{"widget":widget,"type":"Single"}))
		self.list_Form.addWidget(widget)
		return(widgetData)

	def SwitchTwoForm(self):
		self.ClearForm()
		pattern = self.toolPath+"View/NLTA_RigTool_SwitchTwo.ui"
		widget = QtUiTools.QUiLoader().load(pattern)
		widgetData = NLTA_general.WidgetInput(widget)
		
		controls = [None,"Root_Control_NLTA"]
		if session["parent"]!=None:
			controls = NLTA_ControlRigSupport.GetParentControls(session["items"][session["parent"]])

		NLTA_general.reloadComboBox(widgetData["cbx_BeforeParent"],controls)
		allControls = NLTA_ControlRigSupport.GetAllControls(session["items"])
		NLTA_general.reloadComboBox(widgetData["cbx_Parent1"],allControls)
		NLTA_general.reloadComboBox(widgetData["cbx_Parent2"],allControls)
		NLTA_general.reloadComboBox(widgetData["cbx_Child"],allControls)
		widgetData["btn_Ok"].clicked.connect(partial(self.ItemOk,{"widget":widget,"type":"SwitchTwo"}))
		self.list_Form.addWidget(widget)
		return(widgetData)

	def SwitchOneForm(self):
		self.ClearForm()
		pattern = self.toolPath+"View/NLTA_RigTool_SwitchOne.ui"
		widget = QtUiTools.QUiLoader().load(pattern)
		widgetData = NLTA_general.WidgetInput(widget)
		
		controls = [None,"Root_Control_NLTA"]
		if session["parent"]!=None:
			controls = NLTA_ControlRigSupport.GetParentControls(session["items"][session["parent"]])
		NLTA_general.reloadComboBox(widgetData["cbx_BeforeParent"],controls)
		allControls = NLTA_ControlRigSupport.GetAllControls(session["items"])
		NLTA_general.reloadComboBox(widgetData["cbx_Parent"],allControls)
		NLTA_general.reloadComboBox(widgetData["cbx_Child"],allControls)
		widgetData["btn_Ok"].clicked.connect(partial(self.ItemOk,{"widget":widget,"type":"SwitchOne"}))
		self.list_Form.addWidget(widget)
		return(widgetData)

	def AimForm(self):
		self.ClearForm()
		pattern = self.toolPath+"View/NLTA_RigTool_Aim.ui"
		widget = QtUiTools.QUiLoader().load(pattern)
		widgetData = NLTA_general.WidgetInput(widget)

		allControls = NLTA_ControlRigSupport.GetAllControls(session["items"])
		NLTA_general.reloadComboBox(widgetData["cbx_Child"],allControls)
		widgetData["btn_Ok"].clicked.connect(partial(self.ItemOk,{"widget":widget,"type":"Aim"}))
		self.list_Form.addWidget(widget)
		return(widgetData)

	def FingerForm(self):
		self.ClearForm()
		pattern = self.toolPath+"View/NLTA_RigTool_Finger.ui"
		widget = QtUiTools.QUiLoader().load(pattern)
		widgetData = NLTA_general.WidgetInput(widget)
		
		controls = [None,"Root_Control_NLTA"]
		if session["parent"]!=None:
			controls = NLTA_ControlRigSupport.GetParentControls(session["items"][session["parent"]])
		NLTA_general.reloadComboBox(widgetData["cbx_BeforeParent"],controls)
		NLTA_general.reloadComboBox(widgetData["cbx_AttrContent"],controls)

		widgetData["btn_Choice"].clicked.connect(partial(self.ChoiceList,widgetData["txt_Bone"]))
		widgetData["btn_ChoiceAdd"].clicked.connect(partial(self.ChoiceAdd,widgetData["txt_Bone"]))
		widgetData["btn_Ok"].clicked.connect(partial(self.ItemOk,{"widget":widget,"type":"Finger"}))
		self.list_Form.addWidget(widget)
		return(widgetData)

	def TrackCircleForm(self):
		self.ClearForm()
		pattern = self.toolPath+"View/NLTA_RigTool_TrackCircle.ui"
		widget = QtUiTools.QUiLoader().load(pattern)
		widgetData = NLTA_general.WidgetInput(widget)
		
		controls = [None,"Root_Control_NLTA"]
		if session["parent"]!=None:
			controls = NLTA_ControlRigSupport.GetParentControls(session["items"][session["parent"]])
		NLTA_general.reloadComboBox(widgetData["cbx_BeforeParent"],controls)

		widgetData["btn_Choice"].clicked.connect(partial(self.ChoiceList,widgetData["txt_Controls"]))
		widgetData["btn_Ok"].clicked.connect(partial(self.ItemOk,{"widget":widget,"type":"TrackCircle"}))
		self.list_Form.addWidget(widget)
		return(widgetData)

	def TrackSplineForm(self):
		self.ClearForm()
		pattern = self.toolPath+"View/NLTA_RigTool_TrackSpline.ui"
		widget = QtUiTools.QUiLoader().load(pattern)
		widgetData = NLTA_general.WidgetInput(widget)
		
		controls = [None,"Root_Control_NLTA"]
		if session["parent"]!=None:
			controls = NLTA_ControlRigSupport.GetParentControls(session["items"][session["parent"]])
		NLTA_general.reloadComboBox(widgetData["cbx_BeforeParent"],controls)

		widgetData["btn_ChoicePoints"].clicked.connect(partial(self.ChoiceList,widgetData["txt_Points"]))
		widgetData["btn_ChoiceControls"].clicked.connect(partial(self.ChoiceList,widgetData["txt_Controls"]))
		widgetData["btn_Ok"].clicked.connect(partial(self.ItemOk,{"widget":widget,"type":"TrackSpline"}))
		self.list_Form.addWidget(widget)
		return(widgetData)


	############
	def Ok(self):
		global session
		if self.controlRig!=None:
			session["shapes"] = NLTA_ControlRigGeneral.GetAllCurveData({"controlRig":self.controlRig})
			NLTA_ControlRig.CreateAll(session)
			self.SetAllCurveData()

	def Export(self):
		url = NLTA_general.DirectoryDialog(self)

		if url !="":
			sessionData = session.copy()
			for item in sessionData["items"]:
				sessionData["items"][item]["treeWidget"] = ""
			sessionData["shapes"] = NLTA_ControlRigGeneral.GetAllCurveData({"controlRig":self.controlRig})
			sessionData["right"] = self.txt_Right.text()
			sessionData["left"] = self.txt_Left.text()
			NLTA_general.writeJson(
				url+"/RigSetting.json",
				sessionData
			)

	def Import(self):
		global session
		url = NLTA_general.FileDialog(self)[0]
		sessionTemp = NLTA_general.readJson(url)
		sessionTemp["controlRig"] = session["controlRig"]
		session = sessionTemp
		self.txt_Right.setText(session["right"])
		self.txt_Left.setText(session["left"])
		NLTA_ControlRigGeneral.ClearAll(self.controlRig)
		NLTA_ControlRig.CreateAll(session)
		self.LoadItems()
		self.SetAllCurveData()

	def ImportCurve(self):
		global session
		url = NLTA_general.FileDialog(self)[0]
		sessionTemp = NLTA_general.readJson(url)
		session["shapes"] = sessionTemp["shapes"]
		self.SetAllCurveData()

	def SetAllCurveData(self):
		NLTA_ControlRigGeneral.SetAllCurveData({
			"controlRig":self.controlRig,
			"data":session["shapes"]
		})

	def Clear(self):
		global session
		NLTA_ControlRigGeneral.ClearAll(self.controlRig)
		self.txt_Right.setText("")
		self.txt_Left.setText("")
		session["items"] = {}
		self.LoadItems()
		self.ClearForm()

	def MirrorShape(self):
		NLTA_ControlRigGeneral.MirrorShapeBySelected({
			"controlRig":self.controlRig,
		})

	def CreateMorphCurve(self):
		NLTA_ControlRigCore.CreateMorphCurve()




from importlib import *

import unreal, NLTA_ControlRigGeneral, NLTA_ControlRigIK, NLTA_ControlRigSingle, NLTA_ControlRigIKRoll
import NLTA_ControlRigSwitchTwo, NLTA_ControlRigSwitchOne, NLTA_ControlRigAim, NLTA_ControlRigFinger, NLTA_ControlRigTrackCircle, NLTA_ControlRigTrackSpline
reload(NLTA_ControlRigIK)
reload(NLTA_ControlRigIKRoll)
reload(NLTA_ControlRigGeneral)
reload(NLTA_ControlRigSingle)
reload(NLTA_ControlRigSwitchTwo)
reload(NLTA_ControlRigSwitchOne)
reload(NLTA_ControlRigAim)
reload(NLTA_ControlRigFinger)
reload(NLTA_ControlRigTrackCircle)
reload(NLTA_ControlRigTrackSpline)

session = {}
def NameSetting(inputData):
	type_ = inputData["type"]
	value = inputData["value"]
	name = value["txt_Name"]
	if type_ == "IK":
		return({
			"name":"IK_NLTA",
			"module":"NLTA_ControlRigIK",
			"function":name+"_NLTA",
			"controlsArray":[
				name+"_"+value["txt_Bone1"]+"_FK_NLTA",
				name+"_"+value["txt_Bone2"]+"_FK_NLTA",
				name+"_"+value["txt_Bone3"]+"_FK_NLTA",
				name+"_Effector_"+value["txt_Bone3"]+"_NLTA",
				name+"_PointVector_"+value["txt_Bone2"]+"_NLTA",
				name+"_Switch_"+value["txt_Bone3"]+"_NLTA",
			],			
			"names":{
				"fk0":name+"_"+value["txt_Bone1"]+"_FK_NLTA",
				"fk1":name+"_"+value["txt_Bone2"]+"_FK_NLTA",
				"fk2":name+"_"+value["txt_Bone3"]+"_FK_NLTA",
				"effector":name+"_Effector_"+value["txt_Bone3"]+"_NLTA",	
				"pointVector":name+"_PointVector_"+value["txt_Bone2"]+"_NLTA",		
				"switchChannel":name+"_Switch_NLTA",
				"switchControl":name+"_Switch_"+value["txt_Bone3"]+"_NLTA",
				"switchNode":name+"_Node_NLTA",
			},
		})
	if type_ == "IKRoll":
		lastString = value["cbx_IKControl"].split("_Effector_")[-1]
		IKModule = value["cbx_IKControl"].split("_Effector_")[0]
		return({
			"name":"IKRoll_NLTA",
			"module":"NLTA_ControlRigIKRoll",
			"function":name+"_NLTA",
			"controlsArray":[
				name + "_Heel_" +lastString,
				name + "_Toe_" +lastString,
				name + "_Inner_" +lastString,
				name + "_Outer_" +lastString,
				name + "_Ball_" +lastString,
				name + "_Main_" +lastString,
			],
			"names":{
				"Heel":name + "_Heel_" +lastString,
				"Toe":name + "_Toe_" +lastString,
				"Inner":name + "_Inner_" +lastString,
				"Outer":name + "_Outer_" +lastString,
				"Ball":name + "_Ball_" +lastString,
				"IKFake":name + "_Main_" +lastString,
				"switchChannel":IKModule+"_Switch_NLTA",
				"switchControl":IKModule+"_Switch_"+lastString,
				"node":name+"_NLTA_Node",
			}
		})

	if type_ == "Single":
		return({
			"name":"Single_NLTA",
			"module":"NLTA_ControlRigSingle",
			"function":name+"_NLTA",
			"controlsPattern":name+"_{}_NLTA",			
		})
	if type_ == "TrackCircle":
		return({
			"name":"TrackCircle_NLTA",
			"module":"NLTA_ControlRigTrackCircle",			
			"function":name+"_NLTA",
			"names":{
				"offsetsPattern":name+"_offset_{}",
				"originsPattern":name+"_origin_{}",
				"floatNode":name+"_Slide_NLTA",
				"floatControl":name+"_Slide_NLTA",
				"booleanNode":name+"_Reverse_NLTA",
				"booleanControl":name+"_Reverse_NLTA",
			}

		})
	if type_ == "TrackSpline":
		return({
			"name":"TrackSpline_NLTA",
			"module":"NLTA_ControlRigTrackSpline",			
			"function":name+"_NLTA",
			"names":{
				"offsetsPattern":name+"_offset_{}",
				"UNode":name+"_U_NLTA",
				"UControl":name+"_U_NLTA",
				"distanceNode":name+"_Distance_NLTA",
				"distanceControl":name+"_Distance_NLTA",
			}

		})

	if type_ == "SwitchTwo":
		return({
			"name":"SwitchTwo_NLTA",
			"module":"NLTA_ControlRigSwitchTwo",
			"function":name+"NLTA",
			"names":{
				"offset":name+"_Offset_NLTA",
				"switchControl":name+"_Switch_NLTA",
				"switchNode":name+"_SwitchNode_NLTA"
			}						
		})
	if type_ == "SwitchOne":
		return({
			"name":"SwitchOne_NLTA",
			"module":"NLTA_ControlRigSwitchOne",
			"function":name+"NLTA",
			"names":{
				"offset":name+"_Offset_NLTA",
				"switchControl":name+"_Switch_NLTA",
				"switchNode":name+"_SwitchNode_NLTA"
			}						
		})
	if type_ == "Aim":
		return({
			"name":"Aim_NLTA",
			"module":"NLTA_ControlRigAim",
			"function":name+"_NLTA",
			"controlsArray":[
				name+"_"+value["cbx_Child"]+"_NLTA"
			],
			"names":{
				"offset":name+"_Offset_NLTA",
				"worldUp":name+"_WorldUp_NLTA",
				"control":name+"_"+value["cbx_Child"]+"_NLTA"
			}						
		})
	if type_ == "Finger":
		return({
			"name":"Finger_NLTA",
			"module":"NLTA_ControlRigFinger",
			"function":name+"_NLTA",
			"controlsPattern":name+"_{}_NLTA",
			"names":{
				"control":name+"_{}_NLTA",
				"offset":name+"_offset_{}_NLTA",
				"function":name+"_Function_{}_NLTA",
				"holdNode":name+"_Hold_{}_NLTA",
				"holdAttr":name+"_Hold_{}_NLTA",
			}			
		})



def Create(inputData):
	global session
	session = inputData["session"]
	item =  inputData["item"]
	extra =  inputData["extra"]	
	nameSetting = NameSetting(item)
	name =  nameSetting["name"]
	returnDic = {}
	pattern = eval(nameSetting["module"]+".Pattern()")
	CreateFunction(name,pattern)
	return(eval(nameSetting["module"]+".Create")(inputData))

def CreateFunction(name,pattern):
	pinData = {
		"ArrayBool":{
			"type":'TArray<bool>',
			"script":"",
			"default":"()"
		},
		"ArrayRigElementKey":{
			"type":'TArray<FRigElementKey>',
			"script":'/Script/ControlRig.RigElementKey',
			"default":'()'
		},
		"RigElementKey":{
			"type":'FRigElementKey',
			"script":'/Script/ControlRig.RigElementKey',
			"default":'(Type=None,Name="None")'
		},
		"Vector":{
			"type": 'FVector',
			"script": '/Script/CoreUObject.Vector',
			"default": '(X=0.000000,Y=0.000000,Z=0.000000)'		
		},
		"Boolean":{
			"type":"bool",
			"script":"None",
			"default":""
		},
		"Double":{
			"type":"double",
			"script":"None",
			"default":""
		},
		"Transform":{
			"type":'FTransform',
			"script":'/Script/CoreUObject.Transform',
			"default":'(Rotation=(X=0.000000,Y=0.000000,Z=0.000000,W=1.000000),Translation=(X=0.000000,Y=0.000000,Z=0.000000),Scale3D=(X=1.000000,Y=1.000000,Z=1.000000))'
		},
		"ArrayTransform":{
			"type":'TArray<FTransform>',
			"script":'/Script/CoreUObject.Transform',
			"default":'(Rotation=(X=0.000000,Y=0.000000,Z=0.000000,W=1.000000),Translation=(X=0.000000,Y=0.000000,Z=0.000000),Scale3D=(X=1.000000,Y=1.000000,Z=1.000000))'
		}
	}
	controlRig =  session["controlRig"]
	library = session["library"]
	controller = controlRig.get_controller(library)
	if library.find_function(name)==None:
		controller.add_function_to_library(name, True, unreal.Vector2D(0.000000, 0.000000))	
		module = controlRig.get_controller_by_name(name)
		inputData = pattern
		if "pins" in inputData:
			pins = inputData["pins"]
			for order in range(len(pins)):
				pinTemp = pins[order]
				side = pinTemp[0]
				name = pinTemp[1]
				type_ = pinTemp[2]
				if side == "input":
					side = unreal.RigVMPinDirection.INPUT
				else:
					side = unreal.RigVMPinDirection.OUTPUT
				module.add_exposed_pin(
					name,
					side,
					pinData[type_]["type"],
					pinData[type_]["script"],
					pinData[type_]["default"]
				)

		if "variables" in inputData:
			items = inputData["variables"]
			for order in range(len(items)):
				item = items[order]
				name = item[0]
				type_ = item[1]
				module.add_local_variable_from_object_path(
					name,
					pinData[type_]["type"],
					pinData[type_]["script"],
					pinData[type_]["default"]
				)

		if "variablesNode" in inputData:
			items = inputData["variablesNode"]
			for order in range(len(items)):
				item = items[order]
				name = item[0]
				variableName = item[1]
				type_ = item[2]
				setGet = item[3]
				module.add_variable_node_from_object_path(
					variableName,
					pinData[type_]["type"],
					pinData[type_]["script"],					
					setGet,
					'()',
					unreal.Vector2D(0,0),
					name				
				)

		if "nodes" in inputData:
			nodes = inputData["nodes"]
			for order in range(len(nodes)):
				nodeTemp = nodes[order]
				type_ =  nodeTemp[0]
				name = nodeTemp[1]
				NLTA_ControlRigGeneral.AddNode({
					"module":module,
					"type":type_,
					"name":name
				})

		if "positions" in inputData:
			positions = inputData["positions"]
			for order in range(len(positions)):
				positionTemp = positions[order]
				name = positionTemp[0]
				x = positionTemp[1]
				y = positionTemp[2]
				module.set_node_position_by_name(name, unreal.Vector2D(x,y))

		if "wildCard" in inputData:
			items = inputData["wildCard"]
			for order in range(len(items)):
				item = items[order]
				pin = item[0]
				type_ = item[1]
				value = item[2]
				module.resolve_wild_card_pin(pin,type_,value)


		if "values" in inputData:
			items = inputData["values"]
			for order in range(len(items)):
				item = items[order]
				pin = item[0]
				value = item[1]
				module.set_pin_default_value(pin,value)
		
		if "links" in inputData:
			links = inputData["links"]
			for order in range(len(links)):
				linkTemp = links[order]
				source = linkTemp[0]
				destination =  linkTemp[1]
				module.add_link(source,destination)
		
		if "expansions" in inputData:
			items = inputData["expansions"]
			for order in range(len(items)):
				item = items[order]
				pin = item[0]
				total = item[1]
				module.set_pin_expansion(pin, True)
				for order2 in range(total):
					module.set_pin_expansion(pin+"."+str(order2), True)
					
def GetParentControls(inputData):
	controls = [None,"Root_Control_NLTA"]
	if inputData["type"] in ["IK","IKRoll","Aim"]:
		return(controls + NameSetting(inputData)["controlsArray"])
	elif inputData["type"] in ["Single","Finger"]:
		pattern = NameSetting(inputData)["controlsPattern"]
		bonesArray = inputData["value"]["txt_Bone"].split(";")
		for bone in bonesArray:
			controls.append(pattern.format(bone))
		return(controls)

def GetAllControls(items):
	controls = [None,"Root_Control_NLTA"]
	controlsArray = []
	for item in items:
		inputData = items[item]
		if inputData["type"] in ["IK","IKRoll","Aim"]:
			controlsArray.extend(NameSetting(inputData)["controlsArray"])
		elif inputData["type"] in ["Single","Finger"]:
			pattern = NameSetting(inputData)["controlsPattern"]
			bonesArray = inputData["value"]["txt_Bone"].split(";")
			for bone in bonesArray:
				controlsArray.append(pattern.format(bone))
	controlsArray.sort()
	controlsArray = controls + controlsArray
	return(controlsArray)


"""
def RenameModule(inputData):
	oldItem = inputData["oldItem"]
	oldNameSetting = NameSetting(oldItem)
	newName = inputData["newName"]
	newItem = oldItem.copy()
	newItem["txt_Name"] = newName
	newNameSetting = NameSetting(newItem)
"""

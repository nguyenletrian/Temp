from importlib import *
import unreal, NLTA_general, NLTA_ControlRigGeneral, NLTA_ControlRigSupport
reload(NLTA_general)
reload(NLTA_ControlRigGeneral)
reload(NLTA_ControlRigSupport)

session = {}
def Pattern():
	return({
		"pins":[
			["input","Child","RigElementKey"],
			["input","Parent","RigElementKey"],
			["input","WorldUpObject","RigElementKey"],
			["input","AimAxis","Vector"],
			["input","Maintain","Boolean"]
		],
		"nodes":[
			["Sequence","Sequence"],
			["Aim","Aim"],
			["ParentConstraint","ParentConstraint"]
		],
		"positions":[
			["return",656,0],
			["Sequence",32,0],
			["Entry",-250,0],
			["Aim",272,0],
			["ParentConstraint",272,704]
		],
		"values":[
			["Aim.WorldUp.Kind","Location"],
			['Aim.UpAxis','(X=0.000000,Y=0.000000,Z=1.000000)'],
		],
		"links":[
			['Entry.Child', 'Aim.Child'],
			['Entry.Parent', 'Aim.Parents.0.Item'],
			['Entry.AimAxis', 'Aim.AimAxis'],
			['Entry.Maintain', 'Aim.bMaintainOffset'],
			['Aim.ExecuteContext', 'Return.ExecuteContext'],
			['Entry.WorldUpObject', 'Aim.WorldUp.Space'],
			['Entry.ExecuteContext', 'Sequence.ExecuteContext'],
			['Sequence.A', 'Aim.ExecuteContext'],
			['Sequence.B', 'ParentConstraint.ExecuteContext'],
			['Entry.WorldUpObject', 'ParentConstraint.Child'],
			['Entry.Child', 'ParentConstraint.Parents.0.Item'],
		]
	})

def Create(inputData):
	global session
	session = inputData["session"]
	item =  inputData["item"]
	extra =  inputData["extra"]	

	controlRig = session["controlRig"]
	rootNode = session["rootNode"]
	hierarchy = session["hierarchy"]
	controller = session["controller"]
	positionCurrent = extra["positionCurrent"]
	positionCurrent = [positionCurrent[0]+200,0]
	executeInNode =  extra["executeInNode"]

	data = item["value"]
	nameSetting = NLTA_ControlRigSupport.NameSetting(item)
	names = nameSetting["names"]
	functionPattern = nameSetting["name"]

	child = unreal.RigElementKey(type=unreal.RigElementType.CONTROL, name=data["cbx_Child"])
	maintain = data["chx_Maintain"]
	positive = data["chx_Positive"]
	mainX = data["rad_MainX"]
	mainY = data["rad_MainY"]
	mainZ = data["rad_MainZ"]
	upX = data["rad_UpX"]
	upY = data["rad_UpY"]
	upZ = data["rad_UpZ"]
	distance = data["spn_Distance"]

	childTransform = hierarchy.get_global_transform(child)
	childParent = hierarchy.get_parents(child)
	if len(childParent)!=0:
		parent = childParent[0]
	else:
		parent = session["rootControl"]

	#AIM_CONROL
	controlTemp = NLTA_ControlRigGeneral.AddControl({
		"controlRig":session["controlRig"],
		"type":"control",
		"name":"ControlTemp",
		"shape":"Diamond_Thick",
		"transform":childTransform,
		"parent":child
	})
	if positive == True:
		distance = distance
	else:
		distance = distance * (-1)
	aimLocalTransform = NLTA_general.BasicTransform()
	if mainX == True:
		aimLocalTransform.translation = [distance,0,0]
		aimAxis = [1,0,0]
	if mainY == True:
		aimLocalTransform.translation = [0,distance,0]
		aimAxis = [0,1,0]
	if mainZ == True:
		aimLocalTransform.translation = [0,0,distance]
		aimAxis = [0,0,1]
	hierarchy.set_control_offset_transform(controlTemp,aimLocalTransform,True,True)
	globalTransfrom = hierarchy.get_global_transform(controlTemp)
	controller.remove_element(controlTemp)
	AimControl = NLTA_ControlRigGeneral.AddControl({
		"controlRig":session["controlRig"],
		"type":"control",
		"name":names["control"],
		"shape":"Diamond_Thick",
		"transform":globalTransfrom,
		"parent":parent
	})

	#WORLD UP OBJECT
	controlTemp = NLTA_ControlRigGeneral.AddControl({
		"controlRig":session["controlRig"],
		"type":"control",
		"name":"ControlTemp",
		"shape":"Diamond_Thick",
		"transform":childTransform,
		"parent":child
	})
	transformTemp = NLTA_general.BasicTransform()
	if upX == True:
		transformTemp.translation = [1,0,0]
	if upY == True:
		transformTemp.translation = [0,1,0]
	if upZ == True:
		transformTemp.translation = [0,0,1]
	hierarchy.set_control_offset_transform(controlTemp,transformTemp,True,True)
	globalTransfrom = hierarchy.get_global_transform(controlTemp)
	controller.remove_element(controlTemp)
	worldUp = NLTA_ControlRigGeneral.AddControl({
		"controlRig":session["controlRig"],
		"type":"proxy",
		"name":names["worldUp"],
		"shape":"Diamond_Thick",
		"transform":globalTransfrom,
		"parent":parent,
		"visible":False
	})	
	
	#OFFSET	
	offset = NLTA_ControlRigGeneral.AddControl({
		"controlRig":session["controlRig"],
		"type":"proxy",
		"name":names["offset"],
		"transform":childTransform,
		"parent":parent,
		"visible":False
	})
	NLTA_ControlRigGeneral.SetParent({"controlRig":session["controlRig"],"parent":offset,"child":child})
	
	#ADD FUNCTION
	library = controlRig.get_local_function_library()
	functionPattern = library.find_function(functionPattern)
	rootNode.add_function_reference_node(functionPattern,unreal.Vector2D(positionCurrent[0],positionCurrent[1]),nameSetting["function"])	

	
	session["rootNode"].add_link(executeInNode,nameSetting["function"]+".ExecuteContext")	
	rootNode.set_pin_default_value(nameSetting["function"]+'.Child', '(Type=Control,Name="'+names["offset"]+'")')
	rootNode.set_pin_default_value(nameSetting["function"]+'.Parent', '(Type=Control,Name="'+names["control"]+'")')
	rootNode.set_pin_default_value(nameSetting["function"]+'.WorldUpObject', '(Type=Control,Name="'+names["worldUp"]+'")')
	rootNode.set_pin_default_value(nameSetting["function"]+'.AimAxis', '(X='+str(aimAxis[0])+',Y='+str(aimAxis[1])+',Z='+str(aimAxis[2])+')')
	rootNode.set_pin_default_value(nameSetting["function"]+'.Maintain',str(maintain))

	return({
		"executeInNode":nameSetting["function"]+".ExecuteContext",
		"positionCurrent":positionCurrent
	})
from importlib import *
import unreal, NLTA_general, NLTA_ControlRigGeneral, NLTA_ControlRigSupport
reload(NLTA_general)
reload(NLTA_ControlRigGeneral)
reload(NLTA_ControlRigSupport)

session = {}
def Pattern():
	return({
		"pins":[
			["input","OriginTransform","ArrayRigElementKey"],
			["input","Offsets","ArrayRigElementKey"],
			["input","Value","Double"],
			["input","Reverse","Boolean"],
		],		
		"variables":[#name,#type
			["Transform","ArrayTransform"],
		],
		"variablesNode":[#name,#variableName,#type,setGet
			["GetVariableTransform","Transform","ArrayTransform",True],
			["SetVariableTransform","Transform","ArrayTransform",False],
		],
		"nodes":[#type,#name
			["GetTransformArray","GetTransformArray"],
			["Num","Num"],
			["Modulo","Modulo"],
			["FloorInt","Floor"],
			["Add","Add"],
			["ForEach","ForEach"],
			["SetTransform","SetTransform"],
			["GreaterEqual","GreaterEqual"],
			["If","If"],
			["If","If1"],
			["Subtract","Subtract"],
			["Subtract","Subtract1"],
			["At","At"],
			["GetTransform","GetTransform"],			
			["ToEuler","ToEuler"],
			["ToEuler","ToEuler1"],
			["FromEuler","FromEuler"],
			["EvaluateCurve","EvaluateCurveTX"],
			["EvaluateCurve","EvaluateCurveTY"],
			["EvaluateCurve","EvaluateCurveTZ"],
			["EvaluateCurve","EvaluateCurveRX"],
			["EvaluateCurve","EvaluateCurveRY"],
			["EvaluateCurve","EvaluateCurveRZ"],
		],
		"positions":[
			["Entry",-1552,288],
			["Return",-567,366],
			["GetTransformArray",-1296,160],
			["Num",-1328,672],
			["Modulo",-1136,592],
			["Floor",-1312,544],
			["Add",-576,752],
			["ForEach",-816,160],
			["SetTransform",1904,240],
			["GreaterEqual",-400,720],
			["If",-176,768],
			["If1",0,32],
			["Subtract1",-400,848],
			["At",224,768],
			["GetTransform",-336,208],
			["Subtract",-1136,464],
			["ToEuler",384,432],
			["ToEuler1",432,752],
			["FromEuler",1456,880],
			["GetVariableTransform",48,736],
			["SetVariableTransform",-992,736],
			["EvaluateCurveTX",864,1424],
			["EvaluateCurveTY",864,1840],
			["EvaluateCurveTZ",864,2256],
			["EvaluateCurveRX",864,176],
			["EvaluateCurveRY",864,592],
			["EvaluateCurveRZ",864,1008],
		],
		"wildCard":[
			['Floor.Value',"double",'None'],
			['SetTransform.Value', 'FTransform', '/Script/CoreUObject.Transform'],
			['If1.True', 'FVector', '/Script/CoreUObject.Vector']
		],
		"values":[
			['If1.True', '(X=1.000000,Y=0.000000,Z=0.000000)'],
			['If1.False', '(X=0.000000,Y=1.000000,Z=0.000000)']
		],
		"links":[
			['Entry.ExecuteContext', 'SetVariableTransform.ExecuteContext'],
			['Entry.OriginTransform', 'GetTransformArray.Items'],
			['Entry.Offsets', 'Num.Array'],
			['Entry.Offsets', 'ForEach.Array'],
			['Entry.Value', 'Floor.Value'],
			['Entry.Value', 'Subtract1.A'],
			['Entry.Reverse', 'If1.Condition'],
			['GetTransformArray.Transforms', 'SetVariableTransform.Value'],
			['SetVariableTransform.ExecuteContext', 'ForEach.ExecuteContext'],
			['GetVariableTransform.Value', 'At.Array'],
			['If.Result', 'At.Index'],

			["Num.Num","Modulo.B"],
			["Floor.Int","Modulo.A"],
			["ForEach.Element","SetTransform.Item"],
			["Modulo.Result","Add.A"],
			["ForEach.Index","Add.B"],
			["Num.Num","GreaterEqual.B"],
			["GreaterEqual.Result","If.Condition"],

			["Add.Result","Subtract.A"],
			["Num.Num","Subtract.B"],
			["Subtract.Result","If.True"],
			["Add.Result","If.False"],
			["Add.Result","GreaterEqual.A"],
			["ForEach.Element","GetTransform.Item"],
			["Floor.Result","Subtract1.B"],
			['GetTransform.Transform.Rotation', 'ToEuler.Value'],
			['At.Element.Rotation', 'ToEuler1.Value'],
			['FromEuler.Result', 'SetTransform.Value.Rotation'],
			
			
			
			['Subtract1.Result', 'EvaluateCurveRX.Value'],
			['ToEuler.Result.X', 'EvaluateCurveRX.TargetMinimum'],
			['ToEuler1.Result.X', 'EvaluateCurveRX.TargetMaximum'],
			['EvaluateCurveRX.Result', 'FromEuler.Euler.X'],

			['Subtract1.Result', 'EvaluateCurveRY.Value'],			
			['ToEuler.Result.Y', 'EvaluateCurveRY.TargetMinimum'],
			['ToEuler1.Result.Y', 'EvaluateCurveRY.TargetMaximum'],
			['EvaluateCurveRY.Result', 'FromEuler.Euler.Y'],

			['Subtract1.Result', 'EvaluateCurveRZ.Value'],
			['ToEuler.Result.Z', 'EvaluateCurveRZ.TargetMinimum'],
			['ToEuler1.Result.Z', 'EvaluateCurveRZ.TargetMaximum'],
			['EvaluateCurveRZ.Result', 'FromEuler.Euler.Z'],

			['Subtract1.Result', 'EvaluateCurveTX.Value'],
			['GetTransform.Transform.Translation.X', 'EvaluateCurveTX.TargetMinimum'],
			['At.Element.Translation.X', 'EvaluateCurveTX.TargetMaximum'],
			['EvaluateCurveTX.Result', 'SetTransform.Value.Translation.X'],
			['Subtract1.Result', 'EvaluateCurveTY.Value'],
			['GetTransform.Transform.Translation.Y', 'EvaluateCurveTY.TargetMinimum'],
			['At.Element.Translation.Y', 'EvaluateCurveTY.TargetMaximum'],
			['EvaluateCurveTY.Result', 'SetTransform.Value.Translation.Y'],
			['Subtract1.Result', 'EvaluateCurveTZ.Value'],
			['GetTransform.Transform.Translation.Z', 'EvaluateCurveTZ.TargetMinimum'],
			['At.Element.Translation.Z', 'EvaluateCurveTZ.TargetMaximum'],
			['EvaluateCurveTZ.Result', 'SetTransform.Value.Translation.Z'],
			
			['ForEach.ExecuteContext', 'SetTransform.ExecuteContext'],	

			['If1.Result.X', 'EvaluateCurveRX.SourceMinimum'],
			['If1.Result.Y', 'EvaluateCurveRX.SourceMaximum'],

			['If1.Result.X', 'EvaluateCurveRY.SourceMinimum'],
			['If1.Result.Y', 'EvaluateCurveRY.SourceMaximum'],

			['If1.Result.X', 'EvaluateCurveRZ.SourceMinimum'],
			['If1.Result.Y', 'EvaluateCurveRZ.SourceMaximum'],

			['If1.Result.X', 'EvaluateCurveTX.SourceMinimum'],
			['If1.Result.Y', 'EvaluateCurveTX.SourceMaximum'],

			['If1.Result.X', 'EvaluateCurveTY.SourceMinimum'],
			['If1.Result.Y', 'EvaluateCurveTY.SourceMaximum'],

			['If1.Result.X', 'EvaluateCurveTZ.SourceMinimum'],
			['If1.Result.Y', 'EvaluateCurveTZ.SourceMaximum'],
			
			['ForEach.Completed', 'Return.ExecuteContext'],
		]
	})

def Create(inputData):
	global session
	session = inputData["session"]
	item =  inputData["item"]
	extra =  inputData["extra"]

	controlRig = session["controlRig"]
	rootNode = session["rootNode"]
	hierarchy = session["hierarchy"]
	controller = session["controller"]
	positionCurrent = extra["positionCurrent"]
	positionCurrent = [positionCurrent[0]+500,0]
	executeInNode =  extra["executeInNode"]

	#CREATE CONTROL
	data = item["value"]
	nameSetting = NLTA_ControlRigSupport.NameSetting(item)
	functionPattern = nameSetting["name"]
	names = nameSetting["names"]
	offsetsPattern = names["offsetsPattern"]	
	originsPattern = names["originsPattern"]	

	if data["cbx_BeforeParent"]!=None:
		FKParentTemp = unreal.RigElementKey(type=unreal.RigElementType.CONTROL, name=data["cbx_BeforeParent"])
	else:
		FKParentTemp = None

	originsStringArray = []
	offsetsStringArray = []
	controlsArray = data["txt_Controls"].split(";")
	for order in range(len(controlsArray)):
		controlName = controlsArray[order]
		control = unreal.RigElementKey(type=unreal.RigElementType.CONTROL, name=controlName)		
		controlTransform = hierarchy.get_global_transform(control)
		controlParent = hierarchy.get_parents(control)[0]

		#OFFSET
		offsetName = offsetsPattern.format(controlName)
		offsetsStringArray.append('(Type=Control,Name="'+offsetName+'")')
		offsetSetting = {
			"controlRig":session["controlRig"],
			"type":"proxy",
			"visible":False,
			"name":offsetName,
			"shape":"Box_Thick",
			"transform":controlTransform,
		}
		if controlParent!=None:
			offsetSetting["parent"] = controlParent
		offset = NLTA_ControlRigGeneral.AddControl(offsetSetting)
		NLTA_ControlRigGeneral.SetParent({
			"controlRig":session["controlRig"],
			"child":control,
			"parent":offset
		})

		#ORIGIN
		originName = originsPattern.format(controlName)
		originsStringArray.append('(Type=Control,Name="'+originName+'")')
		originSetting = {
			"controlRig":session["controlRig"],
			"type":"proxy",
			"visible":False,
			"name":originName,
			"shape":"Box_Thick",
			"transform":controlTransform,
		}
		if controlParent!=None:
			originSetting["parent"] = controlParent
		NLTA_ControlRigGeneral.AddControl(originSetting)

	
	NLTA_ControlRigGeneral.AddControl({
		"controlRig":session["controlRig"],
		"type":"channelBool",
		"name":names["booleanControl"],
		"parent":FKParentTemp,
		"groupWithParent":True
	})
	NLTA_ControlRigGeneral.AddControl({
		"controlRig":session["controlRig"],
		"type":"channelFloat",
		"name":names["floatControl"],
		"parent":FKParentTemp,
		"groupWithParent":True,	
		"limit":[unreal.RigControlLimitEnabled(False,False)],
		#"min":unreal.RigHierarchy.make_control_value_from_float(-10),
		#"max":unreal.RigHierarchy.make_control_value_from_float( 10),				
	})


	originsString = "("+",".join(originsStringArray)+")"
	offsetsString = "("+",".join(offsetsStringArray)+")"
	library = controlRig.get_local_function_library()
	functionPattern = library.find_function(functionPattern)
	rootNode.add_function_reference_node(functionPattern,unreal.Vector2D(positionCurrent[0],positionCurrent[1]),nameSetting["function"])
	session["rootNode"].add_link(executeInNode,nameSetting["function"]+".ExecuteContext")
	rootNode.set_pin_default_value(nameSetting["function"]+".OriginTransform",originsString)
	rootNode.set_pin_default_value(nameSetting["function"]+".Offsets",offsetsString)


	
	NLTA_ControlRigGeneral.AddNode({
		"module":session["rootNode"],
		"type":"GetBoolChannel",
		"name":names["booleanNode"],
		"position":[positionCurrent[0]-300,220]
	})
	rootNode.set_pin_default_value(names["booleanNode"]+".Control",data["cbx_BeforeParent"])
	rootNode.set_pin_default_value(names["booleanNode"]+".Channel",names["booleanControl"])
	rootNode.add_link(names["booleanNode"]+'.Value',nameSetting["function"]+'.Reverse')
	
	NLTA_ControlRigGeneral.AddNode({
		"module":session["rootNode"],
		"type":"GetFloatChannel",
		"name":names["floatNode"],
		"position":[positionCurrent[0]-300,70],

	})	
	rootNode.set_pin_default_value(names["floatNode"]+".Control",data["cbx_BeforeParent"])
	rootNode.set_pin_default_value(names["floatNode"]+".Channel",names["floatControl"])
	rootNode.add_link(names["floatNode"]+'.Value',nameSetting["function"]+'.Value')
	
	returnDict = {
		"executeInNode":nameSetting["function"]+".ExecuteContext",
		"positionCurrent":positionCurrent

	}

	return(returnDict)
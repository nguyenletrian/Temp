from importlib import *
import unreal, NLTA_general, NLTA_ControlRigGeneral, NLTA_ControlRigSupport
reload(NLTA_general)
reload(NLTA_ControlRigGeneral)
reload(NLTA_ControlRigSupport)

session = {}
def Pattern():
	return({
		"pins":[
			["input","Parent1","RigElementKey"],
			["input","Parent2","RigElementKey"],
			["input","Child","RigElementKey"],
			["input","Maintain","Boolean"],			
			["input","Translate","ArrayBool"],	
			["input","Rotate","ArrayBool"],		
			["input",'Scale',"ArrayBool"],
			["input",'Min',"Double"],
			["input",'Max',"Double"],
			["input",'Value',"Double"],		
		],
		"nodes":[
			["ParentConstraint","ParentConstraint"],
			["Remap","RemapParent1"],
			["Remap","RemapParent2"],
			["At","AtTranslateX"],
			["At","AtTranslateY"],
			["At","AtTranslateZ"],
			["At","AtRotateX"],
			["At","AtRotateY"],
			["At","AtRotateZ"],
			["At","AtScaleX"],
			["At","AtScaleY"],
			["At","AtScaleZ"],
		],
		"positions":[
			["return",480,-288],
			["Entry",-688,-288],
			["ParentConstraint",224,-288],
			["RemapParent1",-208,240],
			["RemapParent2",-208,480],
			["AtTranslateX", -400, -160],
			["AtTranslateY", -224, -160],
			["AtTranslateZ", -48, -160],
			["AtRotateX", -399, -32],
			["AtRotateY",-223, -32],
			["AtRotateZ",-48, -32],
			["AtScaleX",-400, 96],
			["AtScaleY",-224, 96],
			["AtScaleZ",-49, 96],
		],
		"values":[
			['ParentConstraint.Parents','((Item=(Type=Control,Name="None"),Weight=1.000000),(Item=(Type=Control,Name="None"),Weight=1.000000))'],
			["AtTranslateX.Index",'0'],
			["AtTranslateY.Index",'1'],
			["AtTranslateZ.Index",'2'],
			["AtRotateX.Index",'0'],
			["AtRotateY.Index",'1'],
			["AtRotateZ.Index",'2'],
			["AtScaleX.Index",'0'],
			["AtScaleY.Index",'1'],
			["AtScaleZ.Index",'2'],
		],
		"links":[
			['Entry.ExecuteContext', 'ParentConstraint.ExecuteContext'],
			['Entry.Child', 'ParentConstraint.Child'],
			['Entry.Maintain', 'ParentConstraint.bMaintainOffset'],
			['Entry.Translate', 'AtTranslateX.Array'],
			['Entry.Translate', 'AtTranslateY.Array'],
			['Entry.Translate', 'AtTranslateZ.Array'],
			['Entry.Rotate', 'AtRotateX.Array'],
			['Entry.Rotate', 'AtRotateY.Array'],
			['Entry.Rotate', 'AtRotateZ.Array'],
			['Entry.Scale', 'AtScaleX.Array'],
			['Entry.Scale', 'AtScaleY.Array'],
			['Entry.Scale', 'AtScaleZ.Array'],
			['Entry.Min', 'RemapParent1.SourceMaximum'],			
			['Entry.Max', 'RemapParent1.SourceMinimum'],
			['Entry.Min', 'RemapParent2.SourceMinimum'],
			['Entry.Max', 'RemapParent2.SourceMaximum'],
			['Entry.Value', 'RemapParent1.Value'],
			['Entry.Value', 'RemapParent2.Value'],
			['Entry.Parent1', 'ParentConstraint.Parents.0.Item'],
			['Entry.Parent2', 'ParentConstraint.Parents.1.Item'],
			['RemapParent1.Result', 'ParentConstraint.Parents.0.Weight'],
			['RemapParent2.Result', 'ParentConstraint.Parents.1.Weight'],
			['AtRotateX.Element', 'ParentConstraint.Filter.RotationFilter.bX'],
			['AtRotateY.Element', 'ParentConstraint.Filter.RotationFilter.bY'],
			['AtRotateZ.Element', 'ParentConstraint.Filter.RotationFilter.bZ'],
			['AtTranslateX.Element', 'ParentConstraint.Filter.TranslationFilter.bX'],
			['AtTranslateY.Element', 'ParentConstraint.Filter.TranslationFilter.bY'],
			['AtTranslateZ.Element', 'ParentConstraint.Filter.TranslationFilter.bZ'],
			['AtScaleX.Element', 'ParentConstraint.Filter.ScaleFilter.bX'],
			['AtScaleY.Element', 'ParentConstraint.Filter.ScaleFilter.bY'],
			['AtScaleZ.Element', 'ParentConstraint.Filter.ScaleFilter.bZ'],
			['ParentConstraint.ExecuteContext', 'Return.ExecuteContext'],
		]
	})

def Create(inputData):
	global session
	session = inputData["session"]
	item =  inputData["item"]
	extra =  inputData["extra"]	

	controlRig = session["controlRig"]
	rootNode = session["rootNode"]
	hierarchy = session["hierarchy"]
	controller = session["controller"]
	positionCurrent = extra["positionCurrent"]
	positionCurrent = [positionCurrent[0]+500,0]
	executeInNode =  extra["executeInNode"]

	data = item["value"]
	nameSetting = NLTA_ControlRigSupport.NameSetting(item)
	names = nameSetting["names"]
	functionPattern = nameSetting["name"]

	beforeParent = unreal.RigElementKey(type=unreal.RigElementType.CONTROL, name=data["cbx_BeforeParent"])
	parent1 = unreal.RigElementKey(type=unreal.RigElementType.CONTROL, name=data["cbx_Parent1"])
	parent2 = unreal.RigElementKey(type=unreal.RigElementType.CONTROL, name=data["cbx_Parent2"])
	child = unreal.RigElementKey(type=unreal.RigElementType.CONTROL, name=data["cbx_Child"])
	maintain = data["chx_Maintain"]
	translateX = data["chx_TranslateX"]
	translateY = data["chx_TranslateY"]
	translateZ = data["chx_TranslateZ"]
	rotateX = data["chx_RotateX"]
	rotateY = data["chx_RotateY"]
	rotateZ = data["chx_RotateZ"]
	scaleX = data["chx_ScaleX"]
	scaleY = data["chx_ScaleY"]
	scaleZ = data["chx_ScaleZ"]
	min_ = data["spn_Min"]
	max_ = data["spn_Max"]


	childTransform = hierarchy.get_global_transform(child)
	
	dataTemp = {
		"controlRig":session["controlRig"],
		"type":"proxy",
		"name":names["offset"],
		"transform":childTransform,
		"visible":False,
	}
	childParent = hierarchy.get_parents(child)
	if len(childParent)!=0:
		dataTemp["parent"]= childParent[0]
	offset = NLTA_ControlRigGeneral.AddControl(dataTemp)
	NLTA_ControlRigGeneral.SetParent({"controlRig":session["controlRig"],"parent":offset,"child":child})

	switch = NLTA_ControlRigGeneral.AddControl({
		"controlRig":session["controlRig"],
		"type":"channelFloat",
		"name":names["switchControl"],
		"parent":beforeParent,
		"groupWithParent":True,
		"limit":[unreal.RigControlLimitEnabled(True, True)],
		"min":unreal.RigHierarchy.make_control_value_from_float(min_),
		"max":unreal.RigHierarchy.make_control_value_from_float(max_)
	})

	
	#ADD FUNCTION
	library = controlRig.get_local_function_library()
	functionPattern = library.find_function(functionPattern)
	rootNode.add_function_reference_node(functionPattern,unreal.Vector2D(positionCurrent[0],positionCurrent[1]),nameSetting["function"])

	session["rootNode"].add_link(executeInNode,nameSetting["function"]+".ExecuteContext")
	rootNode.set_pin_default_value(nameSetting["function"]+'.Maintain',str(data["chx_Maintain"]))	
	rootNode.set_pin_default_value(nameSetting["function"]+'.Translate',"("+(",").join([str(translateX),str(translateY),str(translateZ)])+")")
	rootNode.set_pin_default_value(nameSetting["function"]+'.Rotate',"("+(",").join([str(rotateX),str(rotateY),str(rotateZ)])+")")
	rootNode.set_pin_default_value(nameSetting["function"]+'.Scale',"("+(",").join([str(scaleX),str(scaleY),str(scaleZ)])+")")
	rootNode.set_pin_default_value(nameSetting["function"]+'.Min',str(min_))
	rootNode.set_pin_default_value(nameSetting["function"]+'.Max',str(max_))
	rootNode.set_pin_default_value(nameSetting["function"]+'.Child', '(Type=Control,Name="'+names["offset"]+'")')
	rootNode.set_pin_default_value(nameSetting["function"]+'.Parent1', '(Type=Control,Name="'+data["cbx_Parent1"]+'")')
	rootNode.set_pin_default_value(nameSetting["function"]+'.Parent2', '(Type=Control,Name="'+data["cbx_Parent2"]+'")')

	NLTA_ControlRigGeneral.AddNode({
		"module":session["rootNode"],
		"type":"GetFloatChannel",
		"name":names["switchNode"],
		"position":[positionCurrent[0]-310,190]
	})
	rootNode.set_pin_default_value(names["switchNode"]+".Control",data["cbx_BeforeParent"])
	rootNode.set_pin_default_value(names["switchNode"]+".Channel",names["switchControl"])
	rootNode.add_link(names["switchNode"]+'.Value',nameSetting["function"]+'.Value')

	return({
		"executeInNode":nameSetting["function"]+".ExecuteContext",
		"positionCurrent":positionCurrent
	})
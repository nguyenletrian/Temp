from importlib import *
import unreal, NLTA_general, NLTA_ControlRigGeneral, NLTA_ControlRigSupport
reload(NLTA_general)
reload(NLTA_ControlRigGeneral)
reload(NLTA_ControlRigSupport)

session = {}
def Pattern():
	return({
		"pins":[
			["input","AttachElement","ArrayRigElementKey"],
			["input","ReferenceControls","ArrayRigElementKey"],			
			["input","CloseCurve","Boolean"],
			["input","CustomDistance","Boolean"],
			["input","PrimaryAxis","Vector"],
			["input","SecondaryAxis","Vector"],
			["input","U","Double"],
			["input","DistanceBetween","Double"],
		],
		"nodes":[#type,#name
			["SplineFromTransforms","SplineFromTransforms"],
			["GetTransformArray","GetTransformArray"],
			["DrawSpline","DrawSpline"],
			["Multiply","Multiply"],
			["FloorInt","Floor"],
			["FloorInt","Floor1"],
			["Subtract","Subtract"],
			["Subtract","Subtract1"],
			["TransformFromSpline","TransformFromSpline"],
			["TransformFromSpline","TransformFromSpline1"],
			["SetTransform","SetTransform"],
			["SetTransform","SetTransform1"],
			["Branch","Branch"],
			["ForEach","ForEach"],
			["ForEach","ForEach1"],
			["ClosestSpline","ClosestSpline"],
			["ClosestSpline","ClosestSpline1"],
			["GetTransform","GetTransform"],
			["GetTransform","GetTransform1"],
			["Add","Add"],
			["Add","Add1"],
			["Add","Add2"],
			["At","At"],
			["At","At1"],
			["IntToDouble","IntToDouble"],
			["Not","Not"],
		],
		"positions":[
			["Entry",-432,-112],
			["Return",1216,176],
			["SplineFromTransforms",288,-400],
			["GetTransformArray",-16,-400],
			["DrawSpline",656,-122],
			["Floor",2256,192],
			["Subtract",2416,128],
			["TransformFromSpline",2624,-112],
			["SetTransform",2848,-224],
			["Branch",992,64],
			["ForEach",1280,-224],
			["ClosestSpline",1776,-16],
			["GetTransform",1472,-176],
			["Add",2096,80],
			["Add1",1936,688],
			["Add2",2128,800],
			["At",1504,-320],
			["At1",960,672],
			["GetTransform1",1152,736],
			["ClosestSpline1",1456,768],
			["ForEach1",1440,480],
			["SetTransform1",2960,480],
			["TransformFromSpline1",2656,672],
			
			["Subtract1",2464,848],
			["Floor1",2304,928],
			["Multiply",1760,624],
			["IntToDouble",1632,640],
			["Not",400,96],
		],
		"wildCard":[
			['Floor.Value',"double",'None'],
			['Floor1.Value',"double",'None'],
			['Subtract.A', 'double', 'None'],
			['Subtract1.A', 'double', 'None'],
		],
		"links":[
			['Entry.AttachElement', 'ForEach1.Array'],
			['Entry.AttachElement', 'At.Array'],
			['Entry.ReferenceControls', 'GetTransformArray.Items'],
			['Entry.ReferenceControls', 'ForEach.Array'],
			['Entry.CloseCurve', 'SplineFromTransforms.bClosed'],
			['Entry.PrimaryAxis', 'TransformFromSpline.PrimaryAxis'],
			['Entry.SecondaryAxis', 'TransformFromSpline.SecondaryAxis'],
			['Entry.U', 'Add.A'],
			['Entry.ExecuteContext', 'DrawSpline.ExecuteContext'],
			['Entry.ReferenceControls', 'At1.Array'],
			['Entry.U', 'Add2.B'],
			['Entry.DistanceBetween', 'Multiply.A'],
			['Entry.CustomDistance', 'Not.Value'],
			['Entry.PrimaryAxis', 'TransformFromSpline1.PrimaryAxis'],
			['Entry.SecondaryAxis', 'TransformFromSpline1.SecondaryAxis'],			
			['GetTransformArray.Transforms', 'SplineFromTransforms.Transforms'],
			['SplineFromTransforms.Spline', 'DrawSpline.Spline'],
			['Floor.Result', 'Subtract.B'],
			['SplineFromTransforms.Spline', 'TransformFromSpline.Spline'],
			['TransformFromSpline.Transform', 'SetTransform.Value'],
			['GetTransform.Transform.Translation', 'ClosestSpline.Position'],
			['SplineFromTransforms.Spline', 'ClosestSpline.Spline'],
			['ClosestSpline.U', 'Add.B'],
			['Branch.True', 'ForEach.ExecuteContext'],
			['ForEach.Index', 'At.Index'],
			['At.Element', 'SetTransform.Item'],
			['Add.Result', 'Subtract.A'],
			['Add.Result', 'Floor.Value'],
			['ForEach.Element', 'GetTransform.Item'],
			['Branch.Completed', 'Return.ExecuteContext'],
			['DrawSpline.ExecuteContext', 'Branch.ExecuteContext'],
			['At1.Element', 'GetTransform1.Item'],
			['GetTransform1.Transform.Translation', 'ClosestSpline1.Position'],
			['SplineFromTransforms.Spline', 'ClosestSpline1.Spline'],
			['Branch.False', 'ForEach1.ExecuteContext'],
			['ForEach1.ExecuteContext', 'SetTransform1.ExecuteContext'],
			['SplineFromTransforms.Spline', 'TransformFromSpline1.Spline'],
			['ClosestSpline1.U', 'Add1.B'],
			['Add1.Result', 'Add2.A'],
			['Add2.Result', 'Subtract1.A'],
			['Add2.Result', 'Floor1.Value'],
			['Floor1.Result', 'Subtract1.B'],
			['Subtract1.Result', 'TransformFromSpline1.U'],
			['ForEach1.Element', 'SetTransform1.Item'],
			['TransformFromSpline1.Transform', 'SetTransform1.Value'],
			['ForEach1.Index', 'IntToDouble.Value'],
			['IntToDouble.Result', 'Multiply.B'],
			['Multiply.Result', 'Add1.A'],
			['Not.Result', 'Branch.Condition'],
			['ForEach.ExecuteContext', 'SetTransform.ExecuteContext'],
			['Subtract.Result', 'TransformFromSpline.U'],

		]
	})

def Create(inputData):
	global session
	session = inputData["session"]
	item =  inputData["item"]
	extra =  inputData["extra"]

	controlRig = session["controlRig"]
	rootNode = session["rootNode"]
	hierarchy = session["hierarchy"]
	controller = session["controller"]
	positionCurrent = extra["positionCurrent"]
	positionCurrent = [positionCurrent[0]+500,0]
	executeInNode =  extra["executeInNode"]
	
	#CREATE CONTROL
	data = item["value"]
	nameSetting = NLTA_ControlRigSupport.NameSetting(item)
	functionPattern = nameSetting["name"]
	names = nameSetting["names"]
	offsetsPattern = names["offsetsPattern"]	

	if data["cbx_BeforeParent"]!=None:
		FKParentTemp = unreal.RigElementKey(type=unreal.RigElementType.CONTROL, name=data["cbx_BeforeParent"])
	else:
		FKParentTemp = None

	#OFFSET
	offsetsStringArray = []
	controlsArray = data["txt_Controls"].split(";")
	for order in range(len(controlsArray)):
		controlName = controlsArray[order]
		control = unreal.RigElementKey(type=unreal.RigElementType.CONTROL, name=controlName)		
		controlTransform = hierarchy.get_global_transform(control)
		controlParent = hierarchy.get_parents(control)[0]

		offsetName = offsetsPattern.format(controlName)
		offsetsStringArray.append('(Type=Control,Name="'+offsetName+'")')
		offsetSetting = {
			"controlRig":session["controlRig"],
			"type":"proxy",
			"visible":False,
			"name":offsetName,
			"shape":"Box_Thick",
			"transform":controlTransform,
		}
		if controlParent!=None:
			offsetSetting["parent"] = controlParent
		offset = NLTA_ControlRigGeneral.AddControl(offsetSetting)
		NLTA_ControlRigGeneral.SetParent({
			"controlRig":session["controlRig"],
			"child":control,
			"parent":offset
		})

	#ATTACH
	referencesArray = []
	references = data["txt_Points"].split(";")
	for reference in references:
		referencesArray.append('(Type=Control,Name="'+reference+'")')

	NLTA_ControlRigGeneral.AddControl({
		"controlRig":session["controlRig"],
		"type":"channelFloat",
		"name":names["UControl"],
		"parent":FKParentTemp,
		"groupWithParent":True,	
		"limit":[unreal.RigControlLimitEnabled(False,False)],
		"min":unreal.RigHierarchy.make_control_value_from_float(-10),
		"max":unreal.RigHierarchy.make_control_value_from_float( 10),				
	})
	NLTA_ControlRigGeneral.AddControl({
		"controlRig":session["controlRig"],
		"type":"channelFloat",
		"name":names["distanceControl"],
		"parent":FKParentTemp,
		"groupWithParent":True,	
		"limit":[unreal.RigControlLimitEnabled(False,False)],
		"min":unreal.RigHierarchy.make_control_value_from_float(-10),
		"max":unreal.RigHierarchy.make_control_value_from_float( 10),				
	})


	offsetsString = "("+",".join(offsetsStringArray)+")"
	referencesString = "("+",".join(referencesArray)+")"
	library = controlRig.get_local_function_library()
	functionPattern = library.find_function(functionPattern)
	rootNode.add_function_reference_node(functionPattern,unreal.Vector2D(positionCurrent[0],positionCurrent[1]),nameSetting["function"])
	session["rootNode"].add_link(executeInNode,nameSetting["function"]+".ExecuteContext")
	rootNode.set_pin_default_value(nameSetting["function"]+".AttachElement",offsetsString)
	rootNode.set_pin_default_value(nameSetting["function"]+".ReferenceControls",referencesString)
	rootNode.set_pin_default_value(nameSetting["function"]+".CustomDistance","True")
	rootNode.set_pin_default_value(nameSetting["function"]+".PrimaryAxis.X",str(data["spindb_PrimaryX"]))
	rootNode.set_pin_default_value(nameSetting["function"]+".PrimaryAxis.Y",str(data["spindb_PrimaryY"]))
	rootNode.set_pin_default_value(nameSetting["function"]+".PrimaryAxis.Z",str(data["spindb_PrimaryZ"]))
	rootNode.set_pin_default_value(nameSetting["function"]+".SecondaryAxis.X",str(data["spindb_SecondaryX"]))
	rootNode.set_pin_default_value(nameSetting["function"]+".SecondaryAxis.Y",str(data["spindb_SecondaryY"]))
	rootNode.set_pin_default_value(nameSetting["function"]+".SecondaryAxis.Z",str(data["spindb_SecondaryZ"]))
	
	NLTA_ControlRigGeneral.AddNode({
		"module":session["rootNode"],
		"type":"GetFloatChannel",
		"name":names["UNode"],
		"position":[positionCurrent[0]-300,70],
	})	
	rootNode.set_pin_default_value(names["UNode"]+".Control",data["cbx_BeforeParent"])
	rootNode.set_pin_default_value(names["UNode"]+".Channel",names["UControl"])
	rootNode.add_link(names["UNode"]+'.Value',nameSetting["function"]+'.U')

	NLTA_ControlRigGeneral.AddNode({
		"module":session["rootNode"],
		"type":"GetFloatChannel",
		"name":names["distanceNode"],
		"position":[positionCurrent[0]-300,250],
	})	
	rootNode.set_pin_default_value(names["distanceNode"]+".Control",data["cbx_BeforeParent"])
	rootNode.set_pin_default_value(names["distanceNode"]+".Channel",names["distanceControl"])
	rootNode.add_link(names["distanceNode"]+'.Value',nameSetting["function"]+'.DistanceBetween')
	
	returnDict = {
		"executeInNode":nameSetting["function"]+".ExecuteContext",
		"positionCurrent":positionCurrent

	}
	
	return(returnDict)
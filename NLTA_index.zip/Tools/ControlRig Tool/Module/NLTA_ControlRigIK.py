from importlib import *
import unreal, NLTA_general, NLTA_ControlRigGeneral, NLTA_ControlRigSupport
reload(NLTA_general)
reload(NLTA_ControlRigGeneral)
reload(NLTA_ControlRigSupport)

session = {}
def Pattern():
	return({
		"pins":[
			["input","Bone1","RigElementKey"],
			["input","Bone2","RigElementKey"],
			["input","Bone3","RigElementKey"],
			["input","FK1","RigElementKey"],
			["input","FK2","RigElementKey"],
			["input","FK3","RigElementKey"],			
			["input",'IK',"RigElementKey"],
			["input",'PointVector',"RigElementKey"],
			["input","SwitchControl","RigElementKey"],
			["input",'Primary',"Vector"],
			["input",'Second',"Vector"],			
			["input",'Switch',"Boolean"],
		],
		"nodes":[
			["FKChain","FKChain"],
			["IKTwoBone","IKTwoBone"],
			["Branch","Branch"],
			["Sequence","Sequence"],
			["ParentConstraint","IKConstraint"],
			["ParentConstraint","PoleVectorConstraint"],
			["ParentConstraint","FK1Constraint"],
			["ParentConstraint","FK2Constraint"],
			["ParentConstraint","FK3Constraint"],
			["ParentConstraint","SwitchControlConstraint"],
			["HideControls","FK_FK"],
			["HideControls","FK_IK"],
			["HideControls","IK_FK"],
			["HideControls","IK_IK"],
		],
		"positions":[
			["return",-1936,-16],
			["Entry",-2832,16],
			["Sequence",-2528,16],
			["FKChain",-2320,-832],
			["IKTwoBone",-2352, 336],
			["Branch",-2160, -80],
			["IKConstraint",-1808,-816],
			["PoleVectorConstraint",-1488,-816],
			["FK1Constraint",-1888,336],
			["FK2Constraint",-1568,336],
			["FK3Constraint",-1232,336],
			['SwitchControlConstraint',-2352,784],
			["FK_IK",-1168,-832],
			["FK_FK",-576,-832],
			["IK_IK",-912,336],
			["IK_FK",-416,336]
		],
		"values":[
			["FKChain.Bones",'((Type=None,Name="None"),(Type=None,Name="None"),(Type=None,Name="None"))'],
			['FKChain.Controls', '((Type=None,Name="None"),(Type=None,Name="None"),(Type=None,Name="None"))'],
			["FK_IK.controls",'((Type=None,Name="None"),(Type=None,Name="None"))'],
			["FK_FK.controls",'((Type=None,Name="None"),(Type=None,Name="None"),(Type=None,Name="None"))'],
			["IK_IK.controls",'((Type=None,Name="None"),(Type=None,Name="None"))'],
			["IK_FK.controls",'((Type=None,Name="None"),(Type=None,Name="None"),(Type=None,Name="None"))'],
			["FK_IK.Active",'false'],
			["FK_FK.Active",'true'],
			["IK_IK.Active",'true'],
			["IK_FK.Active",'false'],
			["SwitchControlConstraint.bMaintainOffset","false"]
		],
		"links":[
			['Entry.Bone1', 'FKChain.Bones.0'],
			['Entry.Bone1', 'IKTwoBone.Bone A'],
			['Entry.Bone1', 'FK1Constraint.Parents.0.Item'],
			['Entry.Bone2', 'FKChain.Bones.1'],
			['Entry.Bone2', 'IKTwoBone.Bone B'],
			['Entry.Bone2', 'FK2Constraint.Parents.0.Item'],
			['Entry.Bone2', 'PoleVectorConstraint.Parents.0.Item'],
			['Entry.Bone3', 'FKChain.Bones.2'],
			['Entry.Bone3', 'IKTwoBone.Bone C'],
			['Entry.Bone3', 'FK3Constraint.Parents.0.Item'],
			['Entry.Bone3', 'IKConstraint.Parents.0.Item'],
			['Entry.Bone3', 'SwitchControlConstraint.Parents.0.Item'],
			['Entry.FK1', 'FKChain.Controls.0'],
			['Entry.FK1', 'FK1Constraint.Child'],
			['Entry.FK1', 'IK_FK.controls.0'],
			['Entry.FK1', 'FK_FK.controls.0'],
			['Entry.FK2', 'FKChain.Controls.1'],
			['Entry.FK2', 'FK2Constraint.Child'],
			['Entry.FK2', 'IK_FK.controls.1'],
			['Entry.FK2', 'FK_FK.controls.1'],
			['Entry.FK3', 'FKChain.Controls.2'],
			['Entry.FK3', 'FK3Constraint.Child'],
			['Entry.FK3', 'IK_FK.controls.2'],
			['Entry.FK3', 'FK_FK.controls.2'],
			['Entry.IK', 'IKConstraint.Child'],
			['Entry.IK', 'IK_IK.controls.0'],
			['Entry.IK', 'FK_IK.controls.0'],
			['Entry.IK', 'IKTwoBone.End Ctrl'],
			['Entry.SwitchControl','SwitchControlConstraint.Child'],
			['Entry.PointVector', 'PoleVectorConstraint.Child'],
			['Entry.PointVector', 'IK_IK.controls.1'],
			['Entry.PointVector', 'FK_IK.controls.1'],
			['Entry.PointVector', 'IKTwoBone.Pole Vector Node'],
			['Entry.Primary', 'IKTwoBone.Primary Axis'],
			['Entry.Second', 'IKTwoBone.Secondary Axis'],
			['Entry.ExecuteContext','Sequence.ExecuteContext'],
			['Entry.Switch','Branch.Condition'],
			["Sequence.A",'Branch.ExecuteContext'],
			["Sequence.B",'SwitchControlConstraint.ExecuteContext'],				
			['Branch.True', 'FKChain.ExecuteContext'],
			['Branch.False','IKTwoBone.ExecuteContext'],
			["FKChain.ExecuteContext",'IKConstraint.ExecuteContext'],
			["IKConstraint.ExecuteContext",'PoleVectorConstraint.ExecuteContext'],
			['PoleVectorConstraint.ExecuteContext','FK_IK.ExecuteContext'],
			['FK_IK.ExecuteContext','FK_FK.ExecuteContext'],			
			['IKTwoBone.ExecuteContext',"FK1Constraint.ExecuteContext"],
			["FK1Constraint.ExecuteContext","FK2Constraint.ExecuteContext"],
			["FK2Constraint.ExecuteContext","FK3Constraint.ExecuteContext"],
			["FK3Constraint.ExecuteContext","IK_IK.ExecuteContext"],
			["IK_IK.ExecuteContext","IK_FK.ExecuteContext"],
			['Branch.Completed', 'Return.ExecuteContext'],
		]
	})

def Create(inputData):
	global session
	session = inputData["session"]
	item =  inputData["item"]
	extra =  inputData["extra"]	

	controlRig = session["controlRig"]
	rootNode = session["rootNode"]
	hierarchy = session["hierarchy"]
	controller = session["controller"]
	positionCurrent = extra["positionCurrent"]
	positionCurrent = [positionCurrent[0]+500,0]
	executeInNode =  extra["executeInNode"]

	IKData = item["value"]
	nameSetting = NLTA_ControlRigSupport.NameSetting(item)
	functionPattern = nameSetting["name"]
	names = nameSetting["names"]
	
	bone1 = IKData["txt_Bone1"]
	bone2 = IKData["txt_Bone2"]
	bone3 = IKData["txt_Bone3"]
	primaryX = int(IKData["cbx_PrimaryX"])
	primaryY = int(IKData["cbx_PrimaryY"])
	primaryZ = int(IKData["cbx_PrimaryZ"])
	secondX = int(IKData["cbx_SecondX"])
	secondY = int(IKData["cbx_SecondY"])
	secondZ = int(IKData["cbx_SecondZ"])
	PVDirection = IKData["chx_PVDirection"]


	bone1Transform = session["bones"][bone1]["transform"]
	bone2Transform = session["bones"][bone2]["transform"]
	bone3Transform = session["bones"][bone3]["transform"]
	distance1_3 = NLTA_general.GetDistance(bone1Transform.translation.to_tuple(),bone3Transform.translation.to_tuple())
	distance1_2 = NLTA_general.GetDistance(bone1Transform.translation.to_tuple(),bone2Transform.translation.to_tuple())
	distance2_3 = NLTA_general.GetDistance(bone2Transform.translation.to_tuple(),bone3Transform.translation.to_tuple())



	#POINT VECTOR
	inputAxis = [secondX,secondY,secondZ]
	arrayValue = [[distance1_3,0,0],[0,distance1_3,0],[0,0,distance1_3]]
	transformTemp = NLTA_general.BasicTransform()
	for order in range(len(inputAxis)):
		if inputAxis[order] != 0:
			addValue = arrayValue[order]
			if PVDirection==True:
				transformTemp.translation.x += addValue[0]
				transformTemp.translation.y += addValue[1]
				transformTemp.translation.z += addValue[2]
			else:
				transformTemp.translation.x -= addValue[0]
				transformTemp.translation.y -= addValue[1]
				transformTemp.translation.z -= addValue[2]
	PVControl = NLTA_ControlRigGeneral.AddControl({
		"controlRig":session["controlRig"],
		"type":"control",
		"name":names["pointVector"],
		"shape":"Diamond_Thick",
		"transform":bone2Transform
	})		
	
	controller.set_parent(PVControl,session["bones"][bone2]["key"],False)
	hierarchy.set_control_offset_transform(PVControl,transformTemp,True,True)
	globalTransfrom = hierarchy.get_global_transform(PVControl)
	controller.remove_element(PVControl)
	globalTransfrom.rotation.x = 0
	globalTransfrom.rotation.y = 0
	globalTransfrom.rotation.z = 0

	PVControl = NLTA_ControlRigGeneral.AddControl({
		"controlRig":session["controlRig"],
		"type":"control",
		"name":names["pointVector"],
		"shape":"Diamond_Thick",
		"transform":globalTransfrom,
		"parent":session["rootControl"]
	})
	#NLTA_ControlRigGeneral.SetParent({"controlRig":session["controlRig"],"child":PVControl,"parent":session["mainControl"]})

	#EEFECTOR
	IkControl = NLTA_ControlRigGeneral.AddControl({
		"controlRig":session["controlRig"],
		"type":"control",
		"name":names["effector"],
		"shape":"Box_Thick",
		"transform":bone3Transform,
		"parent":session["rootControl"]
	})
	#NLTA_ControlRigGeneral.SetParent({"controlRig":session["controlRig"],"child":IkControl,"parent":session["rootControl"]})

	#FK
	boneArray = [bone1,bone2,bone3]
	if IKData["cbx_BeforeParent"]!=None:
		FKParentTemp = unreal.RigElementKey(type=unreal.RigElementType.CONTROL, name=IKData["cbx_BeforeParent"])
	else:
		FKParentTemp = None
	for order in range(len(boneArray)):
		settingtemp = {
			"controlRig":session["controlRig"],
			"type":"control",
			"name":names["fk"+str(order)],
			"shape":"Circle_Thick",
			"transform":session["bones"][boneArray[order]]["transform"]
		}
		if FKParentTemp != None:
			settingtemp["parent"] = FKParentTemp
		FK = NLTA_ControlRigGeneral.AddControl(settingtemp)
		FKParentTemp = FK

	#SWITCH CONTROL
	switchControl = NLTA_ControlRigGeneral.AddControl({
		"controlRig":session["controlRig"],
		"type":"scale",
		"name":names["switchControl"],
		"parent":session["rootControl"],
		"transform":bone3Transform,
		"shape":"Sphere_Thick",
		"color":[1,0,1,1],
	})
	NLTA_ControlRigGeneral.AddControl({
		"controlRig":session["controlRig"],
		"type":"channelBool",
		"name":names["switchChannel"],
		"parent":switchControl,
		"groupWithParent":True
	})

	#ADD FUNCTION
	library = controlRig.get_local_function_library()
	functionPattern = library.find_function(functionPattern)
	rootNode.add_function_reference_node(functionPattern,unreal.Vector2D(positionCurrent[0],positionCurrent[1]),nameSetting["function"])

	session["rootNode"].add_link(executeInNode,nameSetting["function"]+".ExecuteContext")
	rootNode.set_pin_default_value(nameSetting["function"]+".Bone1", '(Type=Bone,Name="'+bone1+'")')
	rootNode.set_pin_default_value(nameSetting["function"]+".Bone2", '(Type=Bone,Name="'+bone2+'")')
	rootNode.set_pin_default_value(nameSetting["function"]+".Bone3", '(Type=Bone,Name="'+bone3+'")')
	rootNode.set_pin_default_value(nameSetting["function"]+".FK1", '(Type=Control,Name="'+names["fk0"]+'")')
	rootNode.set_pin_default_value(nameSetting["function"]+".FK2", '(Type=Control,Name="'+names["fk1"]+'")')
	rootNode.set_pin_default_value(nameSetting["function"]+".FK3", '(Type=Control,Name="'+names["fk2"]+'")')
	rootNode.set_pin_default_value(nameSetting["function"]+'.IK', '(Type=Control,Name="'+names["effector"]+'")')
	rootNode.set_pin_default_value(nameSetting["function"]+'.PointVector', '(Type=Control,Name="'+names["pointVector"]+'")')
	rootNode.set_pin_default_value(nameSetting["function"]+'.SwitchControl', '(Type=Control,Name="'+names["switchControl"]+'")')
	rootNode.set_pin_default_value(nameSetting["function"]+'.Primary', '(X='+str(primaryX)+',Y='+str(primaryY)+',Z='+str(primaryZ)+')')
	rootNode.set_pin_default_value(nameSetting["function"]+'.Second', '(X='+str(secondX)+',Y='+str(secondY)+',Z='+str(secondZ)+')')
	
	NLTA_ControlRigGeneral.AddNode({
		"module":session["rootNode"],
		"type":"GetBoolChannel",
		"name":names["switchNode"],
		"position":[positionCurrent[0]-320,200]
	})	

	rootNode.set_pin_default_value(names["switchNode"]+".Control",names["switchControl"])
	rootNode.set_pin_default_value(names["switchNode"]+".Channel",names["switchChannel"])
	rootNode.add_link(names["switchNode"]+'.Value',nameSetting["function"]+'.Switch')

	return({
		"executeInNode":nameSetting["function"]+".ExecuteContext",
		"positionCurrent":positionCurrent

	})
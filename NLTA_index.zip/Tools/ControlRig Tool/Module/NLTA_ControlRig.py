from importlib import *
import unreal, NLTA_general, NLTA_ControlRigGeneral, NLTA_ControlRigSupport
reload(NLTA_general)
reload(NLTA_ControlRigGeneral)
reload(NLTA_ControlRigSupport)

session = {}
extraNew = {}

def Init(inputData):	
	global session	
	session = inputData.copy()
	session["controlRig"] = unreal.load_asset(inputData["controlRig"])
	session["rootNode"] = session["controlRig"].get_controller_by_name('RigVMModel')
	session["hierarchy"] = session["controlRig"].hierarchy
	session["controller"] = session["hierarchy"].get_controller()
	session["library"] = session["controlRig"].get_local_function_library()	
	session["bones"] = {}
	bones = session["hierarchy"].get_bones()
	for bone in bones:
		session["bones"][str(bone.name)] = {					
			"index":session["hierarchy"].find_bone(bone).get_editor_property("index"),
			"key":bone,
			"transform":session["hierarchy"].get_global_transform(bone)
		}
	
def CreateAll(inputData):
	Init(inputData)
	global extraNew
	extraNew = {
		"executeInNode":"NLTA_Sequence.NLTA",
		"positionCurrent":[220,0]
	}
	NLTA_general.setSession("NLTA_ControlRig_CurrentModule",extraNew)

	NLTA_ControlRigGeneral.ClearAll(session["controlRig"])	
	NLTA_ControlRigGeneral.AddNode({
		"controlRig":session["controlRig"],
		"module":session["rootNode"],
		"type":"Sequence",
		"name":"NLTA_Sequence",
		"position":[200,0]
	})
	session["rootNode"].add_link('RigUnit_BeginExecution.ExecuteContext', 'NLTA_Sequence.ExecuteContext')
	session["rootNode"].add_aggregate_pin("NLTA_Sequence","NLTA")
	#CREATE ROOT CONTROL
	transform = NLTA_general.BasicTransform()
	session["rootControl"] = NLTA_ControlRigGeneral.AddControl({
		"controlRig":session["controlRig"],
		"type":"control",
		"name":"Root_Control_NLTA",
		"shape":"Octagon_Thin",
		"transform":transform
	})
	transform.scale3d = [10,10,10]
	session["hierarchy"].set_control_shape_transform(session["rootControl"],transform,True)	
	CreateModule(None)	

def CreateModule(parent):
	global extraNew
	for itemName in session["items"]:
		itemParent = session["items"][itemName]["parent"]		
		if itemParent == parent:
			item = session["items"][itemName]
			extraNew = NLTA_ControlRigSupport.Create({
				"item":item,
				"session":session,
				"extra":extraNew
			})
			CreateModule(itemName)
			NLTA_general.setSession("NLTA_ControlRig_CurrentModule",extraNew)


def CreateSingleModule(inputData):
	Init(inputData)
	session["rootControl"] = unreal.RigElementKey(type=unreal.RigElementType.CONTROL, name="Root_Control_NLTA")	
	extraNew = NLTA_ControlRigSupport.Create({
		"item":session["items"][next(iter(session["items"]))],
		"session":session,
		"extra":NLTA_general.getSession("NLTA_ControlRig_CurrentModule")
	})
	NLTA_general.setSession("NLTA_ControlRig_CurrentModule",extraNew)
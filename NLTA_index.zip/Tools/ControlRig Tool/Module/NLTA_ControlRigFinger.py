from importlib import *
import unreal, NLTA_general, NLTA_ControlRigGeneral, NLTA_ControlRigSupport
reload(NLTA_general)
reload(NLTA_ControlRigGeneral)
reload(NLTA_ControlRigSupport)

session = {}
def Pattern():
	return({
		"pins":[
			["input","Controls","ArrayRigElementKey"],
			["input","Bones","ArrayRigElementKey"],
			["input","Offsets","ArrayRigElementKey"],
			["input","Hold","Double"],
			["input","Reverse","Boolean"],
			["input","X","Boolean"],
			["input","Y","Boolean"],
			["input","Z","Boolean"],
			["input","Min","Double"],
			["input","Max","Double"],
		],
		"nodes":[			
			["FKChain","FKChain"],
			["SetRotation","SetRotation"],
			["ForEach","ForEach"],
			["If","IfReverse"],
			["If","IfX"],
			["If","IfY"],
			["If","IfZ"],
			["Multiply","Multiply"],
			["FromEuler","FromEuler"],
			["Remap","Remap"],
		],
		"positions":[
			["return",624,192],
			["Entry",-304,0],
			["FKChain",-80,-112],
			["FromEuler",688,448],
			["SetRotation",1088,48],
			["ForEach",416,48],
			["IfReverse",304,320],
			["IfX",512,272],
			["IfY",512,416],
			["IfZ",512,560],
			["Multiply",96,176],
			["FKChain",-64,-16],
			["Remap",-96,192],
		],
		"wildCard":[
			["Remap.Value","double",'None']
		],
		"values":[
			['Remap.Value', '0.0'],
			['Remap.SourceMinimum', '-10'],
			['Remap.SourceMaximum', '10'],
			['Multiply.B','-1.0000'],
			['SetRotation.Space','LocalSpace'],
			["FromEuler.RotationOrder",'XYZ'],
		],
		"links":[			
			['Entry.Controls', 'FKChain.Controls'],
			['Entry.Bones', 'FKChain.Bones'],
			['Entry.Offsets', 'ForEach.Array'],
			['ForEach.Element', 'SetRotation.Item'],				
			['Entry.Hold', 'Remap.Value'],
			['Entry.Reverse', 'IfReverse.Condition'],
			['Entry.X', 'IfX.Condition'],
			['Entry.Y', 'IfY.Condition'],
			['Entry.Z', 'IfZ.Condition'],
			['Entry.Min', 'Remap.TargetMinimum'],
			['Entry.Max', 'Remap.TargetMaximum'],
			['Remap.Result','Multiply.A'],
			['Remap.Result','IfReverse.False'],
			['Multiply.Result', 'IfReverse.True'],
			['IfReverse.Result','IfX.True'],
			['IfReverse.Result','IfY.True'],
			['IfReverse.Result','IfZ.True'],
			['IfX.Result','FromEuler.Euler.X'],
			['IfY.Result','FromEuler.Euler.Y'],
			['IfZ.Result','FromEuler.Euler.Z'],
			['FromEuler.Result', 'SetRotation.Value'],
			['Entry.ExecuteContext', 'FKChain.ExecuteContext'],
			['FKChain.ExecuteContext', 'ForEach.ExecuteContext'],
			['ForEach.Completed', 'Return.ExecuteContext'],
			['ForEach.ExecuteContext', 'SetRotation.ExecuteContext'],
		]
	})

def Create(inputData):
	global session
	session = inputData["session"]
	item =  inputData["item"]
	extra =  inputData["extra"]

	controlRig = session["controlRig"]
	library = controlRig.get_local_function_library()
	rootNode = session["rootNode"]
	hierarchy = session["hierarchy"]
	controller = session["controller"]
	positionCurrent = extra["positionCurrent"]
	executeInNode =  extra["executeInNode"]
	nameSetting = NLTA_ControlRigSupport.NameSetting(item)
	functionPattern = library.find_function(nameSetting["name"])
	names =  nameSetting["names"]
	data = item["value"]
	
	
	offsetParentDefault = unreal.RigElementKey(type=unreal.RigElementType.CONTROL, name=data["cbx_BeforeParent"])
	attrContent = unreal.RigElementKey(type=unreal.RigElementType.CONTROL, name=data["cbx_AttrContent"])
	offsetParentSetting = controller.get_control_settings(offsetParentDefault)
	offsetParentName = str(offsetParentSetting.display_name)
	
	chains = data["txt_Bone"].split("\n")
	for chain in chains:
		positionCurrent = [positionCurrent[0]+500,0]
		bones = chain.split(";")
		functionName = names["function"].format(bones[0])
		offsetParent =  offsetParentDefault
		boneArray = []
		offsetArray = []
		controlArray = []
		for bone in bones:
			if bone != "":
				boneArray.append('(Type=Bone,Name="'+bone+'")')			
				boneTransform = session["bones"][bone]["transform"]

				#OFFSET
				offsetName = names["offset"].format(bone)
				offsetSetting = {
					"controlRig":session["controlRig"],
					"type":"proxy",
					"visible":False,
					"name":offsetName,
					"shape":"Box_Thick",
					"transform":boneTransform,
					"parent":offsetParent
				}
				offset = NLTA_ControlRigGeneral.AddControl(offsetSetting)				
				offsetArray.append('(Type=Control,Name="'+offsetName+'")')

				#CONTROL
				controlName = names["control"].format(bone)
				controlSetting = {
					"controlRig":session["controlRig"],
					"type":"control",
					"name":controlName,
					"shape":"Circle_Thick",
					"transform":boneTransform,
					"parent":offset
				}
				control = NLTA_ControlRigGeneral.AddControl(controlSetting)
				controlArray.append('(Type=Control,Name="'+controlName+'")')

				offsetParent = control

		#ATTR CONTROL
		holdAttr = names["holdAttr"].format(bones[0])
		NLTA_ControlRigGeneral.AddControl({
			"controlRig":session["controlRig"],
			"type":"channelFloat",
			"name":holdAttr,
			"parent":attrContent,
			"groupWithParent":True,
			"limit":[unreal.RigControlLimitEnabled(True, True)],
			"min":unreal.RigHierarchy.make_control_value_from_float(-10),
			"max":unreal.RigHierarchy.make_control_value_from_float(10),
						
		})

		library = controlRig.get_local_function_library()		
		rootNode.add_function_reference_node(functionPattern,unreal.Vector2D(positionCurrent[0],positionCurrent[1]),functionName)

		rootNode.set_pin_default_value(functionName+'.Controls', '('+(",").join(controlArray)+')')
		rootNode.set_pin_default_value(functionName+'.Bones','('+(",").join(boneArray)+')')
		rootNode.set_pin_default_value(functionName+'.Offsets', '('+(",").join(offsetArray)+')')
		rootNode.set_pin_default_value(functionName+'.Reverse', str(data["chx_Reverse"]))
		rootNode.set_pin_default_value(functionName+'.X', str(data["rad_HoldX"]))
		rootNode.set_pin_default_value(functionName+'.Y', str(data["rad_HoldY"]))
		rootNode.set_pin_default_value(functionName+'.Z', str(data["rad_HoldZ"]))
		rootNode.set_pin_default_value(functionName+'.Min', str(data["spn_Min"]))
		rootNode.set_pin_default_value(functionName+'.Max', str(data["spn_Max"]))

		holdNode = names["holdNode"].format(bones[0])
		NLTA_ControlRigGeneral.AddNode({
			"module":session["rootNode"],
			"type":"GetBoolChannel",
			"name":holdNode,
			"position":[positionCurrent[0]-300,200],

		})	
		rootNode.add_link(holdNode+'.Value', functionName+'.Hold')
		rootNode.set_pin_default_value(holdNode+".Control",data["cbx_AttrContent"])
		rootNode.set_pin_default_value(holdNode+".Channel",holdAttr)

		session["rootNode"].add_link(executeInNode,functionName+".ExecuteContext")
		executeInNode = functionName+".ExecuteContext"
		
		
	returnDict = {
		"executeInNode":executeInNode,
		"positionCurrent":positionCurrent

	}		
	return(returnDict)		
	
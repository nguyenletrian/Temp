from importlib import *
import unreal, NLTA_general, NLTA_ControlRigGeneral, NLTA_ControlRigSupport
reload(NLTA_general)
reload(NLTA_ControlRigGeneral)
reload(NLTA_ControlRigSupport)

session = {}
def Pattern():
	return({
		"pins":[
			["input","Controls","ArrayRigElementKey"],
			["input","IK","RigElementKey"],
			["input","IKFake","RigElementKey"],
			["input","Switch","Boolean"],	
		],
		"nodes":[
			["Not","Not"],
			["Branch","Branch"],
			["GetTransform","GetTransform"],
			["SetTransform","SetTransform"],
			["HideControls","HideControls"],
			["HideControls","HideControlsIK"],
		],
		"positions":[
			["return",560,0],
			["Entry",-912,16],
			["HideControlsIK",-656,0],
			["HideControls",80,-16],
			["SetTransform",144,176],
			["Branch",-160,-16],
			["Not",-144,-112],
			["GetTransform",-208,240],
		],
		"values":[
			['HideControlsIK.controls', '((Type=None,Name="None"))'],
			['HideControlsIK.Active', 'false']
		],
		"links":[
			["Entry.ExecuteContext","HideControlsIK.ExecuteContext"],
			["Entry.IK","HideControlsIK.controls.0"],
			["HideControlsIK.ExecuteContext","Branch.ExecuteContext"],
			["Entry.Switch","Branch.Condition"],
			["Entry.Controls","HideControls.controls"],
			["Entry.IKFake","SetTransform.Item"],
			["Entry.IK","GetTransform.Item"],
			
			["Entry.Switch","Not.Value"],
			["Branch.True","SetTransform.ExecuteContext"],
			["Branch.Completed","HideControls.ExecuteContext"],
			["GetTransform.Transform","SetTransform.Value"],
			["Not.Result","HideControls.Active"],
			["HideControls.ExecuteContext","Return.ExecuteContext"],			
		]
	})

def Create(inputData):
	global session
	session = inputData["session"]
	item =  inputData["item"]
	extra =  inputData["extra"]	

	controlRig = session["controlRig"]
	rootNode = session["rootNode"]
	hierarchy = session["hierarchy"]
	controller = session["controller"]
	positionCurrent = extra["positionCurrent"]
	positionCurrent = [positionCurrent[0]+500,0]
	executeInNode =  extra["executeInNode"]

	data = item["value"]
	nameSetting = NLTA_ControlRigSupport.NameSetting(item)
	names = nameSetting["names"]
	functionPattern = nameSetting["name"]

	IK = unreal.RigElementKey(type=unreal.RigElementType.CONTROL, name=data["cbx_IKControl"])
	IKSetting = controller.get_control_settings(IK)
	IKName = str(IKSetting.display_name)
	IKTransform = hierarchy.get_global_transform(IK)
	print(hierarchy.get_parents(IK))
	IKParent = hierarchy.get_parents(IK)[0]
	IKSetting.animation_type = unreal.RigControlAnimationType.VISUAL_CUE
	controller.set_control_settings(IK,IKSetting)

	#IK FAKE
	IKFake = NLTA_ControlRigGeneral.AddControl({
		"controlRig":session["controlRig"],
		"type":"control",
		"name":names["IKFake"],
		"shape":"Box_Thick",
		"transform":IKTransform,
		"parent":IKParent
	})	
	IKShapeTransform = NLTA_ControlRigGeneral.GetCurveData({"controlRig":session["controlRig"],"controls":[IK]})
	hierarchy.set_control_shape_transform(IKFake,IKShapeTransform[IKName]["shape_transform"],True)
	
	#REMAIN CONTROLS
	objData = {
		"order":[],
		"transform":{},
		"controls":{},
		"controlNames":[]
	}	
	for obj in ["Inner","Outer","Heel","Toe","Ball"]:
		if data["txt_TranslationX{}".format(obj)] != '0' and data["txt_TranslationY{}".format(obj)] != '0' and data["txt_TranslationZ{}".format(obj)] != '0' and data["txt_RotationX{}".format(obj)] != '0' and data["txt_RotationY{}".format(obj)] != '0' and data["txt_RotationZ{}".format(obj)] != '0' and data["txt_RotationW{}".format(obj)] != '0':
			objData["order"].append(obj)
			objData["transform"][obj] = unreal.Transform(
				location = unreal.Vector(
					float(data["txt_TranslationX{}".format(obj)]),
					float(data["txt_TranslationY{}".format(obj)]),
					float(data["txt_TranslationZ{}".format(obj)]),
				),
				rotation = unreal.Quat(
					x = float(data["txt_RotationX{}".format(obj)]),
					y = float(data["txt_RotationY{}".format(obj)]),
					z = float(data["txt_RotationZ{}".format(obj)]),
					w = float(data["txt_RotationW{}".format(obj)]),
				).rotator(),
				scale = unreal.Vector(1,1,1,),
			)
	parentTemp = IKFake
	for obj in objData["order"]:
		controlTemp = NLTA_ControlRigGeneral.AddControl({
			"controlRig":session["controlRig"],
			"type":"control",
			"name":names[obj],
			"shape":"Box_Thick",
			"transform":objData["transform"][obj],
			"parent":parentTemp
		})
		objData["controls"][obj] = controlTemp
		objData["controlNames"].append(names[obj])
		parentTemp = controlTemp
	NLTA_ControlRigGeneral.SetParent({
		"controlRig":session["controlRig"],
		"child":IK,
		"parent":parentTemp
	})

	objData["controlNames"].insert(0,names["IKFake"])
	controlString = '(Type=Control,Name="{}")'
	controlNames = []
	for control in objData["controlNames"]:
		controlNames.append(controlString.format(control))

	#ADD FUNCTION
	library = controlRig.get_local_function_library()
	functionPattern = library.find_function(functionPattern)
	rootNode.add_function_reference_node(functionPattern,unreal.Vector2D(positionCurrent[0],positionCurrent[1]),nameSetting["function"])

	
	rootNode.set_pin_default_value(nameSetting["function"]+'.Controls', '('+(",").join(controlNames)+')')
	rootNode.set_pin_default_value(nameSetting["function"]+'.IK', '(Type=Control,Name="'+data["cbx_IKControl"]+'")')
	rootNode.set_pin_default_value(nameSetting["function"]+'.IKFake', '(Type=Control,Name="'+names["IKFake"]+'")')
	rootNode.set_pin_default_value(nameSetting["function"]+'.Switch', 'false')

	NLTA_ControlRigGeneral.AddNode({
		"module":session["rootNode"],
		"type":"GetFloatChannel",
		"name":names["node"],
		"position":[positionCurrent[0]-310,190]
	})
	rootNode.set_pin_default_value(names["node"]+".Control",names["switchControl"])
	rootNode.set_pin_default_value(names["node"]+".Channel",names["switchChannel"])
	rootNode.add_link(names["node"]+'.Value',nameSetting["function"]+'.Switch')
	
	session["rootNode"].add_link(executeInNode,nameSetting["function"]+".ExecuteContext")
	return({
		"executeInNode":nameSetting["function"]+".ExecuteContext",
		"positionCurrent":positionCurrent
	})
import unreal
#load PhysicAsset
physics_asset = unreal.EditorAssetLibrary.load_asset('/Game/Characters/Hero/Hero_PhysicAsset')
#kiem tra
if not isinstance(physics_asset,unreal.PhysicAsset):
	print('Asset khoong phari laf PhysicAsset')
else:
	#Tao body set up neu chua co bone
	bone_name = 'spine_01'
	if not physics_asset.find_body_setup(bone_name):
		unreal.PhysicAssetEditorLibrary.add_body_to_asset(physics_asset,bone_name)
	#Them capsule collision

	shape = unreal.SphylShape() #unreal.BoxShape() #unreal.SphereShape()
	shape.radius = 10.0
	shape.length = 20.0
	shape.center = unreal.Vector(0,0,0)
	shape.rotation = unreal.Rotator(0,0,0)

	#Lay BodySetup cura bone
	body_setup = physics_asset.find_body_setup(bone_name)
	if body_setup:
		body_setup.against_default_collision_response = True
		body_setup.default_instance.add_sphyl(shape)
		print(f'Da them capsule vao bone {bone_name}')
		unreal.EditorAssetLibrary.save_loaded_asset(physics_asset)
	else:
		print('Khong tim thay body setup.')



import unreal

#Load Physics Asset
phys_asset = unreal.EditorAssetLibrary.load_asset('/Game/Characters/Hero/Hero_PhysicAsset')
bone_name = 'spine_01'
if not isinstance(phys_asset,unreal.PhysicAsset):
	print('Khong dung asset')
else:
	#Neu chua co body, tao moi
	if not phys_asset.find_body_setup(bone_name):
		unreal.PhysicAssetEditorLibrary.add_body_to_asset(phys_asset,bone_name)
	body_setup = phys_asset.find_body_setup(bone_name)

	#Tao shap moi (box)
	new_box = unreal.BoxShape()
	new_box.center = unreal.Vector(0,0,0)
	new_box.rotation = unreal.Rotator(0,0,0)
	new_box.dimensions = unreal.Vector(10,5,3)

	#Add vafo AggGeom
	body_setup.default_instance.add_box(new_box)

	#Luu lai
	unreal.EditorAssetLibrary.save_loaded_asset(phys_asset)
	print(f'Da add them box shape cho bone:{bone_name}')
from importlib import *
import unreal, NLTA_general, NLTA_ControlRigGeneral, NLTA_ControlRigSupport
reload(NLTA_general)
reload(NLTA_ControlRigGeneral)
reload(NLTA_ControlRigSupport)

session = {}
def Pattern():
	return({
		"pins":[
			["input","Controls","ArrayRigElementKey"],
			["input","Bones","ArrayRigElementKey"],
		],
		"nodes":[
			["FKChain","FKChain"],
		],
		"positions":[
			["return",512,0],
			["Entry",-250,0],
			["FKChain",0,0],
		],
		"links":[
			['Entry.ExecuteContext','FKChain.ExecuteContext'],
			['Entry.Bones','FKChain.Bones'],
			['Entry.Controls','FKChain.Controls'],
			['FKChain.ExecuteContext','Return.ExecuteContext']
		]
	})

def Create(inputData):
	global session
	session = inputData["session"]
	item =  inputData["item"]
	extra =  inputData["extra"]

	controlRig = session["controlRig"]
	rootNode = session["rootNode"]
	hierarchy = session["hierarchy"]
	controller = session["controller"]
	positionCurrent = extra["positionCurrent"]
	positionCurrent = [positionCurrent[0]+200,0]
	executeInNode =  extra["executeInNode"]

	#CREATE CONTROL
	data = item["value"]
	nameSetting = NLTA_ControlRigSupport.NameSetting(item)
	functionPattern = nameSetting["name"]
	controlsPattern = nameSetting["controlsPattern"]	
	boneArray = data["txt_Bone"].split(";")
	if data["cbx_BeforeParent"]!=None:
		FKParentTemp = unreal.RigElementKey(type=unreal.RigElementType.CONTROL, name=data["cbx_BeforeParent"])
	else:
		FKParentTemp = None
	controlsStringArray = []
	bonesStringArray = []
	for order in range(len(boneArray)):
		boneName = boneArray[order]
		controlName = controlsPattern.format(boneArray[order])
		controlsStringArray.append('(Type=Control,Name="'+controlName+'")')
		bonesStringArray.append('(Type=Bone,Name="'+boneName+'")')
		settingtemp = {
			"controlRig":session["controlRig"],
			"type":"control",
			"name":controlName,
			"shape":"Circle_Thick",
			"transform":session["bones"][boneName]["transform"]
		}
		if data["chx_Chain"]==True:
			if FKParentTemp != None:
				settingtemp["parent"] = FKParentTemp
			FK = NLTA_ControlRigGeneral.AddControl(settingtemp)
			FKParentTemp = FK
		else:
			if FKParentTemp != None:
				settingtemp["parent"] = FKParentTemp
			NLTA_ControlRigGeneral.AddControl(settingtemp)

	controlsString = "("+",".join(controlsStringArray)+")"
	bonesString = "("+",".join(bonesStringArray)+")"
	#ADD FUNCTION
	library = controlRig.get_local_function_library()
	functionPattern = library.find_function(functionPattern)
	rootNode.add_function_reference_node(functionPattern,unreal.Vector2D(positionCurrent[0],positionCurrent[1]),nameSetting["function"])

	session["rootNode"].add_link(executeInNode,nameSetting["function"]+".ExecuteContext")
	rootNode.set_pin_default_value(nameSetting["function"]+".Controls",controlsString)
	rootNode.set_pin_default_value(nameSetting["function"]+".Bones",bonesString)

	returnDict = {
		"executeInNode":nameSetting["function"]+".ExecuteContext",
		"positionCurrent":positionCurrent

	}
	return(returnDict)
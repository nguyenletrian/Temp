import unreal
def AddNode(inputData):
	nodeData = {
		"UnitNode":{
			"IKBasic":'/Script/ControlRig.RigUnit_TwoBoneIKSimplePerItem',
			"GetTransform":'/Script/ControlRig.RigUnit_GetTransform',			
			"TransformLocation":'/Script/RigVM.RigVMFunction_MathTransformTransformVector',
			"FromTwoVectors":'/Script/RigVM.RigVMFunction_MathQuaternionFromTwoVectors',			
			"GetChildren":'/Script/ControlRig.RigUnit_CollectionChildrenArray',			
			"TransformLocation":'/Script/RigVM.RigVMFunction_MathTransformTransformVector',
			'EvaluateCurve':'/Script/RigVM.RigVMFunction_AnimEvalRichCurve',			
			'ToEuler':'/Script/RigVM.RigVMFunction_MathQuaternionToEuler',
			'FromEuler':'/Script/RigVM.RigVMFunction_MathQuaternionFromEuler',			
			'Floor':'/Script/RigVM.RigVMFunction_MathVectorFloor',
			'SphereTrace':'/Script/ControlRig.RigUnit_SphereTraceByObjectTypes',
			'MakeVector':'/Script/RigVM.RigVMFunction_MathVectorMake',			
			"Sequence":'/Script/RigVM.RigVMFunction_Sequence',
			"ForwardsSolve":'/Script/ControlRig.RigUnit_BeginExecution',
			"Branch":'/Script/RigVM.RigVMFunction_ControlFlowBranch',
			'ParentConstraint':'/Script/ControlRig.RigUnit_ParentConstraint',
			'GetControlBool':'/Script/ControlRig.RigUnit_GetControlBool',
			'Aim':'/Script/ControlRig.RigUnit_AimConstraintLocalSpaceOffset',
			'Not':'/Script/RigVM.RigVMFunction_MathBoolNot',
			"GetTransformArray":'/Script/ControlRig.RigUnit_GetTransformItemArray',
			"SplineFromTransforms":'/Script/ControlRigSpline.RigUnit_ControlRigSplineFromTransforms',
			"DrawSpline":'/Script/ControlRigSpline.RigUnit_DrawControlRigSpline',
			"TransformFromSpline":'/Script/ControlRigSpline.RigUnit_TransformFromControlRigSpline2',
			"ClosestSpline":'/Script/ControlRigSpline.RigUnit_ClosestParameterFromControlRigSpline',
		},
		"TemplateNode":{
			"RotateVector":'Rotate Vector::Execute(in Transform,in Vector,out Result)',
			"SpringInterp":'SpringInterp::Execute(in Target,in Strength,in CriticalDamping,in Force,in bUseCurrentInput,in Current,in TargetVelocityAmount,in bInitializeFromTarget,out Result,out Velocity)',
			"Subtract":'Subtract::Execute(in A,in B,out Result)',
			"Multiply":'Multiply::Execute(in A,in B,out Result)',
			'ForEach':'DISPATCH_RigVMDispatch_ArrayIterator(in Array,out Element,out Index,out Count,out Ratio)',
			'SetRotation':'Set Transform::Execute(in Item,in Space,in bInitial,in Value,in Weight,in bPropagateToChildren)',
			'If':'DISPATCH_RigVMDispatch_If(in Condition,in True,in False,out Result)',
			"Add":'Add::Execute(in A,in B,out Result)',
			"Subtract":'Subtract::Execute(in A,in B,out Result)',
			"Greater":'Greater::Execute(in A,in B,out Result)',
			"GetBoolChannel":"GetAnimationChannel::Execute(out Value,in Control,in Channel,in bInitial)",
			"Remap":'Remap::Execute(in Value,in SourceMinimum,in SourceMaximum,in TargetMinimum,in TargetMaximum,in bClamp,out Result)',
			"At":'DISPATCH_RigVMDispatch_ArrayGetAtIndex(in Array,in Index,out Element)',
			'GetFloatChannel':'GetAnimationChannel::Execute(out Value,in Control,in Channel,in bInitial)',
			#'FromEuler':'FromEuler::Execute(in Euler,in RotationOrder,out Result)',
			"SetTransform":'Set Transform::Execute(in Item,in Space,in bInitial,in Value,in Weight,in bPropagateToChildren)',			
			"Num":'DISPATCH_RigVMDispatch_ArrayGetNum(in Array,out Num)',
			"Modulo":'Modulo::Execute(in A,in B,out Result)',
			"FloorInt":'Floor::Execute(in Value,out Result,out Int)',
			"GreaterEqual":'GreaterEqual::Execute(in A,in B,out Result)',
			"IntToDouble":'Cast::Execute(in Value,out Result)',
		},

		"ReferenceNode":{
			"FKChain":'/ControlRig/StandardFunctionLibrary/StandardFunctionLibrary.StandardFunctionLibrary_C',
			'IKTwoBone':'/ControlRig/StandardFunctionLibrary/StandardFunctionLibrary.StandardFunctionLibrary_C',
			'HideControls':'/ControlRig/StandardFunctionLibrary/StandardFunctionLibrary.StandardFunctionLibrary_C', 
		}		
	}
	module = inputData["module"]
	name =  inputData["name"]
	type_ = inputData["type"]

	if "position" in inputData:
		position = unreal.Vector2D(inputData["position"][0],inputData["position"][1])
	else:
		position = unreal.Vector2D(0,0)

	if type_ in nodeData["UnitNode"]:
		module.add_unit_node_from_struct_path(nodeData["UnitNode"][type_],'Execute',position,name)
		if type_ == "SphereTrace":
			module.insert_array_pin(name+'.ObjectTypes', -1, '')
	
	if type_ in nodeData["TemplateNode"]:
		module.add_template_node(nodeData["TemplateNode"][type_],position,name)

	if type_ in nodeData["ReferenceNode"]:
		module.add_external_function_reference_node(nodeData["ReferenceNode"][type_],type_,position,name)


		
def AddControl(inputData):
	data = {
		"control":{	
			"type":unreal.RigControlType.EULER_TRANSFORM,
			"animation":unreal.RigControlAnimationType.ANIMATION_CONTROL,
			"value":unreal.RigHierarchy.make_control_value_from_euler_transform(unreal.EulerTransform(location=[0,0,0],rotation=[0,0,0],scale=[1,1,1]))
		},
		"channelBool":{
			"type":unreal.RigControlType.BOOL,
			"animation":unreal.RigControlAnimationType.ANIMATION_CHANNEL,
			"value":unreal.RigHierarchy.make_control_value_from_bool(False)
		},
		"channelFloat":{
			"type":unreal.RigControlType.FLOAT,
			"animation":unreal.RigControlAnimationType.ANIMATION_CHANNEL,
			"value":unreal.RigHierarchy.make_control_value_from_float(0.000000)
		},
		"proxy":{
			"type":unreal.RigControlType.EULER_TRANSFORM,
			"animation":unreal.RigControlAnimationType.PROXY_CONTROL,
			"value":unreal.RigHierarchy.make_control_value_from_euler_transform(unreal.EulerTransform(location=[0,0,0],rotation=[0,0,0],scale=[1,1,1]))
		},
		"scale":{
			"type":unreal.RigControlType.SCALE,
			"animation":unreal.RigControlAnimationType.ANIMATION_CONTROL,
			"value": unreal.RigHierarchy.make_control_value_from_vector(unreal.Vector(1.000000, 1.000000, 1.000000))
		},
		"cue":{
			"type": unreal.RigControlType.EULER_TRANSFORM,
			"animation":unreal.RigControlAnimationType.VISUAL_CUE,
			"value":unreal.RigHierarchy.make_control_value_from_euler_transform(unreal.EulerTransform(location=[0,0,0],rotation=[0,0,0],scale=[1,1,1]))
		}
	}
	controlRig = inputData["controlRig"]
	hierarchy = controlRig.hierarchy
	controller = hierarchy.get_controller()
	controlData = data[inputData["type"]]

	controlSetting = unreal.RigControlSettings()
	controlSetting.control_type = controlData["type"]
	controlSetting.animation_type = controlData["animation"]
	controlSetting.display_name = inputData["name"]
	controlSetting.primary_axis = unreal.RigControlAxis.X

	if inputData["type"] == "proxy":
		controlSetting.shape_color = unreal.LinearColor(.5,.5,.5,0)
	
	if "color" in inputData:
		controlSetting.shape_color = unreal.LinearColor(inputData["color"][0],inputData["color"][1],inputData["color"][2],inputData["color"][3])
	
	if "visible" in inputData:
		controlSetting.shape_visible = inputData["visible"]
	else:
		controlSetting.shape_visible = True
	
	if "shape" in inputData:
		controlSetting.shape_name = inputData["shape"]
	else:
		controlSetting.shape_name = 'Default'	
	
	if "parent" in inputData:
		parent =  inputData["parent"]
	else:
		parent = unreal.RigElementKey(unreal.RigElementType.NULL, "")

	if "groupWithParent" in inputData:
		controlSetting.set_editor_property("group_with_parent_control",inputData["groupWithParent"])

	if "limit" in inputData:		
		controlSetting.limit_enabled = inputData["limit"]

	if "min" in inputData:
		controlSetting.minimum_value = inputData["min"]

	if "max" in inputData:
		controlSetting.maximum_value = inputData["max"]

	if "rotationOrder" in inputData:
		controlSetting.set_editor_property("preferred_rotation_order",inputData["rotationOrder"])

	newControl = controller.add_control(
		name = inputData["name"],
		parent = parent,
		settings = controlSetting,
		value = controlData["value"]
	)

	if inputData["type"] in ["control","proxy"]:
		transform = inputData["transform"]
		if "parent" in inputData:
			controller.set_parent(newControl,inputData["parent"], True)
			hierarchy.set_global_transform(newControl,transform,True)
			localTransform = hierarchy.get_local_transform(newControl,initial=True)
			hierarchy.set_control_offset_transform(newControl,localTransform,True,True) #True,True
			hierarchy.set_local_transform(newControl, unreal.Transform(location=[0.000000,0.000000,0.000000],rotation=[0.000000,0.000000,0.000000],scale=[1.000000,1.000000,1.000000]), True, True)
			hierarchy.set_local_transform(newControl, unreal.Transform(location=[0.000000,0.000000,0.000000],rotation=[0.000000,0.000000,0.000000],scale=[1.000000,1.000000,1.000000]), False, True)
		else:
			hierarchy.set_control_offset_transform(newControl,transform, True, True)
			#hierarchy.set_global_transform(newControl,transform, True, True)	

	return(newControl)

def SetParent(inputData):
	controlRig = inputData["controlRig"]
	hierarchy = controlRig.hierarchy
	controller = hierarchy.get_controller()
	parent =  inputData["parent"]
	child = inputData["child"]
	parentTransform = hierarchy.get_global_transform(parent)
	childTransform = hierarchy.get_global_transform(child)
	controlTemp = AddControl({
		"controlRig":controlRig,
		"type":"control",
		"name":"ControlTemp_NLTA",
		"parent":parent,
		"transform":parentTransform
	})
	hierarchy.set_global_transform(controlTemp,childTransform,True)
	localTransform = hierarchy.get_local_transform(controlTemp,initial=True)
	controller.set_parent(child,parent, True)
	hierarchy.set_control_offset_transform(child,localTransform,True,True)
	hierarchy.set_local_transform(child, unreal.Transform(location=[0.000000,0.000000,0.000000],rotation=[0.000000,0.000000,0.000000],scale=[1.000000,1.000000,1.000000]), True, True)
	hierarchy.set_local_transform(child, unreal.Transform(location=[0.000000,0.000000,0.000000],rotation=[0.000000,0.000000,0.000000],scale=[1.000000,1.000000,1.000000]), False, True)
	controller.remove_element(controlTemp)
	

def GetShapeTransform(inputData):
	controlRig = inputData["controlRig"]
	control = inputData["control"]
	hierarchy = controlRig.hierarchy
	controller = hierarchy.get_controller()
	transform = hierarchy.get_global_transform(control)	
	controlTemp = AddControl({
		"controlRig":controlRig,
		"type":"control",
		"name":"ControlTemp_NLTA",
		"parent":control,
		"transform":transform
	})
	shapeTransform = hierarchy.get_global_control_shape_transform(control)
	hierarchy.set_global_transform(controlTemp,shapeTransform,True)
	returnTransform = hierarchy.get_local_transform(controlTemp,True)
	returnTransform.scale3d.x = shapeTransform.scale3d.x
	returnTransform.scale3d.y = shapeTransform.scale3d.y
	returnTransform.scale3d.z = shapeTransform.scale3d.z
	controller.remove_element(controlTemp)
	return(returnTransform)


def ClearAll(controlRig):
	controlRig = controlRig
	rootNode = controlRig.get_controller_by_name('RigVMModel')
	hierarchy = controlRig.hierarchy
	controller = hierarchy.get_controller()
	library = controlRig.get_local_function_library()

	#REMOVE NODE
	print(rootNode)
	nodes = rootNode.get_graph().get_nodes()
	for node in nodes:
		nodeName = str(node.get_name())
		if "NLTA" in nodeName:
			rootNode.remove_node(node)

	controls = hierarchy.get_controls()
	for control in controls:
		if "NLTA" in str(control.name):
			controller.remove_element(control)


	libraryController = controlRig.get_controller(library)

	functions = ["IK_NLTA","Single_NLTA","SwitchTwo_NLTA","SwitchOne_NLTA","Aim_NLTA","Finger_NLTA","IKRoll_NLTA","TrackCircle_NLTA","TrackSpline_NLTA"]
	for function in functions:
		try:
			libraryController.remove_function_from_library(function)
		except: pass

def GetAllCurveData(inputData):
	controlRig =  inputData["controlRig"]
	hierarchy = controlRig.hierarchy
	controls =  hierarchy.get_controls()
	data = GetCurveData({
		"controlRig":controlRig,
		"controls":controls
	})
	return(data)

def GetCurveData(inputData):
	controlRig =  inputData["controlRig"]
	controls =  inputData["controls"]
	hierarchy = controlRig.hierarchy
	controller = hierarchy.get_controller()
	data = {}
	for control in controls:
		controlSetting = controller.get_control_settings(control)
		controlName = str(controlSetting.display_name)
		dataTemp = {}
		dataTemp["display_name"] = controlName
		dataTemp["shape_name"] = str(controlSetting.shape_name)
		dataTemp["shape_color"] = {
			"a":controlSetting.shape_color.a,
			"b":controlSetting.shape_color.b,
			"g":controlSetting.shape_color.g,
			"r":controlSetting.shape_color.r
		}			
		shapeTransform  = GetShapeTransform({
			"controlRig":controlRig,
			"control":control,
		})
		dataTemp["shape_transform"] = {
			"translation":{
				"x":shapeTransform.translation.x,
				"y":shapeTransform.translation.y,
				"z":shapeTransform.translation.z
			},
			"rotation":{
				"x":shapeTransform.rotation.x,
				"y":shapeTransform.rotation.y,
				"z":shapeTransform.rotation.z,
				"w":shapeTransform.rotation.w,
			},
			"scale3d":{
				"x":shapeTransform.scale3d.x,
				"y":shapeTransform.scale3d.y,
				"z":shapeTransform.scale3d.z
			}
		}
		data[controlName] = dataTemp
	return(data)

def SetCurveData(inputData):
	control = inputData["control"]
	controlData = inputData["data"]
	controlRig = inputData["controlRig"]
	hierarchy = controlRig.hierarchy
	controller = hierarchy.get_controller()
	controlSetting = controller.get_control_settings(control)
	controlSetting.shape_name = controlData["shape_name"]			
	controlSetting.shape_color = unreal.LinearColor(
		r=controlData["shape_color"]["r"],
		g=controlData["shape_color"]["g"],
		b=controlData["shape_color"]["b"],
		a=controlData["shape_color"]["a"],
	)
	controller.set_control_settings(control,controlSetting)
	hierarchy.set_control_shape_transform(control,unreal.Transform(
		location = unreal.Vector(
			controlData["shape_transform"]["translation"]["x"],
			controlData["shape_transform"]["translation"]["y"],
			controlData["shape_transform"]["translation"]["z"],
		),
		rotation = unreal.Quat(
			x = controlData["shape_transform"]["rotation"]["x"],
			y = controlData["shape_transform"]["rotation"]["y"],
			z = controlData["shape_transform"]["rotation"]["z"],
			w = controlData["shape_transform"]["rotation"]["w"],
		).rotator(),
		scale = unreal.Vector(
			controlData["shape_transform"]["scale3d"]["x"],
			controlData["shape_transform"]["scale3d"]["y"],
			controlData["shape_transform"]["scale3d"]["z"],
		),
	),True)

def SetAllCurveData(inputData):
	data = inputData["data"]
	controlRig = inputData["controlRig"]
	hierarchy = controlRig.hierarchy
	controller = hierarchy.get_controller()
	for controlName in data:
		controlData = data[controlName]
		control = unreal.RigElementKey(type=unreal.RigElementType.CONTROL, name=controlName)
		SetCurveData({
			"controlRig":controlRig,
			"data":controlData,
			"control":control
		})

"""
def MirrorShape(inputData):
	controlRig = inputData["controlRig"]
	right = inputData["right"]
	left = inputData["left"]
	if right !="" and left !="":
		hierarchy = controlRig.hierarchy
		controller = hierarchy.get_controller()
		allControls = hierarchy.get_controls()
		allControlsName = []

		for control in allControls:
			controlSetting = controller.get_control_settings(control)
			allControlsName.append(str(controlSetting.display_name))

		controlsSelected = hierarchy.get_selected_keys()
		for control in controlsSelected:
			controlSetting = controller.get_control_settings(control)
			controlName = str(controlSetting.display_name)
			if right in controlName:
				side = right
				sideNeg = left
			break
			if left in controlName:
				side = left
				sideNeg = right
			break		
		for control in controlsSelected:
			controlSetting = controller.get_control_settings(control)
			controlName = str(controlSetting.display_name)
			mirrorControlName = controlName.replace(side,sideNeg)
			if mirrorControlName in allControlsName:
				mirrorControl = unreal.RigElementKey(type=unreal.RigElementType.CONTROL, name=mirrorControlName)
				mirrorSetting = unreal.RigVMMirrorSettings()
				mirrorSetting.axis_to_flip = unreal.AxisType.X
				mirrorSetting.mirror_axis = unreal.AxisType.X
				controlTemp = controller.mirror_elements([control],mirrorSetting)
				controlTempData = GetCurveData({"controlRig":controlRig,"controls":controlTemp})
				SetCurveData({
					"controlRig":controlRig,
					"data":next(iter(controlTempData.values())),
					"control":mirrorControl
				})
				controller.remove_element(controlTemp[0])
			else:
				unreal.EditorDialog.show_message("Warning","Couldn't find mirror control "+mirrorControlName,unreal.AppMsgType.OK)
	else:
		unreal.EditorDialog.show_message("Warning","Please fill sides text",unreal.AppMsgType.OK)
"""

def MirrorShape(inputData):
	controlRig = inputData["controlRig"]
	hierarchy = controlRig.hierarchy
	controller = hierarchy.get_controller()
	source = inputData["source"]
	destination = inputData["destination"]

	mirrorSetting = unreal.RigVMMirrorSettings()
	mirrorSetting.axis_to_flip = unreal.AxisType.X
	mirrorSetting.mirror_axis = unreal.AxisType.X
	controlTemp = controller.mirror_elements([source],mirrorSetting)
	controlTempData = GetCurveData({"controlRig":controlRig,"controls":controlTemp})
	SetCurveData({
		"controlRig":controlRig,
		"data":next(iter(controlTempData.values())),
		"control":destination
	})
	controller.remove_element(controlTemp[0])


def MirrorShapeBySelected(inputData):
	controlRig = inputData["controlRig"]
	hierarchy = controlRig.hierarchy
	controller = hierarchy.get_controller()
	controlsSelected = hierarchy.get_selected_keys()
	total = len(controlsSelected)
	if total > 1 and (total%2)==0:
		midNumber = int((total/2))
		source= controlsSelected[0:(midNumber)]
		destination= controlsSelected[(midNumber)::]
		for order in range(len(source)):
			MirrorShape({
				"controlRig":controlRig,
				"source":source[order],
				"destination":destination[order]
			})




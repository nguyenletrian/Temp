import unreal
import sys
import os
import shutil
import subprocess
from importlib import *
from PySide2 import QtUiTools, QtWidgets
from PySide2.QtWidgets import QMessageBox, QMenu, QTreeWidgetItem,QTreeWidgetItemIterator
from PySide2 import QtCore
from PySide2 import QtGui
from functools import partial

import time

import NLTA_general, NLTA_Asset
reload(NLTA_general)
reload(NLTA_Asset)

session = {}

class CreateWindow(QtWidgets.QWidget):
	window = None
	def __init__(self,parent=None):
		super(CreateWindow,self).__init__(parent)		
		self.toolPath = NLTA_general.GetCurrentToolPath()
		self.dataPath = NLTA_general.getDataPath()
		self.widget = QtUiTools.QUiLoader().load(self.toolPath+"View/Main.ui")
		self.widget.setParent(self)
		self.btn_Ok = self.widget.findChild(QtWidgets.QPushButton,'btn_Ok')
		self.btn_Ok.clicked.connect(self.Ok)

		self.Detect()

	def resizeEvent(self,event):
		self.widget.resize(self.width(),self.height())
	
	def closeWindow(self):
		self.destroy()
		NLTA_general.openWindow({
			"controller":"NLTA_MainWindow",
			"posX":self.pos().x(),
			"posY":self.pos().y()
		})

	def Detect(self):
		global session
		assets = NLTA_Asset.Selected()
		for asset in assets:
			print(asset)
			if isinstance(asset,unreal.PhysicsAsset):
				print(unreal.SkeletalMeshComponent(asset))
				BodySetup = unreal.BodySetup(asset,"Bip001-Pelvis")
				print(BodySetup.bone_name)
				#print(BodySetup.get_editor_property("default_instance"))
				#print(BodySetup.get_editor_property("bone_name"))
				#BodyInstance =  body.get_editor_property("default_instance")
				#path = asset.get_path_name()
				#print("------")
				#print(path)
				#unreal.AssetToolsHelpers.get_asset_tools().open_editor_for_assets([asset])
				#unreal.GeometryScript_Primitives
				#component = unreal.PrimitiveComponent

				#body = unreal.BodySetup([unreal.BodyInstance()])
				#body.default_instance = unreal.BodyInstance()
				#allConstraint = asset.get_constraints(True)

				#body.set_editor_property("agg_geom",unreal.KAggregateGeom.get_editor_property("box_elems"))
				#self.txt_Name.setText(path)
				#self.controlRig = asset
				
				#session["controlRig"] = path
				#constraint = asset.get_editor_property('thumbnail_info')

				#allConstraint = asset.get_constraints(True)
				#constraint = allConstraint[0]
				#print(unreal.ConstraintInstanceBlueprintLibrary().get_angular_limits(constraint))
				#print(unreal.ConstraintInstanceBlueprintLibrary().get_attached_body_names(constraint))
				#attachBodys = unreal.ConstraintInstanceBlueprintLibrary().get_attached_body_names(constraint)
				#body_instance = unreal.BodyInstance()
				#body_instance.simulate_physics = True
				#body_instance.enable_gravity = True
				#body_instance.mass_in_kg_override = 50.0
				#body_instance.linear_damping = 0.1
				#body_instance.angular_damping = 0.1
				#body_setup = asset.get_body_setup
				#asset.get_root_component()
				#component =  unreal.SkeletalMeshComponent(asset)
				#component.set_all_bodies_below_physics_disabled("spine_01",True)
				
				#print(asset.get_editor_property("constraint_profiles"))
				#print(asset.get_editor_property("not_for_dedicated_server"))
				#print(asset.get_editor_property("physical_animation_profiles"))
				#print(asset.get_editor_property("solver_iterations"))
				#print(asset.get_editor_property("solver_settings"))
				#print(asset.get_editor_property("solver_type"))
				#print(asset.get_editor_property("thumbnail_info"))
				
				#bodySetup =  unreal.BodySetup(asset,"upperarm_l")

				

				#bodySetup.bone_name

				#unreal.PhysicsObjectBlueprintLibrary.get_physics_object_world_transform(asset,attachBodys[1])
				#temp = unreal.PhysicsConstraintComponent(asset)
				#print(temp.get_editor_property("component_name2").get_editor_property("component_name"))
				#print(method)
				#print(constraint.get_editor_property("component_name1").get_editor_property("component_name"))
				#print(asset.get_constraints(True))
				#body = unreal.BodySetup(asset)
				#print(body.get_editor_property("bone_name"))
				#component = unreal.PrimitiveComponent
				#print(asset.get_class())
				#print(component.get_editor_property(asset,"mobility"))
				#component.get_editor_property("absolute_location")
				#print(asset.get_constraints(True)[0])
				#print(constraint)


	############
	def Ok(self):
		print("=========")


"""

unreal.KSphylElem
unreal.BodyInstance = https://dev.epicgames.com/documentation/en-us/unreal-engine/python-api/class/BodyInstance?application_version=5.7

Shape	Struct Type
Sphere	FKSphereElem
Capsule	FKSphylElem
Box	FKBoxElem
Convex	FKConvexElem
Tapered Capsule (UE5)	FKTaperedCapsuleElem

FKAggregateGeom

UPhysicsConstraintTemplate

FConstraintInstance

import unreal

phys_asset = unreal.load_asset("/Game/MyPhysicsAsset")

body_setup = unreal.SkeletalBodySetup()
body_setup.bone_name = "upperarm_l"

capsule = unreal.KSphylElem()
capsule.radius = 8.0
capsule.length = 30.0

agg = body_setup.get_editor_property("agg_geom")
agg.sphyl_elems.append(capsule)

phys_asset.skeletal_body_setups.append(body_setup)

unreal.EditorAssetLibrary.save_loaded_asset(phys_asset)

import unreal

# Load Physics Asset
phys_asset = unreal.load_asset(
    "/Game/Characters/Hero/PA_Hero"
)

print(type(phys_asset))
# <class 'PhysicsAsset'>

import unreal

phys_asset = unreal.load_asset(
    "/Game/Characters/Hero/PA_Hero"
)

body_setups = phys_asset.get_editor_property(
    "skeletal_body_setups"
)

for body in body_setups:
    bone_name = body.get_editor_property("bone_name")
    print(bone_name)


for body in body_setups:

    bone_name = body.get_editor_property("bone_name")
    agg_geom = body.get_editor_property("agg_geom")

    print("\nBone:", bone_name)

    print("Capsules :", len(agg_geom.sphyl_elems))
    print("Boxes    :", len(agg_geom.box_elems))
    print("Spheres  :", len(agg_geom.sphere_elems))
    print("Convexes :", len(agg_geom.convex_elems))

for body in body_setups:

agg_geom = body.get_editor_property("agg_geom")

for capsule in agg_geom.sphyl_elems:

    print("Radius:", capsule.radius)
    print("Length:", capsule.length)
    print("Center:", capsule.center)
    print("Rotation:", capsule.rotation)

constraints = phys_asset.get_editor_property(
    "constraint_setup"
)

for constraint in constraints:

    default_obj = constraint.get_editor_property(
        "default_instance"
    )

    print(default_obj)

def find_body(phys_asset, bone_name):

    body_setups = phys_asset.get_editor_property(
        "skeletal_body_setups"
    )

    for body in body_setups:

        if str(body.get_editor_property("bone_name")) == bone_name:
            return body

    return None

body = find_body(phys_asset, "upperarm_l")

if body:
    print("Found")


mesh = unreal.load_asset(
    "/Game/Characters/Hero/SKM_Hero"
)

phys_asset = mesh.get_editor_property(
    "physics_asset"
)

print(phys_asset.get_name())


asset = unreal.load_asset(
    "/Game/Characters/Hero/PA_Hero"
)

for prop in asset.get_editor_property_names():
    print(prop)


import unreal

phys_asset = unreal.load_asset(
    "/Game/Characters/Hero/PA_Hero"
)

for body in phys_asset.get_editor_property(
    "skeletal_body_setups"
):

    bone = body.get_editor_property("bone_name")
    agg = body.get_editor_property("agg_geom")

    print(f"\n=== {bone} ===")

    for capsule in agg.sphyl_elems:
        print(
            f"Capsule Radius={capsule.radius} "
            f"Length={capsule.length}"
        )

    for box in agg.box_elems:
        print(
            f"Box X={box.x} "
            f"Y={box.y} "
            f"Z={box.z}"
        )

    for sphere in agg.sphere_elems:
        print(
            f"Sphere Radius={sphere.radius}"
        )
"""
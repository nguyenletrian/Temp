import unreal
from importlib import *
import NLTA_general
reload(NLTA_general)
import NLTA_Asset
reload(NLTA_Asset)

assets = NLTA_Asset.Selected()
if assets:
	if isinstance(assets[0],unreal.PhysicsAsset):
		NLTA_general.openWindow({
			"controller":"NLTA_Ctrl_PhysicAsset"
		})
	else:
		unreal.EditorDialog.show_message("Warning","Please select a control rig asset!~ :D",unreal.AppMsgType.OK)
else:
	unreal.EditorDialog.show_message("Warning","Please select a control rig asset!~ :D",unreal.AppMsgType.OK)

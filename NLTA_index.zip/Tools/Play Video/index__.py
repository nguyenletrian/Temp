#from __future__ import annotations
print("------")
import sys
import cv2
from PySide2.QtCore import QStandardPaths, Qt, Slot
from PySide2.QtGui import QIcon, QKeySequence
from PySide2.QtWidgets import (QAction, QApplication,QDialog,QFileDialog,QMainWindow,QSlider,QStyle,QToolBar)
#from PySide2.QtMultimedia import (QAudioOutput,QMediaFormat,QMediaPlayer)
#from PySide2.QtMultimediaWidgets import QVideoWidget

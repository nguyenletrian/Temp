import unreal
import sys
import os
import shutil
import subprocess
import json
import time
from importlib import *
from PySide2 import QtUiTools, QtWidgets
from PySide2.QtWidgets import QMessageBox, QMenu, QTreeWidgetItem,QTreeWidgetItemIterator
from PySide2 import QtCore
from PySide2 import QtGui
from functools import partial

import NLTA_general, NLTA_Asset, NLTA_ControlRigCore, NLTA_Actor, NLTA_SequenceNew
reload(NLTA_general)
reload(NLTA_Asset)
reload(NLTA_Actor)
reload(NLTA_ControlRigCore)
reload(NLTA_SequenceNew)

class CreateWindow(QtWidgets.QWidget):
	window = None
	def __init__(self,parent=None):
		super(CreateWindow,self).__init__(parent)		
		self.toolPath = NLTA_general.GetCurrentToolPath()
		self.dataPath = NLTA_general.getDataPath()
		self.currentToolPath = NLTA_general.GetCurrentToolPath()	
		self.widget = QtUiTools.QUiLoader().load(self.currentToolPath+"View/NLTA_SettingSnapIKFK.ui")
		self.widget.setParent(self)
		self.widgetInput = NLTA_general.WidgetInput(self.widget)
		self.widgetInput['btn_SelectSwitchControl'].clicked.connect(partial(self.selectElement,self.widgetInput['txt_SwitchControl']))
		self.widgetInput['btn_SelectFKSource'].clicked.connect(partial(self.selectElement,self.widgetInput['txt_FKSource']))
		self.widgetInput['btn_SelectFKTarget'].clicked.connect(partial(self.selectElement,self.widgetInput['txt_FKTarget']))
		self.widgetInput['btn_SelectIKSource'].clicked.connect(partial(self.selectElement,self.widgetInput['txt_IKSource']))
		self.widgetInput['btn_SelectIKTarget'].clicked.connect(partial(self.selectElement,self.widgetInput['txt_IKTarget']))	
		self.widgetInput['btn_AddOk'].clicked.connect(self.AddOk)		
		self.widgetInput['btn_Ok'].clicked.connect(self.Ok)
		self.widgetInput['btn_Clear'].clicked.connect(self.Clear)
		self.session = {
			"itemAction":"Add",
			"currentItem":""
		}
		self.Detect()
		self.LoadItems(self.widgetInput['list_Items'])

	def resizeEvent(self,event):
		self.widget.resize(self.width(),self.height())
	
	def closeWindow(self):
		self.destroy()

	def Detect(self):
		global session
		assets = NLTA_Asset.Selected()
		for asset in assets:
			if isinstance(asset,unreal.ControlRigBlueprint):
				self.controlRig = asset
				string = NLTA_ControlRigCore.GetVariable({'controlRig':self.controlRig,'variable':'NLTA_SnapIKFK'})
				if string:
					self.snapIKFKSetting = json.loads(string)
				else:
					self.snapIKFKSetting = {}
				unreal.AssetToolsHelpers.get_asset_tools().open_editor_for_assets([asset])

	def selectElement(self,input):
		seletedElements = NLTA_ControlRigCore.GetSelectedElements(self.controlRig)
		string = ";".join(seletedElements)
		input.setPlainText(string)

	def DeleteItem(self,name):
		self.snapIKFKSetting.pop(name)
		self.LoadItems(self.widgetInput['list_Items'])

	def EditItem(self,name):
		self.session['itemAction'] == "Edit"
		self.session['currentItem'] == "Name"
		NLTA_general.WidgetSet({
			"widget":NLTA_general.WidgetInput(self.widget),
			"value":{
				"txt_Name":name,
				"txt_SwitchControl":self.snapIKFKSetting[name]['SwitchControl'],
				"txt_FKSource":self.snapIKFKSetting[name]['FKSource'],
				"txt_FKTarget":self.snapIKFKSetting[name]['FKTarget'],
				"txt_IKSource":self.snapIKFKSetting[name]['IKSource'],
				"txt_IKTarget":self.snapIKFKSetting[name]['IKTarget'],
			}
		})

	def LoadItems(self,widget):
		for i in reversed(range(widget.count())):
			widget.itemAt(i).widget().deleteLater()
		for key in self.snapIKFKSetting:
			pattern = self.currentToolPath+"View/NLTA_SettingSnapIKFK_Item.ui"
			item = QtUiTools.QUiLoader().load(pattern)
			itemInput = NLTA_general.WidgetInput(item)
			itemInput['lb_Name'].setText(key)
			itemInput['btn_Delete'].clicked.connect(partial(self.DeleteItem,key))
			itemInput['btn_Edit'].clicked.connect(partial(self.EditItem,key))
			widget.addWidget(item)

	def Clear(self):
		NLTA_general.WidgetSet({
			"widget":NLTA_general.WidgetInput(self.widget),
			"value":{
				"txt_Name":"",
				"txt_SwitchControl":"",
				"txt_FKSource":"",
				"txt_FKTarget":"",
				"txt_IKSource":"",
				"txt_IKTarget":"",
			}
		})
		self.session = {
			"itemAction":"Add",
			"currentItem":""
		}

	def AddOk(self):
		widgetGet = NLTA_general.WidgetGet(self.widget)
		if self.session["itemAction"] == "Add":
			self.snapIKFKSetting[widgetGet['txt_Name']] = {
				"SwitchControl":widgetGet['txt_SwitchControl'],
				"FKSource":widgetGet['txt_FKSource'],
				"FKTarget":widgetGet['txt_FKTarget'],
				"IKSource":widgetGet['txt_IKSource'],
				"IKTarget":widgetGet['txt_IKTarget'],
			}

		else:
			if widgetGet['txt_Name'] == self.session["txt_Name"]:
				self.snapIKFKSetting[widgetGet['txt_Name']] = {
					"SwitchControl":widgetGet['txt_SwitchControl'],
					"FKSource":widgetGet['txt_FKSource'],
					"FKTarget":widgetGet['txt_FKTarget'],
					"IKSource":widgetGet['txt_IKSource'],
					"IKTarget":widgetGet['txt_IKTarget'],
				}
			else:
				self.snapIKFKSetting.pop(name)
				self.snapIKFKSetting[widgetGet['txt_Name']] = {
					"SwitchControl":widgetGet['txt_SwitchControl'],
					"FKSource":widgetGet['txt_FKSource'],
					"FKTarget":widgetGet['txt_FKTarget'],
					"IKSource":widgetGet['txt_IKSource'],
					"IKTarget":widgetGet['txt_IKTarget'],
				}
		self.Clear()
		self.LoadItems(self.widgetInput['list_Items'])

	def Ok(self):
		string = json.dumps(self.snapIKFKSetting, indent=4)
		self.controlRig.remove_member_variable('NLTA_SnapIKFK')
		self.controlRig.add_member_variable('NLTA_SnapIKFK', 'FString',True,False,string)
		#seletedElements = NLTA_ControlRigCore.GetSelectedElements(self.controlRig)
		#print(seletedElements)

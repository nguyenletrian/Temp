import unreal
from importlib import *
import NLTA_general
reload(NLTA_general)
import NLTA_Asset
reload(NLTA_Asset)

assets = NLTA_Asset.Selected()
if assets and isinstance(assets[0],unreal.ControlRigBlueprint):
	NLTA_general.openWindow({
		"controller":"NLTA_Ctrl_SettingSnapIKFK"
	})		
else:
	unreal.EditorDialog.show_message("Warning","Please select a control rig asset!~ :D",unreal.AppMsgType.OK)
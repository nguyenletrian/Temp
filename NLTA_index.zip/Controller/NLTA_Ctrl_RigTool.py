import unreal
import sys
import os
import shutil
import subprocess
from importlib import *
from PySide2 import QtUiTools, QtWidgets
from PySide2.QtWidgets import QMessageBox, QMenu, QTreeWidgetItem,QTreeWidgetItemIterator
from PySide2 import QtCore
from PySide2 import QtGui
from functools import partial

import time

import NLTA_general, NLTA_Asset, NLTA_ControlRig, NLTA_ControlRigGeneral, NLTA_ControlRigSupport
reload(NLTA_general)
reload(NLTA_Asset)
reload(NLTA_ControlRig)
reload(NLTA_ControlRigGeneral)
reload(NLTA_ControlRigSupport)




session = {
	"parent":None,
	"currentItem":"root",
	"items":{}
}

class CreateWindow(QtWidgets.QWidget):
	window = None
	def __init__(self,parent=None):
		super(CreateWindow,self).__init__(parent)
		
		self.toolPath = NLTA_general.getToolPath()
		self.dataPath = NLTA_general.getDataPath()
		self.shapeTemp = self.dataPath + "ControlRig/shapeTemp.json"

		self.widget = QtUiTools.QUiLoader().load(self.toolPath+"View/NLTA_RigTool.ui")
		self.widget.setParent(self)


		self.tree_Items = self.widget.findChild(QtWidgets.QTreeWidget,'tree_Items')
		self.tree_Items.setHeaderHidden(True)
		self.tree_Items.itemClicked.connect(self.ItemClick)
		self.tree_Items.setContextMenuPolicy(QtCore.Qt.CustomContextMenu)
		self.tree_Items.customContextMenuRequested.connect(self.ItemRightClick)
		self.LoadItems()

		self.list_Form = self.widget.findChild(QtWidgets.QVBoxLayout,'list_Form')

		self.txt_Name = self.widget.findChild(QtWidgets.QLineEdit,'txt_Name')
		self.Detect()

		self.btn_Ok = self.widget.findChild(QtWidgets.QPushButton,'btn_Ok')
		self.btn_Ok.clicked.connect(self.Ok)
		self.btn_Clear = self.widget.findChild(QtWidgets.QPushButton,'btn_Clear')
		self.btn_Clear.clicked.connect(self.Clear)
		self.btn_Export = self.widget.findChild(QtWidgets.QPushButton,'btn_Export')
		self.btn_Export.clicked.connect(self.Export)
		self.btn_Import = self.widget.findChild(QtWidgets.QPushButton,'btn_Import')
		self.btn_Import.clicked.connect(self.Import)
		self.btn_ExportCurve = self.widget.findChild(QtWidgets.QPushButton,'btn_ExportCurve')
		self.btn_ExportCurve.clicked.connect(partial(self.ExportCurve,True))
		self.btn_ImportCurve = self.widget.findChild(QtWidgets.QPushButton,'btn_ImportCurve')
		self.btn_ImportCurve.clicked.connect(partial(self.ImportCurve,True))

		self.btn_SetParent = self.widget.findChild(QtWidgets.QPushButton,'btn_SetParent')
		self.btn_SetParent.clicked.connect(self.SetParent)

	def resizeEvent(self,event):
		self.widget.resize(self.width(),self.height())
	
	def closeWindow(self):
		self.destroy()
		NLTA_general.openWindow({
			"controller":"NLTA_MainWindow",
			"posX":self.pos().x(),
			"posY":self.pos().y()
		})

	def Detect(self):
		global session
		assets = NLTA_Asset.Selected()
		for asset in assets:
			if isinstance(asset,unreal.ControlRigBlueprint):
				path = asset.get_path_name()
				self.txt_Name.setText(path)
				self.controlRig = asset
				unreal.AssetToolsHelpers.get_asset_tools().open_editor_for_assets([asset])
				session["controlRig"] = path

	def ClearForm(self):
		for i in reversed(range(self.list_Form.count())):
			self.list_Form.itemAt(i).widget().deleteLater()

	def Choice(self,inputArray):
		hierarchy = self.controlRig.hierarchy
		controller = hierarchy.get_controller()
		selectedObject = hierarchy.get_selected_keys()
		for order in range(len(selectedObject)):
			selectedName = str(selectedObject[order].name)
			inputArray[order].setText(selectedName)

	def ChoiceList(self,input_):
		hierarchy = self.controlRig.hierarchy
		controller = hierarchy.get_controller()
		selectedObject = hierarchy.get_selected_keys()
		nameArray = []
		for order in range(len(selectedObject)):
			selectedName = str(selectedObject[order].name)
			nameArray.append(selectedName)
		input_.setText((";").join(nameArray))

	def LoadItems(self):
		self.tree_Items.clear()
		items = []
		currentItem = None
		for item in session["items"]:
			session["items"][item]["treeWidget"] = QTreeWidgetItem([item])
			if item == session["currentItem"]:
				currentItem = session["items"][item]["treeWidget"]
		for item in session["items"]:
			if session["items"][item]["parent"]!=None:
				parent = session["items"][item]["parent"]
				session["items"][parent]["treeWidget"].addChild(session["items"][item]["treeWidget"])
			items.append(session["items"][item]["treeWidget"])
		self.tree_Items.insertTopLevelItems(0,items)
		if currentItem!=None:
			self.tree_Items.setCurrentItem(currentItem)

	def ItemClick(self,item,col):
		text = self.tree_Items.selectedItems()[0].text(0)
		session["parent"]=session["items"][text]["parent"]
		session["currentItem"] = text
		type_ =  session["items"][text]["type"]
		self.Detail(type_)

	def ItemRightClick(self,point):
		global session
		selectedItems = self.tree_Items.selectedItems()
		if len(selectedItems)!=0:
			text = self.tree_Items.selectedItems()[0].text(0)
			session["parent"] = text
			session["currentItem"] = text
		else:
			session["parent"] = None
			session["currentItem"] = None
		menu = QMenu(self)
		menu.addAction("Add Single",partial(self.Add,"Single"))
		menu.addAction("Add IK",partial(self.Add,"IK"))
		
		menu.addSeparator()
		menu.addAction("Delete",self.DeleteModule)
		menu.exec_(QtGui.QCursor.pos())

	def DeleteModule(self):
		global session
		itemData =  session["items"][session["currentItem"]]
		itemType = itemData["type"]
		session["items"].pop(session["currentItem"])
		children = []
		for item in session["items"]:
			if session["items"][item]["parent"]==session["currentItem"]:
				children.append(item)
		for item in children:
			session["items"].pop(item)
		self.ClearForm()
		self.LoadItems()

	def ItemOk(self,inputData):		
		global session
		widget = inputData["widget"]
		type_ = inputData["type"]
		valueData = NLTA_general.WidgetGet(widget)
		name = valueData["txt_Name"]
		if name!="":
			valueTemp = {}
			for inputElement in valueData:
				if valueData[inputElement] != None:
					valueTemp[inputElement] = valueData[inputElement]			
			session["items"][name] = {
				"parent":session["parent"],
				"type":type_,
				"value":valueTemp,				
			}
			session["currentItem"] = name
			widget.deleteLater()
			self.ClearForm()
			self.LoadItems()
		else:
			print("Please fille the name!~ ")

	def Add(self,type_):
		exec('self.'+type_+'Form()')

	def Detail(self,type_):
		if type_ == "IK":
			widgetData = self.IKForm()
		if type_ == "Single":
			widgetData = self.SingleForm()
		value = session["items"][session["currentItem"]]["value"]
		NLTA_general.WidgetSet({"widget":widgetData,"value":value})

	def SettingForm(self):
		self.ClearForm()
		pattern = self.toolPath+"View/NLTA_RigTool_ItemRoot.ui"
		widget = QtUiTools.QUiLoader().load(pattern)
		widgetData = NLTA_general.WidgetInput(widget)
		widgetData["btn_ChoicePelvis"].clicked.connect(partial(self.Choice,[widgetData['btn_ChoicePelvis']]))
		self.list_Form.addWidget(widget)

	def IKForm(self):
		self.ClearForm()
		pattern = self.toolPath+"View/NLTA_RigTool_ItemIk.ui"
		widget = QtUiTools.QUiLoader().load(pattern)
		widgetData = NLTA_general.WidgetInput(widget)
		
		controls = [None,"Root_Control_NLTA"]
		if session["parent"]!=None:
			controls.extend(NLTA_ControlRigSupport.GetListControl(session["items"][session["parent"]]))		
		NLTA_general.reloadComboBox(widgetData["cbx_BeforeParent"],controls)
		
		widgetData["btn_ChoiceBone1"].clicked.connect(partial(self.Choice,[widgetData["txt_Bone1"],widgetData["txt_Bone2"],widgetData["txt_Bone3"],]))
		widgetData["btn_ChoiceBone2"].clicked.connect(partial(self.Choice,[widgetData["txt_Bone2"],widgetData["txt_Bone3"],]))
		widgetData["btn_ChoiceBone3"].clicked.connect(partial(self.Choice,[widgetData["txt_Bone3"],]))		
		widgetData["btn_Ok"].clicked.connect(partial(self.ItemOk,{"widget":widget,"type":"IK"}))
		self.list_Form.addWidget(widget)
		return(widgetData)

	def SingleForm(self):
		self.ClearForm()
		pattern = self.toolPath+"View/NLTA_RigTool_ItemSingle.ui"
		widget = QtUiTools.QUiLoader().load(pattern)
		widgetData = NLTA_general.WidgetInput(widget)
		
		controls = [None,"Root_Control_NLTA"]
		if session["parent"]!=None:
			controls.extend(NLTA_ControlRigSupport.GetListControl(session["items"][session["parent"]]))		
		NLTA_general.reloadComboBox(widgetData["cbx_BeforeParent"],controls)

		widgetData["btn_Choice"].clicked.connect(partial(self.ChoiceList,widgetData["txt_Bone"]))
		widgetData["btn_Ok"].clicked.connect(partial(self.ItemOk,{"widget":widget,"type":"Single"}))
		self.list_Form.addWidget(widget)
		return(widgetData)

	############
	def Ok(self):
		if self.controlRig!=None:
			self.ExportCurve(False)
			NLTA_ControlRig.CreateAll(session)
			self.ImportCurve(False)

	def Export(self):
		url = NLTA_general.DirectoryDialog(self)
		sessionData = session.copy()
		for item in sessionData["items"]:
			sessionData["items"][item]["treeWidget"] = ""
		if url !="":
			NLTA_general.writeJson(
				url+"/RigSetting.json",
				sessionData
			)

	def Import(self):
		global session
		url = NLTA_general.FileDialog(self)[0]
		sessionTemp = NLTA_general.readJson(url)
		sessionTemp["controlRig"] = session["controlRig"]
		session = sessionTemp
		self.LoadItems()

	def ExportCurve(self,url):
		if url == True:
			url = NLTA_general.DirectoryDialog(self)
			if url != "":
				self.ExportCurveBasic(url+"/CurveData.json")
		else:
			self.ExportCurveBasic(self.shapeTemp)

	def ExportCurveBasic(self,url):
		hierarchy = self.controlRig.hierarchy
		controller = hierarchy.get_controller()
		controls =  hierarchy.get_controls()
		data = {}
		for control in controls:
			controlSetting = controller.get_control_settings(control)
			controlName = str(controlSetting.display_name)
			dataTemp = {}
			dataTemp["display_name"] = controlName
			dataTemp["shape_name"] = str(controlSetting.shape_name)

			dataTemp["shape_color"] = {
				"a":controlSetting.shape_color.a,
				"b":controlSetting.shape_color.b,
				"g":controlSetting.shape_color.g,
				"r":controlSetting.shape_color.r
			}

			
			shapeTransform  = NLTA_ControlRigGeneral.GetShapeTransform({
				"controlRig":self.controlRig,
				"control":control,
			})
			returnScale = hierarchy.get_global_control_shape_transform(control)
			dataTemp["shape_transform"] = {
				"translation":{
					"x":shapeTransform.translation.x,
					"y":shapeTransform.translation.y,
					"z":shapeTransform.translation.z
				},
				"rotation":{
					"x":shapeTransform.rotation.x,
					"y":shapeTransform.rotation.y,
					"z":shapeTransform.rotation.z,
					"w":shapeTransform.rotation.w,
				},
				"scale3d":{
					"x":returnScale.scale3d.x,
					"y":returnScale.scale3d.y,
					"z":returnScale.scale3d.z
				}
			}
			data[controlName] = dataTemp
		NLTA_general.writeJson(
			url,
			data
		)
	
	def ImportCurve(self,url):
		if url == True:
			url = NLTA_general.FileDialog(self)[0]
			if url != "":
				self.ImportCurveBasic(url)
		else:
			self.ImportCurveBasic(self.shapeTemp)


	def ImportCurveBasic(self,url):
		data = NLTA_general.readJson(url)
		execute_context = unreal.ControlRigExecuteContext()
		control_name =  "Spine_FK_spine_01_NLTA"
		transform = unreal.Transform(location=[0,0,0],rotation=[0,0,0],scale=[1,1,1])
		set_shape_transfrom = unreal.RigUnit_SetShapeTransform(
			execute_context =  execute_context,
			control = control_name,
			transform =  transform
		)
		hierarchy = self.controlRig.hierarchy
		controller = hierarchy.get_controller()

		for controlName in data:
			controlData = data[controlName]
			control = unreal.RigElementKey(type=unreal.RigElementType.CONTROL, name=controlName)

			controlSetting = controller.get_control_settings(control)
			controlSetting.shape_name = controlData["shape_name"]			
			controlSetting.shape_color = unreal.LinearColor(
				r=controlData["shape_color"]["r"],
				g=controlData["shape_color"]["g"],
				b=controlData["shape_color"]["b"],
				a=controlData["shape_color"]["a"],
			)
			controller.set_control_settings(control,controlSetting)
			hierarchy.set_control_shape_transform(control,unreal.Transform(
				location = unreal.Vector(
					controlData["shape_transform"]["translation"]["x"],
					controlData["shape_transform"]["translation"]["y"],
					controlData["shape_transform"]["translation"]["z"],
				),
				rotation = unreal.Quat(
					x = controlData["shape_transform"]["rotation"]["x"],
					y = controlData["shape_transform"]["rotation"]["y"],
					z = controlData["shape_transform"]["rotation"]["z"],
					w = controlData["shape_transform"]["rotation"]["w"],
				).rotator(),
				scale = unreal.Vector(
					controlData["shape_transform"]["scale3d"]["x"],
					controlData["shape_transform"]["scale3d"]["y"],
					controlData["shape_transform"]["scale3d"]["z"],
				),
			),True)

	def Clear(self):
		NLTA_ControlRigGeneral.ClearAll(self.controlRig)

	def SetParent(self):
		hierarchy = self.controlRig.hierarchy
		controller = hierarchy.get_controller()
		selectedObject = hierarchy.get_selected_keys()
		object0 = selectedObject[0]
		object1 = selectedObject[1]
		NLTA_ControlRigGeneral.SetParent({
			"controlRig":self.controlRig,
			"parent":object0,
			"child":object1
		})

	def MirrorControl(self):
		hierarchy = self.controlRig.hierarchy
		controller = hierarchy.get_controller()
		controller.mirror_elements(control,RigVMMirrorSettings)
		mirrorSetting = unreal.RigVMMirrorSettings()
		mirrorSetting.axis_to_flip = unreal.AxisType.X
		mirrorSetting.mirror_axis = unreal.AxisType.X
		mirrorSetting.replace_string = "r"
		mirrorSetting.search_string = "l"





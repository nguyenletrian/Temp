import unreal
import sys
import os
import shutil
import subprocess
import math
from importlib import *
from PySide2 import QtUiTools, QtWidgets
from PySide2.QtWidgets import QMessageBox, QMenu
from functools import partial

import NLTA_general
reload(NLTA_general)
import NLTA_Actor
reload(NLTA_Actor)
import NLTA_RenderPlayback
reload(NLTA_RenderPlayback)
import NLTA_SequenceNew
reload(NLTA_SequenceNew)

class CreateWindow(QtWidgets.QWidget):
	window = None
	def __init__(self,parent=None):
		super(CreateWindow,self).__init__(parent)

		NLTA_RenderPlayback.ClearScene()

		self.toolPath = NLTA_general.getToolPath()
		self.dataPath = NLTA_general.getDataPath()		
		self.widget = QtUiTools.QUiLoader().load(self.toolPath+"View/NLTA_RenderAnimatedCamera.ui")
		self.widget.setParent(self)


		self.btn_Ok = self.widget.findChild(QtWidgets.QPushButton,'btn_Ok')
		self.btn_Ok.clicked.connect(self.Ok)
		self.btn_Open = self.widget.findChild(QtWidgets.QPushButton,'btn_Open')
		self.btn_Open.clicked.connect(self.Open)
		self.btn_Setting = self.widget.findChild(QtWidgets.QPushButton,'btn_Setting')
		self.btn_Setting.clicked.connect(self.Setting)

	def resizeEvent(self,event):
		self.widget.resize(self.width(),self.height())
	
	def closeWindow(self):
		self.destroy()
		NLTA_general.openWindow({
			"controller":"NLTA_MainWindow",			
			"posX":self.pos().x(),
			"posY":self.pos().y()
		})

	def Open(self):
		renderSetting = NLTA_general.getSession("renderSetting")
		os.startfile(renderSetting["outputFolder"])

	def Setting(self):
		NLTA_general.openWindow({
			"controller":"NLTA_Ctrl_RenderSetting",
			"popup":True,	
			"posX":self.pos().x(),
			"posY":self.pos().y()
		})

	def Ok(self):
		data = NLTA_SequenceNew.getSequenceData()
		if "sequence" in data:
			actors = NLTA_Actor.SelectedActors()
			if len(actors)!=0 and isinstance(actors[0],unreal.CineCameraActor):
				NLTA_RenderPlayback.RenderAnimatedCamera()
			else:
				NLTA_general.createMessageBox({
					"text":"Please Open a sequence and Select a animated camera!~",
					"title":"Warning",
					"buttons":["Cancel"]
				})	

		








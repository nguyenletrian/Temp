import unreal
import sys
import os
from importlib import *
from PySide2 import QtUiTools, QtWidgets
from PySide2.QtWidgets import QMessageBox,QMenu
from PySide2.QtCore import *
from PySide2.QtGui import *

from functools import partial

import NLTA_general
reload(NLTA_general)
import NLTA_SequenceNew
reload(NLTA_SequenceNew)
import NLTA_RenderPlayback
reload(NLTA_RenderPlayback)
import NLTA_Actor
reload(NLTA_Actor)

class CreateWindow(QtWidgets.QWidget):
	window = None
	def __init__(self,parent=None):
		super(CreateWindow,self).__init__(parent)
		

		NLTA_Actor.DeleteActor("NLTA_RenderGroup")

		self.toolPath = NLTA_general.getToolPath()
		self.dataPath = NLTA_general.getDataPath()
		self.widget = QtUiTools.QUiLoader().load(self.toolPath+"View/NLTA_ImportAnimation.ui")
		self.widget.setParent(self)

		self.widget.setFixedWidth(279)
		self.widget.setFixedHeight(243)

		self.list_Animation = self.widget.findChild(QtWidgets.QVBoxLayout,'list_Animation')
		self.btn_Temp = self.widget.findChild(QtWidgets.QPushButton,'btn_Temp')

		#rootNode = treeModel.invisibleRootItem()
		"""
		
		print(self.tree_Folder)


		"""
		"""
		self.txt_Prefix = self.widget.findChild(QtWidgets.QLineEdit,'txt_Prefix')
		self.btn_PreviewRight = self.widget.findChild(QtWidgets.QPushButton,'btn_PreviewRight')
		self.btn_PreviewLeft = self.widget.findChild(QtWidgets.QPushButton,'btn_PreviewLeft')
		self.btn_PreviewTop = self.widget.findChild(QtWidgets.QPushButton,'btn_PreviewTop')
		self.btn_PreviewFront = self.widget.findChild(QtWidgets.QPushButton,'btn_PreviewFront')
		self.btn_PreviewBack = self.widget.findChild(QtWidgets.QPushButton,'btn_PreviewBack')
		self.btn_PreviewBot = self.widget.findChild(QtWidgets.QPushButton,'btn_PreviewBot')
		self.btn_PreviewPerspective = self.widget.findChild(QtWidgets.QPushButton,'btn_PreviewPerspective')
		self.btn_Preview360Around = self.widget.findChild(QtWidgets.QPushButton,'btn_Preview360Around')
		self.btn_Ok = self.widget.findChild(QtWidgets.QPushButton,'btn_Ok')
		self.btn_OpenRender = self.widget.findChild(QtWidgets.QPushButton,'btn_OpenRender')
		self.ac_Save = self.widget.findChild(QtWidgets.QAction,'ac_Save')
		self.ac_Load = self.widget.findChild(QtWidgets.QAction,'ac_Load')
		#self.btn_Save = self.widget.findChild(QtWidgets.QPushButton,'btn_Save')
		#self.btn_Load = self.widget.findChild(QtWidgets.QPushButton,'btn_Load')

		self.cbx_CheckRight = self.widget.findChild(QtWidgets.QCheckBox,'cbx_CheckRight')
		self.cbx_CheckLeft = self.widget.findChild(QtWidgets.QCheckBox,'cbx_CheckLeft')
		self.cbx_CheckTop = self.widget.findChild(QtWidgets.QCheckBox,'cbx_CheckTop')
		self.cbx_CheckFront = self.widget.findChild(QtWidgets.QCheckBox,'cbx_CheckFront')
		self.cbx_CheckBack = self.widget.findChild(QtWidgets.QCheckBox,'cbx_CheckBack')
		self.cbx_CheckBot = self.widget.findChild(QtWidgets.QCheckBox,'cbx_CheckBot')
		self.cbx_CheckPerspective = self.widget.findChild(QtWidgets.QCheckBox,'cbx_CheckPerspective')
		self.cbx_Check360Around = self.widget.findChild(QtWidgets.QCheckBox,'cbx_Check360Around')
		
		self.btn_PreviewRight.clicked.connect(partial(self.Preview,"right"))
		self.btn_PreviewLeft.clicked.connect(partial(self.Preview,"left"))
		self.btn_PreviewTop.clicked.connect(partial(self.Preview,"top"))
		self.btn_PreviewFront.clicked.connect(partial(self.Preview,"front"))
		self.btn_PreviewBack.clicked.connect(partial(self.Preview,"back"))
		self.btn_PreviewBot.clicked.connect(partial(self.Preview,"bot"))
		self.btn_PreviewPerspective.clicked.connect(partial(self.Preview,"perspective"))
		self.btn_Preview360Around.clicked.connect(partial(self.Preview,"360Around"))
		self.btn_Ok.clicked.connect(self.Ok)
		self.btn_OpenRender.clicked.connect(self.OpenRender)
		self.ac_Save.triggered.connect(self.Save)
		self.ac_Load.triggered.connect(self.Load)

		NLTA_RenderPlayback.CreateRenderEnvironment()
		"""
		"""
		***************************************
		self.menu = QMenu()
		self.menu.addAction("Action One",self.Test)
		self.btn_Temp.setMenu(self.menu)
		**************************
		"""

		#self.first_mouse_pos = None
		#self.obj_pose = None

		###### button checkable, checked

		###### Set switch IK FK by channel

		###### ControlRigComponent.get_element_names
		###### ControlRigComponent.get_initial_bone_transform
		###### ControlRigComponent.set_control_bool(control_name,value)

	def mousePressEvent(self,QMouseEvent):
		self.first_mouse_pos = QMouseEvent.pos()
		self.oj_pose = self.btn_Temp.pos()
		print(self.oj_pose)

	def mouseReleaseEvent(self,QMouseEvent):
		pass

	def mouseMoveEvent(self,QMouseEvent):
		width_oj = self.btn_Temp.width()
		height_oj = self.btn_Temp.height()
		if self.oj_pose.x() < self.first_mouse_pos.x() < self.oj_pose.x() + width_oj and \
		self.oj_pose.y() < self.first_mouse_pos.y() and  \
		self.first_mouse_pos.y() - 18 < self.oj_pose.y() + height_oj:
			updated_cursor_position = QMouseEvent.pos()
			updated_cursor_x = updated_cursor_position.x() - self.first_mouse_pos.x() + self.oj_pose.x()
			updated_cursor_y = updated_cursor_position.y() - self.first_mouse_pos.y() + self.oj_pose.y()
			self.btn_Temp.move(updated_cursor_x,updated_cursor_y)
		

	def contextMenuEvent(self,event):
		pass
		"""
		context_menu = QMenu(self)
		action1 = context_menu.addAction("Action 1",self.Test)
		action = context_menu.exec_(self.mapToGlobal(event.pos()))
		"""
	def resizeEvent(self,event):
		self.widget.resize(self.width(),self.height())
	
	def closeWindow(self):
		self.destroy()

	def closeEvent(self,event):
		NLTA_RenderPlayback.ClearRender()

	def Test(self):
		print("-----")		

	def Preview(self,view):
		NLTA_RenderPlayback.Pilot(view)

	def Ok(self):
		data = {
			"view":{
				"right":self.cbx_CheckRight.isChecked(),
				"left":self.cbx_CheckLeft.isChecked(),
				"top":self.cbx_CheckTop.isChecked(),
				"front":self.cbx_CheckFront.isChecked(),
				"back":self.cbx_CheckBack.isChecked(),
				"bot":self.cbx_CheckBot.isChecked(),
				"perspective":self.cbx_CheckPerspective.isChecked(),
				"360Around":self.cbx_Check360Around.isChecked(),	
			},
			"prefix":self.txt_Prefix.text()
		}
		NLTA_RenderPlayback.RenderPlayback(data)

	def Clear(self):
		self.cbx_CheckRight.setChecked(False)
		self.cbx_CheckLeft.setChecked(False)
		self.cbx_CheckTop.setChecked(False)
		self.cbx_CheckFront.setChecked(False)
		self.cbx_CheckBack.setChecked(False)
		self.cbx_CheckBot.setChecked(False)
		self.cbx_CheckPerspective.setChecked(False)
		self.cbx_Check360Around.setChecked(False)
		self.txt_Prefix.clear()

	def OpenRender(self):
		url = NLTA_general.getDataPath()+"RenderPlayback/"
		os.startfile(url)

	def Save(self):
		folder = NLTA_general.DirectoryDialog(self)
		NLTA_RenderPlayback.Save(folder)

	def Load(self):
		file = NLTA_general.FileDialog(self)
		NLTA_RenderPlayback.Load(file[0])
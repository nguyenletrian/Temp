import unreal
import sys
import os
import shutil
import subprocess
import math
from importlib import *
from PySide2 import QtUiTools, QtWidgets
from PySide2.QtWidgets import QMessageBox, QMenu
from functools import partial

import NLTA_general
reload(NLTA_general)
import NLTA_Actor
reload(NLTA_Actor)
import NLTA_RenderPlayback
reload(NLTA_RenderPlayback)
import NLTA_SequenceNew
reload(NLTA_SequenceNew)

class CreateWindow(QtWidgets.QWidget):
	window = None
	def __init__(self,parent=None):
		super(CreateWindow,self).__init__(parent)

		self.toolPath = NLTA_general.getToolPath()
		self.dataPath = NLTA_general.getDataPath()		
		self.widget = QtUiTools.QUiLoader().load(self.toolPath+"View/NLTA_RenderWindow.ui")
		self.widget.setParent(self)
		NLTA_RenderPlayback.CheckRenderSetting()
		self.renderSetting = NLTA_general.getSession("renderSetting")

		self.btn_Ok = self.widget.findChild(QtWidgets.QPushButton,'btn_Ok')
		self.btn_Ok.clicked.connect(self.Ok)

		self.btn_Resolution1980_1080 = self.widget.findChild(QtWidgets.QPushButton,'btn_Resolution1980_1080')
		self.btn_Resolution1980_1080.clicked.connect(partial(self.Resolution,[1980,1080]))

		self.btn_Resolution1280_720 = self.widget.findChild(QtWidgets.QPushButton,'btn_Resolution1280_720')
		self.btn_Resolution1280_720.clicked.connect(partial(self.Resolution,[1280,720]))

		self.txt_Name = self.widget.findChild(QtWidgets.QLineEdit,'txt_Name')
		self.txt_Name.setText(self.renderSetting["name"])

		self.txt_Path = self.widget.findChild(QtWidgets.QLineEdit,'txt_Path')
		self.txt_Path.setText(self.renderSetting["outputFolder"])

		self.btn_ChoosePath = self.widget.findChild(QtWidgets.QPushButton,'btn_ChoosePath')
		self.btn_ChoosePath.clicked.connect(self.ChoosePath)

		self.spin_FrameStart = self.widget.findChild(QtWidgets.QSpinBox,'spin_FrameStart')
		self.spin_FrameStart.setValue(self.renderSetting["frameStart"])
		self.spin_FrameEnd = self.widget.findChild(QtWidgets.QSpinBox,'spin_FrameEnd')
		self.spin_FrameEnd.setValue(self.renderSetting["frameEnd"])

		self.spin_ResolutionWidth = self.widget.findChild(QtWidgets.QSpinBox,'spin_ResolutionWidth')
		self.spin_ResolutionWidth.setValue(self.renderSetting["resolution"][0])
		self.spin_ResolutionHeight= self.widget.findChild(QtWidgets.QSpinBox,'spin_ResolutionHeight')
		self.spin_ResolutionHeight.setValue(self.renderSetting["resolution"][1])

		"""
		self.spin_SensorWidth = self.widget.findChild(QtWidgets.QDoubleSpinBox,'spin_SensorWidth')
		self.spin_SensorWidth.setValue(self.renderSetting["sensor"][0])
		self.spin_SensorHeight= self.widget.findChild(QtWidgets.QDoubleSpinBox,'spin_SensorHeight')
		self.spin_SensorHeight.setValue(self.renderSetting["sensor"][1])
		"""

		self.spin_FrameRate= self.widget.findChild(QtWidgets.QSpinBox,'spin_FrameRate')
		self.spin_FrameRate.setValue(self.renderSetting["frameRate"])

		self.cbx_Type = self.widget.findChild(QtWidgets.QComboBox,'cbx_Type')
		self.cbx_Type.setCurrentText(self.renderSetting["outputType"])

		self.chx_BurnIn = self.widget.findChild(QtWidgets.QCheckBox,'chx_BurnIn')
		if self.renderSetting["burnIn"] == "True":
			self.chx_BurnIn.setChecked(True)
		else:
			self.chx_BurnIn.setChecked(False)

	def resizeEvent(self,event):
		self.widget.resize(self.width(),self.height())
	
	def closeWindow(self):
		self.destroy()

	def ChoosePath(self):
		path = NLTA_general.DirectoryDialog(self)
		if path!="":
			self.txt_Path.setText(path)

	def Resolution(self,inputData):
		self.spin_ResolutionWidth.setValue(inputData[0])
		self.spin_ResolutionHeight.setValue(inputData[1])
		pass

	def Ok(self):
		renderSetting = NLTA_general.getSession("renderSetting")
		renderSetting["name"] = self.txt_Name.text()
		renderSetting["frameStart"] = self.spin_FrameStart.value()
		renderSetting["frameEnd"] = self.spin_FrameEnd.value()
		renderSetting["frameRate"] = self.spin_FrameRate.value()
		renderSetting["resolution"] = [self.spin_ResolutionWidth.value(),self.spin_ResolutionHeight.value()]
		#renderSetting["sensor"] = [self.spin_SensorWidth.value(),self.spin_SensorHeight.value()]
		renderSetting["outputFolder"] = self.txt_Path.text()
		renderSetting["outputType"] = self.cbx_Type.currentText()
		
		if self.chx_BurnIn.isChecked() == True:
			renderSetting["burnIn"] = "True"
		else:
			renderSetting["burnIn"] = "False"
		NLTA_general.setSession("renderSetting",renderSetting)
		self.closeWindow()








import maya.cmds as cmds
import pymel.core as pm

def ChangeOpacity(ui,*arr):
    value = cmds.floatSliderGrp(ui,query=True,value=True)
    ctx = cmds.currentCtx()
    try:
        cmds.artAttrSkinPaintCtx(ctx, e=True, opacity=value)
    except:pass

def ChangeOpacityValue(ui,value,*arr):
    cmds.floatSliderGrp(ui,edit=True,value=value)
    ChangeOpacity(ui)      
    
def replaceWeight(value,*arr):
    pm.mel.eval("artAttrSkinPaintModePaintSelect 1 artAttrSkinPaintCtx;")
    pm.mel.eval("artAttrPaintOperation artAttrSkinPaintCtx Replace;")
    pm.mel.eval("artSkinSetSelectionValue "+str(value)+" false artAttrSkinPaintCtx artAttrSkin;")
    if value == 0:
        ctx = cmds.currentCtx()
        cmds.artAttrSkinPaintCtx(ctx, e=True, opacity=1)
    elif value in [-1,1]:
        ctx = cmds.currentCtx()
        cmds.artAttrSkinPaintCtx(ctx, e=True, opacity=0.005)
    
def addWeight(value,*arr):
    pm.mel.eval("artAttrSkinPaintModePaintSelect 1 artAttrSkinPaintCtx;")
    pm.mel.eval("artAttrPaintOperation artAttrSkinPaintCtx Add;")
    pm.mel.eval("artSkinSetSelectionValue "+str(value)+" false artAttrSkinPaintCtx artAttrSkin;")

def smooth(value,*arr):
    pm.mel.eval("artAttrSkinPaintModePaintSelect 1 artAttrSkinPaintCtx;")
    pm.mel.eval("artUpdateStampProfile "+value+" artAttrSkinPaintCtx;")
    pm.mel.eval("artAttrPaintOperation artAttrSkinPaintCtx Smooth;")
    ctx = cmds.currentCtx()
    cmds.artAttrSkinPaintCtx(ctx, e=True, opacity=1)    

def pickValue(*arr):
    pm.mel.eval("artAttrPaintOperation artAttrSkinPaintCtx Replace;")
    pm.mel.eval("artAttrSkinPaintCtx -e -pickValue `currentCtx`;")

def flood(*arr):
    pm.mel.eval("artAttrSkinPaintModePaintSelect 1 artAttrSkinPaintCtx;")
    pm.mel.eval('artAttrSkinPaintCtx -e -clear `currentCtx`;')
    
def CopyWeight(*arr):
    selection = cmds.ls(flatten=True,os=True)
    source = selection[0]
    destination =  selection[1:]
    cmds.select(source)
    pm.mel.eval('CopyVertexSkinWeights;')
    cmds.select(destination)
    pm.mel.eval('PasteVertexSkinWeights;')


import maya.cmds as cmds
import importlib
import pymel.core as pm
import math
import maya.api.OpenMaya as om

import NLTA_OpenMaya,NLTA_General
importlib.reload(NLTA_General)
importlib.reload(NLTA_OpenMaya)

def ShowQuardraw(*arr):
    pm.mel.eval('lockNode -l off  -lockUnpublished off initialShadingGroup;')

def EdgeDirection(mesh, edgeIndex):
    mesh_path = NLTA_OpenMaya.GetDagPath(mesh)
    edge_it = om.MItMeshEdge(mesh_path)
    edge_it.setIndex(edgeIndex)
    p1 = edge_it.point(0, om.MSpace.kWorld)
    p2 = edge_it.point(1, om.MSpace.kWorld)
    v = om.MVector(p2 - p1)
    return v.normal()

def CheckEdgeBorder(mesh, edgeId):
    dag = NLTA_OpenMaya.GetDagPath(mesh)
    it = om.MItMeshEdge(dag)
    it.setIndex(edgeId)
    return(it.onBoundary())

def JointPos(j):
    return om.MVector(cmds.xform(j, q=True, ws=True, t=True))

def GetID(component):
    if isinstance(component, (int, float)):
        return(component)
    else:
        return(
            int(component.split("[")[-1].replace("]", ""))
        )

def GetJointAxis(joint):
    m = cmds.xform(joint, q=True, ws=True, m=True)
    axis = om.MVector(m[0], m[1], m[2])
    return axis.normal()

def GetClosestVertex(mesh, joint):
    mesh_path = NLTA_OpenMaya.GetDagPath(mesh)
    mesh_fn = om.MFnMesh(mesh_path)
    JointPos = cmds.xform(joint, q=True, ws=True, t=True)
    point = om.MPoint(JointPos)
    closest_point, face_id = mesh_fn.getClosestPoint(point, om.MSpace.kWorld)
    vertices = mesh_fn.getPoints(om.MSpace.kWorld)
    min_dist = float("inf")
    closest_index = -1
    for i, v in enumerate(vertices):
        dist = (v - closest_point).length()
        if dist < min_dist:
            min_dist = dist
            closest_index = i
    return closest_index

def GetEdgeLoop(mesh, start_edge):
    returnData = []
    edges = cmds.polySelect(mesh, edgeLoop=GetID(start_edge), noSelection=True)
    for edge in edges:
        returnData.append(f"{mesh}.e[{edge}]")
    return(returnData)

def GetEdgeRing(mesh, start_edge):
    returnData = []
    edges = cmds.polySelect(mesh, edgeRing=GetID(start_edge), noSelection=True)
    for edge in edges:
        returnData.append(f"{mesh}.e[{edge}]")
    return(returnData)

def VertexFromEdges(mesh, edges):
    dag = NLTA_OpenMaya.GetDagPath(mesh)
    it = om.MItMeshEdge(dag)
    verts = set()
    for edge in edges:
        eid = GetID(edge)
        it.setIndex(eid)

        v1 = it.vertexId(0)
        v2 = it.vertexId(1)

        verts.add(v1)
        verts.add(v2)
    return [f"{mesh}.vtx[{v}]" for v in verts]

def GetConnectedEdges(mesh,vertex_index):
    mesh_path = NLTA_OpenMaya.GetDagPath(mesh)
    vert_it = om.MItMeshVertex(mesh_path)
    vert_it.setIndex(vertex_index)
    return vert_it.getConnectedEdges()

def GetBestEdge(mesh, joint, vertex_index):
    joint_axis = GetJointAxis(joint)
    edges = GetConnectedEdges(mesh, vertex_index)
    best_edge = None
    best_dot = -1
    for e in edges:
        dir_vec = EdgeDirection(mesh, e)
        dot = abs(dir_vec * joint_axis)
        if dot > best_dot:
            best_dot = dot
            best_edge = e
    return best_edge

def GetBestEdgeLoop(mesh, joint,vtxIndex):
    best_edge = GetBestEdge(mesh, joint, vtxIndex)
    if best_edge is None:
        cmds.warning("No edge found")
        return
    return(GetEdgeLoop(mesh, best_edge))

def GetPerpendicularEdge(mesh, joint, vertex_index):
    joint_axis = GetJointAxis(joint)
    edges = GetConnectedEdges(mesh, vertex_index)
    best_edge = None
    best_dot = 999
    for e in edges:
        dir_vec = EdgeDirection(mesh, e)
        dot = abs(dir_vec * joint_axis)
        if dot < best_dot:
            best_dot = dot
            best_edge = e
    return best_edge

def GetPerpendicularEdgeLoop(mesh, joint,vtxIndex):
    best_edge = GetPerpendicularEdge(mesh, joint, vtxIndex)
    if best_edge is None:
        cmds.warning("No edge found")
        return
    return(GetEdgeLoop(mesh, best_edge))

def GetTwoClosestJoints(targetJoint, joints):
    distances = []
    for j in joints:
        if j == targetJoint:
            continue
        dist = NLTA_General.GetDistance(targetJoint,j)
        distances.append((j, dist))
    distances.sort(key=lambda x: x[1])
    return distances[:2]

def SelectVerticesWithinRadius(mesh,joint,verts,radius):
    p0 = JointPos(joint)
    result = []
    for v in verts:
        pos = om.MVector(cmds.pointPosition(v, w=True))
        d = (pos - p0).length()
        if d <= radius:
            result.append(v)
    return(result)
    
def SelectLoopRegion(mesh, joint,joints,verts):
    closest = GetTwoClosestJoints(joint, joints)
    d1 = closest[0][1]
    d2 = closest[1][1]
    radius = min(d1, d2) * 0.7
    verts = SelectVerticesWithinRadius(mesh, joint,verts,radius)
    return(verts)

def LockJoint(mesh,jnts):
    skinJnts = NLTA_General.GetSkinData(mesh)["joints"]
    for jnt in skinJnts:
        if jnt in jnts:
            cmds.setAttr(jnt+".liw",0)
        else:
            cmds.setAttr(jnt+".liw",1)

def EdgesBetween(mesh, edgeSource,edgeTarget):
    id1 = GetID(edgeSource)
    id2 = GetID(edgeTarget)
    edges = cmds.polySelect(mesh, edgeRingPath=(id1, id2),noSelection=True)
    if edges:
        return [f"{mesh}.e[{i}]" for i in edges]
    return []

def CheckEdgesBetween(mesh, edgeSource, edges):
    id1 = GetID(edgeSource)
    for edge in edges:        
        id2 = GetID(edge)
        edges = cmds.polySelect(mesh, edgeRingPath=(id1, id2),noSelection=True)
        if edges:
            return(edge)
    return []

def EdgeCenter(mesh, edgeId):
    edgeId = GetID(edgeId)
    NLTA_OpenMaya.GetDagPath(mesh)
    it = om.MItMeshEdge(dag)
    it.setIndex(edgeId)
    p1 = om.MVector(it.point(0, om.MSpace.kWorld))
    p2 = om.MVector(it.point(1, om.MSpace.kWorld))
    return (p1 + p2) * 0.5

def EdgeRatioBetweenJoints(mesh, edgeId, jointA, jointB):
    pA = JointPos(jointA)
    pB = JointPos(jointB)
    edgeC = EdgeCenter(mesh, edgeId)
    boneVec = pB - pA
    edgeVec = edgeC - pA
    t = (edgeVec * boneVec) / boneVec.length()**2
    return max(0, min(1, t))

def EdgeRatioBetweenEdges(mesh, edgeMid, edgeA, edgeB):
    pA = EdgeCenter(mesh, edgeA)
    pB = EdgeCenter(mesh, edgeB)
    pC = EdgeCenter(mesh, edgeMid)
    vecAB = pB - pA
    vecAC = pC - pA
    t = (vecAC * vecAB) / vecAB.length()**2
    return max(0, min(1, t))

def GetFarthestEdge(mesh, baseEdge, edges):
    baseId = GetID(baseEdge)
    baseCenter = EdgeCenter(mesh, baseId)
    maxDist = -1
    farEdge = None
    for edge in edges:
        eid = GetID(edge)
        center = EdgeCenter(mesh, eid)
        dist = (center - baseCenter).length()
        if dist > maxDist:
            maxDist = dist
            farEdge = edge
    return farEdge

def GetClosestEdge(mesh, edges, joint):
    jointPos = om.MVector(cmds.xform(joint, q=True, ws=True, t=True))
    minDist = 1e10
    closestEdge = None
    for edge in edges:
        edgeId = GetID(edge)
        center = EdgeCenter(mesh, edgeId)
        dist = (center - jointPos).length()
        if dist < minDist:
            minDist = dist
            closestEdge = edge
    return closestEdge



#########################

def Normalize(v):
    l = math.sqrt(sum(x*x for x in v))
    return v if l == 0 else [x/l for x in v]

def Dot(a, b):
    return sum(a[i]*b[i] for i in range(3))

def GetPos(v):
    return cmds.xform(v, q=True, ws=True, t=True)

def GetConnectVerts(v, vertSet):
    edges = cmds.polyListComponentConversion(v, te=True)
    edges = cmds.ls(edges, fl=True)

    result = []

    for e in edges:
        vs = cmds.polyListComponentConversion(e, tv=True)
        vs = cmds.ls(vs, fl=True)
        for x in vs:
            if x != v and x in vertSet:
                result.append((v, x, e))

    return result

def GetPerpEdge(v1, v2, threshold=0.25):
    p1 = GetPos(v1)
    p2 = GetPos(v2)
    dir_vec = Normalize([p2[i] - p1[i] for i in range(3)])
    edges = cmds.polyListComponentConversion(v1, te=True)
    edges = cmds.ls(edges, fl=True)
    best = None
    best_score = 999
    for e in edges:
        vs = cmds.polyListComponentConversion(e, tv=True)
        vs = cmds.ls(vs, fl=True)
        other = [x for x in vs if x != v1]
        if not other:
            continue
        other = other[0]
        if other == v2:
            continue
        vec = Normalize([GetPos(other)[i] - p1[i] for i in range(3)])
        d = abs(Dot(dir_vec, vec))
        if d < best_score:
            best_score = d
            best = e
    if best_score > threshold:
        return None
    return best

def EdgeLoopToVerts(edge):
    loop_edges = cmds.polySelectSp(edge, loop=True)    
    if not loop_edges:
        return []
    loop_edges = cmds.ls(sl=True, fl=True)
    verts = cmds.polyListComponentConversion(loop_edges, tv=True)
    verts = cmds.ls(verts, fl=True)
    return list(set(verts))


def ListToPerVerts(verts, threshold=0.25):
    returnData = {}
    for v in verts:
        connections = GetConnectVerts(v,verts)
        for (a, b, _) in connections:
            edge = GetPerpEdge(a, b, threshold)
            edgeLoopVerts = EdgeLoopToVerts(edge)
            returnData[v] = edgeLoopVerts
    return(returnData)


def GetIntersectVerts(meshA, meshB, threshold,*arr):
    close_curve=True
    cpm = cmds.createNode("closestPointOnMesh")
    shapeB = cmds.listRelatives(meshB, shapes=True, fullPath=True)[0]
    cmds.connectAttr(f"{shapeB}.worldMesh[0]", f"{cpm}.inMesh", force=True)
    cmds.connectAttr(f"{meshB}.worldMatrix[0]", f"{cpm}.inputMatrix", force=True)
    verts = cmds.ls(f"{meshA}.vtx[*]", fl=True)
    close_verts = []
    for v in verts:
        pos = cmds.pointPosition(v, world=True)
        cmds.setAttr(f"{cpm}.inPosition", *pos, type="double3")
        closest = cmds.getAttr(f"{cpm}.position")[0]
        dist = math.sqrt(sum((pos[i] - closest[i]) ** 2 for i in range(3)))
        if dist <= threshold:
            close_verts.append(v)
    cmds.delete(cpm)
    return(close_verts)
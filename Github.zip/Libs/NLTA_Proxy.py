import json
import importlib
import maya.cmds as cmds
import maya.mel as mel
import maya.api.OpenMaya as om

import NLTA_General,NLTA_Mesh
importlib.reload(NLTA_General)
importlib.reload(NLTA_Mesh)

session = {}
def singleProxy(*arr):
    selection = cmds.ls(selection=True)
    if cmds.objectType(selection[0]) == "mesh":
        mel.eval('ConvertSelectionToFaces;')
        face = cmds.ls(selection=True)
        meshTransform = selection[0].split(".")[0]
        skinCluster = mel.eval('findRelatedSkinCluster '+meshTransform)
        if skinCluster:
            joint = cmds.skinCluster(skinCluster,query=True,inf=True)

        meshNew =  cmds.ls(cmds.duplicate(meshTransform)[0],uuid=True)[0]
        meshNew =  cmds.ls(meshNew,ap=True)[0]
        faceNew = cmds.ls(meshNew+".f[*]")
        arrayTemp = []
        for a in face:
            faceName = a.replace(meshTransform,meshNew)
            arrayTemp.append(faceName)
        cmds.select(faceNew)
        cmds.select(arrayTemp,deselect=True)
        cmds.delete()
        cmds.delete(meshNew,constructionHistory=True)
        if skinCluster:
            cmds.select(joint)
            cmds.select(meshNew,add=True)
            NLTA_General.bindSkin()
            cmds.select(meshTransform)
            cmds.select(meshNew,add=True)
            newSkinCluster = mel.eval('findRelatedSkinCluster '+meshNew)
            mel.eval('copySkinWeights -ss '+skinCluster+' -ds '+newSkinCluster+' -noMirror -surfaceAssociation closestPoint -influenceAssociation closestJoint;')
            cmds.select(meshNew)            
        else:
            cmds.select(meshNew)
        copyProxy()
        cmds.warning("Done!!!")

def createProxy(axis,*arr):
    selection = cmds.ls(selection=True)
    if cmds.objectType(selection[0]) == "mesh":
        mel.eval('ConvertSelectionToFaces;')
        face = cmds.ls(selection=True)
        meshTransform = selection[0].split(".")[0]
        skinCluster = mel.eval('findRelatedSkinCluster '+meshTransform)
        if skinCluster:
            joint = cmds.skinCluster(skinCluster,query=True,inf=True)

        meshNew =  cmds.ls(cmds.duplicate(meshTransform)[0],uuid=True)[0]
        meshNew =  cmds.ls(meshNew,ap=True)[0]
        faceNew = cmds.ls(meshNew+".f[*]")
        arrayTemp = []
        for a in face:
            faceName = a.replace(meshTransform,meshNew)
            arrayTemp.append(faceName)

        cluster = cmds.cluster(arrayTemp)
        axisNegPos = NLTA_General.checkNegPosAxis(cluster,axis)
        if axisNegPos == "-":
            direction = str(0)
        else:
            direction = str(1)
        cmds.delete(cluster)

        axisArray = ["x","y","z"]
        axisIndex = str(axisArray.index(axis))

        cmds.select(faceNew)
        cmds.select(arrayTemp,deselect=True)
        cmds.delete()

        mel.eval('polyMirrorFace  -cutMesh 1 -axis '+axisIndex+' -axisDirection '+direction+' -mergeMode 1 -mergeThresholdType 0 '+meshNew+';')#-mergeThreshold 0.001 
        cmds.delete(meshNew,constructionHistory=True)
        cmds.select(joint)
        cmds.select(meshNew,add=True)
        NLTA_General.bindSkin()
        cmds.select(meshTransform)
        cmds.select(meshNew,add=True)
        
        #mel.eval('copySkinWeights  -noMirror -surfaceAssociation closestPoint -influenceAssociation oneToOne -influenceAssociation closestJoint -normalize;')
        #copySkinWeights -ss skinCluster1 -ds skinCluster16 -noMirror -surfaceAssociation closestComponent -influenceAssociation closestJoint;
        newSkinCluster = mel.eval('findRelatedSkinCluster '+meshNew)
        mel.eval('copySkinWeights -ss '+skinCluster+' -ds '+newSkinCluster+' -noMirror -surfaceAssociation closestComponent -influenceAssociation closestJoint;')
        cmds.select(meshNew)
        copyProxy()
        cmds.warning("Done!!!")

def copyProxy(*arr):
    global session
    selection = cmds.ls(selection=True)
    if cmds.objectType(selection[0]) == "mesh":
        mel.eval('ConvertSelectionToVertices;')
        vertex = cmds.ls(selection=True,flatten=True)
        parentName = selection[0].split(".")[0]
        cmds.select(parentName)
    elif cmds.objectType(selection[0]) == "transform":
        vertex = cmds.ls(selection[0]+".vtx[*]",flatten=True)
        parentName = selection[0]
    session["vertex"] = vertex
    session["mesh"] = parentName

def pastProxy(*arr):
    selection = cmds.ls(selection=True)
    if cmds.objectType(selection[0]) == "mesh":
        mel.eval('ConvertSelectionToVertices;')
        vertex = cmds.ls(selection=True)
        parentName = selection[0].split(".")[0]
        cmds.select(session["vertex"])
        cmds.select(vertex,add=True)
        mel.eval('copySkinWeights  -noMirror -surfaceAssociation closestPoint -influenceAssociation closestJoint -influenceAssociation oneToOne')
    elif cmds.objectType(selection[0]) == "transform":
        for aSelect in selection:
            vertex = cmds.ls(aSelect+".vtx[*]")            
            cmds.select(clear=True)
            cmds.select(session["vertex"])
            cmds.select(vertex,add=True)
            sourceSkinCluster = mel.eval('findRelatedSkinCluster '+session["mesh"])            
            targetSkinCluster = mel.eval('findRelatedSkinCluster '+aSelect)
            mel.eval('copySkinWeights  -ss '+sourceSkinCluster+' -ds '+targetSkinCluster+'  -noMirror -surfaceAssociation closestPoint -influenceAssociation closestJoint -influenceAssociation oneToOne;')
    cmds.select(selection)
    cmds.warning("Done!!!")

def SelectClosetFaces(*arr):
    def get_mesh_fn(mesh):
        sel = om.MSelectionList()
        sel.add(mesh)
        dag = sel.getDagPath(0)
        return om.MFnMesh(dag)

    def get_face_centroids(mesh):
        fn = get_mesh_fn(mesh)
        centroids = {}
        for i in range(fn.numPolygons):
            points = fn.getPolygonVertices(i)
            verts = [om.MVector(fn.getPoint(v, om.MSpace.kWorld)) for v in points]
            c = sum(verts, om.MVector()) / len(verts)
            centroids[i] = c
        return centroids

    def FindMatchingFaces(source,target, tolerance=0.001):
        centA = get_face_centroids(source)
        centB = get_face_centroids(target)
        matches = []
        for fA, cA in centA.items():
            for fB, cB in centB.items():
                if (cA - cB).length() < tolerance:
                    matches.append(fB)
        return matches
    objs = cmds.ls(selection=True)
    source = objs[0]
    targets = objs[1:]
    faces = []
    for target in targets:
        facesID = FindMatchingFaces(source,target)
        for faceID in facesID:
            faces.append(f"{target}.f[{faceID}]")
    cmds.select(faces)



#### RETOPOLOGY
loftAttr = 'NLTA_LoftData'

def GetPositions(objs):
    return([om.MVector(cmds.pointPosition(v, w=True)) for v in objs])

def GetCenter(objs):
    positions = GetPositions(objs)
    center = sum(positions, om.MVector(0, 0, 0)) / len(positions)
    return(center)

def GetFarthest(objs):
    positions = GetPositions(objs)
    center = GetCenter(objs)
    farIndex, farDist = 0,0
    for i, pos in enumerate(positions):
        dist = (pos - center).length()
        if dist > farDist:
            farIndex,farDist = i,dist
    vertexVector = positions[farIndex]
    vectorFromCenter = (vertexVector - center).normalize()
    return({
        'vertexVector':vertexVector,
        'obj':objs[farIndex],
        'distance':farDist,
        'vectorFromCenter':vectorFromCenter,
    })

def GetNormalFromVectors(data):
    vector1 = data['v1']
    vertor2 = data['v2']
    vector3 = data['v3']
    cmds.select(clear=True)
    jnt_center = cmds.joint(name="joint_center", position=(vector1.x,vector1.y,vector1.z))
    cmds.select(clear=True)
    jnt_far = cmds.joint(name="joint_far", position=(vertor2.x,vertor2.y,vertor2.z))
    cmds.select(clear=True)
    jnt_best = cmds.joint(name="joint_best", position=(vector3.x,vector3.y,vector3.z))
    cmds.aimConstraint(
        jnt_far,        
        jnt_center,     
        aimVector=[0,0, 1],         
        upVector=[1, 0, 0],          
        worldUpType="object",       
        worldUpObject=jnt_best      # hướng up theo joint_best
    )
    transform = cmds.xform(jnt_center, q=True, ws=True, m=True) 
    cmds.delete([jnt_far,jnt_center,jnt_best])
    return(transform)

def GetPerpendicular(data):
    center = data['center']
    positions = data['positions']
    vector = data['vector']
    best_dot = float('inf')
    best_index = None
    for i, pos in enumerate(positions):
        vec = (pos - center).normalize()
        dot = abs(vec * vector)
        if dot < best_dot:
            best_dot = dot
            best_index = i
    return(positions[best_index])

def GetNormalFromObjs(verts):
    positions = GetPositions(verts)
    center = GetCenter(verts)
    farthestVertex = GetFarthest(verts)
    farVertexVector = farthestVertex['vertexVector']
    perpendicularVertexVector = GetPerpendicular({
        'vector':farthestVertex['vectorFromCenter'],
        'positions':positions,
        'center':center,
    })
    return(GetNormalFromVectors({'v1':center,'v2':farVertexVector,'v3':perpendicularVertexVector}))

def CorrectCurveAxis(curve):    
    cvs = cmds.ls(curve+".cv[*]", fl=True)
    matrix = GetNormalFromObjs(cvs)
    original_positions = [cmds.xform(cv, worldSpace=True,query=True, translation=True) for cv in cvs]
    cmds.xform(curve, ws=True, m=matrix)
    for cv, pos in zip(cvs, original_positions):
        cmds.xform(cv, ws=True, t=pos)
    cmds.makeIdentity(curve, apply=True, t=True, r=False, s=False, n=0)
    return(curve)

def EdgesToCurve(*arr):
    cmds.polyToCurve(form=0,degree=3,conformToSmoothMeshPreview=True)

def VertsToCurve(*args):
    sel = cmds.ls(sl=True, fl=True)
    verts = cmds.filterExpand(sel, selectionMask=31)
    if not verts:
        cmds.warning("Please select vertices")
        return
    positions = [cmds.pointPosition(v, w=True) for v in verts]
    if len(positions) < 2:
        cmds.warning("Not enough valid points")
        return
    degree = 3 if len(positions) >= 4 else 1
    curve = cmds.curve(name='NLTA_Curve#',degree=degree,point=positions)
    cmds.rebuildCurve(curve,ch=True,rpo=True,rt=0,end=1,kr=0,kcp=False,kep=False,kt=False,s=0,d=3,tol=0.01)
    return curve

def DrawCurve(*arr):
    d = 3
    bez=False
    ctx_name = "myCurveEPContext"    
    if not cmds.contextInfo(ctx_name, exists=True):
        cmds.curveEPCtx(name=ctx_name, d=d, bez=bez)
    else:
        cmds.curveEPCtx(ctx_name, edit=True, d=d, bez=bez)    
    cmds.setToolTo(ctx_name)

def FlipLoftNormal(*arr):
    objs = cmds.ls(selection=True)
    if objs:
        lofData = GetLoftData(objs[0])
        cmds.reverseSurface(cmds.ls(lofData['loft'])[0], direction=0, ch=1)

def FlipCurveNormal(*arr):
    objs= cmds.ls(selection=True)
    if objs:
        for obj in objs:
            cmds.reverseCurve(obj, ch=False, rpo=True)
    cmds.select(objs)

def RotateCVsPositive(*arr):
    objs = cmds.ls(selection=True)
    if objs:
        obj = objs[0]
        cvs = cmds.ls(obj+".cv[*]", fl=True)
        count = len(cvs)
        originPos = [cmds.xform(cv, worldSpace=True,query=True, translation=True) for cv in cvs]
        for i in range(count):
            cmds.xform(cvs[i], ws=True, t=originPos[i-1])

def RotateCVsNegative(*arr):
    objs = cmds.ls(selection=True)
    if objs:
        obj = objs[0]
        cvs = cmds.ls(obj+".cv[*]", fl=True)
        count = len(cvs) 
        originPos = [cmds.xform(cv, worldSpace=True,query=True, translation=True) for cv in cvs]
        for i in range(len(originPos)):
            increaseI = i + 1
            if increaseI !=  len(originPos):
                cvIndex = i
                posIndex = increaseI
            else:
                cvIndex = i
                posIndex = 0
            cmds.xform(cvs[cvIndex], ws=True, t=originPos[posIndex])

def CloseCurve(*arr):
    objs = cmds.ls(selection=True)
    for obj in objs:
        dup = cmds.duplicate(obj, rr=True)[0]
        closed = cmds.closeCurve(dup, ch=False, replaceOriginal=True, preserveShape=False)[0]
        new_shape = cmds.listRelatives(closed, s=True, f=True)[0]
        old_shapes = cmds.listRelatives(obj, s=True, f=True) or []
        cmds.parent(new_shape, obj, shape=True, relative=True)
        for s in old_shapes:
            cmds.delete(s)
        if closed != obj:
            cmds.delete(closed)
        CorrectCurveAxis(obj)
    cmds.select(objs)

def RebuildCurves(curves):
    spans=16
    for c in curves:
        cmds.delete(c, ch=True)  # ✅ Xóa history trước khi rebuild
        cmds.rebuildCurve(c, ch=False, rpo=True, rt=0,
                          end=1, kr=0, kcp=0, kep=1, d=3, s=spans)
def AlignCurvesDirection(curves):
    def get_tangent(curve):
        p0 = om.MVector(cmds.pointPosition(f"{curve}.cv[0]", w=True))
        p1 = om.MVector(cmds.pointPosition(f"{curve}.cv[1]", w=True))
        return (p1 - p0).normalize()
    base_vec = get_tangent(curves[0])
    for c in curves[1:]:
        this_vec = get_tangent(c)
        dot = base_vec * this_vec
        if dot < 0:
            cmds.reverseCurve(c, ch=False, rpo=True)

def CleanCurve(curves):
    RebuildCurves(curves)
    AlignCurvesDirection(curves)

def SetLoftData(obj,data):
    data = {
        'curves':cmds.ls(data['curves'],uuid=True),
        'loft':cmds.ls(data['loft'],uuid=True)[0],
        'poly':cmds.ls(data['poly'],uuid=True)[0],
    }
    dataStr = json.dumps(data)
    if not cmds.attributeQuery(loftAttr, node=obj, exists=True):
        cmds.addAttr(obj, longName=loftAttr, dataType="string")
    cmds.setAttr(obj+"."+loftAttr, dataStr, type="string")

def GetLoftData(obj):
    if cmds.attributeQuery(loftAttr, node=obj, exists=True):
        raw = cmds.getAttr(obj+"."+loftAttr)
        data = json.loads(raw)
        return(data)
    return(None)

def ClearLoftData(obj):
    if cmds.attributeQuery(loftAttr, node=obj, exists=True):
        cmds.deleteAttr(obj+"."+loftAttr)
        shapes = cmds.listRelatives(obj, shapes=True, fullPath=True) or []
        for shape in shapes:
            if cmds.objectType(shape) == "nurbsCurve":
                cmds.setAttr(obj + ".overrideColor",0)
                cmds.setAttr(obj+".overrideDisplayType",0)
                break

def ClearAllLoft(*arr):
    objs = cmds.ls(type='loft')
    for obj in objs:
        if cmds.attributeQuery(loftAttr, node=obj, exists=True):
            data = GetLoftData(obj)
            if cmds.ls(data['poly']) == []:
                cmds.delete(cmds.ls(data['loft'])[0])
                for curve in data['curves']:
                    if cmds.ls(curve):
                        ClearLoftData(cmds.ls(curve)[0])
            else:
                loft = cmds.ls(data['loft'])[0]
                poly = cmds.ls(data['poly'])[0] 
                curves = GetLoftInputCurves(loft)
                for objTemp in  [loft]+[poly]+curves:
                    SetLoftData(objTemp,{
                        'loft':loft,
                        'poly':poly,
                        'curves':curves
                    })

def GetLoftNode(loft):
    history = cmds.listHistory(loft)
    node = next((h for h in history if cmds.nodeType(h) == "loft"), None)
    if node:
        return(node)
    return(None)

def GetLoftInputCurves(loft):
    node = GetLoftNode(loft)
    if node:
        curves = []
        i = 0
        while True:
            plug = node+".inputCurve["+str(i)+"]"
            conn = cmds.connectionInfo(plug,sfd=True)       
            if conn:
                shapeName = conn.split('.')[0]
                transformName = cmds.listRelatives(shapeName,parent=True)[0]
                curves.append(transformName)
            else:
                break
            i += 1
        return(curves)
    return(None)

def CreateLoft(*arr):
    ClearAllLoft()
    curves = cmds.ls(selection=True, type='transform')
    objsSave = curves.copy()
    if len(curves) < 2:
        cmds.warning("Chọn ít nhất 2 curve.")
        return
    CleanCurve(curves)
    result = cmds.loft(curves,ch=True,u=False,c=False,ar=False,d=3,ss=1,rn=False,po=0)
    surface = result[0]
    cmds.setAttr(surface+".hiddenInOutliner", 1)
    cmds.setAttr(surface+".visibility",0)
    objsSave.extend(result)
    poly = cmds.nurbsToPoly(
        surface,
        mnd=1,     # Match Normal Direction
        ch=1,      # Keep history
        f=2,       # Format: quads by number
        pt=1,      # Polygon type: quads
        pc=200,    # Polygon count target (for control)
        chr=0.99,  # chord height ratio
        ft=1,      # fit tolerance
        mel=1,     # merge edge length
        d=1,       # Use chord height
        ut=1,      # Use U divisions
        un=20,     # U number
        vt=1,      # Use V divisions
        vn=20,     # V number
        uch=0,     # use chord height in U (off)
        ucr=0,     # uniform chord ratio in U (off)
        cht=0.2,   # chord height
        es=0,      # edge swap (off)
        ntr=0,     # not trim
        mrt=0,     # merge trimmed surface (off)
        uss=1      # use surface span
    )[0]
    objsSave.append(poly) 
    data = {
        'curves':curves,
        'loft':surface,
        'poly':poly,
    }
    for curve in curves:
        cmds.setAttr(curve + ".overrideColor",17)
    for obj in objsSave:
        SetLoftData(obj,data)
    return(poly)

def AddLoftCurve(*arr):
    ClearAllLoft()    
    objs = cmds.ls(selection=True,ap=True)
    if objs:
        curveReference = None
        for obj in objs:
            if cmds.attributeQuery(loftAttr, node=obj, exists=True):
                curveReference = obj
                data = GetLoftData(curveReference)
                break
        if curveReference:
            loft = cmds.ls(data['loft'])[0]
            poly = cmds.ls(data['poly'])[0]
            curves = cmds.ls(data['curves'])
            loftNode = GetLoftNode(loft)
            
            currentIndex = objs.index(curveReference)
            oldIndex = curves.index(curveReference)             
            if currentIndex == 0:
                oldIndex = curves.index(curveReference) + 1
                addObjs = objs[1:]
            elif currentIndex == (len(objs)-1):
                oldIndex = curves.index(curveReference)
                addObjs = objs[:-1]
                if oldIndex <= 0:
                    oldIndex = 0
            CleanCurve(addObjs)
            finalOrder = curves[:oldIndex] + addObjs + curves[oldIndex:]
            i = 0
            for curve in finalOrder:
                shape = cmds.listRelatives(curve,children=True,f=True)[0]
                cmds.connectAttr(shape+'.worldSpace[0]',loftNode+'.inputCurve['+str(i)+']',f=True)
                i += 1
            data['curves'] = finalOrder
            for obj in (finalOrder+[loft]+[poly]):
                SetLoftData(obj,{
                    'curves':finalOrder,
                    'poly':poly,
                    'loft':loft
                })

def ClearAllLoft(*arr):
    objs = cmds.ls(type='loft')
    for obj in objs:
        if cmds.attributeQuery(loftAttr, node=obj, exists=True):
            data = GetLoftData(obj)
            if cmds.ls(data['poly']) == []:
                cmds.delete(cmds.ls(data['loft'])[0])
                for curve in data['curves']:
                    if cmds.ls(curve):
                        ClearLoftData(cmds.ls(curve)[0])
            else:
                loft = cmds.ls(data['loft'])[0]
                poly = cmds.ls(data['poly'])[0] 
                curves = GetLoftInputCurves(loft)
                for objTemp in  [loft]+[poly]+curves:
                    SetLoftData(objTemp,{
                        'loft':loft,
                        'poly':poly,
                        'curves':curves
                    })

def AnimProxyPaste(*arr):
    selection =  cmds.ls(selection=True)
    if selection:
        source = selection[0]
        target = selection[1]
        keyObj = selection[2]
    cmds.select(source)
    copyProxy()
    keys = cmds.keyframe(keyObj, q=True)
    if not keys:
        return None
    for time in range(int(min(keys)),int(max(keys))):
        cmds.currentTime(time)
        vertsNearest = NLTA_Mesh.GetIntersectVerts(target,source,0.05)
        if vertsNearest:
            cmds.select(vertsNearest)
            pastProxy()

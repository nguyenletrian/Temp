import maya.cmds as cmds

def PickObject(ui, *args):
    objs = cmds.ls(selection=True)
    if not objs:
        return
    string = ";".join(objs)
    count = len(objs)
    ui_type = cmds.objectTypeUI(ui)
    if ui_type in ["textField", "textFieldGrp","field"]:
        cmds.textField(ui, e=True, text=string)
    elif ui_type in ["intField", "intFieldGrp"]:
        cmds.intField(ui, e=True, value=count)
    elif ui_type in ["floatField", "floatFieldGrp"]:
        cmds.floatField(ui, e=True, value=float(count))
    elif ui_type == "text":
        cmds.text(ui, e=True, label=string)
    elif ui_type == "optionMenu":
        items = cmds.optionMenu(ui, q=True, itemListLong=True) or []
        for item in items:
            cmds.deleteUI(item)
        for obj in objs:
            cmds.menuItem(label=obj, parent=ui)
        cmds.optionMenu(ui, e=True, value=objs[0])
    elif ui_type == "checkBox":
        cmds.checkBox(ui, e=True, value=bool(objs))
    elif ui_type == "scrollField":
        cmds.scrollField(ui, e=True, text="\n".join(objs))
    else:
        print(f"UI type '{ui_type}' chưa support")

def PickObjectName(ui, *args):
    selection = cmds.ls(selection=True)
    if not selection:
        return
    objs = []
    for sel in selection:
        objs.append(sel.split(":")[-1])
    string = ";".join(objs)
    count = len(objs)
    ui_type = cmds.objectTypeUI(ui)
    if ui_type in ["textField", "textFieldGrp","field"]:
        cmds.textField(ui, e=True, text=string)
    elif ui_type in ["intField", "intFieldGrp"]:
        cmds.intField(ui, e=True, value=count)
    elif ui_type in ["floatField", "floatFieldGrp"]:
        cmds.floatField(ui, e=True, value=float(count))
    elif ui_type == "text":
        cmds.text(ui, e=True, label=string)
    elif ui_type == "optionMenu":
        items = cmds.optionMenu(ui, q=True, itemListLong=True) or []
        for item in items:
            cmds.deleteUI(item)
        for obj in objs:
            cmds.menuItem(label=obj, parent=ui)
        cmds.optionMenu(ui, e=True, value=objs[0])
    elif ui_type == "checkBox":
        cmds.checkBox(ui, e=True, value=bool(objs))
    elif ui_type == "scrollField":
        cmds.scrollField(ui, e=True, text="\n".join(objs))
    else:
        print(f"UI type '{ui_type}' chưa support")


def PickNamespace(ui, *args):
    objs = cmds.ls(selection=True)
    if objs:
        obj = objs[0]
        parts = obj.split(":")
        if len(parts) <= 1:
            namespace = ""
        else:
            namespace = ":".join(parts[:-1])
        count = len(objs)
        ui_type = cmds.objectTypeUI(ui)

        if ui_type in ["textField", "textFieldGrp","field"]:
            cmds.textField(ui, e=True, text=namespace)
        elif ui_type in ["intField", "intFieldGrp"]:
            cmds.intField(ui, e=True, value=count)
        elif ui_type in ["floatField", "floatFieldGrp"]:
            cmds.floatField(ui, e=True, value=float(count))
        elif ui_type == "text":
            cmds.text(ui, e=True, label=namespace)
        elif ui_type == "optionMenu":
            items = cmds.optionMenu(ui, q=True, itemListLong=True) or []
            for item in items:
                cmds.deleteUI(item)
            namespaces = []
            for o in objs:
                p = o.split(":")
                ns = ":".join(p[:-1]) if len(p) > 1 else ""
                namespaces.append(ns)
            namespaces = list(set(namespaces))
            for ns in namespaces:
                cmds.menuItem(label=ns, parent=ui)
            if namespaces:
                cmds.optionMenu(ui, e=True, value=namespaces[0])
        elif ui_type == "checkBox":
            cmds.checkBox(ui, e=True, value=bool(namespace))
        elif ui_type == "scrollField":
            cmds.scrollField(ui, e=True, text=namespace)

        else:
            print(f"UI type '{ui_type}' chưa support")

def ClearUI(ui,*arr):
    children = cmds.rowColumnLayout(ui, q=True, childArray=True)
    if children:
        for child in children:
            cmds.deleteUI(child)
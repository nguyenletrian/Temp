import maya.cmds as cmds
import os
import sys
import base64
import importlib.util
import urllib.request
import urllib.parse
import json
from datetime import datetime, timezone

setting = {
    'token':'',
    'headers':{'Authorization':''},
    #'token':'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',
    #'headers':{'Authorization':'token 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'},
    'owner':'nguyenletrian',
    'repo':'MayaScripts',

}

def convertISO2Time(ISOString):
    dt = datetime.strptime(ISOString, "%Y-%m-%dT%H:%M:%SZ")
    dt = dt.replace(tzinfo=timezone.utc)
    return dt.timestamp()

def GetToolFiles(toolFolder, recursive=True):
    result = {}
    for root, _, files in os.walk(toolFolder):
        for file in files:
            if file.endswith('.py'):
                full_path = os.path.join(root, file)
                mod_time = os.path.getmtime(full_path)
                relative_path = os.path.relpath(full_path, toolFolder)
                result[relative_path.replace('\\', '/')] = int(mod_time)
        if not recursive:
            break
    return result

def make_request(url):
    req = urllib.request.Request(url)
    for k, v in setting['headers'].items():
        req.add_header(k, v)
    try:
        with urllib.request.urlopen(req) as response:
            status = response.getcode()
            data = response.read()
            return status, data
    except urllib.error.HTTPError as e:
        print(f"HTTP Error: {e.code} - {e.reason}")
        return e.code, e.read()
    except urllib.error.URLError as e:
        print(f"URL Error: {e.reason}")
        return None, None

def GetRepoFiles():
    url = f"https://api.github.com/repos/{setting['owner']}/{setting['repo']}/git/trees/main?recursive=1"
    status, data = make_request(url)
    if status == 200:
        tree_data = json.loads(data)
        return [item['path'] for item in tree_data.get('tree', []) if item['type'] == 'blob']
    else:
        print("Failed to fetch file list:", status)
        return None

def GetFileCommits(linkArray):
    returnArray = {}
    for link in linkArray:
        url = f"https://api.github.com/repos/{setting['owner']}/{setting['repo']}/commits?path={urllib.parse.quote(link)}"
        status, data = make_request(url)
        if status == 200:
            commits = json.loads(data)
            if commits:
                dateCommits = commits[0]['commit']['committer']['date']
                returnArray[link] = int(convertISO2Time(dateCommits))
        else:
            print("Failed to fetch commit info:", status)
    return returnArray

def LoadGHFile(data):
    fileName = data['fileName']
    toolFolder = data['toolFolder']
    url = f"https://api.github.com/repos/{setting['owner']}/{setting['repo']}/contents/{urllib.parse.quote(fileName)}?ref=main"
    status, data_bytes = make_request(url)
    if status == 200:
        content = json.loads(data_bytes)
        encoded = content['content']
        decoded = base64.b64decode(encoded).decode('utf-8')
        full_path = os.path.join(toolFolder, fileName)
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        with open(full_path, "w", encoding="utf-8") as f:
            f.write(decoded)
        print(fileName + " downloaded and saved!")
    else:
        print("Failed:", status)

def SyschronizeGH(data):
    toolFolder = data['toolFolder']
    repoFiles = GetRepoFiles()
    if repoFiles:
        toolFiles = GetToolFiles(toolFolder)
        commitFiles = GetFileCommits(repoFiles)
        folders = []
        for f in commitFiles:
            if '/' in f:
                folder, _ = f.rsplit('/', 1)
                if folder not in folders:
                    folders.append(folder)
            if not os.path.exists(os.path.join(toolFolder, f)):
                LoadGHFile({'toolFolder': toolFolder, 'fileName': f})
            else:
                if commitFiles[f] > toolFiles.get(f, 0):
                    LoadGHFile({'toolFolder': toolFolder, 'fileName': f})
    else:
        folders = [f for f in os.listdir(data['toolFolder']) if os.path.isdir(os.path.join(data['toolFolder'], f))]
    for folder in folders:
        path = os.path.join(toolFolder, folder)
        if path not in sys.path:
            sys.path.append(path)

def DictToFlags(dict):
    return [f'{k}="{v}"' if isinstance(v, str) else f'{k}={v}' for k, v in dict.items()]

def LoadUI(data):
    module = importlib.import_module(data['module'])
    importlib.reload(module)
    module.CreateUI(data)

def CreateTool(data):
    if 'paths' in data:
        for path in data['paths']:
            if path not in sys.path:
                sys.path.append(path)
    SyschronizeGH(data)
    UIData = data['UI']
    if cmds.window(UIData['windowName'], exists=True):
        cmds.deleteUI(UIData['windowName'])
    cmds.window(UIData['windowName'], title=UIData['windowTitle'])
    cmds.rowColumnLayout('MainLayout', nc=UIData['column'])
    cmds.setParent("..")
    cmds.showWindow(UIData['windowName'])
    for layoutData in UIData['layouts']:
        LoadUI(layoutData)

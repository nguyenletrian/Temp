'''
setAttr "gameExporterPreset1.blendshapes" 0;
Resetting Maya Settings on Close
setAttr "gameExporterPreset1.embedMedia" 0;
setAttr -type "string" gameExporterPreset1.exportFilename "BLE@CSN";
'''

import maya.cmds as cmds
import importlib
import os
import sys
import pymel.core as pm
from functools import partial

import NLTA_General
importlib.reload(NLTA_General)

sceneData = {}

def CreateUI(data):  
    def ModifyData(data):
        global titleFlags, layoutFlags, buttonFlags, inputFlags
        titleFlags = data.get('titleFlags', {})
        layoutFlags = data.get('layoutFlags', {})
        buttonFlags = data.get('buttonFlags', {})
        inputFlags = data.get('inputFlags', {})
    ModifyData(data) 

    titles, buttons, inputs = [], [], []
    parent = data['parent']
    layoutTempt = cmds.rowColumnLayout(data["module"],parent=parent)#*
    cmds.rowColumnLayout(layoutTempt,edit=True,**layoutFlags)
    titles.append(cmds.textField(text=data['title'],editable=False))    

    cmds.rowColumnLayout(numberOfColumns=4)#1
    buttons.append(cmds.button(label="Up P-Script",c=RunUpPostScript,width=100))
    buttons.append(cmds.button(label="Current P-Script",c=RunCurrentPostScript,width=100))
    buttons.append(cmds.button(label="Up A-Script",c=RunUpAfterScript,width=100)) 
    buttons.append(cmds.button(label="Current A-Script",c=RunCurrentAfterScript,width=100))
    cmds.setParent("..")#1


    ### VISIBILITY
    cmds.rowColumnLayout(numberOfColumns=2)#Visibility Setup
    titles.append(cmds.textField(text='Visibility Setup',editable=False))
    cmds.rowColumnLayout(numberOfColumns=2)
    visibilityUI = cmds.scrollField(wordWrap=True,height=80)
    cmds.rowColumnLayout(numberOfColumns=1)#1
    buttons.append(cmds.button(label="Add",c=partial(AddVisibiliyItem,visibilityUI)))
    buttons.append(cmds.button(label="Remove",c=partial(RemoveVisibiliyItem,visibilityUI)))
    buttons.append(cmds.button(label="Select",c=partial(SelectVisibiliyItem,visibilityUI)))
    cmds.setParent("..")
    cmds.setParent("..")
    cmds.setParent("..")

    cmds.rowColumnLayout(numberOfColumns=2)
    buttons.append(cmds.button(label="Run",c=partial(RunVisibility,visibilityUI),width=200))
    buttons.append(cmds.button(label="Save",c=partial(SaveVisibility,visibilityUI),width=200))
    cmds.setParent("..")
    cmds.setParent("..")#Close Visibility



    ### SET ATTRIBUTE DEFAULT
    cmds.rowColumnLayout(numberOfColumns=1)#Start
    titles.append(cmds.textField(text='Set defaultValue',editable=False))
    cmds.rowColumnLayout(numberOfColumns=2)
    valueDefaultUI = cmds.scrollLayout(horizontalScrollBarThickness=4,w=400,h=300)
    cmds.setParent("..")
    cmds.rowColumnLayout(numberOfColumns=1)#1
    buttons.append(cmds.button(label="Add",c=partial(AddAttributeDefaultItem,valueDefaultUI)))
    cmds.setParent("..")
    cmds.setParent("..")
    cmds.rowColumnLayout(numberOfColumns=2)
    buttons.append(cmds.button(label="Run",c=partial(RunAttributeDefaultItem,valueDefaultUI),width=200))
    buttons.append(cmds.button(label="Save",c=partial(SaveAttributeDefaultItem,valueDefaultUI),width=200))
    cmds.setParent("..")
    cmds.setParent("..")#End
    

    ### SET DRIVEN KEY
    cmds.rowColumnLayout(numberOfColumns=2)
    ### SPACE SWITCH
    cmds.frameLayout(label="Set Driven key", collapsable=True,collapse=True,width=400)
    cmds.rowColumnLayout(numberOfColumns=1,backgroundColor=(0.2, 0.2, 0.2),)
    SDKScroll = cmds.scrollLayout(horizontalScrollBarThickness=4,w=400,h=600)
    cmds.setParent("..")
    cmds.rowColumnLayout(numberOfColumns=3)#1
    buttons.append(cmds.button(label="Run",c=RunSDK,w=132))#c=RunSpaceScript
    buttons.append(cmds.button(label="Add",c=partial(AddSDKItem,SDKScroll,{}),w=132))    
    buttons.append(cmds.button(label="Save",c=SaveSDK,w=133))
    cmds.setParent("..")
    cmds.setParent("..")
    cmds.setParent("..")
    cmds.setParent("..")


    cmds.rowColumnLayout(numberOfColumns=2)# Start Switch
    ### SPACE SWITCH
    cmds.frameLayout(label="Space Nums", collapsable=True,collapse=True,width=400)
    cmds.rowColumnLayout(numberOfColumns=1,backgroundColor=(0.2, 0.2, 0.2),)
    scrollArea = cmds.scrollLayout(horizontalScrollBarThickness=4,w=400,h=500)
    cmds.setParent("..")
    cmds.rowColumnLayout(numberOfColumns=3)#1
    buttons.append(cmds.button(label="Run",c=SpaceOK,w=132))#c=RunSpaceScript
    buttons.append(cmds.button(label="Add",c=partial(AddSpaceItem,scrollArea,{}),w=132))    
    buttons.append(cmds.button(label="Save",c=SaveData,w=133))
    cmds.setParent("..")
    cmds.setParent("..")
    cmds.setParent("..")

    ### VISIBLE SWITCH
    cmds.frameLayout(label="Visible Switch", collapsable=True,collapse=True,width=400)
    cmds.rowColumnLayout(numberOfColumns=1,backgroundColor=(0.2, 0.2, 0.2),)
    visibleArea = cmds.scrollLayout(horizontalScrollBarThickness=4,w=400,h=500)
    cmds.setParent("..")
    cmds.rowColumnLayout(numberOfColumns=3)#1
    buttons.append(cmds.button(label="Run",c=VisibleOK,w=132))
    buttons.append(cmds.button(label="Add",c=partial(AddVisibleItem,visibleArea,{}),w=132))    
    buttons.append(cmds.button(label="Save",c=SaveVisibleData,w=133))
    cmds.setParent("..")
    cmds.setParent("..")
    cmds.setParent("..")

    cmds.setParent("..")# End Switch
    
    cmds.setParent("..")
    cmds.setParent("..")#*
      
    for title in titles:
        cmds.textField(title,edit=True,**titleFlags)
    for button in buttons:
        cmds.button(button,edit=True,**buttonFlags)
    for input_ in inputs:
        if cmds.objectTypeUI(input_) == 'textField':
            cmds.textField(input_,edit=True,**inputFlags)
        if cmds.objectTypeUI(input_) == 'intField':
            cmds.intField(input_,edit=True,**inputFlags)
    LoadData(scrollArea)
    LoadVisibleData(visibleArea)
    LoadVisibility(visibilityUI)
    LoadAttributeDefaultItem(valueDefaultUI)
    LoadSDK(SDKScroll)

### SET DRIVER KEY
'''
data = [
    {
        'driver':'BulletBelt2_Top_IK_Ctrl',
        'driverAttr':'FollowValue',
        'driven':'BulletBelt2_Mid_IK_Ctrl',
        'drivenAttr':['tx','ty','tz','rx','ry','rz'],
        'keyData':{
            '0':{
                'tx':0,
                'ty':0,
                'tz':0,
            }
        }
    }
]
'''


def SetAttrValue(attr,value,*arr):
    attrType = cmds.getAttr(attr, type=True)
    if attrType in ("double", "float"):
        cmds.setAttr(attr,float(value))
        value = float(value)
    elif attrType in ("long", "short", "byte", "bool"):
        cmds.setAttr(attr,int(value))
    elif attrType in ("string", "enum"):
        cmds.setAttr(attr,str(value))

def GetAttributeSelected(*arr):
    objs =  cmds.ls(selection=True)
    if objs:
        returnData = {
            "allAttr":[]
        }
        mainAttr = cmds.channelBox("mainChannelBox",query=True,sma=True)
        if mainAttr:
            returnData["main"] = mainAttr
            returnData["allAttr"].extend(mainAttr)
        shapeAttr = cmds.channelBox("mainChannelBox",query=True,ssa=True)
        if shapeAttr:
            returnData["shape"] = shapeAttr
            returnData["allAttr"].extend(shapeAttr)
        inputAttr = cmds.channelBox("mainChannelBox",query=True,sha=True)
        if inputAttr:
            returnData["input"] = inputAttr
            returnData["allAttr"].extend(inputAttr)
        outputAttr = cmds.channelBox("mainChannelBox",query=True,soa=True)
        if outputAttr:
            returnData["output"] = outputAttr
            returnData["allAttr"].extend(outputAttr)
        for obj in objs:
            maxIncrease = len(returnData["allAttr"])
            numberIncrease = 0
            for attr in returnData["allAttr"]:
                if cmds.attributeQuery(attr,node=obj,ex=True):
                    numberIncrease +=1
            if maxIncrease == numberIncrease:
                returnData["obj"] = obj
        return(returnData)
    return(None)


SDKUis = {}
SDKData = {}
SDKFile = 'NLTA_SDKData.json'


def AddSDKItem(ui,data,*arr):
    global SDKUis
    titleWidth = 80
    inputWidth = 233
    inputHeight = 25
    buttonHeight = 25

    def PickDriver(ui,*arr):
        selection = cmds.ls(selection=True) or []
        if selection:
            obj = selection[0]
            cmds.textField(ui,edit=True,text=obj)

    def PickDriven(ui,*arr):
        selection = cmds.ls(selection=True) or []
        if selection:
            content = ";".join(selection)
            currentContent = cmds.scrollField(ui, query=True, text=True)
            if currentContent !="":
                cmds.scrollField(ui, edit=True, text=currentContent+"\n"+content)
            else:
                cmds.scrollField(ui, edit=True, text=content)

    def PickAttrs(ui,*arr):
        attrs = GetAttributeSelected()
        if attrs:
            cmds.textField(ui,edit=True,text=(';').join(attrs['allAttr']))   
        else:
            cmds.textField(ui,edit=True,text='')

    def PickContentAttr(ui,*arr):
        selection = cmds.ls(selection=True) or []
        if selection:
            obj = selection[0]
            cmds.textField(ui,edit=True,text=obj)   

    def DeleteItem(ui,*arr):
        cmds.deleteUI(ui)
        del SDKUis[ui]
        SDKData.remove(ui)

    def AddKeyItem(ParentUI,data,*arr):
        print(data)
        if 'keyData' not in SDKUis[ParentUI]:
            SDKUis[ParentUI]['keyData'] = {}        
        UIData = SDKUis[ParentUI]
        ScrollArea = UIData['ScrollArea']
        Driver = UIData['Driver']
        DriverAttr = UIData['DriverAttr']
        Drivens =  UIData['Drivens']
        DrivenAttrs = UIData['DrivenAttrs']

        driverVal = cmds.textField(Driver,query=True,text=True)
        driverAttrVal = cmds.textField(DriverAttr,query=True,text=True)
        drivensVal = cmds.scrollField(Drivens,query=True,text=True)
        drivensAttrsVal = cmds.textField(DrivenAttrs,query=True,text=True)        
        drivens = drivensVal.split(';')
        drivensAttrs = drivensAttrsVal.split(';')        

        if data == {}:
            driverCurrentValue = cmds.getAttr(driverVal+'.'+driverAttrVal)   
            if str(driverCurrentValue) in SDKUis[ParentUI]['keyData']:
                cmds.deleteUI(SDKUis[ParentUI]['keyData'][str(driverCurrentValue)]['ItemUI'])
                del SDKUis[ParentUI]['keyData'][str(driverCurrentValue)]

            ItemUI = cmds.rowColumnLayout(numberOfColumns=1,parent=ScrollArea)
            cmds.rowColumnLayout(numberOfColumns=2)
            cmds.textField(text='Driver value',editable=False,width=80)
              
            driverValueUI = cmds.floatField(value=driverCurrentValue,width=283)
            cmds.setParent('..') 
            itemData = {'ItemUI':ItemUI,'DriverValueUI':driverValueUI,}
            cmds.rowColumnLayout(numberOfColumns=1)
            itemData['DrivenUIs'] = {}
            for driven in drivens:
                cmds.rowColumnLayout(numberOfColumns=1,width=380)   
                drivenUI = cmds.textField(text=driven,editable=False)
                itemData['DrivenUIs'][driven] = {}
                cmds.rowColumnLayout(numberOfColumns=6)
                for attr in drivensAttrs:
                    cmds.rowColumnLayout(numberOfColumns=1,width=60)
                    cmds.textField(text=attr,editable=False)
                    if 'drivenData' in data:
                        attrValueUI = cmds.floatField(value = float(data['drivenData'][driven][attr]))
                    else:
                        attrValueUI = cmds.floatField(value = cmds.getAttr(driven+'.'+attr))
                    itemData['DrivenUIs'][driven][attr] = attrValueUI
                    cmds.setParent('..')
                cmds.setParent('..')
                cmds.setParent('..')
            cmds.setParent('..')
            cmds.setParent('..')
            SDKUis[ParentUI]['keyData'][str(driverCurrentValue)] = itemData
        else:
            ItemUI = cmds.rowColumnLayout(numberOfColumns=1,parent=ScrollArea)
            cmds.rowColumnLayout(numberOfColumns=2)
            cmds.textField(text='Driver value',editable=False,width=80)        
            driverValueUI = cmds.floatField(value=float(data['driverValue']),width=283)
            cmds.setParent('..') 
            itemData = {'ItemUI':ItemUI,'DriverValueUI':driverValueUI}
            cmds.rowColumnLayout(numberOfColumns=1)
            itemData['DrivenUIs'] = {}
            for driven in drivens:
                cmds.rowColumnLayout(numberOfColumns=1,width=380)   
                drivenUI = cmds.textField(text=driven,editable=False)
                itemData['DrivenUIs'][driven] = {}
                cmds.rowColumnLayout(numberOfColumns=6)
                for attr in drivensAttrs:
                    cmds.rowColumnLayout(numberOfColumns=1,width=60)
                    cmds.textField(text=attr,editable=False)
                    attrValueUI = cmds.floatField(value = float(data['drivenData'][driven][attr]))
                    itemData['DrivenUIs'][driven][attr] = attrValueUI
                    cmds.setParent('..')
                cmds.setParent('..')
                cmds.setParent('..')
            cmds.setParent('..')
            cmds.setParent('..')
            SDKUis[ParentUI]['keyData'][str(data['driverValue'])] = itemData

    ParentUI = cmds.rowColumnLayout(numberOfColumns=1,parent=ui,backgroundColor=(0.15, 0.15, 0.15))    
    SDKUis[ParentUI] = {}
    itemData = {}
    cmds.rowColumnLayout(numberOfColumns=1)
    cmds.rowColumnLayout(numberOfColumns=2)
    cmds.rowColumnLayout(numberOfColumns=2)
    cmds.textField(text='Driver',editable=False,w=titleWidth)
    Driver = cmds.textField(w=inputWidth,height=inputHeight,text=data.get("Driver", ""))
    itemData['Driver'] = Driver
    cmds.setParent("..")
    cmds.rowColumnLayout(numberOfColumns=2)
    cmds.button(label="+",w=30,h=buttonHeight,c=partial(PickDriver,Driver))
    cmds.setParent("..")
    cmds.setParent("..")

    cmds.rowColumnLayout(numberOfColumns=2)
    cmds.rowColumnLayout(numberOfColumns=2)
    cmds.textField(text='Driver Attrs',editable=False,w=titleWidth)
    DriverAttr = cmds.textField(w=inputWidth,height=inputHeight,text=data.get("DriverAttr", ""))
    itemData['DriverAttr'] = DriverAttr
    cmds.setParent("..")
    cmds.rowColumnLayout(numberOfColumns=2)
    cmds.button(label="+",w=30,h=buttonHeight,c=partial(PickAttrs,DriverAttr))
    cmds.setParent("..")
    cmds.setParent("..")


    cmds.rowColumnLayout(numberOfColumns=2)
    cmds.rowColumnLayout(numberOfColumns=2)
    cmds.textField(text='Driven',editable=False,w=titleWidth)
    Drivens = cmds.scrollField(wordWrap=True,height=80,w=inputWidth,text=data.get("Drivens", ""))
    itemData['Drivens'] = Drivens
    cmds.setParent("..")
    cmds.rowColumnLayout(numberOfColumns=2)
    cmds.button(label="+",w=30,h=buttonHeight,c=partial(PickDriven,Drivens))
    cmds.setParent("..")
    cmds.setParent("..")


    cmds.rowColumnLayout(numberOfColumns=2)
    cmds.rowColumnLayout(numberOfColumns=2)
    cmds.textField(text='Driven Attrs',editable=False,w=titleWidth)
    DrivenAttrs = cmds.textField(w=inputWidth,height=inputHeight,text=data.get("DrivenAttrs", ""))
    itemData['DrivenAttrs'] = DrivenAttrs
    cmds.setParent("..")
    cmds.rowColumnLayout(numberOfColumns=2)
    cmds.button(label="+",w=30,h=buttonHeight,c=partial(PickAttrs,DrivenAttrs))
    cmds.setParent("..")
    cmds.setParent("..")
    ScrollArea = cmds.scrollLayout(horizontalScrollBarThickness=4,w=400,h=300)
    itemData['ScrollArea'] = ScrollArea
    cmds.setParent("..")

    SDKUis[ParentUI] = itemData
    
    
    if data and ('keyData' in data):
        for i in range(len(data['keyData'])):
            AddKeyItem(ParentUI,data['keyData'][i])
    
    cmds.rowColumnLayout(numberOfColumns=2)
    cmds.button(label="X",h=buttonHeight,w=35,backgroundColor=(.5,.2,.2),c=partial(DeleteItem,ParentUI))
    cmds.button(label="Add",h=buttonHeight,w=35,c=partial(AddKeyItem,ParentUI,{}))
    cmds.setParent("..")

    cmds.separator(height=10, style='none')
    cmds.setParent("..")    
    cmds.setParent("..")

def GetSDKData(*arr):
    returnData = []
    for ParentUI in SDKUis:
        if 'keyData' in SDKUis[ParentUI]:
            itemData = {}
            DriverUI = SDKUis[ParentUI]['Driver']
            DriverAttrUI = SDKUis[ParentUI]['DriverAttr']
            DirvensUI = SDKUis[ParentUI]['Drivens']
            DrivensAttrsUI =  SDKUis[ParentUI]['DrivenAttrs']
            DriverName = cmds.textField(DriverUI,query=True,text=True)
            DriverAttr = cmds.textField(DriverAttrUI,query=True,text=True)
            Drivens = cmds.scrollField(DirvensUI,query=True,text=True)
            DrivensAttrs = cmds.textField(DrivensAttrsUI,query=True,text=True)
            itemData['Driver'] = DriverName
            itemData['DriverAttr'] = DriverAttr
            itemData['Drivens'] = Drivens
            itemData['DrivenAttrs'] = DrivensAttrs
            itemData['keyData'] = []
            keyData = SDKUis[ParentUI]['keyData']
            for key in keyData:
                DriverValueUI = keyData[key]['DriverValueUI']
                DriverValue = cmds.floatField(DriverValueUI,query=True,value=True)
                keyTemp = {
                    'driverValue':str(DriverValue),
                    'drivenData':{}
                }
                for driven in keyData[key]['DrivenUIs']:
                    keyTemp['drivenData'][driven] = {}
                    drivenData = keyData[key]['DrivenUIs'][driven]
                    #itemData['keyData'][str(DriverValue)][driven] = {}
                    for attr in drivenData:
                        valueUI = drivenData[attr]
                        keyTemp['drivenData'][driven][attr]= cmds.floatField(valueUI,query=True,value=True)
                        #itemData['keyData'][str(DriverValue)][driven][attr] = cmds.textField(valueUI,query=True,text=True)
                itemData['keyData'].append(keyTemp)
            returnData.append(itemData)
    return(returnData)

def SaveSDK(*arr):
    data = GetSDKData()
    path = cmds.file(q=True, sn=True)
    if path:
        filePath = os.path.dirname(path)+'/'+SDKFile
        NLTA_General.writeJsonFile(filePath,data)

def LoadSDK(ui,*arr):
    path = cmds.file(q=True, sn=True)
    if path:
        filePath = os.path.dirname(path)+'/'+SDKFile
        data = NLTA_General.readJsonFile(filePath)
        if data:
            for i in range(len(data)):
                AddSDKItem(ui,data[i])

def RunSDK(*arr):
    data = GetSDKData()
    for i in range(len(data)):
        itemData = data[i]
        driver = itemData['Driver']
        driverAttr = itemData['DriverAttr']
        drivens = itemData['Drivens'].split(';')
        offsetDict = {}
        for driven in drivens:
            offsetGroup = cmds.group(em=True, name=driven+"_SDKGrp")
            cmds.delete(cmds.parentConstraint(driven,offsetGroup, mo=False))
            drivenParent =  cmds.listRelatives(driven,parent=True)
            if drivenParent:
                cmds.parent(offsetGroup,drivenParent)
            cmds.parent(driven,offsetGroup)
            offsetDict[driven] = offsetGroup
        
        for i in range(len(itemData['keyData'])):
            keyData = itemData['keyData'][i]
            driverValue =  float(keyData['driverValue'])
            drivenData = keyData['drivenData']
            for driven in drivenData:
                offsetGroup = offsetDict[driven]
                attrData = drivenData[driven]
                for attr in attrData:
                    attrValue = attrData[attr]
                    if attr in ['tx','ty','tz','rx','ry','rz']:                        
                        drivenAttr = offsetGroup+'.'+attr                        
                    else:
                        drivenAttr = driven+'.'+attr
                    cmds.setDrivenKeyframe(
                        drivenAttr,
                        currentDriver=driver+"."+driverAttr,
                        driverValue=driverValue,
                        value=attrValue
                    )
                    cmds.keyTangent(drivenAttr, itt='linear', ott='linear')
        


"""
def set_driven_keys(driver_attr, driven_attr, pairs,in_tangent='linear', out_tangent='linear',clear_existing=False):#'auto', 'linear', 'spline', 'flat', 'step', ...
    
    Tạo Set Driven Key giữa driver_attr -> driven_attr.

    Parameters
    ----------
    driver_attr : str
        Ví dụ: "pCube1.rotateY"
    driven_attr : str
        Ví dụ: "pSphere1.translateX"
    pairs : list[tuple[float, float]]
        Danh sách (driverValue, drivenValue).
        Ví dụ: [(0, 0), (45, 5), (90, 10)]
    in_tangent, out_tangent : str
        
    clear_existing : bool
        True để xóa key cũ trên driven_attr trước khi đặt mới.

    if not cmds.objExists(driver_attr) or not cmds.objExists(driven_attr):
        raise RuntimeError("Driver hoặc Driven attribute không tồn tại.")

    if clear_existing:
        cmds.cutKey(driven_attr, clear=True)

    # Đảm bảo attribute có thể key
    try:
        cmds.setAttr(driven_attr, lock=False, keyable=True, channelBox=True)
    except:
        pass

    for drv_val, drv_n_val in pairs:
        # Set driver tới giá trị mong muốn để khóa SDK
        try:
            cmds.setAttr(driver_attr, drv_val)
        except:
            # Driver có thể là output (đang bị kết nối), dùng driverValue của setDrivenKeyframe thay thế
            pass

        # Đặt keyframe SDK
        cmds.setDrivenKeyframe(
            driven_attr,
            currentDriver=driver_attr,
            driverValue=float(drv_val),
            value=float(drv_n_val)  # với string/enum cần đổi sang đúng kiểu riêng
        )

    # Set tangent cho các key vừa tạo
    cmds.keyTangent(driven_attr, itt=in_tangent, ott=out_tangent)

    # Tùy chọn: không clamp để tránh phẳng đỉnh
    # cmds.keyTangent(driven_attr, cl=False)

    # Trả về các animCurve được tạo/ảnh hưởng
    return cmds.listConnections(driven_attr, s=True, d=False, type='animCurve') or []

# ----- Ví dụ dùng -----
# pCube1.rotateY (driver) điều khiển pSphere1.translateX (driven)
curves = set_driven_keys(
    driver_attr="pCube1.rotateY",
    driven_attr="pSphere1.translateX",
    pairs=[(0, 0), (45, 5), (90, 10)],
    in_tangent='auto',
    out_tangent='auto',
    clear_existing=True
)
print("AnimCurves:", curves)
"""




#### ATTRIBUTE VALUE
attributeData = {}
attributeUIs = {}
attributeFile = 'NLTA_AttributeDefault.json'

def GetAttributeDefaultData(*arr):
    global attributeData
    attributeData = {}
    for key in attributeUIs:
        attr = cmds.textField(attributeUIs[key]['attr'],query=True,text=True)
        value = cmds.textField(attributeUIs[key]['value'],query=True,text=True)
        if value == 'True':
            value = 1
        if value == 'False':
            value = 0
        attributeData[attr] = value
    return(attributeData)    

def CreateAttributeDefaultItem(ui,data,*arr):
    global attributeUIs
    global attributeData
    def Delete(attr,*arr):
        cmds.deleteUI(attributeUIs[attr]['parent'])        
        del attributeUIs[attr]
        del attributeData[attr]

    if data['attr'] not in attributeUIs:
        item = cmds.rowColumnLayout(numberOfColumns=2,parent=ui)# Open Item
        cmds.rowColumnLayout(numberOfColumns=3)
        attr = cmds.textField(text=data.get("attr", ""),width=280)
        value = cmds.textField(text=data.get("value", ""),width=50)
        cmds.button(label="X",c=partial(Delete,data['attr']),width=50)
        attributeUIs[data['attr']] = {
            'parent':item,
            'attr':attr,
            'value':value
        }
        attributeData[data['attr']] = data['value']
        cmds.setParent("..")
        cmds.setParent("..")#Close
    else:
        cmds.textField(attributeUIs[data['attr']]['value'],edit=True,text=data['value'])

def AddAttributeDefaultItem(ui,*arr):
    current = GetAttributeSelected()
    if current:
        attr = current['obj']+'.'+current['main'][0]
        if attr == True:
            attr = 1
        if attr == False:
            attr = 0
        CreateAttributeDefaultItem(ui,{
            'attr':attr,
            'value':cmds.getAttr(attr)
        })

def RunAttributeDefaultItem(data,*arr):
    data = GetAttributeDefaultData()
    for key in data:
        value = data[key]
        attrType = cmds.getAttr(key, type=True)
        if attrType in ("double", "float"):
            value = float(value)
        elif attrType in ("long", "short", "byte", "bool", "enum"):
            value = int(value)
        elif attrType in ("string"):
            value = str(value)
        cmds.setAttr(key,value)

def SaveAttributeDefaultItem(*arr):
    data = GetAttributeDefaultData()
    path = cmds.file(q=True, sn=True)
    if path:
        filePath = os.path.dirname(path)+'/'+attributeFile
        NLTA_General.writeJsonFile(filePath,data)

def LoadAttributeDefaultItem(ui,*arr):
    path = cmds.file(q=True, sn=True)
    if path:
        filePath = os.path.dirname(path)+'/'+attributeFile
        data = NLTA_General.readJsonFile(filePath)
        if data:
            children = cmds.layout(ui,q=True, ca=True) or []
            for key in data:
                CreateAttributeDefaultItem(ui,{
                    'attr':key,
                    'value':data[key],
                })
    

#### VISIBILITY SET UP ####
visibilityFile =  'NLTA_Visibility.json'
def AddVisibiliyItem(ui,*arr):
    objs = cmds.ls(selection=True,ap=True)
    currentItems = cmds.scrollField(ui,query=True,text=True).split(";")
    currentItems = [item for item in currentItems if item != ""]
    if objs:
        for obj in objs:
            if obj not in currentItems:
                currentItems.append(obj)

    if currentItems:
        string = (';').join(currentItems)
        cmds.scrollField(ui,edit=True,text=string)

def RemoveVisibiliyItem(ui,*arr):
    objs = cmds.ls(selection=True,ap=True)
    currentItems = cmds.scrollField(ui,query=True,text=True).split(";")
    if objs:
        for obj in objs:
            currentItems.remove(obj)
    if currentItems:
        string = (';').join(currentItems)
        cmds.scrollField(ui,edit=True,text=string)        

def SelectVisibiliyItem(ui,*arr):
    currentItems = cmds.scrollField(ui,query=True,text=True).split(";")
    cmds.select(currentItems)

def SaveVisibility(ui,*arr):
    data = cmds.scrollField(ui,query=True,text=True).split(";")
    path = cmds.file(q=True, sn=True)
    if path:
        filePath = os.path.dirname(path)+'/'+visibilityFile
        NLTA_General.writeJsonFile(filePath,data)

def LoadVisibility(ui,*arr):
    path = cmds.file(q=True, sn=True)
    if path:
        filePath = os.path.dirname(path)+'/'+visibilityFile
        data = NLTA_General.readJsonFile(filePath)
        if data:
            cmds.scrollField(ui,edit=True,text=(";").join(data))

def RunVisibility(ui,*arr):
    objs = cmds.scrollField(ui,query=True,text=True).split(";")
    for obj in objs:
        if cmds.objExists(obj):
            attr = obj + '.visibility'
            conn =  cmds.listConnections(attr, source=True, destination=False)
            lock = cmds.getAttr(obj + ".visibility", lock=True)
            if conn or lock:
                grp = cmds.group(empty=True, name=f"{obj}_VisGrp")
                cmds.delete(cmds.parentConstraint(obj, grp))
                grpReplace = cmds.group(empty=True, name=f"{obj}_ReplaceGrp")
                cmds.delete(cmds.parentConstraint(obj,grpReplace))
                
                objParent = cmds.listRelatives(obj,parent=True)[0]     
                if objParent:
                    cmds.parent(grp,objParent)
                objChildren = cmds.listRelatives(obj,children=True)
                if objChildren:
                    cmds.parent(objChildren,grpReplace)
                    cmds.parent(grpReplace,objParent)
                    cmds.parentConstraint(obj,grpReplace,mo=True)
                    cmds.scaleConstraint(obj,grpReplace,mo=True)
                else:
                    cmds.delete(grpReplace)
                cmds.parent(obj,grp)            
                cmds.setAttr(grp+'.visibility',0)
            else:
                cmds.setAttr(obj+'.visibility',0)        



#### VISIBLE SWITCH####
visibleItems = {
    'order':[],
    'items':{},
}

def AddVisibleItem(parentUI,data,*arr):
    global spaceItems
    titleWidth = 80
    inputWidth = 233
    inputHeight = 25
    buttonHeight = 25

    def PickObjects(ui,*arr):
        selection = cmds.ls(selection=True) or []
        if selection:
            content = ";".join(selection)
            currentContent = cmds.scrollField(ui, query=True, text=True)
            if currentContent !="":
                cmds.scrollField(ui, edit=True, text=currentContent+"\n"+content)
            else:
                cmds.scrollField(ui, edit=True, text=content)   

    def PickContentAttr(ui,*arr):
        selection = cmds.ls(selection=True) or []
        if selection:
            obj = selection[0]
            cmds.textField(ui,edit=True,text=obj)   

    def DeleteItem(ui,*arr):
        cmds.deleteUI(ui)
        del visibleItems['items'][ui]
        visibleItems['order'].remove(ui)

    itemData = {}   
    parentUI = cmds.rowColumnLayout(numberOfColumns=1,parent=parentUI,backgroundColor=(0.15, 0.15, 0.15))

    cmds.rowColumnLayout(numberOfColumns=1)


    cmds.rowColumnLayout(numberOfColumns=2)
    cmds.textField(text='Options',editable=False,w=titleWidth)
    options = cmds.textField(w=inputWidth,height=inputHeight,text=data.get("Options", ""))
    itemData['Options'] = options
    cmds.setParent("..")

    cmds.rowColumnLayout(numberOfColumns=2)
    cmds.rowColumnLayout(numberOfColumns=2)
    cmds.textField(text='Objects',editable=False,w=titleWidth)
    Objects = cmds.scrollField(wordWrap=True,height=80,w=inputWidth,text=data.get("Objects", ""))
    itemData['Objects'] = Objects
    cmds.setParent("..")
    cmds.rowColumnLayout(numberOfColumns=2)
    cmds.button(label="+",w=30,h=buttonHeight,c=partial(PickObjects,Objects))
    cmds.button(label="*",w=30,h=buttonHeight)
    cmds.setParent("..")
    cmds.setParent("..")

    cmds.rowColumnLayout(numberOfColumns=2)
    cmds.rowColumnLayout(numberOfColumns=2)
    cmds.textField(text='Content Attr',editable=False,w=titleWidth)
    ContentAttr =cmds.textField(w=inputWidth,height=inputHeight,text=data.get("ContentAttr", ""))
    itemData['ContentAttr'] = ContentAttr
    cmds.setParent("..")
    cmds.rowColumnLayout(numberOfColumns=2)
    cmds.button(label="->",w=30,h=buttonHeight,c=partial(PickContentAttr,ContentAttr))
    cmds.setParent("..")
    cmds.setParent("..")

    cmds.rowColumnLayout(numberOfColumns=2)
    cmds.textField(text='Attr Pick',editable=False,w=titleWidth)
    attrPick = cmds.textField(w=inputWidth,height=inputHeight,text=data.get("AttrPick", ""))
    itemData['AttrPick'] = attrPick
    cmds.setParent("..")    

    cmds.button(label="X",h=buttonHeight,w=35,backgroundColor=(.5,.2,.2),c=partial(DeleteItem,parentUI))
    cmds.separator(height=10, style='none')

    cmds.setParent("..")    
    cmds.setParent("..")

    visibleItems['items'][parentUI] = itemData
    visibleItems['order'].append(parentUI)

visibleFile = 'NLTA_VisibleData.txt'
def GetVisibleData():
    returnData = []
    for item in visibleItems['items']:
        Objects=cmds.scrollField(visibleItems['items'][item]['Objects'],query=True,text=True)
        ContentAttr=cmds.textField(visibleItems['items'][item]['ContentAttr'],query=True,text=True)
        AttrPick=cmds.textField(visibleItems['items'][item]['AttrPick'],query=True,text=True)
        Options=cmds.textField(visibleItems['items'][item]['Options'],query=True,text=True)
        returnData.append({
            'Objects':Objects,
            'ContentAttr':ContentAttr,
            'AttrPick':AttrPick,
            'Options':Options,
        })
    return(returnData)

def SaveVisibleData(*arr):
    path = cmds.file(q=True, sn=True)
    if path:
        filePath = os.path.dirname(path)+'/'+visibleFile
        data = GetVisibleData()
        NLTA_General.writeJsonFile(filePath,data)

def LoadVisibleData(ui,*arr):
    path = cmds.file(q=True, sn=True)
    if path:
        filePath = os.path.dirname(path)+'/'+visibleFile
        data = NLTA_General.readJsonFile(filePath)
        if data:
            children = cmds.layout(ui,q=True, ca=True) or []
            for child in children:
                if cmds.control(child, exists=True):
                    cmds.deleteUI(child)
            for i in range(len(data)):
                AddVisibleItem(ui,data[i])

def VisibleOK(*arr):
    data = GetVisibleData()
    for i in range(len(data)):
        CreateVisible(data[i])

def CreateVisible(data,*arr):
    ctrl = data['ContentAttr']
    if not cmds.attributeQuery(data['AttrPick'], node=ctrl, exists=True):
        cmds.addAttr(ctrl, ln=data['AttrPick'], at='enum', en=data['Options'])
        cmds.setAttr(ctrl+'.'+data['AttrPick'], e=True, keyable=True)
    objectArrays = data['Objects'].split('\n')
    options = data['Options'].split(':')[0:-1]
    
    for i in range(len(options)):
        if objectArrays[i]!='':
            objs = objectArrays[i].split(';')
            condition = cmds.shadingNode("condition", asUtility=True)
            cmds.connectAttr(ctrl+"."+data['AttrPick'], condition+".firstTerm", force=True)
            cmds.setAttr(condition+".secondTerm",i)
            cmds.setAttr(condition+".colorIfTrueR",1)
            cmds.setAttr(condition+".colorIfFalseR",0)
            for obj in objs:
                attr = obj + '.visibility'
                conn =  cmds.listConnections(attr, source=True, destination=False)
                lock = cmds.getAttr(obj + ".visibility", lock=True)
                if conn or lock:
                    grp = cmds.group(empty=True, name=f"{obj}_VisGrp")
                    cmds.delete(cmds.parentConstraint(obj, grp))
                    grpReplace = cmds.group(empty=True, name=f"{obj}_ReplaceGrp")
                    cmds.delete(cmds.parentConstraint(obj,grpReplace))
                    
                    objParent = cmds.listRelatives(obj,parent=True)[0]     
                    if objParent:
                        cmds.parent(grp,objParent)
                    objChildren = cmds.listRelatives(obj,children=True)
                    if objChildren:
                        cmds.parent(objChildren,grpReplace)
                        cmds.parent(grpReplace,objParent)
                        cmds.parentConstraint(obj,grpReplace,mo=True) 
                    else:
                        cmds.delete(grpReplace)
                    cmds.parent(obj,grp)
                    cmds.connectAttr(condition+".outColorR",grp+'.visibility', force=True)
       
                    #cmds.setAttr(grp+'.visibility',0)
                else:
                    shapes = cmds.listRelatives(obj,children=True,type='mesh')
                    cmds.connectAttr(condition+".outColorR",obj+'.visibility', force=True)
                    if shapes:
                        for shape in shapes:
                            cmds.connectAttr(condition+".outColorR",shape+'.visibility', force=True)  
            


#### SPACE ####
spaceItems = {
    'order':[],
    'items':{},
}

def AddSpaceItem(parentUI,data,*arr):
    global spaceItems
    titleWidth = 80
    inputWidth = 233
    inputHeight = 25
    buttonHeight = 25

    def PickChild(ui,*arr):
        objs = cmds.ls(selection=True,ap=True)
        if objs:
            obj = objs[0]
            cmds.textField(ui,edit=True,text=obj)
            cmds.textField(offsetName,edit=True,text=obj+'_OffsetGrp')

    def PickParents(ui,*arr):
        selection = cmds.ls(selection=True) or []
        if selection:
            content = "\n".join(selection)
            cmds.scrollField(ui, edit=True, text=content)
            cmds.textField(options,edit=True,text=':'.join(selection)+':')

    def AddParents(ui,*arr):
        selection = cmds.ls(selection=True) or []
        if selection:
            current_text = cmds.scrollField(ui, query=True, text=True).strip()
            new_lines = current_text.splitlines() if current_text else []
            new_lines += selection
            updated_text = "\n".join(new_lines)
            cmds.scrollField(ui, edit=True, text=updated_text)
            cmds.textField(options,edit=True,text=':'.join(new_lines)+':')
    
    def DeleteItem(ui,*arr):
        cmds.deleteUI(ui)
        del spaceItems['items'][ui]
        spaceItems['order'].remove(ui)

    itemData = {}   
    parentUI = cmds.rowColumnLayout(numberOfColumns=1,parent=parentUI,backgroundColor=(0.15, 0.15, 0.15))

    cmds.rowColumnLayout(numberOfColumns=1)

    cmds.rowColumnLayout(numberOfColumns=2)
    cmds.rowColumnLayout(numberOfColumns=2)
    cmds.textField(text='Child',editable=False,w=titleWidth)
    child = cmds.textField(w=inputWidth,height=inputHeight,text=data.get("child", ""))
    itemData['Child'] = child
    cmds.setParent("..")
    cmds.rowColumnLayout(numberOfColumns=2)
    cmds.button(label="+",w=30,h=buttonHeight,c=partial(PickChild,child))
    cmds.button(label="*",w=30,h=buttonHeight)
    cmds.setParent("..")
    cmds.setParent("..")

    cmds.rowColumnLayout(numberOfColumns=2)
    cmds.rowColumnLayout(numberOfColumns=2)
    cmds.textField(text='Parents',editable=False,w=titleWidth)
    Parents = cmds.scrollField(wordWrap=True,height=52,w=inputWidth,text=data.get("parents", ""))
    itemData['Parents'] = Parents
    cmds.setParent("..")
    cmds.rowColumnLayout(numberOfColumns=2)
    cmds.button(label="->",w=30,h=buttonHeight,c=partial(PickParents,Parents))
    cmds.button(label="*",w=30,h=buttonHeight)
    cmds.button(label="+",w=30,h=buttonHeight,c=partial(AddParents,Parents))    
    cmds.setParent("..")
    cmds.setParent("..")

    cmds.rowColumnLayout(numberOfColumns=2)
    cmds.textField(text='Offset Name',editable=False,w=titleWidth)
    offsetName = cmds.textField(w=inputWidth,height=inputHeight,text=data.get("offsetName", ""))
    itemData['OffsetName'] = offsetName
    cmds.setParent("..")

    cmds.rowColumnLayout(numberOfColumns=2)
    cmds.textField(text='Attr Pick',editable=False,w=titleWidth)
    attrPick = cmds.textField(w=inputWidth,height=inputHeight,text=data.get("attrPick", ""))
    itemData['AttrPick'] = attrPick
    cmds.setParent("..")

    cmds.rowColumnLayout(numberOfColumns=2)
    cmds.textField(text='Attr Slide',editable=False,w=titleWidth)
    attrSlide = cmds.textField(w=inputWidth,height=inputHeight,text=data.get("attrSlide", ""))
    itemData['AttrSlide'] = attrSlide
    cmds.setParent("..")

    cmds.rowColumnLayout(numberOfColumns=2)
    cmds.textField(text='Default Value',editable=False,w=titleWidth)
    defaultValue = cmds.textField(w=inputWidth,height=inputHeight,text=data.get("defaultValue", "0"))
    itemData['DefaultValue'] = defaultValue
    cmds.setParent("..")

    cmds.rowColumnLayout(numberOfColumns=2)
    cmds.textField(text='Options',editable=False,w=titleWidth)
    options = cmds.textField(w=inputWidth,height=inputHeight,text=data.get("options", ""))
    itemData['Options'] = options
    cmds.setParent("..")

    cmds.rowColumnLayout(numberOfColumns=2)
    cmds.textField(text='Maintain',editable=False,w=titleWidth)
    maintain = cmds.checkBox("Maintain", value=data.get("maintain",True))
    itemData['Maintain'] = maintain
    cmds.setParent("..")

    cmds.button(label="X",h=buttonHeight,w=35,backgroundColor=(.5,.2,.2),c=partial(DeleteItem,parentUI))
    cmds.separator(height=10, style='none')

    cmds.setParent("..")    
    cmds.setParent("..")

    spaceItems['items'][parentUI] = itemData
    spaceItems['order'].append(parentUI)

def GroupMatchObject(obj,name):
    grp = cmds.group(em=True, name=name)
    cmds.delete(cmds.parentConstraint(obj, grp, mo=False))
    cmds.delete(cmds.scaleConstraint(obj, grp, mo=False))
    return(grp)

dataFileName = 'NLTA_SpaceData.txt'
def SaveData(*arr):
    path = cmds.file(q=True, sn=True)
    if path:
        filePath = os.path.dirname(path)+'/'+dataFileName
        data = GetSpacesData()
        NLTA_General.writeJsonFile(filePath,data)

def LoadData(ui,*arr):
    path = cmds.file(q=True, sn=True)
    if path:

        filePath = os.path.dirname(path)+'/'+dataFileName
        data = NLTA_General.readJsonFile(filePath)
        if data:
            children = cmds.layout(ui,q=True, ca=True) or []
            for child in children:
                if cmds.control(child, exists=True):
                    cmds.deleteUI(child)
            for i in range(len(data)):
                AddSpaceItem(ui,data[i])

def CreateSpace(data):
    offset = GroupMatchObject(data['child'],data['offsetName'])
    ctrl = data['child']
    ctrlParent = cmds.listRelatives(ctrl,parent=True)
    parents = data['parents'].split('\n')
    if ctrlParent:
        rootParent = ctrlParent[0]
        cmds.parent(offset,rootParent)
    else:
        rootParent = GroupMatchObject(offset,offset+'Parent')
        cmds.parent(offset,rootParent)
    cmds.parent(ctrl,offset)
    if data['maintain']:
        constr = cmds.parentConstraint(*parents,offset,mo=data['maintain'])[0]
        addStt = 0
    else:
        constr = cmds.parentConstraint(rootParent,offset,mo=data['maintain'])[0]
        cmds.parentConstraint(*parents,offset,mo=data['maintain'])
        addStt = 1

    connOrder = {}

    if not cmds.attributeQuery(data['attrPick'], node=ctrl, exists=True):
        cmds.addAttr(ctrl, ln=data['attrPick'], at='enum', en=data['options'])
        cmds.setAttr(ctrl+'.'+data['attrPick'], e=True, keyable=True)
    if not cmds.attributeQuery(data['attrSlide'], node=ctrl, exists=True):
        cmds.addAttr(ctrl, ln=data['attrSlide'], at='double', min=0, max=1, dv=float(data['defaultValue']))
        cmds.setAttr(ctrl+'.'+data['attrSlide'], e=True, keyable=True)

    stt = 0
    for i in range(len(parents)):
        condition = cmds.shadingNode("condition", asUtility=True)
        cmds.connectAttr(ctrl+"."+data['attrPick'], condition+".firstTerm", force=True)
        cmds.setAttr(condition+".secondTerm",i)
        cmds.connectAttr(ctrl+"."+data['attrSlide'],condition+".colorIfTrueR", force=True)
        cmds.setAttr(condition+'.colorIfFalseR', 0)
        cmds.connectAttr(condition+".outColorR", constr+"."+(parents[i]+'W'+str(i+addStt)), force=True)
        stt +=1
    plus = cmds.shadingNode("plusMinusAverage", asUtility=True)
    cmds.setAttr(plus+".operation", 2)
    cmds.connectAttr(ctrl+"."+data['attrSlide'],plus+".input1D[0]", force=True)
    cmds.connectAttr(ctrl+"."+data['attrSlide'],plus+".input1D[1]", force=True)
    cmds.disconnectAttr(ctrl+"."+data['attrSlide'],plus+".input1D[0]")
    cmds.setAttr(plus+".input1D[0]", 1)
    if data['maintain']:
        cmds.parentConstraint(rootParent,offset,mo=True)
        cmds.connectAttr(plus+".output1D", constr+"."+rootParent+"W"+str(stt), force=True)
    else:
        cmds.connectAttr(plus+".output1D", constr+"."+rootParent+"W"+str(0), force=True)

def SpaceOK(*arr):
    data = GetSpacesData()
    for i in range(len(data)):
        CreateSpace(data[i])

def GetSpacesData():
    returnData = []
    for item in spaceItems['items']:
        child=cmds.textField(spaceItems['items'][item]['Child'],query=True,text=True)
        parents=cmds.scrollField(spaceItems['items'][item]['Parents'],query=True,text=True)
        offsetName=cmds.textField(spaceItems['items'][item]['OffsetName'],query=True,text=True)
        attrPick=cmds.textField(spaceItems['items'][item]['AttrPick'],query=True,text=True)
        attrSlide=cmds.textField(spaceItems['items'][item]['AttrSlide'],query=True,text=True)
        defaultValue=cmds.textField(spaceItems['items'][item]['DefaultValue'],query=True,text=True)
        options=cmds.textField(spaceItems['items'][item]['Options'],query=True,text=True)
        maintain = cmds.checkBox(spaceItems['items'][item]['Maintain'],query=True,value=True)
        returnData.append({
            'child':child,
            'parents':parents,
            'offsetName':offsetName,
            'attrPick':attrPick,
            'attrSlide':attrSlide,
            'defaultValue':defaultValue,
            'options':options,
            'maintain':maintain,

        })
    return(returnData)

def RunCurrentPostScript(*arr):
    folderTemp = os.path.dirname(pm.sceneName())
    if not folderTemp:
        folderTemp = pm.mel.eval("SaveSceneAs;")
    if folderTemp:
        folderTemp = os.path.dirname(pm.sceneName())
        NLTA_General.RunScriptFile(folderTemp+'/PostScript.py')

def RunCurrentAfterScript(*arr):
    folderTemp = os.path.dirname(pm.sceneName())
    if not folderTemp:
        folderTemp = pm.mel.eval("SaveSceneAs;")
    if folderTemp:
        folderTemp = os.path.dirname(pm.sceneName())
        NLTA_General.RunScriptFile(folderTemp+'/AfterScript.py')

def RunUpPostScript(*arr):
    folderTemp = os.path.dirname(pm.sceneName())
    if not folderTemp:
        folderTemp = pm.mel.eval("SaveSceneAs;")
    if folderTemp:
        folderTemp = ("/").join(os.path.dirname(pm.sceneName()).split('/')[0:-1])
        NLTA_General.RunScriptFile(folderTemp+'/PostScript.py')

def RunUpAfterScript(*arr):
    folderTemp = os.path.dirname(pm.sceneName())
    if not folderTemp:
        folderTemp = pm.mel.eval("SaveSceneAs;")
    if folderTemp:
        folderTemp = ("/").join(os.path.dirname(pm.sceneName()).split('/')[0:-1])
        NLTA_General.RunScriptFile(folderTemp+'/AfterScript.py')



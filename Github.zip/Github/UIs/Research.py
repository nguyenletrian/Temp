import os
import maya.cmds as cmds
from functools import partial
"""
import json
import shutil
import importlib
import maya.utils

import maya.mel as mel
import pymel.core as pm
import maya.api.OpenMaya as om
import maya.api.OpenMayaAnim as oma

import xml.dom.minidom as xd
import xml.etree.ElementTree as ET

from math import pow,sqrt


import NLTA_General, NLTA_Mesh, NLTA_Graph, NLTA_Brush,NLTA_GraphSkinning,NLTA_Set,NLTA_Proxy,NLTA_Skinning,NLTA_Keyframes,NLTA_BlendShape
for module in [NLTA_General, NLTA_Mesh, NLTA_Graph, NLTA_Brush,NLTA_GraphSkinning,NLTA_Set,NLTA_Proxy,NLTA_Skinning,NLTA_Keyframes,NLTA_BlendShape]:
    try:
        importlib.reload(module)
    except:
        reload(module)
"""
def CreateUI(data):
    global UI 
    def ModifyData(data):
        global titleFlags, layoutFlags, buttonFlags, inputFlags
        titleFlags = data.get('titleFlags', {})
        layoutFlags = data.get('layoutFlags', {})
        buttonFlags = data.get('buttonFlags', {})
        inputFlags = data.get('inputFlags', {})
    ModifyData(data) 

    titles, buttons, inputs = [], [], []
    parent = data['parent']

    layoutTempt = cmds.rowColumnLayout(data["module"],parent=parent)
    cmds.rowColumnLayout(layoutTempt,edit=True,**layoutFlags)
    cmds.rowColumnLayout(numberOfColumns=1)

    cmds.rowColumnLayout( numberOfColumns=2)
    cmds.rowColumnLayout( numberOfColumns=2)
    titles.append(cmds.textField(text="Folder",editable=False,width=110))
    inputs.append(cmds.textField("researchFolder"))
    titles.append(cmds.textField(text="Text",editable=False,width=110))
    inputs.append(cmds.textField("researchText"))
    titles.append(cmds.textField(text="Exts '.py' or ['.py']",editable=False,width=110))
    inputs.append(cmds.textField("researchExts"))
    cmds.setParent("..")
    cmds.rowColumnLayout( numberOfColumns=1)
    buttons.append(cmds.button("SearchOK",label="Check"))
    cmds.setParent("..")
    cmds.setParent("..")

    filesList = cmds.scrollLayout(height=400,width=700)#START SCROLL    
    filesListContent = cmds.rowColumnLayout(nc=1)
    cmds.setParent("..")
    cmds.setParent("..")#END SCROLL
    cmds.button("SearchOK",edit=True,command =partial(RunCheckString,filesListContent))

    cmds.setParent("..")
    cmds.setParent("..")

    for title in titles:
        cmds.textField(title,edit=True,**titleFlags)
    for button in buttons:
        cmds.button(button,edit=True,**buttonFlags)
    for input_ in inputs:
        if cmds.objectTypeUI(input_) == 'textField':
            cmds.textField(input_,edit=True,**inputFlags)
        if cmds.objectTypeUI(input_) == 'intField':
            cmds.intField(input_,edit=True,**inputFlags)

"""
def RunCheckString(ui=None, *arr):s
    # folder = cmds.textField(ui, q=True, text=True)
    folder = r'E:\Projects\ELT\mechanical-arts\Python'
    search_string = "Check Out Scene"
    text_exts = (".py", ".mel", ".ma",".ui",)
    binary_exts = (".mb",)
    result = []
    for root, dirs, files in os.walk(folder):  # tự động xét folder con
        for file in files:
            full_path = os.path.join(root, file)
            lower_file = file.lower()
            try:
                if lower_file.endswith(text_exts):

                    with open(full_path,"r",
                              encoding="utf-8",
                              errors="ignore") as f:
                        for line_num, line in enumerate(f, 1):
                            if search_string in line:
                                data = {
                                    "file": full_path,
                                    "line": line_num,
                                    "text": line.strip()
                                }
                                result.append(data)
                                print("\nFOUND:")
                                print("FILE :", full_path)
                                print("LINE :", line_num)
                                print("TEXT :", line.strip())
                                break
                elif lower_file.endswith(binary_exts):
                    with open(full_path, "rb") as f:
                        content = f.read()
                        if search_string.encode() in content:
                            data = {
                                "file": full_path,
                                "line": None,
                                "text": "FOUND IN BINARY"
                            }
                            result.append(data)
                            print("\nFOUND:")
                            print("FILE :", full_path)
                            print("TEXT : FOUND IN BINARY")
            except Exception as e:
                print("\nERROR:")
                print(full_path)
                print(e)

    print("\n=========================")
    print("TOTAL :", len(result))
    print("=========================")

    return result
"""

def RunCheckString(search_string,folder=r'E:\Projects\ELT',exts=None,*arr):
    #"E:\Projects\ELT\mechanical-arts\Python\framework\packages\mca-maya\mca\mya\tools\rigchecklist\ui\checklist.py"
    #E:\Projects\ELT\mechanical-arts\Python\framework\packages\mca-maya\mca\mya\tools
    """
    import sys
    sys.path.append(
        r"E:\Projects\ELT\mechanical-arts\Python\framework\packages\mca-maya"
    )

    from mca.mya.tools.rigchecklist.actions import tpose

    tpose.fk_to_tpose()    """



    """
    exts:
        None                -> tất cả file
        ".py"               -> chỉ py
        (".py", ".mel")     -> nhiều đuôi
    """

    result = []
    if isinstance(exts, str):
        exts = (exts.lower(),)
    elif exts:
        exts = tuple(e.lower() for e in exts)

    for root, dirs, files in os.walk(folder):
        dirs[:] = [
            d for d in dirs
            if d not in {
                ".git",
                "__pycache__",
                ".idea",
                ".vs"
            }
        ]
        for file in files:
            lower_file = file.lower()
            if exts and not lower_file.endswith(exts):
                continue
            full_path = os.path.join(root, file)
            try:
                found = False
                try:
                    with open(full_path,"r",encoding="utf-8",errors="ignore") as f:
                        for line_num, line in enumerate(f, 1):
                            if search_string in line:
                                data = {
                                    "file": full_path,
                                    "line": line_num,
                                    "text": line.strip()
                                }
                                result.append(data)
                                print("\nFOUND:")
                                print("FILE :", full_path)
                                print("LINE :", line_num)
                                print("TEXT :", line.strip())
                                found = True
                                break
                except:
                    pass
                if not found:
                    try:
                        with open(full_path, "rb") as f:
                            content = f.read()
                            if search_string.encode() in content:
                                data = {
                                    "file": full_path,
                                    "line": None,
                                    "text": "FOUND IN BINARY"
                                }
                                result.append(data)
                                print("\nFOUND:")
                                print("FILE :", full_path)
                                print("TEXT : FOUND IN BINARY")
                    except:
                        pass
            except Exception as e:
                print("\nERROR:")
                print(full_path)
                print(e)
    print("\n=========================")
    print("TOTAL :", len(result))
    print("=========================")

    return result 
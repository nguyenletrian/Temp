import os
import json
import shutil
import importlib
import maya.utils
import maya.cmds as cmds
import maya.mel as mel
import pymel.core as pm
import maya.api.OpenMaya as om
import maya.api.OpenMayaAnim as oma

import xml.dom.minidom as xd
import xml.etree.ElementTree as ET
from functools import partial
from math import pow,sqrt


import NLTA_General, NLTA_Mesh, NLTA_Graph
importlib.reload(NLTA_General)
importlib.reload(NLTA_Mesh)
importlib.reload(NLTA_Graph)


########### SCRIPT JOB
skinSession = {
    'mesh':None,
    'skinCluster':None,
    'joints':None,
}
"""
def DetectCurrentSkin():
    global skinSession
    selection = cmds.ls(selection=True)
    if selection:
        mesh = selection[0]
        skinCluster = cmds.ls(cmds.listHistory(mesh), type='skinCluster')
        if skinCluster:
            skinSession['mesh'] = mesh
            skinSession['skinCluster'] = skinCluster[0]
            skinSession['joints'] = cmds.skinCluster(skinCluster[0], query=True, influence=True)
"""
def DetectCurrentSkin():
    global skinSession    
    selection = cmds.ls(selection=True)
    if not selection:
        return    
    obj = selection[0]    
    obj = obj.split('.')[0]
    shapes = cmds.listRelatives(obj, shapes=True, fullPath=True) or []
    if not shapes:
        return    
    shape = shapes[0]
    history = cmds.listHistory(shape) or []
    skins = cmds.ls(history, type='skinCluster')    
    if not skins:
        return    
    skin = skins[0]
    skinSession['mesh'] = obj
    skinSession['skinCluster'] = skin
    skinSession['joints'] = cmds.skinCluster(skin, q=True, inf=True)


def OpenSkinToolListen():
    jobs = cmds.scriptJob(listJobs=True)
    for job in jobs:
        if 'DetectCurrentSkin' in job:
            jobID = int(job.split(":")[0])
            cmds.scriptJob(kill=jobID, force=True)
    cmds.scriptJob(event=["ToolChanged",DetectCurrentSkin], protected=True)
    cmds.scriptJob(event=["SelectionChanged",DetectCurrentSkin], protected=True)
OpenSkinToolListen()



###################
UIs = {
    "animationDistance":None,
}

def CreateUI(data):
    global UI 
    def ModifyData(data):
        global titleFlags, layoutFlags, buttonFlags, inputFlags
        titleFlags = data.get('titleFlags', {})
        layoutFlags = data.get('layoutFlags', {})
        buttonFlags = data.get('buttonFlags', {})
        inputFlags = data.get('inputFlags', {})
    ModifyData(data) 

    titles, buttons, inputs = [], [], []
    parent = data['parent']

    layoutTempt = cmds.rowColumnLayout(data["module"],parent=parent)
    cmds.rowColumnLayout(layoutTempt,edit=True,**layoutFlags)
    cmds.rowColumnLayout(numberOfColumns=1)


    cmds.rowColumnLayout( numberOfColumns=2)#***
    cmds.rowColumnLayout( numberOfColumns=1)#<*
    animationDistance = cmds.intSliderGrp(label="Distance",field=True,minValue=0,maxValue=10000,value=300,width=270,columnWidth=[(1, 60)])    
    UIs["animationDistance"] = animationDistance
    cmds.rowColumnLayout( numberOfColumns=2)#<
    cmds.rowColumnLayout( numberOfColumns=1)
    titles.append(cmds.textField(text="Local",editable=False))
    cmds.rowColumnLayout( numberOfColumns=2)
    buttons.append(cmds.button( label='Rotate',command = partial(CreateKeyframe,{'space':'local','type':'rotate','inturn':True}),width=120))
    buttons.append(cmds.button( label='Translate',command = partial(CreateKeyframe,{'space':'local','type':'translate','inturn':True}),width=120))
    buttons.append(cmds.button( label='Rotate Together',command = partial(CreateKeyframe,{'space':'local','type':'rotate','inturn':False})))
    buttons.append(cmds.button( label='Translate Together',command = partial(CreateKeyframe,{'space':'local','type':'translate','inturn':False})))
    cmds.setParent("..")
    cmds.setParent("..")
    cmds.rowColumnLayout( numberOfColumns=1)
    titles.append(cmds.textField(text="Global",editable=False))
    cmds.rowColumnLayout( numberOfColumns=2)
    buttons.append(cmds.button( label='Rotate',command = partial(CreateKeyframe,{'space':'world','type':'rotate','inturn':True}),width=120))
    buttons.append(cmds.button( label='Translate',command = partial(CreateKeyframe,{'space':'world','type':'translate','inturn':True}),width=120))
    buttons.append(cmds.button( label='Rotate Toget',command = partial(CreateKeyframe,{'space':'world','type':'rotate','inturn':False})))
    buttons.append(cmds.button( label='Translate Together',command = partial(CreateKeyframe,{'space':'world','type':'translate','inturn':False})))
    cmds.setParent("..")
    cmds.setParent("..")
    cmds.setParent("..")#>
    cmds.setParent("..")#*>
    cmds.rowColumnLayout( numberOfColumns=2)
    buttons.append(cmds.button( label='Delete',command = deleteSenceKeyframe,width=95))
    buttons.append(cmds.button( label='Zoom',command = ZoomRangeAnim,width=95))
    buttons.append(cmds.button( label='Delete Attr',command = DeleteAttrKeyframes,width=95)) 
    buttons.append(cmds.button( label='Fit',command = FitRangeAnim,width=95))
    buttons.append(cmds.button(label='Bind pose',c = goToBindPose))        
    cmds.setParent("..")
    cmds.setParent("..")#***

    ############################

    cmds.separator(height=10, style='in')
    titles.append(cmds.textField(text="Paint Skin Tools",editable=False))

    cmds.rowColumnLayout( numberOfColumns=1)#Open    

    cmds.rowColumnLayout(numberOfColumns=1)#-
    opacitySlider = cmds.floatSliderGrp(label="Opacity",field=True,minValue=0,maxValue=1,fieldMinValue=0,fieldMaxValue=1,value=1,step=0.0001,width=700,columnWidth=[(1, 60)]),#changeCommand=on_change
    cmds.floatSliderGrp(opacitySlider,e=True,cc=partial(ChangeOpacity,opacitySlider))
    cmds.rowColumnLayout(numberOfColumns=3)#--
    cmds.rowColumnLayout(numberOfColumns=1)
    buttons.append(cmds.button( label='Unlock',c = unlock,width=70))
    buttons.append(cmds.button( label='Add unlock',c = addUnlock))
    buttons.append(cmds.button( label='Switch',c = switchJoint))    
    cmds.setParent("..")
    cmds.rowColumnLayout( numberOfColumns=1)
    buttons.append(cmds.button( label='Add Down',c = addUnlockDown,width=70))
    buttons.append(cmds.button( label='Add Up',c = addUnlockUp))
    buttons.append(cmds.button( label='Unlock all',c = unlockAll))
    buttons.append(cmds.button( label='Isolate',c = IsolateEffectVertex))
    cmds.setParent("..")
    cmds.rowColumnLayout(numberOfColumns=1)#---
    cmds.rowColumnLayout(numberOfColumns=10)
    buttons.append(cmds.button(label="0.0001",width=60, c = partial(ChangeOpacityValue,opacitySlider,0.0001)))
    buttons.append(cmds.button(label="0.0005",width=60, c = partial(ChangeOpacityValue,opacitySlider,0.0005)))
    buttons.append(cmds.button(label="0.001",width=60, c = partial(ChangeOpacityValue,opacitySlider,0.001)))
    buttons.append(cmds.button(label="0.003",width=60, c = partial(ChangeOpacityValue,opacitySlider,0.003)))
    buttons.append(cmds.button(label="0.005",width=60, c = partial(ChangeOpacityValue,opacitySlider,0.005)))
    buttons.append(cmds.button(label="0.01",width=50, c = partial(ChangeOpacityValue,opacitySlider,0.01)))
    buttons.append(cmds.button(label="0.05",width=50, c = partial(ChangeOpacityValue,opacitySlider,0.05)))
    buttons.append(cmds.button(label="0.1",width=50, c = partial(ChangeOpacityValue,opacitySlider,0.1)))
    buttons.append(cmds.button(label="0.5",width=50, c = partial(ChangeOpacityValue,opacitySlider,0.5)))
    buttons.append(cmds.button(label="1",width=40, c = partial(ChangeOpacityValue,opacitySlider,1)))
    cmds.setParent("..")
    cmds.rowColumnLayout( numberOfColumns=8)
    buttons.append(cmds.button(label="-1",width=60, c = partial(replaceWeight,-1)))
    buttons.append(cmds.button(label="0",width=60, c = partial(replaceWeight,0)))
    buttons.append(cmds.button(label="1",width=60, c = partial(replaceWeight,1)))
    buttons.append(cmds.button(label="Smooth", c = partial(smooth,"solid"),width=80))
    buttons.append(cmds.button(label="Flood", c = flood,width=80))
    buttons.append(cmds.button(label='Pick value',c = pickValue,width=100))
    buttons.append(cmds.button(label="Copy Weight",c = CopyWeight,width=100))    
    cmds.setParent("..")
    cmds.separator(height=10, style='in')
    cmds.rowColumnLayout( numberOfColumns=7)
    buttons.append(cmds.button(label="Miror +X ",c=partial(mirrorSkin,"x","+"),width=77))
    buttons.append(cmds.button(label="Miror -X ",c=partial(mirrorSkin,"x","-"),width=77))
    buttons.append(cmds.button(label="Proxy",c=singleProxy,width=77))
    buttons.append(cmds.button(label="Proxy X",c=partial(createProxy,"x"),width=77))
    buttons.append(cmds.button(label="Copy Proxy",c=copyProxy,width=77))
    buttons.append(cmds.button(label="Past Proxy",c=pastProxy,width=77))
    buttons.append(cmds.button(label="Closet Faces",c=SelectClosetFaces,width=77))  
    cmds.setParent("..")
    cmds.separator(height=10, style='in')
    cmds.rowColumnLayout( numberOfColumns= 7)
    buttons.append(cmds.button(label="Copy Skin",c = NLTA_General.copyJointBind,width=77))
    buttons.append(cmds.button(label='Import Skin',c = ImportAllSkin,width=77))
    buttons.append(cmds.button(label='Export Skin',c = ExportAllSkin,width=77))      
    buttons.append(cmds.button(label="Clear Skins",c = clearSkin,width=77))
    buttons.append(cmds.button(label="Bind Skin",c = NLTA_General.bindSkin,width=77))
    buttons.append(cmds.button(label="Import Folder",c = ImportFolderSkin,width=77))
    buttons.append(cmds.button(label="Export Folder",c = ExportFolderSkin,width=77))

    cmds.setParent("..")
    cmds.separator(height=10, style='in')
    cmds.rowColumnLayout( numberOfColumns= 7)
    buttons.append(cmds.button(label='Component',c=component,width=77))
    buttons.append(cmds.button(label="Middle",c=setMiddleWeight,width=77))
    buttons.append(cmds.button(label="Load UI", c=loadUi,width=77))
    buttons.append(cmds.button(label="Prune",c=pruneSmallWeights,width=77))
    buttons.append(cmds.button(label="Add joint",c=AddJoint,width=77))
    buttons.append(cmds.button(label="Add Mesh jnt",c=AddMeshJoint,width=77))    
    buttons.append(cmds.button(label="Clr Unneed",c=removeUnneedJoint,width=77))    
    buttons.append(cmds.button(label="Export FBX",c = ExportSkinFbx,width=77))
    buttons.append(cmds.button(label="Export Scene",c = ObjToNewScene,width=77))
    buttons.append(cmds.button(label="Fix Quad",c=NLTA_Mesh.ShowQuardraw))
    buttons.append(cmds.button(label="Fix Initial",c=fixInitial))
    buttons.append(cmds.button(label="Clear Weight ",c = ClearWeight,width=90))
    cmds.setParent("..")
    cmds.separator(height=10, style='in')
    cmds.rowColumnLayout( numberOfColumns=4)
    buttons.append(cmds.button( label="Create Set",width=135, command = CreateSet))
    buttons.append(cmds.button( label="Next Set",width=135, command = NextSet))
    buttons.append(cmds.button( label="Back Set",width=135, command = BackSet))
    buttons.append(cmds.button( label="Delete Sets",width=135, command = DeleteSets))
    cmds.setParent("..")
    cmds.separator(height=10, style='in')
    cmds.rowColumnLayout(numberOfColumns=4)
    titles.append(cmds.textField(text="Max Influent",editable=False,width=90))
    inputs.append(cmds.intField("maxInfluent",value=4,width=90))
    buttons.append(cmds.button(label="Fix",command = partial(fixMaxInfluence,cmds.intField("maxInfluent",value=True,query=True)),width=179))
    buttons.append(cmds.button(label="Check",command = checkMaxInfluent,width=180))
    cmds.setParent("..")
    cmds.setParent("..")#---
    cmds.setParent("..")#--
    cmds.setParent("..")#-

    cmds.setParent("..")#End

    cmds.separator(height=10, style='in')
    titles.append(cmds.textField(text="Proxy",editable=False))
    cmds.rowColumnLayout(nc=2)#Open
    cmds.rowColumnLayout(nc=1)#<-
    cmds.rowColumnLayout(nc=3)


    buttons.append(cmds.button(label="Open Graph",c=partial(NLTA_Graph.OpenGraph,"NLTA_Graph"),width=95))
    buttons.append(cmds.button(label="Flip",c=partial(NLTA_Graph.FlipX,"NLTA_Graph"),width=95))
    buttons.append(cmds.button(label="Clamp",c=partial(NLTA_Graph.Clamp,"NLTA_Graph"),width=95))
    #buttons.append(cmds.button(label="Smooth 2 Joint",c=GradientTwoJoints,width=95))
    buttons.append(cmds.button(label="Graph smooth",c=GradientActiveJoint,width=95))
    buttons.append(cmds.button(label="Copy Weight Per",c=CopyWeightPer,width=95))
    buttons.append(cmds.button(label="Copy Ratio Per",c=CopyRatioWeight,width=95))
    buttons.append(cmds.button(label="Anim Proxy Paste",c=AnimProxyPaste,width=95))
    
    

    
    cmds.setParent("..")

    cmds.setParent("..")#>-
    cmds.rowColumnLayout(nc=1)#<-
    cmds.rowColumnLayout(nc=4)
    buttons.append(cmds.button(label="Edges > Curve ",c=EdgesToCurve,width=95))
    buttons.append(cmds.button(label="Verts > Curve ",c=VertsToCurve,width=95))
    buttons.append(cmds.button(label="Draw Curve",c=DrawCurve,width=95))
    buttons.append(cmds.button(label="Close Curve",c=CloseCurve,width=95))        
    cmds.setParent("..")
    cmds.separator(height=10, style='in')
    cmds.rowColumnLayout(nc=4)
    buttons.append(cmds.button(label="Create Loft",c=CreateLoft,width=95))
    buttons.append(cmds.button(label="Flip Curve",c=FlipCurveNormal,width=95))       
    buttons.append(cmds.button(label="RotateCVs +",c=RotateCVsPositive,width=95))
    buttons.append(cmds.button(label="RotateCVs -",c=RotateCVsNegative,width=95))
    buttons.append(cmds.button(label="Flip Loft",c=FlipLoftNormal,width=95)) 
    buttons.append(cmds.button(label="Add Loft Curve",c=AddLoftCurve))
    buttons.append(cmds.button(label="Clear Scene",c=ClearAllLoft,width=95))
    cmds.setParent("..")  
    cmds.setParent("..")#>-

    cmds.setParent("..")#End


    cmds.separator(height=10, style='in')
    titles.append(cmds.textField(text="Blend Shape",editable=False))
    cmds.rowColumnLayout( numberOfColumns=7)#<- 
    buttons.append(cmds.button(label="Import BlendShape",c = ImportBlendShape))
    buttons.append(cmds.button(label="Export BlendShape",c = ExportBlendShape))
    buttons.append(cmds.button(label="Export BS to XML",c = ExportBSToXML))
    buttons.append(cmds.button(label="Export Vertexs Pos",c = ExportVertexsPosition))
    buttons.append(cmds.button(label="Import Vertexs Pos",c = ImportVertexsPosition))
    cmds.setParent("..")#>-

    cmds.setParent("..")
    cmds.setParent("..")

    for title in titles:
        cmds.textField(title,edit=True,**titleFlags)
    for button in buttons:
        cmds.button(button,edit=True,**buttonFlags)
    for input_ in inputs:
        if cmds.objectTypeUI(input_) == 'textField':
            cmds.textField(input_,edit=True,**inputFlags)
        if cmds.objectTypeUI(input_) == 'intField':
            cmds.intField(input_,edit=True,**inputFlags)

def getDagPath(node):
    sel = om.MSelectionList()
    sel.add(node)
    return sel.getDagPath(0)


def getSkinClusterFn(skinCluster):
    sel = om.MSelectionList()
    sel.add(skinCluster)
    obj = sel.getDependNode(0)
    return oma.MFnSkinCluster(obj)

def GetVertexWeights(skinCluster, vert):
    infls = cmds.skinCluster(skinCluster, q=True, influence=True)
    weights = cmds.skinPercent(skinCluster, vert, q=True, value=True)
    return dict(zip(infls, weights))

def SetVertexWeights(skinCluster, vert, weightDict):
    influences = list(weightDict.keys())
    values = list(weightDict.values())
    cmds.skinPercent(
        skinCluster,
        vert,
        transformValue=list(zip(influences, values))
    )

def GradientActiveJoint(*args):
    verts = cmds.ls(sl=True, fl=True)
    if not verts:
        cmds.warning("No vertices selected")
        return

    mesh = verts[0].split(".")[0]
    skinData = NLTA_General.GetSkinData(mesh)

    jointA = skinData["jointActive"]
    joints = skinData["jointsUnlock"]
    skinCluster = skinData["skinCluster"]

    # 🔥 TẮT DEFORM
    oldEnv = cmds.getAttr(skinCluster + ".envelope")
    cmds.setAttr(skinCluster + ".envelope", 0)

    try:
        # --- collect distances ---
        distances = []
        validVerts = []

        for v in verts:
            if ".vtx[" not in v:
                continue
            d = NLTA_General.GetDistance(v, jointA)
            if d is None:
                continue
            distances.append(d)
            validVerts.append(v)

        if not distances:
            return

        minDist = min(distances)
        maxDist = max(distances)

        
        if abs(maxDist - minDist) < 1e-8:
            maxDist = minDist + 1e-8
        

        # --- process ---
        for v in validVerts:
            d = NLTA_General.GetDistance(v, jointA)

            ratio = (d - minDist) / (maxDist - minDist)
            #ratio = d/maxDist
            ratio = 1-(max(0.0, min(1.0, ratio)))

            val = NLTA_Graph.GetValue(ratio)
            if val is None:
                val = ratio * 100.0

            val = val / 100.0

            totalW = 0.0
            for j in joints:
                totalW += cmds.skinPercent(skinCluster, v, q=True, transform=j)

            if totalW == 0:
                continue

            newA = totalW * val

            cmds.skinPercent(
                skinCluster,
                v,
                transformValue=[(jointA, newA)],
                normalize=True
            )

    finally:
        # 🔥 BẬT LẠI DEFORM
        cmds.setAttr(skinCluster + ".envelope", oldEnv)

    # --- force update ---
    cmds.skinCluster(skinCluster, e=True, forceNormalizeWeights=True)
    cmds.dgdirty(mesh)
    cmds.refresh()

def CopyWeightPer(*arr):
    verts = cmds.ls(selection=True,flatten=True)
    if verts:
        mesh = verts[0].split(".")[0]
        skinData = NLTA_General.GetSkinData(mesh)
        skinCluster = skinData["skinCluster"]
        oldEnv = cmds.getAttr(skinCluster + ".envelope")
        cmds.setAttr(skinCluster + ".envelope", 0)
        data = NLTA_Mesh.ListToPerVerts(verts)
        for vert in data:
            cmds.select(vert)
            pm.mel.eval('CopyVertexSkinWeights;')
            cmds.select(data[vert])
            pm.mel.eval('PasteVertexSkinWeights;')
        cmds.setAttr(skinCluster + ".envelope",oldEnv)
        cmds.skinCluster(skinCluster, e=True, forceNormalizeWeights=True)
        cmds.dgdirty(mesh)
        cmds.refresh()
 
def AnimProxyPaste(*arr):
    selection =  cmds.ls(selection=True)
    if selection:
        source = selection[0]
        targets = selection[1]
        keyObj = selection[2]

    keys = cmds.keyframe(keyObj, q=True)

    if not keys:
        return None
    for timeTemp in (min(keys),max(keys)):
        print(timeTemp)

    """
    for target in targets:
        vertsNearest = NLTA_Mesh.GetIntersectVerts(source,target,0.05)
        cmds.select(vertsNearest)
    """
def GetJointsWeight(data):
    skinCluster = data["skinCluster"]
    vert = data["vert"]
    joints = data["joints"]
    if not joints:
        return {}
    values = [
        cmds.skinPercent(skinCluster, vert, q=True, transform=j)
        for j in joints
    ]
    total = sum(values)
    result = {}
    for j, w in zip(joints, values):
        ratio = (w / total) if total != 0 else 0.0
        result[j] = {
            "weight": w,
            "ratio": ratio
        }
    return result

def GetJointsTotalWeight(skinCluster, vert, joints):
    if not joints:
        return 0.0
    values = cmds.skinPercent(
        skinCluster,
        vert,
        q=True,
        transformValue=joints
    )
    # Maya trả float nếu chỉ có 1 joint
    if not isinstance(values, (list, tuple)):
        values = [values]
    return sum(values)

def WeightFromRatio(data):
    skinCluster = data["skinCluster"]
    vert = data["vert"]
    joints = data["joints"]
    ratios = data["ratios"]
    if not joints or not ratios or len(joints) != len(ratios):
        return
    values = [
        cmds.skinPercent(skinCluster, vert, q=True, transform=j)
        for j in joints
    ]

    totalWeight = sum(values)
    if totalWeight == 0:
        return
    newWeights = [totalWeight * r for r in ratios]
    cmds.skinPercent(
        skinCluster,
        vert,
        transformValue=list(zip(joints, newWeights))
    )




def ApplyWeightRatio(sourceVert, targetVert, skinCluster,joints=None):
    pass

def CopyRatioWeight(*arr):
    verts = cmds.ls(selection=True,flatten=True)
    if verts:
        mesh = verts[0].split(".")[0]
        skinData = NLTA_General.GetSkinData(mesh)
        skinCluster = skinData["skinCluster"]
        oldEnv = cmds.getAttr(skinCluster + ".envelope")
        cmds.setAttr(skinCluster + ".envelope", 0)
        data = NLTA_Mesh.ListToPerVerts(verts)

        for vert in data:
            jointsWeight = GetJointsWeight({
                "skinCluster":skinData["skinCluster"],
                "vert":vert,
                "joints":skinData["jointsUnlock"]
            })
            ratios = []
            for jointUnlock in skinData["jointsUnlock"]:
                ratios.append(jointsWeight[jointUnlock]["ratio"])
            verts = data[vert]
            for vertTemp in verts:
                WeightFromRatio({
                    "skinCluster":skinCluster,
                    "vert":vertTemp,
                    "joints":skinData["jointsUnlock"],
                    "ratios":ratios
                })
        cmds.setAttr(skinCluster + ".envelope",oldEnv)
        cmds.skinCluster(skinCluster, e=True, forceNormalizeWeights=True)
        cmds.dgdirty(mesh)
        cmds.refresh()


def GetVertexsSelected(*arr):
    sel = cmds.ls(sl=True)    
    if not sel:
        return []    
    verts = cmds.polyListComponentConversion(sel, toVertex=True)
    verts = cmds.ls(verts, fl=True)    
    return verts

def ClearWeight(JointActive):
    verts = GetVertexsSelected()
    if verts:
        mesh = verts[0].split(".")[0]
        skinData = NLTA_General.GetSkinData(mesh)    
        # lấy skinCluster
        skin = skinData["skinCluster"]
        jointActive = skinData["jointActive"]
        if not skin:
            cmds.warning("Mesh không có skinCluster")
            return
        for v in verts:
            # lấy influences + weight
            influences = cmds.skinPercent(skin, v, q=True, transform=None)
            weights    = cmds.skinPercent(skin, v, q=True, value=True)        
            if not influences or not weights:
                continue
            weightMap = dict(zip(influences, weights))
            # skip nếu source không có
            if jointActive not in weightMap:
                print("not in weight map")
                continue
            sourceW = weightMap[jointActive]
            if sourceW <= 0.0:
                continue        
            # tìm dominant (trừ source)
            dominantJoint = None
            print(dominantJoint)
            max_w = -1        
            for j, w in weightMap.items():
                if j == jointActive:
                    continue            
                if w > max_w:
                    max_w = w
                    dominantJoint = j
            print(dominantJoint)    
            if not dominantJoint:
                continue        
            # transfer
            new_dom_w = weightMap.get(dominantJoint, 0.0) + sourceW        
            cmds.skinPercent(skin,v,transformValue=[
                    (dominantJoint, new_dom_w),
                    (jointActive, 0.0)
                ]
            )
        
        # normalize (quan trọng)
        cmds.skinCluster(skin, e=True, forceNormalizeWeights=True)    
        print("Done transfer on selected vertices")


def GetGradientValue(ctrl, x):
    s = cmds.gradientControlNoAttr(ctrl, q=True, asString=True)
    data = list(map(float, s.split(",")))
    points = []
    for i in range(0, len(data), 3):
        pos = data[i]
        val = data[i+1]
        interp = int(data[i+2])
        points.append((pos, val, interp))
    points.sort(key=lambda p: p[0])
    if x <= points[0][0]:
        return points[0][1]
    if x >= points[-1][0]:
        return points[-1][1]
    for i in range(len(points)-1):
        p0, v0, interp = points[i]
        p1, v1, _ = points[i+1]
        if p0 <= x <= p1:
            t = (x - p0) / (p1 - p0)
            if interp == 0:  # none
                return v0
            elif interp == 1:  # linear
                return v0 + (v1 - v0) * t
            elif interp == 2:  # smooth
                t = t * t * (3 - 2 * t)
                return v0 + (v1 - v0) * t

def GetJointVertexs(mesh, joints, threshold=0.0001):
    skins = cmds.ls(cmds.listHistory(mesh), type='skinCluster')
    if not skins:
        return []
    skin = skins[0]

    sel = om.MSelectionList()
    sel.add(mesh)
    dagPath = sel.getDagPath(0)

    sel.add(skin)
    skinObj = sel.getDependNode(1)

    fnSkin = oma.MFnSkinCluster(skinObj)

    infPaths = fnSkin.influenceObjects()
    jointSet = set(joints)

    infIndices = [i for i, inf in enumerate(infPaths)
                  if inf.partialPathName() in jointSet]

    if not infIndices:
        return []

    # --- get all vertex ids ---
    itVert = om.MItMeshVertex(dagPath)
    vtxIds = []
    while not itVert.isDone():
        vtxIds.append(itVert.index())
        itVert.next()

    # --- component ---
    compFn = om.MFnSingleIndexedComponent()
    comp = compFn.create(om.MFn.kMeshVertComponent)
    compFn.addElements(vtxIds)

    # --- weights ---
    weights, infCount = fnSkin.getWeights(dagPath, comp)

    # --- result ---
    result = []
    for i, vId in enumerate(vtxIds):
        base = i * infCount
        for infId in infIndices:
            if weights[base + infId] > threshold:
                result.append(f"{mesh}.vtx[{vId}]")
                break

    return result


def ChangeOpacity(ui,*arr):
    value = cmds.floatSliderGrp(ui,query=True,value=True)
    ctx = cmds.currentCtx()
    try:
        cmds.artAttrSkinPaintCtx(ctx, e=True, opacity=value)
    except:pass

def ChangeOpacityValue(ui,value,*arr):
    cmds.floatSliderGrp(ui,edit=True,value=value)
    ChangeOpacity(ui)

def GetSkinCluster(mesh):
    history = cmds.listHistory(mesh)
    skins = cmds.ls(history, type='skinCluster')
    return skins[0] if skins else None


def fixInitial(*arr):
    cmds.lockNode('initialShadingGroup', l=0, lockUnpublished=0)



def ImportBlendShape(*arr):
    folder_temp = os.path.dirname(pm.sceneName())
    if not folder_temp:
        folder_temp = pm.mel.eval("SaveSceneAs;")
    folder_temp = os.path.dirname(pm.sceneName())
    jsonPath = folder_temp+'/BlendShapeData.json'
    data = NLTA_General.readJsonFile(jsonPath)
    if data:
        for entry in data:
            base_mesh = entry["mesh"]
            targets = entry["targets"]
            target_meshes = [t["target_mesh"] for t in targets]
            bs_node = cmds.blendShape(
                target_meshes,
                base_mesh,
                name=entry["BS"]
            )[0]
            for i, t in enumerate(targets):
                alias_list = cmds.aliasAttr(bs_node, q=True) or []
                alias_dict = {alias_list[i+1]: alias_list[i] for i in range(0, len(alias_list), 2)}
                plug_name = f"weight[{i}]"
                if plug_name in alias_dict:
                    cmds.aliasAttr(bs_node+'.'+alias_dict[plug_name], remove=True)
                cmds.aliasAttr(t["name"], f"{bs_node}.w[{i}]")
                cmds.setAttr(f"{bs_node}.{t['name']}", t["value"])

def GetBSSingle(mesh):
    history = cmds.listHistory(mesh)
    BS = cmds.ls(history, type="blendShape")
    if not BS:
        return
    BSNode = BS[0]
    attrs = cmds.listAttr(BSNode + '.w', m=True) or []
    alias_list = cmds.aliasAttr(BSNode, q=True) or []
    alias_dict = {}
    for i in range(0, len(alias_list), 2):
        name = alias_list[i]
        plug = alias_list[i+1]  # ví dụ: "weight[0]"
        index = int(plug.split("[")[1].split("]")[0])
        alias_dict[name] = index    
    data = {
        "mesh": mesh,
        "BS": BSNode,
        "targets": []
    }

    for attr in attrs:
        index = alias_dict.get(attr)
        if index is None:
            continue
        targetMeshes = cmds.blendShape(BSNode, q=True, target=True) or []
        if index >= len(targetMeshes):
            continue    
        targetMesh = targetMeshes[index]
        value = cmds.getAttr(f"{BSNode}.{attr}")
        data["targets"].append({
            "name": attr,
            "target_mesh": targetMesh,
            "value": value
        })
    return(data)

def GetAllBSData():    
    data = []    
    meshs = list(set(cmds.listRelatives(cmds.ls(type="mesh"),parent=True)))
    for mesh in meshs:
        if GetBSSingle(mesh) != None:
            data.append(GetBSSingle(mesh))
    return(data)


def ExportBlendShape(*arr):
    folder_temp = os.path.dirname(pm.sceneName())
    if not folder_temp:
        folder_temp = pm.mel.eval("SaveSceneAs;")
    folder_temp = os.path.dirname(pm.sceneName())
    if folder_temp:
        jsonPath = folder_temp+'/BlendShapeData.json'
        BSData = GetAllBSData()
        NLTA_General.writeJsonFile(jsonPath,BSData)
        cmds.warning("Done!!!")

def ExportBSToXML(*arr):
    folder_temp = os.path.dirname(pm.sceneName())
    if not folder_temp:
        folder_temp = pm.mel.eval("SaveSceneAs;")
    folder_temp = os.path.dirname(pm.sceneName())
    if folder_temp:
        jsonPath = folder_temp+'/BlendShapeData.xml'
        BSData = GetAllBSData()
        root = ET.Element("Meshes")
        for item in BSData:
            mesh_elem = ET.SubElement(root, "Mesh", name=item.get("mesh", ""), BS=item.get("BS", ""))
            for target in item.get("targets", []):
                ET.SubElement(
                    mesh_elem,
                    "Target",
                    name=target.get("name", ""),
                    target_mesh=target.get("target_mesh", ""),
                    value=str(target.get("value", "0.0"))
                )
        tree = ET.ElementTree(root)
        tree.write(jsonPath, encoding="utf-8", xml_declaration=True)
        print(f"XML file saved to: {jsonPath}")

def ExportVertexsPositionSingle(mesh, jsonPath, space='world'):
    dag = NLTA_Mesh.GetDagPath(mesh)
    fn_mesh = om.MFnMesh(dag)

    space_enum = om.MSpace.kWorld if space == 'world' else om.MSpace.kObject
    pts = fn_mesh.getPoints(space_enum)
    positions = [[p.x, p.y, p.z] for p in pts]
    vcount = fn_mesh.numVertices
    folder = os.path.dirname(jsonPath)
    if folder and not os.path.isdir(folder):
        os.makedirs(folder)
    data = {
        "mesh": mesh,
        "space": space,
        "vertexCount": vcount,
        "positions": positions
    }
    with open(jsonPath, "w") as f:
        json.dump(data, f, indent=2)

def ExportVertexsPosition(*arr):
    folder_temp = os.path.dirname(pm.sceneName())
    if not folder_temp:
        folder_temp = pm.mel.eval("SaveSceneAs;")
    folderTemp = os.path.dirname(pm.sceneName())
    if folderTemp:
        exportPath = folderTemp+"/VertexsPosition/"
        objs = cmds.ls(selection=True)
        for obj in objs:
            ExportVertexsPositionSingle(obj,exportPath+obj+'.json')

    print("Export Vertexs Done!~")

def ImportVertexsPositionSingle(json_path, target_mesh=None, space_override=None):
    with open(json_path, "r") as f:
        data = json.load(f)

    mesh = target_mesh or data.get("mesh")
    if not mesh:
        raise RuntimeError("JSON không chứa tên mesh và bạn chưa truyền 'target_mesh'.")
    if cmds.objExists(mesh):
        dag = NLTA_Mesh.GetDagpath(mesh)
        fn_mesh = om.MFnMesh(dag)

        positions = data.get("positions")
        vcount_json = data.get("vertexCount")
        vcount_scene = fn_mesh.numVertices

        if vcount_json != vcount_scene:
            raise RuntimeError("Vertex count không khớp: file={} vs scene={}".format(vcount_json, vcount_scene))
        if not positions or len(positions) != vcount_scene:
            raise RuntimeError("Dữ liệu 'positions' trong JSON không hợp lệ.")

        # Chọn space cho import
        file_space = data.get("space", "world")
        space = space_override or file_space
        space_enum = om.MSpace.kWorld if space == 'world' else om.MSpace.kObject

        # Tạo MPointArray và set điểm một lần
        mpoints = om.MPointArray()
        for x, y, z in positions:
            mpoints.append(om.MPoint(x, y, z))

        # Ghi điểm vào mesh
        fn_mesh.setPoints(mpoints, space_enum)

        print(">> Import xong vertex positions vào '{}' ({} space) từ {}".format(mesh, space, json_path))
        return mesh

def  ImportVertexsPosition(*arr):
    objs = cmds.ls(selection=True)
    folder = os.path.dirname(pm.sceneName())+"/"+'VertexsPosition'
    files  = NLTA_General.GetFiles(folder,'json')
    for obj in objs:
        if obj in files:
            filePath = folder+"/"+obj+".json"
            ImportVertexsPositionSingle(filePath)




#######
session = {}

### KEYFRAMES
def CreateKeyframe(keyInput,*arr):
    animationDistance = cmds.intSliderGrp(
        UIs["animationDistance"],
        query=True,
        value=True,
    )

    originTime = cmds.currentTime(query=True)
    currentTool = cmds.currentCtx()
    if currentTool == 'artAttrSkinContext':
        objs = [cmds.connectionInfo(skinSession['skinCluster']+".paintTrans",sourceFromDestination=True).split(".")[0]]
    else:
        objs = cmds.ls(selection=True)
    if objs:
        jointAddKey = []        
        keySpace = keyInput['space']
        keyType = keyInput['type']
        keyInturn = keyInput['inturn']           
        for obj in objs:
            parent = cmds.listRelatives(obj,parent=True)
            if parent:
                parent = parent[0]
            cmds.select(clear=True)
            jointSpace = cmds.joint()
            cmds.addAttr(jointSpace,longName="NLTA_worldKeyframe",dt='string')
            cmds.setAttr(jointSpace+'.overrideEnabled',1)
            cmds.setAttr(jointSpace+'.overrideVisibility',0)
            cmds.setAttr(jointSpace+'.hiddenInOutliner',True)
            if parent:
                cmds.parent(jointSpace,parent)
            jointChild = cmds.joint()
            if not cmds.attributeQuery("NLTA_SourceJoint",node=obj, exists=True):
              cmds.addAttr(obj,longName="NLTA_SourceJoint",dt='string')
            cmds.setAttr(obj+".NLTA_SourceJoint",jointSpace, type="string")
      
            jointAddKey.append(jointChild)
            if keySpace == 'world':
                cmds.matchTransform(jointSpace,obj,pos=True)
            elif keySpace == 'local':
                cmds.matchTransform(jointSpace,obj,pos=True,rot=True)
            constraint = cmds.parentConstraint(jointChild,obj,mo=True)
            cmds.setAttr(jointSpace+'.visibility',0)
        if keyType == 'rotate':
            keyData = {
                "rx":[0,-90,0,90,0],
                "ry":[0,-90,0,90,0],
                "rz":[0,-90,0,90,0],
            }
        elif keyType == 'translate':
            keyData = {
                    "tx":[0,animationDistance*(-1),0,animationDistance,0],
                    "ty":[0,animationDistance*(-1),0,animationDistance,0],
                    "tz":[0,animationDistance*(-1),0,animationDistance,0],
            }
        for jointChild in jointAddKey:
            if keyInput['inturn'] == False:
                currentTime = originTime
            else:
                currentTime = cmds.currentTime(query=True)
            for key in keyData:
                keyArray = keyData[key]
                for keyValue in keyArray:
                    currentTime += 30
                    cmds.currentTime(currentTime)              
                    cmds.setKeyframe(jointChild, attribute=key,value=keyValue)

    cmds.select(jointAddKey)
    NLTA_General.FitRangeAnim()
    cmds.currentTime(originTime)
    cmds.playbackOptions(min=0)
    if currentTool == 'artAttrSkinContext':
        cmds.select(skinSession['mesh'])
    else:
        cmds.select(objs)

def FitRangeAnim(*arr):    
    anim_curves = cmds.ls(type='animCurve') or []    
    if not anim_curves:
        cmds.warning("Không có animCurve trong scene")
        return
    key_times = cmds.keyframe(anim_curves, q=True)    
    if not key_times:
        cmds.warning("Không có keyframe")
        return
    start = min(key_times)
    end   = max(key_times)
    cmds.playbackOptions(min=start, max=end)
    cmds.playbackOptions(ast=start, aet=end)    
    
def ZoomRangeAnim(*arr):
    anim_curves = cmds.ls(type='animCurve') or []    
    if not anim_curves:
        cmds.warning("Không có animCurve nào")
        return
    key_times = cmds.keyframe(anim_curves, q=True)
    
    if not key_times:
        cmds.warning("Không có keyframe")
        return
    key_times = sorted(set(key_times))
    current = cmds.currentTime(q=True)
    start = None
    end = None    
    for i in range(len(key_times) - 1):
        if key_times[i] <= current <= key_times[i + 1]:
            start = key_times[i]
            end = key_times[i + 1]
            break    
    if start is None and len(key_times) > 1:
        if current < key_times[0]:
            start, end = key_times[0], key_times[1]
        elif current > key_times[-1]:
            start, end = key_times[-2], key_times[-1]    
    if start is not None and end is not None:
        cmds.playbackOptions(min=start, max=end)
        cmds.currentTime(current)
    else:
        cmds.warning("Không tìm được range phù hợp")

def deleteSenceKeyframe(*attr):
    objs = cmds.ls()
    for i in objs:
        try:
            if cmds.attributeQuery("NLTA_SourceJoint",node=i,ex=True):
                cmds.deleteAttr(i+'.NLTA_SourceJoint')
        except:pass
        try:
            if cmds.attributeQuery("NLTA_worldKeyframe",node=i,ex=True):
                cmds.delete(i)
        except:pass
    cmds.currentTime(0)

def DeleteAttrKeyframes(*arr):
    sel = cmds.ls(selection=True)
    if sel:
        cmds.cutKey(sel, clear=True)
# CLOSE KEYFRAMES
        
def clearMesh(*arr):
    for mesh in cmds.ls(selection=True):
        cmds.select(mesh)
        pm.mel.eval('DeleteHistory;')
        """
        for attr in ["tx","ty","tz","rx","ry","rz","sx","sy","sz"]:
            cmds.setAttr(mesh+"."+attr,lock=False)
        """
        cmds.setAttr(mesh+".translate",e=True,lock=0)
        cmds.setAttr(mesh+".rotate",e=True,lock=0)
        cmds.setAttr(mesh+".scale",e=True,lock=0)
        cmds.setAttr(mesh+".visibility",e=True,lock=0)
        pm.mel.eval('makeIdentity -apply true -t 1 -r 1 -s 1 -n 0 -pn 1;')
        pm.mel.eval('ResetTransformations;')



def setMiddleWeight(*arr):
    cmds.currentTime(0)
    deleteSenceKeyframe()
    selection = cmds.ls(selection=True)
    middleJoint = selection[0]
    vertexArray = []
    jointArray = []
    for a in selection:
        if cmds.objectType(a) == "joint":
            if a != middleJoint:
                jointArray.append(a)
        elif ".vtx[" in a :
            vertexArray.append(a)
    mesh = vertexArray[0].split(".")[0]
    skinCluster = pm.mel.eval('findRelatedSkinCluster '+mesh)
    if skinCluster:
        jointBindArray = cmds.skinCluster(skinCluster,query=True,inf=True)
        for jointBind in jointBindArray:
            cmds.setAttr(jointBind+".liw",0)
        for ver in vertexArray:
            cmds.skinPercent(skinCluster,ver, transformValue=[middleJoint,1])
        for jointBind in jointBindArray:
            cmds.setAttr(jointBind+".liw",1)
    averageWeight = float(1.0/(len(jointArray)+1))
    for joint in jointArray:
        cmds.setAttr(joint+".liw",0)
        cmds.setAttr(middleJoint+".liw",0)
        for ver in vertexArray:
            cmds.skinPercent(skinCluster,ver, transformValue=[joint,averageWeight])
        cmds.setAttr(joint+".liw",1)
        cmds.setAttr(middleJoint+".liw",1)
    for joint in jointArray:
        cmds.setAttr(joint+".liw",0)
    cmds.setAttr(middleJoint+".liw",0)

    cmds.select(jointArray)
    CreateKeyframe({'space':'local','type':'rotate','inturn':False})
    component()
    cmds.select(vertexArray)

def copyProxy(*arr):
    global session
    selection = cmds.ls(selection=True)
    if cmds.objectType(selection[0]) == "mesh":
        pm.mel.eval('ConvertSelectionToVertices;')
        vertex = cmds.ls(selection=True,flatten=True)
        parentName = selection[0].split(".")[0]
        cmds.select(parentName)
    elif cmds.objectType(selection[0]) == "transform":
        vertex = cmds.ls(selection[0]+".vtx[*]",flatten=True)
        parentName = selection[0]
    session["vertex"] = vertex
    session["mesh"] = parentName

def pastProxy(*arr):
    selection = cmds.ls(selection=True)
    if cmds.objectType(selection[0]) == "mesh":
        pm.mel.eval('ConvertSelectionToVertices;')
        vertex = cmds.ls(selection=True)
        parentName = selection[0].split(".")[0]
        cmds.select(session["vertex"])
        cmds.select(vertex,add=True)

        #sourceSkinCluster = pm.mel.eval('findRelatedSkinCluster '+session["mesh"])
        #targetSkinCluster = pm.mel.eval('findRelatedSkinCluster '+parentName)
        #copySkinWeights -ss skinCluster13 -ds skinCluster19 -noMirror -surfaceAssociation closestPoint -influenceAssociation closestJoint -influenceAssociation oneToOne;
        
        #pm.mel.eval('copySkinWeights  -noMirror -surfaceAssociation closestPoint -influenceAssociation oneToOne -influenceAssociation closestJoint -normalize;')
        

        pm.mel.eval('copySkinWeights  -noMirror -surfaceAssociation closestPoint -influenceAssociation closestJoint -influenceAssociation oneToOne')
        

        #print('copySkinWeights  -ss '+sourceSkinCluster+' -ds '+targetSkinCluster+'  -noMirror -surfaceAssociation closestPoint -influenceAssociation closestJoint -influenceAssociation oneToOne;')



        #pm.mel.eval('copySkinWeights  -ss '+sourceSkinCluster+' -ds '+targetSkinCluster+'  -noMirror -surfaceAssociation closestPoint -influenceAssociation closestJoint -influenceAssociation oneToOne;')#-normalize
    elif cmds.objectType(selection[0]) == "transform":
        for aSelect in selection:
            vertex = cmds.ls(aSelect+".vtx[*]")            
            cmds.select(clear=True)
            cmds.select(session["vertex"])
            cmds.select(vertex,add=True)
            sourceSkinCluster = pm.mel.eval('findRelatedSkinCluster '+session["mesh"])            
            targetSkinCluster = pm.mel.eval('findRelatedSkinCluster '+aSelect)

            #pm.mel.eval('copySkinWeights  -noMirror -surfaceAssociation closestPoint -influenceAssociation oneToOne -influenceAssociation closestJoint -normalize;')
            #pm.mel.eval('copySkinWeights  -noMirror -surfaceAssociation closestComponent -influenceAssociation closestJoint -influenceAssociation oneToOne -normalize;')
            pm.mel.eval('copySkinWeights  -ss '+sourceSkinCluster+' -ds '+targetSkinCluster+'  -noMirror -surfaceAssociation closestPoint -influenceAssociation closestJoint -influenceAssociation oneToOne;')
    cmds.select(selection)
    cmds.warning("Done!!!")

def SelectClosetFaces(*arr):
    def get_mesh_fn(mesh):
        sel = om.MSelectionList()
        sel.add(mesh)
        dag = sel.getDagPath(0)
        return om.MFnMesh(dag)

    def get_face_centroids(mesh):
        fn = get_mesh_fn(mesh)
        centroids = {}
        for i in range(fn.numPolygons):
            points = fn.getPolygonVertices(i)
            verts = [om.MVector(fn.getPoint(v, om.MSpace.kWorld)) for v in points]
            c = sum(verts, om.MVector()) / len(verts)
            centroids[i] = c
        return centroids

    def FindMatchingFaces(source,target, tolerance=0.001):
        centA = get_face_centroids(source)
        centB = get_face_centroids(target)
        matches = []
        for fA, cA in centA.items():
            for fB, cB in centB.items():
                if (cA - cB).length() < tolerance:
                    matches.append(fB)
        return matches
    objs = cmds.ls(selection=True)
    source = objs[0]
    targets = objs[1:]
    faces = []
    for target in targets:
        facesID = FindMatchingFaces(source,target)
        for faceID in facesID:
            faces.append(f"{target}.f[{faceID}]")
    cmds.select(faces)    


def loadUi(*arr):   
    pm.mel.eval('artAttrSkinPaintCtx -e -minvalue -1 -useColorRamp 1 -colorRamp "1,0,0,1,1,1,0.5,0,0.8,1,1,0.7,0,0.6,1,0,.5,0,0.4,1,0,0,1,0,1"  -rampMaxColor .57 .57 .57  artAttrSkinContext;')
    pm.mel.eval('setObjectPickMask "Joint" false;')

def mirrorSkin(axis,neg_pos,*arr):
    selection = cmds.ls(selection=True)
    if ".vtx[" in selection[0]:
        mesh = selection[0].split(".")[0]
        if axis == "x":
            pm.mel.eval("reflectionSetMode objectx;")
        else:
            pm.mel.eval("reflectionSetMode objectx;")        
        pm.mel.eval("reflectionSetMode none;")
    else:
        mesh = selection[0]

    currentSkinCluster = pm.mel.eval('findRelatedSkinCluster '+mesh)  
    if axis == "x":
        face = "YZ"
    if neg_pos == "-":
        print("copySkinWeights -ss "+currentSkinCluster+" -ds "+currentSkinCluster+" -mirrorMode "+face+" -mirrorInverse -surfaceAssociation closestPoint -influenceAssociation closestJoint -influenceAssociation oneToOne;")
        pm.mel.eval("copySkinWeights -ss "+currentSkinCluster+" -ds "+currentSkinCluster+" -mirrorMode "+face+" -mirrorInverse -surfaceAssociation closestPoint -influenceAssociation closestJoint -influenceAssociation oneToOne;")
    elif neg_pos == "+":
        print("copySkinWeights -ss "+currentSkinCluster+" -ds "+currentSkinCluster+" -mirrorMode "+face+" -surfaceAssociation closestPoint -influenceAssociation closestJoint -influenceAssociation oneToOne;")     
        pm.mel.eval("copySkinWeights -ss "+currentSkinCluster+" -ds "+currentSkinCluster+" -mirrorMode "+face+" -surfaceAssociation closestPoint -influenceAssociation closestJoint -influenceAssociation oneToOne;")


        
def singleProxy(*arr):
    selection = cmds.ls(selection=True)
    if cmds.objectType(selection[0]) == "mesh":
        pm.mel.eval('ConvertSelectionToFaces;')
        face = cmds.ls(selection=True)
        meshTransform = selection[0].split(".")[0]
        skinCluster = pm.mel.eval('findRelatedSkinCluster '+meshTransform)
        if skinCluster:
            joint = cmds.skinCluster(skinCluster,query=True,inf=True)

        meshNew =  cmds.ls(cmds.duplicate(meshTransform)[0],uuid=True)[0]
        meshNew =  cmds.ls(meshNew,ap=True)[0]
        faceNew = cmds.ls(meshNew+".f[*]")
        arrayTemp = []
        for a in face:
            faceName = a.replace(meshTransform,meshNew)
            arrayTemp.append(faceName)

        cmds.select(faceNew)
        cmds.select(arrayTemp,deselect=True)
        cmds.delete()
        cmds.delete(meshNew,constructionHistory=True)
        if skinCluster:
            cmds.select(joint)
            cmds.select(meshNew,add=True)
            NLTA_General.bindSkin()
            cmds.select(meshTransform)
            cmds.select(meshNew,add=True)
            newSkinCluster = pm.mel.eval('findRelatedSkinCluster '+meshNew)
            pm.mel.eval('copySkinWeights -ss '+skinCluster+' -ds '+newSkinCluster+' -noMirror -surfaceAssociation closestPoint -influenceAssociation closestJoint;')
            #pm.mel.eval('copySkinWeights -ss '+skinCluster+' -ds '+newSkinCluster+' -noMirror -surfaceAssociation closestComponent -influenceAssociation closestJoint;')
            #pm.mel.eval('copySkinWeights  -noMirror -surfaceAssociation closestPoint -influenceAssociation oneToOne -influenceAssociation closestJoint -normalize;')
            
            cmds.select(meshNew)            
        else:
            cmds.select(meshNew)
        copyProxy()
        cmds.warning("Done!!!")

def createProxy(axis,*arr):
    selection = cmds.ls(selection=True)
    if cmds.objectType(selection[0]) == "mesh":
        pm.mel.eval('ConvertSelectionToFaces;')
        face = cmds.ls(selection=True)
        meshTransform = selection[0].split(".")[0]
        skinCluster = pm.mel.eval('findRelatedSkinCluster '+meshTransform)
        if skinCluster:
            joint = cmds.skinCluster(skinCluster,query=True,inf=True)

        meshNew =  cmds.ls(cmds.duplicate(meshTransform)[0],uuid=True)[0]
        meshNew =  cmds.ls(meshNew,ap=True)[0]
        faceNew = cmds.ls(meshNew+".f[*]")
        arrayTemp = []
        for a in face:
            faceName = a.replace(meshTransform,meshNew)
            arrayTemp.append(faceName)

        cluster = cmds.cluster(arrayTemp)
        axisNegPos = NLTA_General.checkNegPosAxis(cluster,axis)
        if axisNegPos == "-":
            direction = str(0)
        else:
            direction = str(1)
        cmds.delete(cluster)

        axisArray = ["x","y","z"]
        axisIndex = str(axisArray.index(axis))

        cmds.select(faceNew)
        cmds.select(arrayTemp,deselect=True)
        cmds.delete()

        pm.mel.eval('polyMirrorFace  -cutMesh 1 -axis '+axisIndex+' -axisDirection '+direction+' -mergeMode 1 -mergeThresholdType 0 '+meshNew+';')#-mergeThreshold 0.001 
        cmds.delete(meshNew,constructionHistory=True)
        cmds.select(joint)
        cmds.select(meshNew,add=True)
        NLTA_General.bindSkin()
        cmds.select(meshTransform)
        cmds.select(meshNew,add=True)
        
        #pm.mel.eval('copySkinWeights  -noMirror -surfaceAssociation closestPoint -influenceAssociation oneToOne -influenceAssociation closestJoint -normalize;')
        #copySkinWeights -ss skinCluster1 -ds skinCluster16 -noMirror -surfaceAssociation closestComponent -influenceAssociation closestJoint;
        newSkinCluster = pm.mel.eval('findRelatedSkinCluster '+meshNew)
        pm.mel.eval('copySkinWeights -ss '+skinCluster+' -ds '+newSkinCluster+' -noMirror -surfaceAssociation closestComponent -influenceAssociation closestJoint;')
        cmds.select(meshNew)
        copyProxy()
        cmds.warning("Done!!!")

def goToBindPose(*arr): 
    pm.mel.eval("GoToBindPose;")

def component(*arr):    
    pm.mel.eval("ComponentEditor;")
    
def pruneSmallWeights(*arr):    
    pm.mel.eval("artSkinLockInf artAttrSkinPaintCtx 0;")
    pm.mel.eval("artSkinInvLockInf artAttrSkinPaintCtx 0;")
    pm.mel.eval("PruneSmallWeights;")
    pm.mel.eval("artSkinLockInf artAttrSkinPaintCtx 0;")
    pm.mel.eval("artSkinInvLockInf artAttrSkinPaintCtx 1;")        
    
def replaceWeight(value,*arr):
    pm.mel.eval("artAttrSkinPaintModePaintSelect 1 artAttrSkinPaintCtx;")
    pm.mel.eval("artAttrPaintOperation artAttrSkinPaintCtx Replace;")
    pm.mel.eval("artSkinSetSelectionValue "+str(value)+" false artAttrSkinPaintCtx artAttrSkin;")
    
def addWeight(value,*arr):
    pm.mel.eval("artAttrSkinPaintModePaintSelect 1 artAttrSkinPaintCtx;")
    pm.mel.eval("artAttrPaintOperation artAttrSkinPaintCtx Add;")
    pm.mel.eval("artSkinSetSelectionValue "+str(value)+" false artAttrSkinPaintCtx artAttrSkin;")

def smooth(value,*arr):
    pm.mel.eval("artAttrSkinPaintModePaintSelect 1 artAttrSkinPaintCtx;")
    pm.mel.eval("artUpdateStampProfile "+value+" artAttrSkinPaintCtx;")
    pm.mel.eval("artAttrPaintOperation artAttrSkinPaintCtx Smooth;")
    

def unlockAll(*arr):
    pm.mel.eval("artSkinInvLockInf artAttrSkinPaintCtx 0;")
    pm.mel.eval("artSkinLockInf artAttrSkinPaintCtx 0;")

def lockAll(*arr):
    pm.mel.eval("artSkinInvLockInf artAttrSkinPaintCtx 1;")
    pm.mel.eval("artSkinLockInf artAttrSkinPaintCtx 1;")

def singleUnlock(objs,*arr):
    for joint in skinSession['joints']:
        cmds.setAttr(joint+'.liw',1)
    print(objs)
    for obj in objs:
        print(obj+".liw")
        cmds.setAttr(obj+'.liw',0)

def unlock(*arr):
    objs = cmds.ls(selection=True,type='joint')
    if objs:
        result = all(obj in skinSession['joints'] for obj in objs)
        if result:
            cmds.select(skinSession['mesh'])
            singleUnlock(objs)
            pm.mel.eval('ArtPaintSkinWeightsTool;')
            pm.mel.eval('setSmoothSkinInfluence '+objs[0]+';')
    else:
        pm.mel.eval("artSkinLockInf artAttrSkinPaintCtx 0;")
        pm.mel.eval("artSkinInvLockInf artAttrSkinPaintCtx 1;")
      
def addUnlock(*arr):
    pm.mel.eval("artSkinLockInf artAttrSkinPaintCtx 0;")    

def addUnlockUp(*arr):
    print(skinSession["skinCluster"])
    jointActive = cmds.connectionInfo(skinSession['skinCluster']+".paintTrans",sourceFromDestination=True).split(".")[0]
    parentJoint =  cmds.listRelatives(jointActive,parent=True)
    if parentJoint:
        parentJoint = parentJoint[0]
        singleUnlock([jointActive,parentJoint])
        pm.mel.eval('ArtPaintSkinWeightsTool;')
        pm.mel.eval('setSmoothSkinInfluence '+parentJoint+';')

def addUnlockDown(*arr):
    jointActive = cmds.connectionInfo(skinSession['skinCluster']+".paintTrans",sourceFromDestination=True).split(".")[0]
    childrenJoint =  cmds.listRelatives(jointActive,children=True)
    if childrenJoint:
        childJoint = childrenJoint[0]
        singleUnlock([jointActive,childJoint])
        pm.mel.eval('ArtPaintSkinWeightsTool;')
        pm.mel.eval('setSmoothSkinInfluence '+childJoint+';')

def pickValue(*arr):
    pm.mel.eval("artAttrPaintOperation artAttrSkinPaintCtx Replace;")
    pm.mel.eval("artAttrSkinPaintCtx -e -pickValue `currentCtx`;")

def flood(*arr):
    pm.mel.eval("artAttrSkinPaintModePaintSelect 1 artAttrSkinPaintCtx;")
    pm.mel.eval('artAttrSkinPaintCtx -e -clear `currentCtx`;')

def switchJoint(*arr):
    objName = cmds.ls(sl=True)[0]
    skinName = pm.mel.eval('findRelatedSkinCluster '+objName)
    allJoints = cmds.skinCluster(objName,inf=True,q=True)
    jointCurrent = []
    for a in allJoints:
        if cmds.getAttr(a+".liw")!=1:
            jointCurrent.append(a)
    joint_active = cmds.connectionInfo(skinName+".paintTrans",sourceFromDestination=True).split(".")[0]
    if joint_active not in jointCurrent:
        index = 0
    else:
        index = jointCurrent.index(joint_active)
        if index < (len(jointCurrent) - 1):
            index = index + 1
        else:
            index = 0
    pm.mel.eval('setSmoothSkinInfluence '+jointCurrent[index]+';artSkinRevealSelected artAttrSkinPaintCtx;')


def IsolateEffectVertex(*args):
    selection = cmds.ls(selection=True)
    if selection:
        mesh = selection[0]
        currentData = NLTA_General.GetSkinData(mesh)
        jointActive = currentData["jointActive"]
        jointsUnlock = currentData["jointsUnlock"]
        vertexs = GetJointVertexs(mesh,[jointActive])
        cmds.setToolTo('selectSuperContext')
        cmds.select(clear=True)
        cmds.select(vertexs, add=True)

        if jointsUnlock:
            cmds.select(jointsUnlock, add=True)
        panelCurrent = cmds.getPanel(withFocus=True)
        state = cmds.isolateSelect(panelCurrent, q=True, state=True)
        if state == 1:
            pm.mel.eval('ToggleIsolateSelect;')
            pm.mel.eval('ToggleIsolateSelect;')
        elif state == 0:
            pm.mel.eval('ToggleIsolateSelect;')
        cmds.select(clear=True)
        cmds.select(mesh)
        try:
            cmds.ArtPaintSkinWeightsTool()
        except:
            pass




def ExportAllSkinUrl(folder,*arr):
    jsonData = {}
    jsonPath = folder+'/skinData.json'
    #cmds.currentTime(0)
    if len(cmds.ls(selection=True))!=0:
        meshTransform = cmds.ls(selection=True)
    else:
        meshTransform = cmds.listRelatives(cmds.ls(type = "mesh",ap=True),parent=True,pa=True)
        meshTransform = list(set(meshTransform))
    for transform in meshTransform:
        skin_name = pm.mel.eval('findRelatedSkinCluster '+transform)
        transformName = transform
        transformName = transformName.replace("|","&")
        transformName = transformName.replace(":","%")
        if skin_name:
            jsonData[transformName] = {
                'skinName':skin_name
            }
            version = cmds.about(version=True)
            if version in ["2018"]:
                pm.mel.eval('deformerWeights -export -deformer "'+skin_name+'" -path "'+folder+'" "'+transformName+'.xml";')
            else:
                pm.mel.eval('deformerWeights -export -deformer "'+skin_name+'" -format "XML" -path "'+folder+'" "'+transformName+'.xml";')
            NLTA_General.writeJsonFile(jsonPath,jsonData)

def ExportAllSkin(*arr):
    folder_temp = os.path.dirname(pm.sceneName())
    if not folder_temp:
        folder_temp = pm.mel.eval("SaveSceneAs;")
    folder_temp = os.path.dirname(pm.sceneName())
    if folder_temp:
        folder_temp = os.path.join(os.path.dirname(pm.sceneName()), 'bnlta_all_skins_export')
        folder_temp = cmds.encodeString(folder_temp)
        if os.path.exists(folder_temp):
            shutil.rmtree(folder_temp)
        if not os.path.exists(folder_temp):
            os.makedirs(folder_temp)
        ExportAllSkinUrl(folder_temp)
        cmds.warning("Done!!!")


def ExportFolderSkin(*arr):
    url = cmds.fileDialog2(dialogStyle=2, fileMode=3, caption="Select Folder")[0]
    if url:
        dataTemp = {}
        meshs = cmds.ls(selection=True)
        for mesh in meshs:
            dataTemp[mesh] = {}
            dataTemp[mesh]["uuid"] = cmds.ls(mesh,uuid=True)
            meshParent =  cmds.listRelatives(mesh,parent=True)
            if meshParent:
                dataTemp[mesh]["parent"] =  meshParent[0]
                cmds.parent(mesh, world=True)
            else:
                dataTemp[mesh]["parent"] = None
            if "NLTA_" not in mesh:
                cmds.rename(mesh,"NLTA_"+mesh)
                dataTemp[mesh]["nameTemp"] = "NLTA_"+mesh
            else:
                dataTemp[mesh]["nameTemp"] = mesh
        cmds.select(clear=True)
        for mesh in dataTemp:
            cmds.select(cmds.ls(dataTemp[mesh]["uuid"]),add=True)
        cmds.file(url +'/mesh.obj', force=True, options="groups=1;ptgroups=0;materials=0;smoothing=0;normals=1", type='OBJexport', exportSelected=True)
        ExportAllSkinUrl(url)
        for mesh in dataTemp:
            if dataTemp[mesh]["parent"]!=None:
                cmds.parent(dataTemp[mesh]["nameTemp"],dataTemp[mesh]["parent"])
            cmds.rename(cmds.ls(dataTemp[mesh]["uuid"])[0],mesh)



def ImportAllSkinUrl(folder,keepHistory,*arr):
    if os.path.exists(folder):
        jsonData = {}
        jsonPath = folder+'/skinData.json'
        if os.path.exists(jsonPath):
            jsonData = NLTA_General.readJsonFile(jsonPath)
        cmds.currentTime(0)
        if len(cmds.ls(selection=True))!=0:
            meshTransform = cmds.ls(selection=True)
        else:
            meshTransform = cmds.listRelatives(cmds.ls(type = "mesh",ap=True),parent=True,pa=True)
            meshTransform = list(set(meshTransform))
        for transform in meshTransform:
            transformName = transform
            transformName = transformName.replace("|","&")
            transformName = transformName.replace(":","%")

            each_file = ""
            
            fileLink = cmds.encodeString(folder + "/" + transformName + ".xml")
            if os.path.exists(fileLink):
                each_file = fileLink            
            fileLinkSame = cmds.encodeString(folder + "/" + transformName + ".xml")
            if os.path.exists(fileLinkSame):
                each_file = fileLinkSame

            if each_file!="":
                joints = []
                xFile = xd.parse(each_file)
                elements = xFile.getElementsByTagName("weights")
                for e in elements:
                    attrs = e.attributes.keys()
                    for a in attrs:
                        if a == "source":
                            pair = e.attributes[a]
                            joints.append(pair.value)

                if not keepHistory:
                    cmds.select(transform)
                    pm.mel.eval('DeleteHistory;')
                    for attr in ["tx","ty","tz","rx","ry","rz","sx","sy","sz"]:
                        cmds.setAttr(transform+"."+attr,lock=False)

                    pm.mel.eval('makeIdentity -apply true -t 1 -r 1 -s 1 -n 0 -pn 1;')
                    pm.mel.eval('ResetTransformations;')
                """
                else:                    
                    mesh = transformName
                    path = folder
                    history = cmds.listHistory(mesh, pdo=True) or []
                    skinClusters = [node for node in history if cmds.nodeType(node) == "skinCluster"]
                    if skinClusters:
                        skin = skinClusters[0]
                        for j in joints:
                            if cmds.objExists(j):
                                try:
                                    cmds.skinCluster(skin, e=True, ai=j, lw=True)
                                except:pass
                        pm.mel.eval('deformerWeights -import -method "index" -deformer "'+skin+'" -path "'+folder+'/" "'+transformName+'.xml"; skinCluster -e -forceNormalizeWeights "'+skin+'";')
                    else:
                """
                if len(joints)!=0:
                    cmds.select(clear=True)
                    for b in joints:
                        if len(cmds.ls(b))>1:
                            print("More than one joint name is "+b)
                        else:
                            if cmds.objExists(b):                            
                                cmds.select(b,add=True)
                            else:
                                print("Cant find joint name "+b)
                    jointSelection = cmds.ls(selection=True)
                    shapes = cmds.listRelatives(transform,children=True,type='mesh')
                    
                    connsData = []
                    attrsReconns = ['visibility']
                    for shape in shapes:
                        for attr in attrsReconns:
                            src = cmds.connectionInfo(shape+"."+attr, sourceFromDestination=True)
                            if src:
                                connsData.append([src,shape+'.'+attr])

                    for i in range(len(connsData)):
                        conn = connsData[i]
                        cmds.disconnectAttr(conn[0],conn[1])

                    for shape in shapes:
                        cmds.setAttr(shape+'.visibility',1)
                        
                    if jointSelection:
                        cmds.select(transform,add=True)
                        skin_name = cmds.skinCluster(cmds.ls(selection=True),toSelectedBones=True,bindMethod=0,skinMethod=0,normalizeWeights=1,maximumInfluences=1)[0]
                        pm.mel.eval('deformerWeights -import -method "index" -deformer "'+skin_name+'" -path "'+folder+'/" "'+transformName+'.xml"; skinCluster -e -forceNormalizeWeights "'+skin_name+'";')
                        if jsonData !={} and (transform in jsonData):
                            cmds.rename(skin_name,jsonData[transform]['skinName'])
                    for i in range(len(connsData)):
                        conn = connsData[i]
                        cmds.connectAttr(conn[0],conn[1], force=True)



                        
    else:
        cmds.confirmDialog(title="Confirm",message="Dont have data!",button=["Yes"],defaultButton="Yes",cancelButton="Yes") 

def ImportAllSkin(*arr):
    folder = os.path.dirname(pm.sceneName())+"/"+'bnlta_all_skins_export'
    ImportAllSkinUrl(folder,False)
    cmds.warning("Done!!!")



def ImportFolderSkin(*arr):
    url = cmds.fileDialog2(dialogStyle=2, fileMode=3, caption="Select Folder")[0]
    if url:
        files = NLTA_General.GetFiles(url,'obj')
        for file_ in files:
            filePath =  url+"/"+file_+".obj"
            cmds.file(filePath, i=True, type="OBJ", ignoreVersion=True, ra=True, mergeNamespacesOnClash=False, namespace=":", options="mo=1", pr=True)
    ImportAllSkinUrl(url,False)
    cmds.warning("Done!!!")

def fixMaxInfluence(maxInfluence,*arr):
    meshes = cmds.ls(selection=True, type="mesh")
    if not meshes:
        meshes = cmds.ls(type="mesh")

    for mesh in meshes:
        skin = GetSkinCluster(mesh)
        if not skin:
            continue

        # Lấy dagPath + component
        dagPath = getDagPath(mesh)
        mfnMesh = om.MFnMesh(dagPath)

        # SkinCluster
        sel = om.MSelectionList()
        sel.add(skin)
        skinObj = sel.getDependNode(0)
        skinFn = oma.MFnSkinCluster(skinObj)

        # Lấy influences
        infPaths = skinFn.influenceObjects()
        infCount = len(infPaths)

        # Lấy toàn bộ vertex component
        comp = om.MFnSingleIndexedComponent().create(om.MFn.kMeshVertComponent)
        vtxCount = mfnMesh.numVertices
        om.MFnSingleIndexedComponent(comp).addElements(range(vtxCount))

        # Lấy weights
        weights, infCount = skinFn.getWeights(dagPath, comp)

        newWeights = list(weights)

        # Loop từng vertex
        for i in range(vtxCount):
            start = i * infCount
            end = start + infCount

            w = list(weights[start:end])

            # Lọc influence > 0
            indexed = [(j, w[j]) for j in range(len(w)) if w[j] > 0]

            if len(indexed) > maxInfluence:
                # sort theo weight giảm dần
                indexed.sort(key=lambda x: x[1], reverse=True)

                # giữ lại maxInfluence cái lớn nhất
                keep = indexed[:maxInfluence]
                keep_indices = [k[0] for k in keep]

                # zero phần còn lại
                for j in range(len(w)):
                    if j not in keep_indices:
                        w[j] = 0.0

                # normalize lại
                total = sum(w)
                if total > 0:
                    w = [val / total for val in w]

                # set lại vào array
                newWeights[start:end] = w

        # apply lại toàn bộ weights (1 lần duy nhất → rất nhanh)
        infIndices = om.MIntArray(range(infCount))
        newWeightsArray = om.MDoubleArray(newWeights)
        skinFn.setWeights(dagPath, comp, infIndices, newWeightsArray, True)
    cmds.warning("Done (OpenMaya)!!!")


def fixMaxInfluenceAll(maxValue,*arr):
    cmds.select(clear=True)
    for a in cmds.ls(type="mesh"):
        if a.endswith("Orig")!=True:
            for b in cmds.listHistory(a):
                if cmds.objExists(b) and cmds.objectType(b) == "skinCluster":
                    cmds.select(cmds.listRelatives(a,parent=True)[0],add=True)
    fixMaxInfluence(maxValue)
    cmds.warning("Done!!!")

def checkMaxInfluentNumber(val,*arr):
    if len(cmds.ls(sl=True)) !=0:
        maxValue = val
        objName = cmds.ls(sl=True)[0]
        vertex = cmds.ls(objName+'.vtx[*]',fl=True)
        skinName = pm.mel.eval('findRelatedSkinCluster '+objName)
        cmds.select(clear=True)
        arrayTemp = []
        for a in vertex:
            joints = cmds.skinPercent(skinName,a,query=True,transform=None)
            values = cmds.skinPercent(skinName,a,query=True,value=True)
            jointsTemp = []
            for b in range(len(joints)):
                if values[b]>0:
                    jointsTemp.append(joints[b])
            if len(jointsTemp) > maxValue:
                arrayTemp.append(a)
        if cmds.objExists("vertexOverMaxInfluence"):
            cmds.delete("vertexOverMaxInfluence")
        cmds.select(arrayTemp)
        #pm.mel.eval('sets -name "vertexOverMaxInfluence";')
    cmds.warning("Done!!!")



def GetSkinCluster(node):
    history = cmds.listHistory(node)
    skins = cmds.ls(history, type="skinCluster")
    return skins[0] if skins else None

def checkMaxInfluenceNumber(maxValue, *args):
    sel = cmds.ls(sl=True)
    if not sel:
        cmds.warning("No object selected")
        return

    obj = sel[0]
    skin = GetSkinCluster(obj)

    if not skin:
        cmds.warning("No skinCluster found")
        return

    # get dag path + components
    dag = NLTA_Mesh.GetDagpath(obj)
    mfn_mesh = om.MFnMesh(dag)

    # get skinCluster MObject
    sel_list = om.MSelectionList()
    sel_list.add(skin)
    skin_obj = sel_list.getDependNode(0)
    skin_fn = om.MFnSkinCluster(skin_obj)

    # get all vertices
    vert_count = mfn_mesh.numVertices
    comp_fn = om.MFnSingleIndexedComponent()
    comp = comp_fn.create(om.MFn.kMeshVertComponent)
    comp_fn.addElements(list(range(vert_count)))

    # get weights
    weights, influence_count = skin_fn.getWeights(dag, comp)

    # reshape weights
    result = []
    for i in range(vert_count):
        start = i * influence_count
        end = start + influence_count
        w = weights[start:end]

        # count non-zero weights
        count = sum(1 for val in w if val > 0.0001)

        if count > maxValue:
            result.append(f"{obj}.vtx[{i}]")

    # cleanup old set
    if cmds.objExists("vertexOverMaxInfluence"):
        cmds.delete("vertexOverMaxInfluence")
    cmds.select(result)
    if result:
        cmds.sets(result, name="vertexOverMaxInfluence")
    cmds.warning("Done!!!")


def checkMaxInfluent(*arr):
    if len(cmds.ls(sl=True)) !=0:
        maxValue = cmds.intField("maxInfluent",query=True,value=True)
        checkMaxInfluentNumber(maxValue)


def clearSkin(*arr):
    for a in cmds.ls(type="mesh"):
        if cmds.objExists(a):
            for b in cmds.listHistory(a):
                if cmds.objExists(b) and cmds.objectType(b) == "skinCluster":
                    cmds.select(a)
                    pm.mel.eval('DeleteHistory;')
    cmds.warning("Done!!!")

def removeUnneedJoint(*arr):
    cmds.currentTime(0)
    if len(cmds.ls(selection=True))!=0:
        meshTransform = cmds.ls(selection=True)
    else:
        meshTransform = cmds.listRelatives(cmds.ls(type = "mesh",ap=True),parent=True,pa=True)
        meshTransform = list(set(meshTransform))
    for transform in meshTransform:
        skinCluster = pm.mel.eval('findRelatedSkinCluster '+transform)
        if skinCluster:
            joints = cmds.skinCluster(skinCluster,query=True,inf=True)
            removeJoints = []
            for joint in joints:
                flag = False
                cmds.select(clear=True)
                pm.mel.eval('skinCluster -e -selectInfluenceVerts '+joint+' '+skinCluster+';')
                selection = cmds.ls(selection=True)
                if len(selection) == 1:
                    if '.vtx[' not in selection[0]:
                        flag = True
                if flag == True:
                    removeJoints.append(joint)            
            cmds.skinCluster(skinCluster, e=True, removeInfluence=removeJoints)
            print('Remove Joint '+ (' - ').join(removeJoints))
    cmds.select(meshTransform)
    cmds.warning("Done!!!")

def AddMeshJoint(*arr):
    cmds.currentTime(0)
    if len(cmds.ls(selection=True)) == 2:
        selection =  cmds.ls(selection=True)
        source = selection[0]
        destination =  selection[1]
        skinClusterSource = pm.mel.eval('findRelatedSkinCluster '+ source)
        skinClusterDestination =  pm.mel.eval('findRelatedSkinCluster '+ destination)
        if skinClusterSource and skinClusterDestination:
            jointsSource = cmds.skinCluster(skinClusterSource,query=True,inf=True)
            jointsDestination =  cmds.skinCluster(skinClusterDestination,query=True,inf=True)
            jointsAdd = []
            for joint in jointsSource:
                if joint not in jointsDestination:
                    jointsAdd.append(joint)
            cmds.skinCluster(skinClusterDestination, edit=True, addInfluence=jointsAdd, weight=0)
            print('Add Joint '+ (' - ').join(jointsAdd))
            cmds.warning("Done!!!")

def AddJoint(*arr):
    cmds.currentTime(0)
    if len(cmds.ls(selection=True)) >= 2:
        selection =  cmds.ls(selection=True)
        jnts = cmds.ls(selection=True,type="joint")
        meshs =  cmds.listRelatives(cmds.ls(type ="mesh",ap=True),parent=True,pa=True)
        meshBind = []
        for mesh in meshs:
            if (mesh in selection) and (mesh not in jnts):
                if mesh not in meshBind:
                    skinCluster =  pm.mel.eval('findRelatedSkinCluster '+mesh)
                    if skinCluster:
                        meshJoints = cmds.skinCluster(skinCluster,query=True,inf=True)
                        jointsAdd = []
                        for joint in jnts:
                            if joint not in meshJoints:
                                jointsAdd.append(joint)
                        cmds.skinCluster(skinCluster, edit=True, addInfluence=jointsAdd, weight=0)
                        print('Add Joint '+ (' - ').join(jointsAdd))
                meshBind.append(mesh)
        cmds.warning("Done!!!")

def CopyWeight(*arr):
    selection = cmds.ls(flatten=True,os=True)
    source = selection[0]
    destination =  selection[1:]
    cmds.select(source)
    pm.mel.eval('CopyVertexSkinWeights;')
    cmds.select(destination)
    pm.mel.eval('PasteVertexSkinWeights;')


### SET ####
def GetSetPrefix(*arr):
    selection = cmds.ls(selection=True)
    selection0 = selection[0]
    setNamePrefix = selection0.split(".")[0]
    setNamePrefix = setNamePrefix.split(":")[-1]
    setNamePrefix = "NLTA"+setNamePrefix
    setNamePrefix = setNamePrefix.replace("|","_")
    setNamePrefix = setNamePrefix.replace(":","_")
    return(setNamePrefix)

def GetSameSetNumber(prefix,*arr):
    sets = cmds.ls(type='objectSet')
    returnNumber = 0
    for set_ in sets:
        if prefix in set_:
            returnNumber +=1
    return(returnNumber)

def CreateSet(*arr):
    selection = cmds.ls(selection=True)
    prefix = GetSetPrefix()
    order = []
    sets = cmds.ls(type='objectSet')
    for set_ in sets:
        if prefix in set_:
            order.append(int(set_.replace(prefix,"")))

    if len(order)!=0:
        newName = prefix+ str(max(order) + 1)        
    else:
        newName = prefix+ str(0)
    newSet = cmds.sets(name=newName, empty=True)
    cmds.sets(selection, add=newSet)

setIndex = 0
def NextSet(*arr):
    global setIndex
    prefix =  GetSetPrefix()
    maxNumber = GetSameSetNumber(prefix)
    if setIndex >= (maxNumber - 1):
        currentIndex = 0
    else:
        currentIndex = setIndex + 1
    sets = cmds.ls(type='objectSet')
    for set_ in sets:
        if prefix in set_:
            members = cmds.sets(set_, query=True)
            if members:
                cmds.showHidden(members)
    for set_ in sets:
        if prefix in set_:          
            members = cmds.sets(set_, query=True)
            if set_ == prefix + str(currentIndex):
                if members:
                    cmds.showHidden(members)                
            else:
                if members:
                    cmds.hide(members)
    setIndex = currentIndex

def BackSet(*arr):
    global setIndex
    prefix =  GetSetPrefix()
    maxNumber = GetSameSetNumber(prefix)
    if setIndex <= 0:
        currentIndex = (maxNumber - 1)
    else:
        currentIndex = setIndex - 1
    sets = cmds.ls(type='objectSet')
    for set_ in sets:
        if prefix in set_:
            members = cmds.sets(set_, query=True)
            if members:
                cmds.showHidden(members)                
    for set_ in sets:
        if prefix in set_:
            members = cmds.sets(set_, query=True)
            if set_ == prefix + str(currentIndex):
                if members:
                    cmds.showHidden(members)
            else:
                if members:
                    cmds.hide(members)
    setIndex = currentIndex
def DeleteSets(*arr):
    sets = cmds.ls(type='objectSet')
    for set_ in sets:
        if "NLTA" in set_:
            members = cmds.sets(set_, query=True)
            cmds.showHidden(members)
            cmds.delete(set_)

def ExportSkinFbx(*arr):
    objs = cmds.ls(selection=True)
    for obj in objs:
        meshTransform = []                
        children = cmds.listRelatives(obj,ad=True,type='mesh')
        if children:
            for child in children:
                childVisAttr = child+ '.visibility'
                childVisConns = cmds.listConnections(childVisAttr, source=True, destination=False, plugs=True)
                if childVisConns:
                    for conn in childVisConns:
                        cmds.disconnectAttr(conn,childVisAttr)
                cmds.setAttr(childVisAttr,1)
                parentTransform = cmds.listRelatives(child,parent=True)
                if parentTransform:
                    parentName = parentTransform[0]
                    if parentName not in meshTransform:
                        meshTransform.append(parentName)
        for transform in meshTransform:                
            transformVisAttr = transform + '.visibility' 
            transformVisConns = cmds.listConnections(transformVisAttr, source=True, destination=False, plugs=True)
            if transformVisConns:
                for conn in transformVisConns:
                    cmds.disconnectAttr(conn,transformVisAttr)
            print(transformVisAttr)
            cmds.setAttr(transformVisAttr,1)
            
    layers = cmds.ls(type='displayLayer')
    for layer in layers:
        if layer == 'defaultLayer':
            continue
        cmds.setAttr(layer+".visibility", 1)
        cmds.setAttr(layer+".displayType", 0)
        
    
    scenePath = cmds.file(q=True, sn=True)
    sceneDir = os.path.dirname(scenePath)
    sceneName = os.path.splitext(os.path.basename(scenePath))[0]
    exportPath = sceneDir+'/'+sceneName+"_SkinFbx.fbx"

    if not cmds.pluginInfo('fbxmaya', query=True, loaded=True):
        cmds.loadPlugin('fbxmaya', quiet=True)
    mel.eval('FBXExportShapes -v false')
    mel.eval('FBXExportInputConnections -v false')
    mel.eval('FBXExportEmbeddedTextures -v false')
    mel.eval('FBXExportSkins -v true')
    mel.eval('FBXExportSmoothMesh -v true')
    mel.eval('FBXExportSmoothingGroups -v true')
    mel.eval('FBXExportConstraints -v false')    
    mel.eval(f'FBXExport -f "{exportPath}" -s')

def ObjToNewScene(*arr):
    objs = cmds.ls(selection=True)
    if objs:
        result = cmds.promptDialog(
            title='Tên File Scene Mới',
            message='Nhập tên file mới:',
            button=['OK', 'Cancel'],
            defaultButton='OK',
            cancelButton='Cancel',
            dismissString='Cancel'
        )
        if result != 'OK':            
            return
        ExportSkinFbx()
        scenePath = cmds.file(q=True, sn=True)
        sceneDir = os.path.dirname(scenePath)
        sceneName = os.path.splitext(os.path.basename(scenePath))[0]
        exportPath = sceneDir+'/'+sceneName+"_SkinFbx.fbx"
        newSceneName = cmds.promptDialog(query=True, text=True)
        if not newSceneName.strip():
            cmds.error("Tên scene không hợp lệ.")
        newScenePath = sceneDir+'/'+newSceneName+'.ma'
        cmds.file(new=True, force=True)
        cmds.file(rename=newScenePath)
        cmds.file(save=True, type='mayaAscii')
        cmds.file(exportPath, i=True, type="FBX", ignoreVersion=True, options="fbx", ra=True, mergeNamespacesOnClash=False)
    else:
        print('Nothing is selected')


#### RETOPOLOGY
loftAttr = 'NLTA_LoftData'

def GetPositions(objs):
    return([om.MVector(cmds.pointPosition(v, w=True)) for v in objs])

def GetCenter(objs):
    positions = GetPositions(objs)
    center = sum(positions, om.MVector(0, 0, 0)) / len(positions)
    return(center)

def GetFarthest(objs):
    positions = GetPositions(objs)
    center = GetCenter(objs)
    farIndex, farDist = 0,0
    for i, pos in enumerate(positions):
        dist = (pos - center).length()
        if dist > farDist:
            farIndex,farDist = i,dist
    vertexVector = positions[farIndex]
    vectorFromCenter = (vertexVector - center).normalize()
    return({
        'vertexVector':vertexVector,
        'obj':objs[farIndex],
        'distance':farDist,
        'vectorFromCenter':vectorFromCenter,
    })

def GetNormalFromVectors(data):
    vector1 = data['v1']
    vertor2 = data['v2']
    vector3 = data['v3']
    cmds.select(clear=True)
    jnt_center = cmds.joint(name="joint_center", position=(vector1.x,vector1.y,vector1.z))
    cmds.select(clear=True)
    jnt_far = cmds.joint(name="joint_far", position=(vertor2.x,vertor2.y,vertor2.z))
    cmds.select(clear=True)
    jnt_best = cmds.joint(name="joint_best", position=(vector3.x,vector3.y,vector3.z))
    cmds.aimConstraint(
        jnt_far,        
        jnt_center,     
        aimVector=[0,0, 1],         
        upVector=[1, 0, 0],          
        worldUpType="object",       
        worldUpObject=jnt_best      # hướng up theo joint_best
    )
    transform = cmds.xform(jnt_center, q=True, ws=True, m=True) 
    cmds.delete([jnt_far,jnt_center,jnt_best])
    return(transform)

def GetPerpendicular(data):
    center = data['center']
    positions = data['positions']
    vector = data['vector']
    best_dot = float('inf')
    best_index = None
    for i, pos in enumerate(positions):
        vec = (pos - center).normalize()
        dot = abs(vec * vector)
        if dot < best_dot:
            best_dot = dot
            best_index = i
    return(positions[best_index])

def GetNormalFromObjs(verts):
    positions = GetPositions(verts)
    center = GetCenter(verts)
    farthestVertex = GetFarthest(verts)
    farVertexVector = farthestVertex['vertexVector']
    perpendicularVertexVector = GetPerpendicular({
        'vector':farthestVertex['vectorFromCenter'],
        'positions':positions,
        'center':center,
    })
    return(GetNormalFromVectors({'v1':center,'v2':farVertexVector,'v3':perpendicularVertexVector}))

def CorrectCurveAxis(curve):    
    cvs = cmds.ls(curve+".cv[*]", fl=True)
    matrix = GetNormalFromObjs(cvs)
    original_positions = [cmds.xform(cv, worldSpace=True,query=True, translation=True) for cv in cvs]
    cmds.xform(curve, ws=True, m=matrix)
    for cv, pos in zip(cvs, original_positions):
        cmds.xform(cv, ws=True, t=pos)
    cmds.makeIdentity(curve, apply=True, t=True, r=False, s=False, n=0)
    return(curve)

def EdgesToCurve(*arr):
    cmds.polyToCurve(form=0,degree=3,conformToSmoothMeshPreview=True)

def VertsToCurve(*args):
    sel = cmds.ls(sl=True, fl=True)
    verts = cmds.filterExpand(sel, selectionMask=31)
    if not verts:
        cmds.warning("Please select vertices")
        return
    positions = [cmds.pointPosition(v, w=True) for v in verts]
    if len(positions) < 2:
        cmds.warning("Not enough valid points")
        return
    degree = 3 if len(positions) >= 4 else 1
    curve = cmds.curve(name='NLTA_Curve#',degree=degree,point=positions)
    cmds.rebuildCurve(curve,ch=True,rpo=True,rt=0,end=1,kr=0,kcp=False,kep=False,kt=False,s=0,d=3,tol=0.01)
    return curve

def DrawCurve(*arr):
    d = 3
    bez=False
    ctx_name = "myCurveEPContext"    
    if not cmds.contextInfo(ctx_name, exists=True):
        cmds.curveEPCtx(name=ctx_name, d=d, bez=bez)
    else:
        cmds.curveEPCtx(ctx_name, edit=True, d=d, bez=bez)    
    cmds.setToolTo(ctx_name)

def FlipLoftNormal(*arr):
    objs = cmds.ls(selection=True)
    if objs:
        lofData = GetLoftData(objs[0])
        cmds.reverseSurface(cmds.ls(lofData['loft'])[0], direction=0, ch=1)

def FlipCurveNormal(*arr):
    objs= cmds.ls(selection=True)
    if objs:
        for obj in objs:
            cmds.reverseCurve(obj, ch=False, rpo=True)
    cmds.select(objs)

def RotateCVsPositive(*arr):
    objs = cmds.ls(selection=True)
    if objs:
        obj = objs[0]
        cvs = cmds.ls(obj+".cv[*]", fl=True)
        count = len(cvs)
        originPos = [cmds.xform(cv, worldSpace=True,query=True, translation=True) for cv in cvs]
        for i in range(count):
            cmds.xform(cvs[i], ws=True, t=originPos[i-1])

def RotateCVsNegative(*arr):
    objs = cmds.ls(selection=True)
    if objs:
        obj = objs[0]
        cvs = cmds.ls(obj+".cv[*]", fl=True)
        count = len(cvs) 
        originPos = [cmds.xform(cv, worldSpace=True,query=True, translation=True) for cv in cvs]
        for i in range(len(originPos)):
            increaseI = i + 1
            if increaseI !=  len(originPos):
                cvIndex = i
                posIndex = increaseI
            else:
                cvIndex = i
                posIndex = 0
            cmds.xform(cvs[cvIndex], ws=True, t=originPos[posIndex])

def CloseCurve(*arr):
    objs = cmds.ls(selection=True)
    for obj in objs:
        dup = cmds.duplicate(obj, rr=True)[0]
        closed = cmds.closeCurve(dup, ch=False, replaceOriginal=True, preserveShape=False)[0]
        new_shape = cmds.listRelatives(closed, s=True, f=True)[0]
        old_shapes = cmds.listRelatives(obj, s=True, f=True) or []
        cmds.parent(new_shape, obj, shape=True, relative=True)
        for s in old_shapes:
            cmds.delete(s)
        if closed != obj:
            cmds.delete(closed)
        CorrectCurveAxis(obj)
    cmds.select(objs)

def RebuildCurves(curves):
    spans=16
    for c in curves:
        cmds.delete(c, ch=True)  # ✅ Xóa history trước khi rebuild
        cmds.rebuildCurve(c, ch=False, rpo=True, rt=0,
                          end=1, kr=0, kcp=0, kep=1, d=3, s=spans)
def AlignCurvesDirection(curves):
    def get_tangent(curve):
        p0 = om.MVector(cmds.pointPosition(f"{curve}.cv[0]", w=True))
        p1 = om.MVector(cmds.pointPosition(f"{curve}.cv[1]", w=True))
        return (p1 - p0).normalize()
    base_vec = get_tangent(curves[0])
    for c in curves[1:]:
        this_vec = get_tangent(c)
        dot = base_vec * this_vec
        if dot < 0:
            cmds.reverseCurve(c, ch=False, rpo=True)

def CleanCurve(curves):
    RebuildCurves(curves)
    AlignCurvesDirection(curves)

def SetLoftData(obj,data):
    data = {
        'curves':cmds.ls(data['curves'],uuid=True),
        'loft':cmds.ls(data['loft'],uuid=True)[0],
        'poly':cmds.ls(data['poly'],uuid=True)[0],
    }
    dataStr = json.dumps(data)
    if not cmds.attributeQuery(loftAttr, node=obj, exists=True):
        cmds.addAttr(obj, longName=loftAttr, dataType="string")
    cmds.setAttr(obj+"."+loftAttr, dataStr, type="string")

def GetLoftData(obj):
    if cmds.attributeQuery(loftAttr, node=obj, exists=True):
        raw = cmds.getAttr(obj+"."+loftAttr)
        data = json.loads(raw)
        return(data)
    return(None)

def ClearLoftData(obj):
    if cmds.attributeQuery(loftAttr, node=obj, exists=True):
        cmds.deleteAttr(obj+"."+loftAttr)
        shapes = cmds.listRelatives(obj, shapes=True, fullPath=True) or []
        for shape in shapes:
            if cmds.objectType(shape) == "nurbsCurve":
                cmds.setAttr(obj + ".overrideColor",0)
                cmds.setAttr(obj+".overrideDisplayType",0)
                break

def ClearAllLoft(*arr):
    objs = cmds.ls(type='loft')
    for obj in objs:
        if cmds.attributeQuery(loftAttr, node=obj, exists=True):
            data = GetLoftData(obj)
            if cmds.ls(data['poly']) == []:
                cmds.delete(cmds.ls(data['loft'])[0])
                for curve in data['curves']:
                    if cmds.ls(curve):
                        ClearLoftData(cmds.ls(curve)[0])
            else:
                loft = cmds.ls(data['loft'])[0]
                poly = cmds.ls(data['poly'])[0] 
                curves = GetLoftInputCurves(loft)
                for objTemp in  [loft]+[poly]+curves:
                    SetLoftData(objTemp,{
                        'loft':loft,
                        'poly':poly,
                        'curves':curves
                    })

def GetLoftNode(loft):
    history = cmds.listHistory(loft)
    node = next((h for h in history if cmds.nodeType(h) == "loft"), None)
    if node:
        return(node)
    return(None)

def GetLoftInputCurves(loft):
    node = GetLoftNode(loft)
    if node:
        curves = []
        i = 0
        while True:
            plug = node+".inputCurve["+str(i)+"]"
            conn = cmds.connectionInfo(plug,sfd=True)       
            if conn:
                shapeName = conn.split('.')[0]
                transformName = cmds.listRelatives(shapeName,parent=True)[0]
                curves.append(transformName)
            else:
                break
            i += 1
        return(curves)
    return(None)

def CreateLoft(*arr):
    ClearAllLoft()
    curves = cmds.ls(selection=True, type='transform')
    objsSave = curves.copy()
    if len(curves) < 2:
        cmds.warning("Chọn ít nhất 2 curve.")
        return
    CleanCurve(curves)
    result = cmds.loft(curves,ch=True,u=False,c=False,ar=False,d=3,ss=1,rn=False,po=0)
    surface = result[0]
    cmds.setAttr(surface+".hiddenInOutliner", 1)
    cmds.setAttr(surface+".visibility",0)
    objsSave.extend(result)
    poly = cmds.nurbsToPoly(
        surface,
        mnd=1,     # Match Normal Direction
        ch=1,      # Keep history
        f=2,       # Format: quads by number
        pt=1,      # Polygon type: quads
        pc=200,    # Polygon count target (for control)
        chr=0.99,  # chord height ratio
        ft=1,      # fit tolerance
        mel=1,     # merge edge length
        d=1,       # Use chord height
        ut=1,      # Use U divisions
        un=20,     # U number
        vt=1,      # Use V divisions
        vn=20,     # V number
        uch=0,     # use chord height in U (off)
        ucr=0,     # uniform chord ratio in U (off)
        cht=0.2,   # chord height
        es=0,      # edge swap (off)
        ntr=0,     # not trim
        mrt=0,     # merge trimmed surface (off)
        uss=1      # use surface span
    )[0]
    objsSave.append(poly) 
    data = {
        'curves':curves,
        'loft':surface,
        'poly':poly,
    }
    for curve in curves:
        cmds.setAttr(curve + ".overrideColor",17)
    for obj in objsSave:
        SetLoftData(obj,data)
    return(poly)

def AddLoftCurve(*arr):
    ClearAllLoft()    
    objs = cmds.ls(selection=True,ap=True)
    if objs:
        curveReference = None
        for obj in objs:
            if cmds.attributeQuery(loftAttr, node=obj, exists=True):
                curveReference = obj
                data = GetLoftData(curveReference)
                break
        if curveReference:
            loft = cmds.ls(data['loft'])[0]
            poly = cmds.ls(data['poly'])[0]
            curves = cmds.ls(data['curves'])
            loftNode = GetLoftNode(loft)
            
            currentIndex = objs.index(curveReference)
            oldIndex = curves.index(curveReference)             
            if currentIndex == 0:
                oldIndex = curves.index(curveReference) + 1
                addObjs = objs[1:]
            elif currentIndex == (len(objs)-1):
                oldIndex = curves.index(curveReference)
                addObjs = objs[:-1]
                if oldIndex <= 0:
                    oldIndex = 0
            CleanCurve(addObjs)
            finalOrder = curves[:oldIndex] + addObjs + curves[oldIndex:]
            i = 0
            for curve in finalOrder:
                shape = cmds.listRelatives(curve,children=True,f=True)[0]
                cmds.connectAttr(shape+'.worldSpace[0]',loftNode+'.inputCurve['+str(i)+']',f=True)
                i += 1
            data['curves'] = finalOrder
            for obj in (finalOrder+[loft]+[poly]):
                SetLoftData(obj,{
                    'curves':finalOrder,
                    'poly':poly,
                    'loft':loft
                })

def ClearAllLoft(*arr):
    objs = cmds.ls(type='loft')
    for obj in objs:
        if cmds.attributeQuery(loftAttr, node=obj, exists=True):
            data = GetLoftData(obj)
            if cmds.ls(data['poly']) == []:
                cmds.delete(cmds.ls(data['loft'])[0])
                for curve in data['curves']:
                    if cmds.ls(curve):
                        ClearLoftData(cmds.ls(curve)[0])
            else:
                loft = cmds.ls(data['loft'])[0]
                poly = cmds.ls(data['poly'])[0] 
                curves = GetLoftInputCurves(loft)
                for objTemp in  [loft]+[poly]+curves:
                    SetLoftData(objTemp,{
                        'loft':loft,
                        'poly':poly,
                        'curves':curves
                    })
import maya.cmds as cmds
import importlib
import pymel.core as pm
import math
import maya.api.OpenMaya as om

import NLTA_General, NLTA_OpenMaya
for module in [NLTA_General, NLTA_OpenMaya]:
    try:
        importlib.reload(module)
    except:
        reload(module)

cmds.selectPref(trackSelectionOrder=True)

def ShowQuardraw(*arr):
    pm.mel.eval('lockNode -l off  -lockUnpublished off initialShadingGroup;')

def GetVertexsSelected(*arr):
    sel = cmds.ls(sl=True)    
    if not sel:
        return []    
    verts = cmds.polyListComponentConversion(sel, toVertex=True)
    verts = cmds.ls(verts, fl=True)    
    return verts

def GetMesh(*arr):
    selection = cmds.ls(sl=True, fl=True)
    return(list(set([s.split(".")[0] for s in selection])))

def EdgeDirection(mesh, edgeIndex):
    mesh_path = NLTA_OpenMaya.GetDagPath(mesh)
    edge_it = om.MItMeshEdge(mesh_path)
    edge_it.setIndex(edgeIndex)
    p1 = edge_it.point(0, om.MSpace.kWorld)
    p2 = edge_it.point(1, om.MSpace.kWorld)
    v = om.MVector(p2 - p1)
    return v.normal()

def CheckEdgeBorder(mesh, edgeId):
    dag = NLTA_OpenMaya.GetDagPath(mesh)
    it = om.MItMeshEdge(dag)
    it.setIndex(edgeId)
    return(it.onBoundary())

def JointPos(j):
    return om.MVector(cmds.xform(j, q=True, ws=True, t=True))

def GetID(component):
    if isinstance(component, (int, float)):
        return(component)
    else:
        return(
            int(component.split("[")[-1].replace("]", ""))
        )

def GetJointAxis(joint):
    m = cmds.xform(joint, q=True, ws=True, m=True)
    axis = om.MVector(m[0], m[1], m[2])
    return axis.normal()

def GetClosestVertex(mesh, joint):
    mesh_path = NLTA_OpenMaya.GetDagPath(mesh)
    mesh_fn = om.MFnMesh(mesh_path)
    JointPos = cmds.xform(joint, q=True, ws=True, t=True)
    point = om.MPoint(JointPos)
    closest_point, face_id = mesh_fn.getClosestPoint(point, om.MSpace.kWorld)
    vertices = mesh_fn.getPoints(om.MSpace.kWorld)
    min_dist = float("inf")
    closest_index = -1
    for i, v in enumerate(vertices):
        dist = (v - closest_point).length()
        if dist < min_dist:
            min_dist = dist
            closest_index = i
    return closest_index

def GetEdgeLoop(mesh, start_edge):
    returnData = []
    edges = cmds.polySelect(mesh, edgeLoop=GetID(start_edge), noSelection=True)
    for edge in edges:
        returnData.append(
            "{}.e[{}]".format(mesh, edge)
        )
    return(returnData)

def GetEdgeRing(mesh, start_edge):
    returnData = []
    edges = cmds.polySelect(mesh, edgeRing=GetID(start_edge), noSelection=True)
    for edge in edges:
        returnData.append("{}.e[{}]".format(mesh, edge))
    return(returnData)

def VertexFromEdges(mesh, edges):
    dag = NLTA_OpenMaya.GetDagPath(mesh)
    it = om.MItMeshEdge(dag)
    verts = set()
    for edge in edges:
        eid = GetID(edge)
        it.setIndex(eid)

        v1 = it.vertexId(0)
        v2 = it.vertexId(1)

        verts.add(v1)
        verts.add(v2)
    return ["{}.vtx[{}]".format(mesh, v) for v in verts]

def GetConnectedEdges(mesh,vertex_index):
    mesh_path = NLTA_OpenMaya.GetDagPath(mesh)
    vert_it = om.MItMeshVertex(mesh_path)
    vert_it.setIndex(vertex_index)
    return vert_it.getConnectedEdges()

def GetJointEdge(mesh, joint, vertex_index):
    joint_axis = GetJointAxis(joint)
    edges = GetConnectedEdges(mesh, vertex_index)
    best_edge = None
    best_dot = -1
    for e in edges:
        dir_vec = EdgeDirection(mesh, e)
        dot = abs(dir_vec * joint_axis)
        if dot > best_dot:
            best_dot = dot
            best_edge = e
    return best_edge

def GetJointEdgeLoop(mesh, joint,vtxIndex):
    best_edge = GetJointEdge(mesh, joint, vtxIndex)
    if best_edge is None:
        cmds.warning("No edge found")
        return
    return(GetEdgeLoop(mesh, best_edge))

def GetPerpendicularEdge(mesh, joint, vertex_index):
    joint_axis = GetJointAxis(joint)
    edges = GetConnectedEdges(mesh, vertex_index)
    best_edge = None
    best_dot = 999
    for e in edges:
        dir_vec = EdgeDirection(mesh, e)
        dot = abs(dir_vec * joint_axis)
        if dot < best_dot:
            best_dot = dot
            best_edge = e
    return best_edge

def GetPerpendicularEdgeLoop(mesh, joint,vtxIndex):
    best_edge = GetPerpendicularEdge(mesh, joint, vtxIndex)
    if best_edge is None:
        cmds.warning("No edge found")
        return
    return(GetEdgeLoop(mesh, best_edge))

def GetTwoClosestJoints(targetJoint, joints):
    distances = []
    for j in joints:
        if j == targetJoint:
            continue
        dist = NLTA_General.GetDistance(targetJoint,j)
        distances.append((j, dist))
    distances.sort(key=lambda x: x[1])
    return distances[:2]

def SelectVerticesWithinRadius(mesh,joint,verts,radius):
    p0 = JointPos(joint)
    result = []
    for v in verts:
        pos = om.MVector(cmds.pointPosition(v, w=True))
        d = (pos - p0).length()
        if d <= radius:
            result.append(v)
    return(result)
    
def SelectLoopRegion(mesh, joint,joints,verts):
    closest = GetTwoClosestJoints(joint, joints)
    d1 = closest[0][1]
    d2 = closest[1][1]
    radius = min(d1, d2) * 0.7
    verts = SelectVerticesWithinRadius(mesh, joint,verts,radius)
    return(verts)

def EdgesBetween(mesh, edgeSource, edgeTarget):
    id1 = GetID(edgeSource)
    id2 = GetID(edgeTarget)
    edges = cmds.polySelect(
        mesh,
        edgeRingPath=(id1, id2),
        noSelection=True
    )
    if edges is None:
        edges = cmds.polySelect(
            mesh,
            edgeLoopPath=(id1, id2),
            noSelection=True
        )
    if edges is None:
        return []
    if isinstance(edges, int):
        edges = [edges]
    result = ["{}.e[{}]".format(mesh, i) for i in edges]
    return result

def CheckEdgesBetween(mesh, edgeSource, edges):
    id1 = GetID(edgeSource)
    for edge in edges:        
        id2 = GetID(edge)
        edges = cmds.polySelect(mesh, edgeRingPath=(id1, id2),noSelection=True)
        if edges:
            return(edge)
    return []

def EdgeCenter(mesh, edgeId):
    edgeId = GetID(edgeId)
    dag = NLTA_OpenMaya.GetDagPath(mesh)
    it = om.MItMeshEdge(dag)
    it.setIndex(edgeId)
    p1 = om.MVector(it.point(0, om.MSpace.kWorld))
    p2 = om.MVector(it.point(1, om.MSpace.kWorld))
    return (p1 + p2) * 0.5

def EdgeRatioBetweenJoints(mesh, edgeId, jointA, jointB):
    pA = JointPos(jointA)
    pB = JointPos(jointB)
    edgeC = EdgeCenter(mesh, edgeId)
    boneVec = pB - pA
    edgeVec = edgeC - pA
    t = (edgeVec * boneVec) / boneVec.length()**2
    return max(0, min(1, t))

def EdgeRatioBetweenEdges(mesh, edgeMid, edgeA, edgeB):
    pA = EdgeCenter(mesh, edgeA)
    pB = EdgeCenter(mesh, edgeB)
    pC = EdgeCenter(mesh, edgeMid)
    vecAB = pB - pA
    vecAC = pC - pA
    t = (vecAC * vecAB) / vecAB.length()**2
    return max(0, min(1, t))

def GetFarthestEdge(mesh, baseEdge, edges):
    baseId = GetID(baseEdge)
    baseCenter = EdgeCenter(mesh, baseId)
    maxDist = -1
    farEdge = None
    for edge in edges:
        eid = GetID(edge)
        center = EdgeCenter(mesh, eid)
        dist = (center - baseCenter).length()
        if dist > maxDist:
            maxDist = dist
            farEdge = edge
    return farEdge

def GetClosestEdge(mesh, edges, joint):
    jointPos = om.MVector(cmds.xform(joint, q=True, ws=True, t=True))
    minDist = 1e10
    closestEdge = None
    for edge in edges:
        edgeId = GetID(edge)
        center = EdgeCenter(mesh, edgeId)
        dist = (center - jointPos).length()
        if dist < minDist:
            minDist = dist
            closestEdge = edge
    return closestEdge



#########################

def Normalize(v):
    l = math.sqrt(sum(x*x for x in v))
    return v if l == 0 else [x/l for x in v]

def Dot(a, b):
    return sum(a[i]*b[i] for i in range(3))

def GetPos(v):
    return cmds.xform(v, q=True, ws=True, t=True)

def GetConnectVerts(v, vertSet):
    edges = cmds.polyListComponentConversion(v, te=True)
    edges = cmds.ls(edges, fl=True)

    result = []

    for e in edges:
        vs = cmds.polyListComponentConversion(e, tv=True)
        vs = cmds.ls(vs, fl=True)
        for x in vs:
            if x != v and x in vertSet:
                result.append((v, x, e))

    return result

def GetPerpEdge(v1, v2, threshold=0.25):
    p1 = GetPos(v1)
    p2 = GetPos(v2)
    dir_vec = Normalize([p2[i] - p1[i] for i in range(3)])
    edges = cmds.polyListComponentConversion(v1, te=True)
    edges = cmds.ls(edges, fl=True)
    best = None
    best_score = 999
    for e in edges:
        vs = cmds.polyListComponentConversion(e, tv=True)
        vs = cmds.ls(vs, fl=True)
        other = [x for x in vs if x != v1]
        if not other:
            continue
        other = other[0]
        if other == v2:
            continue
        vec = Normalize([GetPos(other)[i] - p1[i] for i in range(3)])
        d = abs(Dot(dir_vec, vec))
        if d < best_score:
            best_score = d
            best = e
    if best_score > threshold:
        return None
    return best

def EdgeLoopToVerts(edge):
    loop_edges = cmds.polySelectSp(edge, loop=True)    
    if not loop_edges:
        return []
    loop_edges = cmds.ls(sl=True, fl=True)
    verts = cmds.polyListComponentConversion(loop_edges, tv=True)
    verts = cmds.ls(verts, fl=True)
    return list(set(verts))

def EdgesToVerts(edges):
    verts = cmds.polyListComponentConversion(
        edges,
        toVertex=True
    )
    return(verts)

def ListToPerVerts(verts, threshold=9999):
    returnData = {}
    for v in verts:
        connections = GetConnectVerts(v,verts)
        for (a, b, _) in connections:
            edge = GetPerpEdge(a, b, threshold)
            edgeLoopVerts = EdgeLoopToVerts(edge)
            returnData[v] = edgeLoopVerts
    return(returnData)


def GetIntersectVerts(meshA, meshB, threshold,*arr):
    close_curve=True
    cpm = cmds.createNode("closestPointOnMesh")
    shapeB = cmds.listRelatives(meshB, shapes=True, fullPath=True)[0]
    cmds.connectAttr(
        "{}.worldMesh[0]".format(shapeB),
        "{}.inMesh".format(cpm),
        force=True
    )

    cmds.connectAttr(
        "{}.worldMatrix[0]".format(meshB),
        "{}.inputMatrix".format(cpm),
        force=True
    )

    verts = cmds.ls(
        "{}.vtx[*]".format(meshA),
        fl=True
    )
    close_verts = []
    for v in verts:
        pos = cmds.pointPosition(v, world=True)
        cmds.setAttr(
            "{}.inPosition".format(cpm),
            *pos,
            type="double3"
        )
        closest = cmds.getAttr(
            "{}.position".format(cpm)
        )[0]
        dist = math.sqrt(sum((pos[i] - closest[i]) ** 2 for i in range(3)))
        if dist <= threshold:
            close_verts.append(v)
    cmds.delete(cpm)
    return(close_verts)

def GetVertexBetweenParentChild(data,*arr):
    mesh =  data["mesh"]
    source = data["source"]
    des = data["destination"]
    closetVert =  GetClosestVertex(mesh,source)
    edgeLoop = GetJointEdgeLoop(mesh,source,closetVert)
    sourceClosestEgde = GetClosestEdge(mesh,edgeLoop,source)
    desClosestEdge = GetClosestEdge(mesh,edgeLoop,des)
    print(sourceClosestEgde)
    print(desClosestEdge)
    edgeBetween = EdgesBetween(mesh,sourceClosestEgde,desClosestEdge)
    print(edgeBetween)
    cmds.select(edgeBetween)
    """
    edgeLoop =  GetJointEdge({
        "mesh":mesh,
        "joint":source

    })
    """


def GetVertRatioBetweenJoints(data, *arr):
    vert = data["vert"]
    joints = data["joints"]
    if len(joints) != 2:
        cmds.error("Need exactly 2 joints")
    joint1, joint2 = joints
    dist1 = NLTA_General.GetDistance(vert, joint1)
    dist2 = NLTA_General.GetDistance(vert, joint2)
    total = dist1 + dist2
    if total == 0:
        ratio1 = 0.5
        ratio2 = 0.5
    else:
        ratio1 = 1.0 - (dist1 / total)
        ratio2 = 1.0 - (dist2 / total)

    return {
        "vert": vert,
        "joints": [joint1, joint2],
        "ratios": [ratio1, ratio2]
    }


def RatioDistanceVertsFromPlane(data):
    vertices= data["verts"]
    plane_obj = data["plane"]
    def point_plane_distance(point, plane_point, plane_normal):
        v = point - plane_point
        return v * plane_normal
    m = cmds.xform(plane_obj, q=True, ws=True, m=True)
    mat = om.MMatrix(m)
    plane_point = om.MVector(mat[12], mat[13], mat[14])
    plane_normal = om.MVector(mat[4], mat[5], mat[6]).normal()
    data = []
    max_dist = 0.0
    for vtx in vertices:
        pos = cmds.pointPosition(vtx, w=True)
        pos = om.MVector(pos)
        dist = abs(point_plane_distance(
            pos,
            plane_point,
            plane_normal
        ))
        data.append([vtx, dist])
        if dist > max_dist:
            max_dist = dist
    result = {}
    for vtx, dist in data:
        ratio = 0.0
        if max_dist > 1e-8:
            ratio = dist / max_dist
        result[vtx] = ratio
    return result


def GetMirrorVertexByUv(vtx, axis="U", tol=0.01):
    mesh = vtx.split(".")[0]
    uvs = cmds.polyListComponentConversion(vtx, tuv=True)
    uvs = cmds.ls(uvs, fl=True)
    if not uvs:
        return None
    uv = uvs[0]
    u, v = cmds.polyEditUV(uv, q=True)
    if axis.upper() == "U":
        target_uv = (1.0 - u, v)
    else:
        target_uv = (u, 1.0 - v)
    vtx_count = cmds.polyEvaluate(mesh, v=True)
    best = None
    best_dist = 999999
    for i in range(vtx_count):
        other = "{}.vtx[{}]".format(mesh,i)
        other_uvs = cmds.polyListComponentConversion(
            other,
            tuv=True
        )
        other_uvs = cmds.ls(other_uvs, fl=True)
        if not other_uvs:
            continue
        ou, ov = cmds.polyEditUV(
            other_uvs[0],
            q=True
        )
        dist = (
            abs(ou - target_uv[0]) +
            abs(ov - target_uv[1])
        )
        if dist < best_dist:
            best_dist = dist
            best = other
    if best_dist <= tol:
        return best
    return None


def MirrorVertexByUvSingle(vtx, axis="X"):
    mirror_vtx = GetMirrorVertexByUv(vtx)
    if not mirror_vtx:
        cmds.warning("Mirror vertex not found")
        return
    pos = cmds.pointPosition(vtx, w=True)
    x, y, z = pos
    axis = axis.upper()
    if axis == "X":
        mirrored_pos = (-x, y, z)
    elif axis == "Y":
        mirrored_pos = (x, -y, z)
    elif axis == "Z":
        mirrored_pos = (x, y, -z)
    else:
        cmds.warning("Invalid axis")
        return
    cmds.xform(
        mirror_vtx,
        ws=True,
        t=mirrored_pos
    )

def MirrorVertexByUv(*arr):
    verts = cmds.ls(selection=True,flatten=True)
    for vert in verts:
        MirrorVertexByUvSingle(vert)

import maya.cmds as cmds


def MirrorVertPos(*arr):
    sel = cmds.ls(orderedSelection=True)
    if len(sel) != 2:
        cmds.warning("Select source vertex then target vertex")
        return
    src = sel[0]
    dst = sel[1]
    x, y, z = cmds.pointPosition(src, w=True)
    mirrored_pos = (-x, y, z)
    cmds.xform(
        dst,
        ws=True,
        t=mirrored_pos
    )
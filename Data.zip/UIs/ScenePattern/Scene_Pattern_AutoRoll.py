import os
import maya.cmds as cmds
import pymel.core as pm
from functools import partial
from datetime import datetime

import NLTA_General,NLTA_UI
for module in [NLTA_General,NLTA_UI]:
    try:
        importlib.reload(module)
    except:
        from importlib import reload
        reload(module)

ITEMS = {
    "items":{},
    "order":[]
}

def DefaultSetting(path,*arr):
    moduleName = os.path.basename(__file__).replace(".py","")
    ext = "json"
    name = "Auto Roll"
    return({
        "ext":ext,
        "path":path+moduleName+"."+ext,
        "moduleName":moduleName,
        "order":0,
        "title":name,
        "name":name,
        "id":datetime.now().strftime("%Y%m%d%H%M%S")
    })


def Load(data,listUI,*arr):
    newestData = NLTA_General.JsonGetByID({
        "path":data["sceneDataPath"]+"/ScenePatternData.json",
        "id":data["id"]
    })
    path = newestData["path"]
    if ".json" in path:
        children = cmds.layout(listUI,q=True, ca=True) or []
        for child in children:
            if cmds.control(child, exists=True):
                cmds.deleteUI(child)        
        itemDatas = NLTA_General.readJsonFile(path)
        if itemDatas:
            for i in range(len(itemDatas)):
                Add(listUI,itemDatas[i])

def Form(data,*arr):
    def Save(data, *arr):
        itemData = NLTA_General.JsonGetByID({
            "path":data["sceneDataPath"]+"/ScenePatternData.json",
            "id":data["id"]
        })          
        returnData = NLTA_UI.GetData(ITEMS['items'])
        NLTA_General.writeJsonFile(itemData["path"],returnData)

    mainForm = NLTA_General.LoadModule("Scene_Form")
    dataBack = mainForm.Create(data)
    buttonUI = dataBack["buttonUI"]
    listUI = dataBack["listUI"]

    cmds.rowColumnLayout(numberOfColumns=3,parent=buttonUI)
    cmds.button(label="Add",width=130,c=partial(Add,listUI,{}))
    cmds.button(label="Save", width=130,c=partial(Save,data))
    cmds.button(label="Run",width=130, c=partial(Run,data))
    cmds.setParent("..")
    Load(data,listUI)

def Run(data, *arr):
    newestData = NLTA_General.JsonGetByID({
        "path": data["sceneDataPath"] + "/ScenePatternData.json",
        "id": data["id"]
    })
    datas = NLTA_General.readJsonFile(newestData["path"])
    if not datas:
        return

    for data in datas:
        parent = data["parent"]
        children = [x.strip() for x in data["children"].split("\n") if x.strip()]
        childrenAttr = data["childrenAttr"]
        attrHolders = [x.strip() for x in data["attrHolders"].split("\n") if x.strip()]
        attr = data["attr"]
        ratio = float(data.get("ratio", 1))
        forwardAxis = data.get("forwardAxis", "z").lower()

        if not cmds.objExists(parent) or not children or not attrHolders:
            continue

        master = attrHolders[0]
        ratioAttr = "{}Ratio".format(attr)

        # ATTRIBUTES
        if not cmds.attributeQuery(attr, node=master, exists=True):
            cmds.addAttr(master, ln=attr, at="bool", dv=1, k=True)

        if not cmds.attributeQuery(ratioAttr, node=master, exists=True):
            cmds.addAttr(master, ln=ratioAttr, at="double", dv=ratio, k=True)

        for holder in attrHolders[1:]:
            if not cmds.objExists(holder):
                continue

            if not cmds.attributeQuery(attr, node=holder, exists=True):
                cmds.addAttr(holder, ln=attr, proxy="{}.{}".format(master, attr))

            if not cmds.attributeQuery(ratioAttr, node=holder, exists=True):
                cmds.addAttr(holder, ln=ratioAttr, proxy="{}.{}".format(master, ratioAttr))

        # ------------------------------------------------------------
        # FORWARD AXIS
        # ------------------------------------------------------------
        axisVectors = {"x": (1, 0, 0),"-x": (-1, 0, 0),"y": (0, 1, 0),"-y": (0, -1, 0),"z": (0, 0, 1),"-z": (0, 0, -1),}
        forwardVector = axisVectors.get(forwardAxis, (0, 0, 1))
        turnAxisMap = {"x": "y","-x": "y","z": "y","-z": "y","y": "z","-y": "z",}
        turnAxis = turnAxisMap.get(forwardAxis, "y")
        turnOutputMap = {"x": "outputRotateX","y": "outputRotateY","z": "outputRotateZ",}
        turnOutput = turnOutputMap[turnAxis]

        # ------------------------------------------------------------
        # PARENT WORLD ROTATION
        # ------------------------------------------------------------
        parentSafeName = parent.replace("|", "_").replace(":", "_")
        parentDcmName = "{}_{}_World_DCM".format(parentSafeName, attr)
        if cmds.objExists(parentDcmName):
            parentDcm = parentDcmName
        else:
            parentDcm = cmds.createNode("decomposeMatrix", n=parentDcmName)
        if not cmds.isConnected(parent + ".worldMatrix[0]", parentDcm + ".inputMatrix"):
            cmds.connectAttr(parent + ".worldMatrix[0]", parentDcm + ".inputMatrix", f=True)
        prevTurnAttr = "{}PrevTurn".format(attr)
        currentTurn = cmds.getAttr("{}.{}".format(parentDcm, turnOutput))
        if not cmds.attributeQuery(prevTurnAttr, node=master, exists=True):
            cmds.addAttr(master, ln=prevTurnAttr, at="double", dv=currentTurn)
        cmds.setAttr("{}.{}".format(master, prevTurnAttr), currentTurn)
        prevTurnPlug = "{}.{}".format(master, prevTurnAttr)

        # ------------------------------------------------------------
        # EXPRESSION HEADER
        # ------------------------------------------------------------
        expressionHeader = """
float $prevTurn = {prevTurn};
float $nowTurn = {parentDcm}.{turnOutput};
float $turnDelta = $nowTurn - $prevTurn;

if ($turnDelta > 180)
    $turnDelta -= 360;
else if ($turnDelta < -180)
    $turnDelta += 360;

float $turnDirection = 0;

if ($turnDelta > 0.0001)
    $turnDirection = 1;
else if ($turnDelta < -0.0001)
    $turnDirection = -1;
        """.format(prevTurn=prevTurnPlug,parentDcm=parentDcm,turnOutput=turnOutput)
        expressionLines = []

        # ------------------------------------------------------------
        # CHILDREN
        # ------------------------------------------------------------
        for child in children:
            if not cmds.objExists(child):
                continue
            safeName = child.replace("|", "_").replace(":", "_")
            offsetGrp = child + "_{}Grp".format(attr)
            sensor = child + "_{}Sensor".format(attr)
            # SENSOR
            if not cmds.objExists(sensor):
                childParent = cmds.listRelatives(child, p=True)
                sensor = NLTA_General.GroupMatchObject(child, sensor)
                if childParent:
                    cmds.parent(sensor, childParent[0])
                if cmds.attributeQuery("rotateOrder", node=child, exists=True):
                    cmds.setAttr(sensor + ".rotateOrder", cmds.getAttr(child + ".rotateOrder"))
                cmds.setAttr(sensor + ".visibility", 0)

            # OFFSET GROUP
            if not cmds.objExists(offsetGrp):
                NLTA_General.CreateOffsetGroup(child, offsetGrp)

            # SENSOR WORLD POSITION
            dcmName = "{}_{}_Sensor_DCM".format(safeName, attr)

            if cmds.objExists(dcmName):
                dcm = dcmName
            else:
                dcm = cmds.createNode("decomposeMatrix", n=dcmName)

            if not cmds.isConnected(sensor + ".worldMatrix[0]", dcm + ".inputMatrix"):
                cmds.connectAttr(sensor + ".worldMatrix[0]", dcm + ".inputMatrix", f=True)

            # COMMON FORWARD DIRECTION FROM PARENT
            forwardName = "{}_{}_Forward_VP".format(safeName, attr)

            if cmds.objExists(forwardName):
                forwardVP = forwardName
            else:
                forwardVP = cmds.createNode("vectorProduct", n=forwardName)

            cmds.setAttr(forwardVP + ".operation", 3)
            cmds.setAttr(forwardVP + ".normalizeOutput", 1)
            cmds.setAttr(
                forwardVP + ".input1",
                forwardVector[0],
                forwardVector[1],
                forwardVector[2],
                type="double3"
            )

            if not cmds.isConnected(parent + ".worldMatrix[0]", forwardVP + ".matrix"):
                cmds.connectAttr(parent + ".worldMatrix[0]", forwardVP + ".matrix", f=True)

            # PREVIOUS POSITION
            currentPos = cmds.xform(sensor, q=True, ws=True, t=True)

            prevXAttr = "{}_{}PrevX".format(attr, safeName)
            prevYAttr = "{}_{}PrevY".format(attr, safeName)
            prevZAttr = "{}_{}PrevZ".format(attr, safeName)

            for prevAttr, value in zip(
                [prevXAttr, prevYAttr, prevZAttr],
                currentPos
            ):
                if not cmds.attributeQuery(prevAttr, node=master, exists=True):
                    cmds.addAttr(master, ln=prevAttr, at="double", dv=value)

                cmds.setAttr("{}.{}".format(master, prevAttr), value)

            prevX = "{}.{}".format(master, prevXAttr)
            prevY = "{}.{}".format(master, prevYAttr)
            prevZ = "{}.{}".format(master, prevZAttr)

            expressionLines.append("""
float ${name}PrevX = {prevX};
float ${name}PrevY = {prevY};
float ${name}PrevZ = {prevZ};

float ${name}NowX = {dcm}.outputTranslateX;
float ${name}NowY = {dcm}.outputTranslateY;
float ${name}NowZ = {dcm}.outputTranslateZ;

float ${name}MoveX = ${name}NowX - ${name}PrevX;
float ${name}MoveY = ${name}NowY - ${name}PrevY;
float ${name}MoveZ = ${name}NowZ - ${name}PrevZ;

float ${name}Distance = mag(<<${name}MoveX, ${name}MoveY, ${name}MoveZ>>);

float ${name}Forward =
    (${name}MoveX * {forward}.outputX) +
    (${name}MoveY * {forward}.outputY) +
    (${name}MoveZ * {forward}.outputZ);

float ${name}Direction = 0;

if (abs(${name}Forward) > 0.0001) {{
    if (${name}Forward > 0)
        ${name}Direction = 1;
    else
        ${name}Direction = -1;
}}
else if (abs($turnDelta) > 0.0001) {{
    ${name}Direction = $turnDirection;
}}

float ${name}RollDelta =
    ${name}Distance *
    {master}.{ratioAttr} *
    {master}.{attr} *
    ${name}Direction;

{offset}.{childrenAttr} =
    {offset}.{childrenAttr} +
    ${name}RollDelta;

{prevX} = ${name}NowX;
{prevY} = ${name}NowY;
{prevZ} = ${name}NowZ;
""".format(name=safeName, prevX=prevX, prevY=prevY, prevZ=prevZ,dcm=dcm,forward=forwardVP,master=master,ratioAttr=ratioAttr,attr=attr,offset=offsetGrp,childrenAttr=childrenAttr))
        if not expressionLines:
            continue

        expressionFooter = """
{prevTurn} = $nowTurn;
""".format(prevTurn=prevTurnPlug)
        expressionName = "{}_{}_EXP".format(parentSafeName, attr)
        if cmds.objExists(expressionName):
            cmds.delete(expressionName)
        cmds.expression(
            n=expressionName,
            s=expressionHeader + "\n".join(expressionLines) + expressionFooter,
            ae=True,
            uc="all"
        )


def Add(listUI,data,*arr):
    global ITEMS
    def Delete(ui,*arr):
        global ITEMS
        cmds.deleteUI(ui)
        del ITEMS['items'][ui]
        ITEMS['order'].remove(ui)

    itemData = {}   
    itemUI = cmds.rowColumnLayout(numberOfColumns=1,parent=listUI,backgroundColor=(0.15, 0.15, 0.15))

    cmds.rowColumnLayout(numberOfColumns=1)

    cmds.rowColumnLayout( numberOfColumns=3,columnWidth=[(1,80),(2,265),(3,32)]) #--


    cmds.textField(text='Parent',editable=False)
    itemData['Parent'] = cmds.textField(text=data.get("parent", ""))
    cmds.button(label="->",w=30,c=partial(NLTA_UI.PickObject,itemData['Parent']))




    cmds.textField(text='Children',editable=False)
    itemData['children'] = cmds.scrollField(wordWrap=True,height=80,text=data.get('children', ""))
    cmds.rowColumnLayout(nc=1)
    cmds.button(label="->",w=30,c=partial(NLTA_UI.PickObject,itemData['children']))
    cmds.button(label="+",w=30,c=partial(NLTA_UI.PickObjectAdd,itemData['children']))
    cmds.setParent("..")

    cmds.textField(text='Children Attribute',editable=False)
    itemData['childrenAttr'] = cmds.textField(text=data.get("childrenAttr", ""))
    cmds.button(label="->",w=30,c=partial(NLTA_UI.PickAttrOnly,itemData["childrenAttr"]))

    cmds.textField(text='Attr Holders',editable=False)
    itemData['attrHolders'] = cmds.scrollField(text=data.get('attrHolders', ""),height=80)
    cmds.rowColumnLayout(nc=1)
    cmds.button(label="->",w=30,c=partial(NLTA_UI.PickObject,itemData['attrHolders']))
    cmds.button(label="+",w=30,c=partial(NLTA_UI.PickObjectAdd,itemData['attrHolders']))
    cmds.setParent("..")

    cmds.textField(text='Attr',editable=False)
    itemData['attr'] = cmds.textField(text=data.get('attr', ""))
    cmds.text("..")

    cmds.textField(text='ratio',editable=False)
    itemData['ratio'] = cmds.textField(text=data.get('ratio', "1"))
    cmds.text("..")

    cmds.textField(text='Forward Axis',editable=False)
    itemData['forwardAxis'] = cmds.textField(text=data.get('forwardAxis', "z"))
    cmds.button(label="->",w=30,c=partial(NLTA_UI.PickAttrOnly,itemData['forwardAxis']))



    cmds.setParent("..") #--

    cmds.button(label="X",w=35,backgroundColor=(.5,.2,.2),c=partial(Delete,itemUI))
    cmds.separator(height=10, style='none')

    cmds.setParent("..")    
    cmds.setParent("..")

    ITEMS['items'][itemUI] = itemData
    ITEMS['order'].append(itemUI)











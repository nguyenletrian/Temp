import os
import maya.cmds as cmds
import pymel.core as pm
from functools import partial
from datetime import datetime

import NLTA_General,NLTA_UI,NLTA_Control
for module in [NLTA_General,NLTA_UI,NLTA_Control]:
    try:
        importlib.reload(module)
    except:
        from importlib import reload
        reload(module)

ITEMS = {
    "items":{},
    "order":[]
}

def DefaultSetting(*arr):
    moduleName = os.path.basename(__file__).replace(".py","")
    ext = "json"
    name = "Control Shape"
    return({
        "ext":ext,
        "path":("/").join(os.path.dirname(pm.sceneName()).split('/'))+"/SceneData/"+moduleName+"."+ext,
        "moduleName":moduleName,
        "order":0,
        "title":name,
        "name":name,
        "id":datetime.now().strftime("%Y%m%d%H%M%S")
    })


def Load(data,listUI,*arr):
    newestData = NLTA_General.JsonGetByID({
        "path":data["sceneDataPath"],
        "id":data["id"]
    })
    path = newestData["path"]
    if ".json" in path:
        children = cmds.layout(listUI,q=True, ca=True) or []
        for child in children:
            if cmds.control(child, exists=True):
                cmds.deleteUI(child)        
        itemDatas = NLTA_General.readJsonFile(path)
        if itemDatas:
            for i in range(len(itemDatas)):
                Add(listUI,itemDatas[i])

def Form(data,*arr):
    def Save(data, *arr):
        itemData = NLTA_General.JsonGetByID({
            "path":data["sceneDataPath"],
            "id":data["id"]
        })          
        returnData = NLTA_UI.GetData(ITEMS['items'])
        NLTA_General.writeJsonFile(itemData["path"],returnData)

    mainForm = NLTA_General.LoadModule("Scene_Form")
    dataBack = mainForm.Create(data)
    buttonUI = dataBack["buttonUI"]
    listUI = dataBack["listUI"]

    cmds.rowColumnLayout(numberOfColumns=1,parent=buttonUI)
    cmds.rowColumnLayout(nc=2)
    cmds.button(label="Add",c=partial(Add,listUI,{}),width=200)
    cmds.button(label="Save",c=partial(Save,data),width=200)
    cmds.setParent("..")
    colorParent = cmds.rowColumnLayout(nc=1)
    colorPick = NLTA_Control.IndexColorPick({"parent":colorParent,"width":400,"height":100})
    cmds.setParent("..")
    cmds.setParent("..")
    Load(data,listUI)

def Run(data,*arr):
    newestData = NLTA_General.JsonGetByID({
        "path":data["sceneDataPath"],
        "id":data["id"]
    })
    datas = NLTA_General.readJsonFile(newestData["path"])
    if datas:
        for data in datas:
            objs = data["object"].split("\n")
            shape = data["shape"]
            NLTA_Control.ShapeChangeSingle({"objs":objs,"shape":shape})
            

def Add(listUI,data,*arr):
    global ITEMS
    def Delete(ui,*arr):
        global ITEMS
        cmds.deleteUI(ui)
        del ITEMS['items'][ui]
        ITEMS['order'].remove(ui)

    def PickChild(ui,*arr):
        NLTA_UI.PickObject(ui)
        offsetGroup = cmds.textField(itemData["Child"],query=True,text=True)+"_Offset"
        cmds.textField(itemData["OffsetName"],edit=True,text=offsetGroup)

    itemData = {}   
    itemUI = cmds.rowColumnLayout(numberOfColumns=1,parent=listUI,backgroundColor=(0.15, 0.15, 0.15))
    cmds.rowColumnLayout(numberOfColumns=1)

    cmds.rowColumnLayout( numberOfColumns=3,columnWidth=[(1,80),(2,265),(3,32)]) #--
    cmds.textField(text='Object',editable=False)
    itemData['object'] = cmds.scrollField(wordWrap=True,height=100,text=data.get("object", ""))
    cmds.rowColumnLayout(nc=1)
    cmds.button(label="->",w=30,c=partial(NLTA_UI.PickObject,itemData['object']))
    cmds.button(label="+",w=30,c=partial(NLTA_UI.PickObjectAdd,itemData['object']))
    cmds.setParent("..")
    cmds.textField(text='Shape',editable=False)
    itemData["shape"] = cmds.optionMenu()
    shapeData = NLTA_Control.ShapeData()
    for key in shapeData:
        cmds.menuItem(label=key)
    cmds.optionMenu(itemData["shape"], e=True, value=data.get("shape", "circle"))
    cmds.text(label="")

    cmds.setParent("..") #--

    cmds.button(label="X",w=35,backgroundColor=(.5,.2,.2),c=partial(Delete,itemUI))
    cmds.separator(height=10, style='none')

    cmds.setParent("..")    
    cmds.setParent("..")

    ITEMS['items'][itemUI] = itemData
    ITEMS['order'].append(itemUI)











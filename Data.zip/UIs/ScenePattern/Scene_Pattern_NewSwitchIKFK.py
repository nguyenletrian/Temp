import os
import sys
import json
import copy
import maya.cmds as cmds
import pymel.core as pm
import maya.api.OpenMaya as om
from functools import partial
from datetime import datetime


import NLTA_General,NLTA_UI,NLTA_ScriptJob
for module in [NLTA_General,NLTA_UI,NLTA_ScriptJob]:
    try:
        importlib.reload(module)
    except:
        from importlib import reload
        reload(module)

ITEMS = {
    "items":{},
    "order":[]
}

def DefaultSetting(*arr):
    moduleName = os.path.basename(__file__).replace(".py","")
    ext = "json"
    name = "New Switch IK FK"
    return({
        "ext":ext,
        "path":("/").join(os.path.dirname(pm.sceneName()).split('/'))+"/SceneData/"+moduleName+"."+ext,
        "moduleName":moduleName,
        "order":0,
        "title":name,
        "name":name,
        "id":datetime.now().strftime("%Y%m%d%H%M%S")
    })


def Load(data,listUI,*arr):
    newestData = NLTA_General.JsonGetByID({
        "path":data["sceneDataPath"],
        "id":data["id"]
    })
    path = newestData["path"]
    if ".json" in path:
        children = cmds.layout(listUI,q=True, ca=True) or []
        for child in children:
            if cmds.control(child, exists=True):
                cmds.deleteUI(child)        
        itemDatas = NLTA_General.readJsonFile(path)
        if itemDatas:
            for i in range(len(itemDatas)):
                Add(listUI,itemDatas[i])

def Form(data,*args):
    def Save(data,*args):
        itemData = NLTA_General.JsonGetByID({
            "path": data["sceneDataPath"],
            "id": data["id"]
        })
        saveData = NLTA_UI.GetData(ITEMS["items"])
        NLTA_General.writeJsonFile(itemData["path"],saveData)

    mainForm = NLTA_General.LoadModule("Scene_Form")
    dataBack = mainForm.Create(data)
    buttonUI = dataBack["buttonUI"]
    listUI = dataBack["listUI"]
    cmds.rowColumnLayout(numberOfColumns=2,parent=buttonUI)
    cmds.button(label="Add",width=200,c=partial(Add,listUI,{}))
    cmds.button(label="Save",width=200,c=partial(Save,data))
    cmds.setParent("..")
    Load(data,listUI)


def Run(data,*args):
    def CtrlUI(*arr):
        if cmds.objExists("Rig_UI"):
            return "Rig_UI"
        curve = cmds.curve(n='Rig_UI',d=1,
            p=[
                (-1,0,-1),(-1,0,-3),(1,0,-3),(1,0,-1),(3,0,-1),(3,0,1),
                (1,0,1),(1,0,3),(-1,0,3),(-1,0,1),(-3,0,1),(-3,0,-1),(-1,0,-1)
            ]
        )
        shape = cmds.listRelatives(curve, shapes=True)[0]
        cmds.setAttr(shape + ".isHistoricallyInteresting", 0)
        cmds.setAttr(shape + ".overrideEnabled", 1)
        cmds.setAttr(shape + ".overrideColor", 17)
        for attr in ["tx", "ty", "tz","rx", "ry", "rz","sx", "sy", "sz","v"]:
            cmds.setAttr(curve + "." + attr,lock=True,keyable=False,channelBox=False)
        # Add Snap IK/FK attribute
        if not cmds.attributeQuery("snapIKFK", node=curve, exists=True):
            cmds.addAttr(curve,ln="snapIKFK",at="bool",dv=0,keyable=True)
        return curve

    def CreateDataNode():
        nodeName="NLTA_DataNode"
        if pm.objExists(nodeName):
            return pm.PyNode(nodeName)
        node = pm.createNode("network", name=nodeName)
        return(node)

    def AddData(data):
        jsonString = json.dumps(data, indent=2)
        node = CreateDataNode()
        attr = "IKFKData"
        if not node.hasAttr(attr):
            pm.addAttr(node, ln=attr, dt="string")
        node.IKFKData.set(jsonString)

    mainControl = CtrlUI()

    NLTA_ScriptJob.SkillAll()

    nodeName="NLTA_DataNode"

    # GET DATA
    newestData = NLTA_General.JsonGetByID({"path": data["sceneDataPath"],"id": data["id"]})
    datas = NLTA_General.readJsonFile(newestData["path"])

    # ADD MIRROR SIDE
    expandedDatas = []
    for itemData in datas:
        expandedDatas.append(itemData)
        if not itemData.get("mirror"):
            continue
        mirrorData = copy.deepcopy(itemData)
        mirrorFields = [
            "switchControl",
            "sources",
            "targets",
            "refObjects",
        ]
        for field in mirrorFields:
            if field not in mirrorData:
                continue
            value = mirrorData[field]
            if not value:
                continue
            if "\n" in str(value):
                mirrorData[field] = "\n".join(
                    NLTA_General.GetMirrorName(x)
                    for x in value.split("\n")
                    if x.strip()
                )
            else:
                mirrorData[field] = NLTA_General.GetMirrorName(value)
        expandedDatas.append(mirrorData)
    datas = expandedDatas
    node = CreateDataNode()
    AddData(datas)

    # CREATE SNAP
    for itemData in datas:

        ### PARENT MAIN CONTROL
        if "controlParent" in itemData:
            try:
                cmds.parent(mainControl,itemData["controlParent"])
            except:pass

        ### ADD MATRIX
        sourcesArray = itemData["sources"].split("\n")
        targetsArray = itemData["targets"].split("\n")
        for i in range(len(sourcesArray)):
            source = sourcesArray[i]
            target = targetsArray[i]
            if not cmds.attributeQuery(source+"_Matrix", node=nodeName, exists=True):
                cmds.addAttr(nodeName, ln=source+"_Matrix", at="matrix")
            targetMtx = om.MMatrix(cmds.getAttr(target + ".worldMatrix[0]"))
            sourceMtx = om.MMatrix(cmds.getAttr(source + ".worldMatrix[0]"))
            offset = sourceMtx * targetMtx.inverse()
            cmds.setAttr(nodeName+"."+source+"_Matrix",list(offset),type="matrix")

    ### CREATE SCRIPT JOBS        
    NLTA_ScriptJob.AddAttributeChange({
        "functionName":"SnapIKFK",
        "functionContent":r"""
import json
import maya.cmds as cmds
import maya.api.OpenMaya as om

mainControl = "{}"
mainControlAttr = mainControl+".snapIKFK"
mainControlValue = cmds.getAttr(mainControlAttr)

if mainControlValue:
    def CreateWindow(*arr):
        def Snap(data,*arr):
            node = "NLTA_DataNode"
            nameSpace = data["nameSpace"]
            snapData = data["snapData"]
            switchAttr = snapData["switchControl"]+"."+snapData["switchAttr"]
            sourcesArray = snapData["sources"].split("\n")
            targetsArray = snapData["targets"].split("\n")
            dataMatch = {{}}
            for i in range(len(sourcesArray)):
                source = sourcesArray[i]
                target = targetsArray[i]
                targetMaxtrix = om.MMatrix(cmds.getAttr(target + ".worldMatrix[0]"))
                offset = om.MMatrix(cmds.getAttr(node + "."+source+"_Matrix"))
                sourceMtx = offset * targetMaxtrix
                dataMatch[source] = sourceMtx
            cmds.setAttr(switchAttr,int(snapData["valueActive"]))

            for source in dataMatch:
                print(source)
                cmds.xform(
                    source,
                    ws=True,
                    matrix=list(dataMatch[source])
                )
            cmds.select(sourcesArray[-1])

        def Run(*arr):
            objs = cmds.ls(selection=True)
            if objs:
                node = "NLTA_DataNode"
                jsonString = cmds.getAttr(node+".IKFKData")
                snapDatas = json.loads(jsonString)
                snapWorks = []              
                for snapData in snapDatas:
                    switchAttr = snapData["switchControl"]+"."+snapData["switchAttr"]
                    valueActive = int(snapData["valueActive"])
                    currentValue = int(cmds.getAttr(switchAttr))
                    for obj in objs:
                        if obj in (snapData["refObjects"].split("\n")+[snapData["switchControl"]]) and (valueActive != currentValue):
                            snapWorks.append(snapData)
                for snapWork in snapWorks:
                    nameSpace = ""
                    Snap({{
                        "nameSpace":nameSpace,
                        "snapData":snapWork
                    }}) 

        if cmds.window("SnapIKFK", exists=True):
            cmds.deleteUI("SnapIKFK")
        win = cmds.window("SnapIKFK", title="Snap IK/FK", widthHeight=(130,40),mxb=False,mnb=False,sizeable=False)
        cmds.columnLayout(adjustableColumn=True)
        cmds.button(label="Snap", command=Run,height=40)
        cmds.showWindow(win)

    CreateWindow()
    cmds.setAttr(mainControlAttr,0)
            """.format(mainControl),
            "obj":mainControl,
            "attr":"snapIKFK"
        })

"""
obj = "{}"
attr = "{}"
valueActive = int({})
attrSwitch = obj+"."+attr
currentValue = cmds.getAttr(attrSwitch)
if currentValue == valueActive:
"""

def Add(listUI,data,*args):
    global ITEMS
    def Delete(ui,*args):
        global ITEMS
        cmds.deleteUI(ui)
        del ITEMS["items"][ui]
        ITEMS["order"].remove(ui)

    itemData = {}
    itemUI = cmds.rowColumnLayout(numberOfColumns=1,parent=listUI,backgroundColor=(0.15,0.15,0.15))
    cmds.rowColumnLayout(numberOfColumns=1)

    cmds.rowColumnLayout(numberOfColumns=3,columnWidth=[(1,100),(2,235),(3,32)])
    cmds.textField(text="Control Parent",editable=False)
    itemData["controlParent"] = cmds.textField(text=data.get("controlParent",""))
    cmds.button(label="+",w=30,c=partial(NLTA_UI.PickObject,itemData["controlParent"]))
    cmds.setParent("..")

    cmds.rowColumnLayout(numberOfColumns=3,columnWidth=[(1,100),(2,235),(3,32)])
    cmds.textField(text="Switch Control",editable=False)
    itemData["switchControl"] = cmds.textField(text=data.get("switchControl",""))
    cmds.button(label="+",w=30,c=partial(NLTA_UI.PickObject,itemData["switchControl"]))
    cmds.setParent("..")
    
    cmds.rowColumnLayout(numberOfColumns=3,columnWidth=[(1,100),(2,235),(3,32)])
    cmds.textField(text="Switch Attribute",editable=False)
    itemData["switchAttr"] = cmds.textField(text=data.get("switchAttr",""))
    cmds.button(label="+",w=30,c=partial(NLTA_UI.PickAttrOnly,itemData["switchAttr"]))
    cmds.setParent("..")

    cmds.rowColumnLayout(numberOfColumns=3,columnWidth=[(1,100),(2,235),(3,32)])
    cmds.textField(text="Value Active",editable=False)
    itemData["valueActive"] = cmds.textField(text=data.get("valueActive",""))
    cmds.button(label="+",w=30,c=partial(NLTA_UI.PickObject,itemData["valueActive"]))
    cmds.setParent("..")

    cmds.rowColumnLayout(numberOfColumns=3,columnWidth=[(1,100),(2,235),(3,32)])
    cmds.textField(text="Ref Objects",editable=False)
    itemData["refObjects"] = cmds.scrollField(text=data.get("refObjects",""),height=65)
    cmds.button(label="+",w=30,c=partial(NLTA_UI.PickObject,itemData["refObjects"]))
    cmds.setParent("..")

    cmds.rowColumnLayout(numberOfColumns=3,columnWidth=[(1,100),(2,235),(3,32)])
    cmds.textField(text="Sources",editable=False)
    itemData["sources"] = cmds.scrollField(text=data.get("sources",""),height=65)
    cmds.button(label="+",w=30,c=partial(NLTA_UI.PickObject,itemData["sources"]))
    cmds.setParent("..")



    cmds.rowColumnLayout(numberOfColumns=3,columnWidth=[(1,100),(2,235),(3,32)])
    cmds.textField(text="Targets",editable=False)
    itemData["targets"] = cmds.scrollField(text=data.get("targets",""),height=65)
    cmds.button(label="+",w=30,c=partial(NLTA_UI.PickObject,itemData["targets"]))
    cmds.setParent("..")

    cmds.rowColumnLayout(numberOfColumns=3,columnWidth=[(1,100),(2,245),(3,32)])
    cmds.textField(text="Mirror",editable=False)
    itemData["mirror"] = cmds.checkBox(value=data.get("mirror", True),label="")
    cmds.setParent("..")

    cmds.button(label="X",w=380,bgc=(0.5,0.2,0.2),c=partial(Delete,itemUI))
    cmds.setParent("..")
    cmds.setParent("..")

    ITEMS["items"][itemUI] = itemData
    ITEMS["order"].append(itemUI)











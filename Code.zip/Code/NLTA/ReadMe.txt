#copy folder NLTA into "C:\Users\an.nguyen_g\Documents\maya\scripts"
#run code below

import sys,os
import maya.cmds as cmds
import importlib
user = os.environ.get("USERNAME")
if "C:/Users/"+user+"/Documents/maya/scripts/NLTA" not in sys.path:
    sys.path.append("C:/Users/"+user+"/Documents/maya/scripts/NLTA")
import ta_index
if int(cmds.about(version=True)) < 2022:
    reload(ta_index)
else:
    importlib.reload(ta_index)  
ta_index.run()
import json,os,general,NLTA_setup,A_skinning
import pymel.core as pm
import maya.cmds as cmds
import xml.dom.minidom as xd
import A_skinning,general,NLTA_setup

def createLayout(*arr):
    name = "SBG"
    cmds.window(name+"Window", title = name+" tool")
    cmds.rowColumnLayout(numberOfColumns=4)
    cmds.button(label="Set up scene",width=100,c=SetupScene)
    cmds.button(label="Create Control",width=100,c=CreateControl)
    cmds.button(label="Rename Costume",width=100,c=RenameCostume)
    cmds.button(label="Modify Scene",width=100,c=ModifyScene)

    cmds.setParent("..")
    cmds.showWindow()

def SetupScene(*arr):
    Repath()
    EyeSetup()

def Repath(*arr):
    general.Repath("//virtuosgames.com/spxprojects/SBG/09_Share/LongThanh/Share/Characters")

def EyeSetup(*arr):
    sideArray = ["R","L"]
    for side in sideArray:
        node = "M_Eye_"+side+"_LeifErikson"
        connection = cmds.connectionInfo(node+".color",sfd=True)
        if connection:
            currentNode =  connection.split(".")[0]
            cmds.connectAttr("Add_offset_"+side+".output3D.output3Dx",currentNode+".uCoord",f=True)
            cmds.connectAttr("Add_offset_"+side+".output3D.output3Dy",currentNode+".vCoord",f=True)
            cmds.setAttr(currentNode+'.defaultColor',*(1,1,1), type='double3')
            place2d = cmds.connectionInfo(currentNode+".wrapU",sfd=True)
            place2d = place2d.split(".")[0]
            cmds.setAttr(place2d+".wrapU",0)
            cmds.setAttr(place2d+".wrapV",0)

def RenameCostume(*arr):
    sceneName = pm.sceneName()
    scenePath = os.path.dirname(pm.sceneName())
    characterName = (scenePath.split('/')[-1]).split("_")
    print(characterName)
    if characterName[0]!="Costume":
        characterName = "Costume_"+("_").join(characterName)
    else:
        characterName = ("_").join(characterName)
    objs = cmds.ls(selection=True)[::-1]
    for obj in objs:
        if not obj.startswith("Costume_"):
            preName = characterName+"_"+obj
        else:
            preName = obj
        cmds.rename(obj,preName)

def ModifyScene(*arr):
    AddToSet()

def AddToSet(*arr):
    layerData = {
        "nurbsCurve":{
            "set":["AllSet","ControlSet","CTRLs_All"]
        },
        "joint":{
            "set":["DeformSet","Export_Animation"]
        }
    }
    for key in layerData:
        if key == "nurbsCurve":
            objs = list(set(cmds.listRelatives(cmds.ls(type=key),parent=True)))
        else:
            objs = cmds.ls(type=key)
        sets = layerData[key]["set"]
        for obj in objs:
            if obj.startswith("Costume_"):
                for set_ in sets:
                    if key == "joint":
                        if "FK" not in obj:
                            cmds.sets(obj, add=set_)   
                    else:
                        cmds.sets(obj, add=set_)

def CreateControl(type,*arr):
    sceneName = pm.sceneName()
    scenePath = os.path.dirname(pm.sceneName())
    characterName = (scenePath.split('/')[-1]).split("_")[0:-1]
    if characterName[0]!="Costume":
        characterName = "Costume_"+("_").join(characterName)
    else:
        characterName = ("_").join(characterName)
    objs = cmds.ls(selection=True,type="joint")[::-1]
    parentData = []
    for obj in objs:
        if not obj.startswith("Costume_"):
            preName = characterName+"_"+obj
        else:
            preName = obj
        translation = cmds.xform(obj,query=True,t=True,worldSpace=True)
        rotation =  cmds.xform(obj,query=True,ro=True,worldSpace=True)    
        groupZero = cmds.group(em=True, name=preName+'_ctrl_zero_Grp')
        groupOff = cmds.group(em=True, name=preName+'_ctrl_off_Grp')
        groupSDK = cmds.group(em=True, name=preName+'_ctrl_SDK_Grp')
        groupConstraint = cmds.group(em=True, name=preName+'_contraint')
        curve = cmds.circle(radius=1, name=preName)[0]    
        cmds.scale(10,10,10,curve)
        cmds.rotate(90,0,0,curve)
        cmds.makeIdentity(curve, apply=True,rotate=True,scale=True)
        cmds.parent(groupConstraint,curve)
        cmds.parent(curve,groupSDK)
        cmds.parent(groupSDK,groupOff)
        cmds.parent(groupOff,groupZero)
        cmds.xform(groupZero,t=translation,worldSpace=True)
        cmds.xform(groupZero,ro=rotation,worldSpace=True)
        cmds.parentConstraint(curve,obj)
        cmds.sets(curve, add="ControlSet")
        cmds.sets(obj, add="DeformSet")
        cmds.sets(obj, add="Export_Animation")
        for scale in ["sx","sy","sz"]:
            cmds.connectAttr(curve+"."+scale,obj+"."+scale)
        if not obj.startswith("Costume_"):
            obj = cmds.rename(obj,preName)  
    """        
    parent = cmds.listRelatives(obj,parent=True)
        if parent:
            parent = parent[0]
            if parent in objs:
                childrenZeoGrp = characterName+"_"+obj+'_ctrl_zero_Grp'
                parentConstraintGrp = characterName+parent+"_contraint"                
                parentData.append([childrenZeoGrp,parentConstraintGrp])

    for pair in parentData:
        cmds.parent(pair[0],pair[1])
    """


    

        
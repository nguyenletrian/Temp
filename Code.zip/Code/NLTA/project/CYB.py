import json,os,general,NLTA_setup,A_skinning
import pymel.core as pm
import maya.cmds as cmds
import xml.dom.minidom as xd

#preFix = "Rig_Imp_"
def createLayout(*arr):
	name = "CYB"
	cmds.window(name+"Window", title = name+" tool")

	cmds.rowColumnLayout(numberOfColumns=4)
	cmds.button(label="Constraint Face",width=100,c=ConstraintFace)
	cmds.button(label="Camel Control",width=100,c=RenameASControlToCamel)
	cmds.button(label="Replace Texture",width=100,c=ReplaceTextture)
	
	cmds.setParent("..")

	cmds.showWindow()

def ConstraintFace(*arr):
	data = {
		'C_brow_mid':'EyeBrowCenterJoint_M',
		'L_brow_mid':'EyeBrowInnerJoint_L',
		'L_brow_outer':'EyeBrowOuterJoint_L',
		'L_cheek_inner':'CheekJoint_L',
		'C_lip_upper_mid':'upperLipJoint0_M',
		'L_lip_upper_outer':'upperLipJoint5_L',
		'L_lip_corner':'cornerLipJoint_L',
		'C_nose_bridge':'NoseJoint_M',
		'R_brow_mid':'EyeBrowInnerJoint_R',
		'R_brow_outer':'EyeBrowOuterJoint_R',
		'R_cheek_inner':'CheekJoint_R',
		'R_lip_corner':'cornerLipJoint_R',
		'C_jaw':'JawJoint_M',
		'L_lip_lower_outer':'lowerLipJoint5_L',
		'C_lip_lower_mid':'lowerLipJoint0_M',
		'R_lip_lower_outer':'lowerLipJoint5_R',
		'teeth_lower':'lowerTeethJoint_M',
		'R_eye':'EyeJoint_R',
		'R_eye_lid_upper_mid':'upperLidMain5_R',
		'R_eye_lid_lower_mid':'lowerLidMain5_R',
		'L_eye':'EyeJoint_L',
		'L_eye_lid_upper_mid':'upperLidMain5_L',
		'L_eye_lid_lower_mid':'lowerLidMain5_L',
		'teeth_upper':'upperTeethJoint_M',
		'R_lip_upper_outer':'upperLipJoint5_R',
		'tongue':'Tongue1Joint_M',

	}
	for key in data:
		cmds.parentConstraint(data[key],key,mo=True)

def CompleteScene():
	pass

def SelectAllFk():
	pass

objs = cmds.ls(selection=True)

def RenameCamel(obj):
	parts = obj.split('_')
	name = obj.replace('_AS_',"")
	name = parts[0].replace("FK","").capitalize()
	for part in parts[1:-1]:
		name = name+(part.capitalize())
	name = "FK"+name+"_"+parts[-1]
	name = name.replace('As',"")
	cmds.rename(obj,name)

def SelectControlInSet(setName):
	members = cmds.sets(setName,q=True) or []
	curveTransforms = []
	for obj in members:
		shapes = cmds.listRelatives(obj,shapes = True,fullPath = True) or []
		for shape in shapes:
			if cmds.objectType(shape) == 'nurbsCurve':
				if obj not in curveTransforms:
					curveTransforms.append(obj)
	return(curveTransforms)
	
def RenameASControlToCamel(*arr):
	ctrls = SelectControlInSet('ControlSet')
	for ctrl in ctrls:
		if len(ctrl.split('_'))>2:
			RenameCamel(ctrl)

def ReplaceTextture(*arr):
	oldPath = "D:/P4/LayoutPortfolio_BAZ/" 
	newPath = "//virtuosgames.com/spxprojects/LKS/PORTFOLIO/BAZ/11_ProjectSpace/02_Assets/"
	fileNodes = cmds.ls(type='file')
	replaced = []
	for node in fileNodes:
	    filePath = cmds.getAttr(node+'.fileTextureName')    
	    if filePath and oldPath in filePath:
	        newFilePath = filePath.replace(oldPath,newPath)
	        cmds.setAttr(node+'.fileTextureName',newFilePath,type='string')



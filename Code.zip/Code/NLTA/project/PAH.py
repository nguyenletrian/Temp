import json, os, general, NLTA_setup, A_skinning
import pymel.core as pm
import maya.cmds as cmds
import xml.dom.minidom as xd

def createLayout(*arr):
    name = "PAH"
    cmds.window(name+"Window", title = name+" tool")

    cmds.rowColumnLayout(numberOfColumns=4)
    cmds.button(label="Export Origin",width=100,c=ExportOriginMesh)
    cmds.button(label="Import Max Skin",width=100,c=ImportMaxSkin)
    cmds.button(label="Import Origin",width=100,c=ImportOriginMesh)
    cmds.button(label="Import Quad",width=100,c=ImportQuadMesh)
    cmds.setParent("..")
    cmds.showWindow()

def ImportMaxSkin(*arr):
    scenePath = os.path.dirname(pm.sceneName())
    maxSkin =  scenePath + '/MaxExport/SkinMeshs.fbx'
    if os.path.exists(maxSkin):
        cmds.file(maxSkin, i=True, type="FBX", ignoreVersion=True, ra=True, mergeNamespacesOnClash=False, namespace=":", options="fbx", pr=True)

def ImportOriginMesh(*arr):
    scenePath = os.path.dirname(pm.sceneName())
    fbx =  scenePath + '/MaxExport/OriginMesh.fbx'
    if os.path.exists(fbx):
        cmds.file(fbx, i=True, type="FBX", ignoreVersion=True, ra=True, mergeNamespacesOnClash=False, namespace="Origin", options="fbx", pr=True)

def ImportQuadMesh(*arr):
    scenePath = os.path.dirname(pm.sceneName())
    fbx =  scenePath + '/MaxExport/QuadMesh.fbx'
    print(fbx)
    print("D:/TASK/PAH/work/u_cav_thracian_chieftain/MaxExport/QuadMesh.fbx")
    if os.path.exists(fbx):
        cmds.file(fbx, i=True, type="FBX", ignoreVersion=True, ra=True, mergeNamespacesOnClash=False, namespace="Quad", options="fbx", pr=True)

def ExportOriginMesh(*arr):
    path = cmds.fileDialog2(dialogStyle=2, fileMode=3, caption="Select Folder")[0]
    if path:
        cmds.select(cmds.listRelatives(cmds.ls(type="mesh"),parent=True))
        filePath = path + "/OriginMesh.fbx" 
        cmds.file(filePath,force=True,options='v=0',typ="FBX export",pr=True,es=True)
        cmds.select(clear=True)
"""
def ExportSkins(*arr):
    folder_scene = os.path.join(os.path.dirname(pm.sceneName()), 'skinWeights')
    if not os.path.exists(folder_scene):
        os.makedirs(folder_scene)
    list_selected = pm.ls(sl=True)
    if not list_selected:
        list_selected = pm.ls(type='transform')
    for mesh in list_selected:
        if not pm.listRelatives(mesh, type='mesh'): continue
        sc = pm.mel.eval('findRelatedSkinCluster ' + mesh)
        if sc is '': continue
        name_trans = mesh.getTransform().name()
        nameFile = name_trans + '.xml'
        path = pm.deformerWeights(nameFile,path = folder_scene + os.sep,export = True,deformer = sc)

def ImportFbx(*arr):
    user = os.environ.get("USERNAME")
    data = general.readJsonFile("C:/Users/"+user+"/Documents/NLTA_Session/CreateMaya.json")
    folder = data["folder"]
    maxFbx = folder+"MaxExport/mesh.fbx"
    #cmds.file(maxFbx, i=True, type="Fbx", ignoreVersion=True, ra=True, mergeNamespacesOnClash=False, namespace=":", options="v=0", pr=True,f=True)
    cmds.file(maxFbx, i=True, type="Fbx", ignoreVersion=True, ra=True, mergeNamespacesOnClash=False, namespace="max", options="fbx", pr=True)
    #file -import -type "FBX"  -ignoreVersion -ra true -mergeNamespacesOnClash false -namespace "Temp" -options "fbx"  -pr  -importFrameRate true  -importTimeRange "override" "D:/code/3DSMAX_FULL/File CAT/TestPAH/MaxExport/mesh.fbx";

def ImportObj(*arr):
    user = os.environ.get("USERNAME")
    data = general.readJsonFile("C:/Users/"+user+"/Documents/NLTA_Session/CreateMaya.json")
    folder = data["folder"]
    maxFbx = folder+"MaxExport/mesh.obj"
    cmds.file(maxFbx, i=True, type="OBJ", ignoreVersion=True, ra=True, mergeNamespacesOnClash=False, namespace="max", options="mo=1", pr=True)

    # Define the mesh name and the namespace
    mesh_name = "pCube1"
    namespace = "myNamespace"

    # Create the namespace if it doesn't exist
    if not cmds.namespace(exists=namespace):
        cmds.namespace(add=namespace)

    # Add the namespace to the mesh
    new_name = namespace + ":" + mesh_name
    cmds.rename(mesh_name, new_name)

    print("Mesh renamed with namespace:", new_name)
"""
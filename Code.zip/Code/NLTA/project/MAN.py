import json,os,general,NLTA_setup,A_skinning
import pymel.core as pm
import maya.cmds as cmds
import xml.dom.minidom as xd

#preFix = "Rig_Imp_"
def createLayout(*arr):
    name = "MAN"
    cmds.window(name+"Window", title = name+" tool")

    cmds.rowColumnLayout(numberOfColumns=4)
    cmds.button(label="Fix Initial",width=100,c=fix_initial)
    cmds.button(label="Select all joint",width=100,c=select_all_joint)
    cmds.button(label="Export PostScript",width=100,c=export_postscript)
    cmds.button(label="Create Root Joint",width=100,c=createRootJoint)
    cmds.button(label="Orient Joint",width=100,c=orientJoint)
    cmds.button(label="Mirror Joint",width=100,c=mirrorJoint)
    cmds.button(label="Clear Small Value",width=100,c=clearAttr)
    cmds.button(label="Preferred Angle",width=100,c=preferredAngle)
    cmds.button(label="Export UE",width=100,c=exportUE)
    cmds.setParent("..")

    cmds.showWindow()

def createRootJoint (*arr):
    cmds.select(clear=True)
    rootJoint = cmds.joint(n="RootSHJnt",p=(0,0,0))
    cmds.setAttr(rootJoint+".rx",90)
    pm.mel.eval("makeIdentity -apply true -t 1 -r 1 -s 1 -n 0 -pn 1;")

def clearAttr(*arr):
    for obj in cmds.ls(selection=True):
        for a  in ("translate","rotate","jointOrient","preferredAngle"):
            for b in ("X","Y","Z"):
                attrValue = abs(cmds.getAttr(obj+"."+a+b))
                if attrValue < 0.001:
                    cmds.setAttr(obj+"."+a+b,0)

def preferredAngle (*arr):
    axis = ("X","Y","Z")
    for a in cmds.ls(selection=True):
        valueArray = (abs(cmds.getAttr(a+".jointOrientX")),abs(cmds.getAttr(a+".jointOrientY")),abs(cmds.getAttr(a+".jointOrientZ")))
        maxValue = max(valueArray)
        maxIndex = valueArray.index(maxValue)
        axisMax = axis[maxIndex]
        for b in axis:
            if b != axisMax:
                cmds.setAttr(a+".preferredAngle"+b,0)
            else:
                if cmds.getAttr(a+".jointOrient"+b) > 0:
                    cmds.setAttr(a+".preferredAngle"+b,0.1)
                else:
                    cmds.setAttr(a+".preferredAngle"+b,-0.1)
                

def mirrorJoint(*arr):
    for a in cmds.ls(selection=True):
        cmds.select(a)
        if "_R_" in a:
            pm.mel.eval('mirrorJoint -mirrorYZ -mirrorBehavior -searchReplace "_R_" "_L_";')
        else:
            pm.mel.eval('mirrorJoint -mirrorYZ -mirrorBehavior -searchReplace "_L_" "_R_";')

def orientJoint (*arr):
    pm.mel.eval("joint -e  -oj xzy -secondaryAxisOrient ydown -ch -zso;")

def fix_initial(*arr):
    cmds.lockNode('initialShadingGroup', l=0, lockUnpublished=0)

def select_all_joint(*arr):
    root = "RootSHJnt"
    cmds.select(cmds.listRelatives(root,ad=True,type="joint"))
    cmds.select(root,add=True)
    
def export_postscript(*arr):    
    folder_temp = os.path.dirname(pm.sceneName())
    data_temp = "import pymel.core as pm\n"
    data_temp += "import maya.cmds as cmds\n\n"
    character_name = ""
    
    for i in cmds.ls(type="network"):
        if cmds.getAttr(i+".mant_type")=="charnode":
            character_name = i
        
    data_temp += 'CHARNODE = "'+character_name+'" '
    data_temp += '# This will dynamically be assigned to the charnode instance variable.\n\n'
    
    space_switch = ""
    for i in cmds.ls(type="network"):
        if cmds.getAttr(i+".mant_type")!="charnode":
            data_temp += "def "+i+"_pre_():\n"
            data_temp += '    """\n'+"    pre-script for the "+i+" module\n"+'    """\n'
            data_temp += "def "+i+"_post_():\n"
            data_temp += '    """\n'+"    post-script for the "+i+" module\n"+'    """\n'
            if cmds.attributeQuery("shape",n=i,exists=True):
                if cmds.getAttr(i+".side") == "c":
                    if cmds.getAttr(i+".shape") =="circleBigArrow_4way":
                        ctrl_name =  i+"_Ctrl"
                        data_temp += "    for i in ['circleBigArrow_4wayShape','circleBigArrow_4way3Shape','circleBigArrow_4way4Shape','circleBigArrow_4way5Shape','bigArrow15Shape','bigArrow16Shape','bigArrow17Shape','bigArrow18Shape']:\n"
                        data_temp += "        pm.mel.eval('setAttr "+'"'+ctrl_name+"|'+i+'.overrideEnabled"+'"'+" 1;')\n"
                        data_temp += "        pm.mel.eval('setAttr "+'"'+ctrl_name+"|'+i+'.drawOverride.overrideColorR"+'"'+" 0;')\n"
                        data_temp += "        pm.mel.eval('setAttr "+'"'+ctrl_name+"|'+i+'.drawOverride.overrideColorG"+'"'+" 1;')\n"
                        data_temp += "        pm.mel.eval('setAttr "+'"'+ctrl_name+"|'+i+'.drawOverride.overrideColorB"+'"'+" 0;')\n"
                    else:
                        for b in cmds.ls(i+"*_Ctrl"):
                            shape_array = ""
                            for c in cmds.listRelatives(b,type="shape"):
                                shape_array += "'"+c+"',"
                            shape_array = "["+shape_array+"]"
                            data_temp += "    for i in {}:\n".format(shape_array)
                            data_temp += "        pm.mel.eval('setAttr "+'"'+b+"|'+i+'.overrideEnabled"+'"'+" 1;')\n"
                            data_temp += "        pm.mel.eval('setAttr "+'"'+b+"|'+i+'.drawOverride.overrideColorR"+'"'+" 1;')\n"
                            data_temp += "        pm.mel.eval('setAttr "+'"'+b+"|'+i+'.drawOverride.overrideColorG"+'"'+" 1;')\n"
                            data_temp += "        pm.mel.eval('setAttr "+'"'+b+"|'+i+'.drawOverride.overrideColorB"+'"'+" 0;')\n"
                        
               
                    
            if cmds.getAttr(i+".mant_type") in ["ik_fk_arm"]: 
                data_temp += "    if pm.objExists('"+i+"_poleVector_Ctrl_bfr_pointConstraint1'):\n"
                data_temp += "        pm.delete('"+i+"_poleVector_Ctrl_bfr_pointConstraint1')\n"
                
            if cmds.getAttr(i+".mant_type") in ["ik_fk_arm","fk_chain"]:              
                fk_ctrl = []
                if cmds.getAttr(i+".mant_type") ==  "ik_fk_arm":
                    attr_name = "fk_controller_"
                elif cmds.getAttr(i+".mant_type") ==  "fk_chain":
                    attr_name = "controller_"
                for a in [0,1,2]:
                    if cmds.attributeQuery(attr_name+str(a),n=i,exists=True):
                        ctrl_name = cmds.connectionInfo(i+"."+attr_name+str(a),sourceFromDestination=True)
                        fk_ctrl.append(ctrl_name.split(".")[0])
                    else:
                        break
                        
                ctrl_shape_string = ""
                for b in fk_ctrl:
                    if cmds.listRelatives(b,c=True,type="mesh"):                        
                        ctrl_shape = cmds.listRelatives(b,c=True,type="mesh")[0]
                        ctrl_shape_string += "'"+ b + "|" + ctrl_shape +"',"                
                if ctrl_shape_string != "":
                    data_temp += "    for a in ["+ctrl_shape_string+"]:\n"
                    if cmds.getAttr(i+".side") == "r":
                        data_temp += "        pm.mel.eval('setAttr "+'"'+"'+a+'.overrideEnabled"+'"'+" 1;')\n"
                        data_temp += "        pm.mel.eval('setAttr "+'"'+"'+a+'.drawOverride.overrideColorR"+'"'+" 1;')\n"
                        data_temp += "        pm.mel.eval('setAttr "+'"'+"'+a+'.drawOverride.overrideColorG"+'"'+" 0;')\n"
                        data_temp += "        pm.mel.eval('setAttr "+'"'+"'+a+'.drawOverride.overrideColorB"+'"'+" 0;')\n"
                    elif cmds.getAttr(i+".side") == "l":
                        data_temp += "        pm.mel.eval('setAttr "+'"'+"'+a+'.overrideEnabled"+'"'+" 1;')\n"
                        data_temp += "        pm.mel.eval('setAttr "+'"'+"'+a+'.drawOverride.overrideColorR"+'"'+" 0;')\n"
                        data_temp += "        pm.mel.eval('setAttr "+'"'+"'+a+'.drawOverride.overrideColorG"+'"'+" 0;')\n"
                        data_temp += "        pm.mel.eval('setAttr "+'"'+"'+a+'.drawOverride.overrideColorB"+'"'+" 1;')\n"
        
            
            if len(cmds.ls("body",type="joint"))!=0:
                body_ctrl = cmds.parentConstraint(cmds.ls("body",type="joint")[0],q=True,tl=True)
                body = "'"+body_ctrl[0]+"',"
            else:
                body = ""
            
            if len(cmds.ls("chest",type="joint"))!=0:
                chest_ctrl = cmds.parentConstraint(cmds.ls("chest",type="joint")[0],q=True,tl=True)
                chest = "'"+chest_ctrl[0]+"',"
            else:
                chest = ""
                       
            if cmds.getAttr(i+".mant_type") ==  "ik_fk_arm":                    
                space_switch += "    child = pm.PyNode('"+i+"_poleVector_Ctrl_bfr')\n"
                space_switch += cmds.format("    parents = ['negateTrajectory', 'RootSHJnt', 'MAIN_Ctrl', 'MAIN_Inner_Ctrl',^1s^2s'"+i+"_WristIk_Ctrl']\n",stringArg=(body,chest))
                space_switch += "    selector = pm.PyNode('"+i+"_ElbowIk_Ctrl')\n"
                space_switch += "    createSpaceSwitch(child, parents, selector)\n\n"
                
                space_switch += "    child = pm.PyNode('"+i+"_end_ik_Ctrl_bfr')\n"
                space_switch += "    parents = ['negateTrajectory', 'RootSHJnt', 'MAIN_Ctrl', 'MAIN_Inner_Ctrl',{}{}]\n".format(body,chest)
                space_switch += "    selector = pm.PyNode('"+i+"_WristIk_Ctrl')\n"
                space_switch += "    createSpaceSwitch(child, parents, selector)\n\n"
                
            if cmds.getAttr(i+".mant_type")=="ik_fk_leg":
                data_temp += "    if pm.objExists('"+i+"_end_ik_Ctrl_bfr_pointConstraint1'):\n"
                data_temp += "        pm.delete('"+i+"_poleVector_Ctrl_bfr_pointConstraint1')\n"
                
                space_switch += "    child = pm.PyNode('"+i+"_poleVector_Ctrl_bfr')\n"
                space_switch += "    parents = ['negateTrajectory', 'RootSHJnt', 'MAIN_Ctrl', 'MAIN_Inner_Ctrl',{} '"+i+"_FootIk_Ctrl', '"+i+"_BallIk_Ctrl']\n".format(body)
                space_switch += "    selector = pm.PyNode('"+i+"_KneeIk_Ctrl')\n"
                space_switch += "    createSpaceSwitch(child, parents, selector)\n\n"
                
                space_switch += "    child = pm.PyNode('"+i+"_end_ik_Ctrl_bfr')\n"
                space_switch += "    parents = ['negateTrajectory', 'RootSHJnt', 'MAIN_Ctrl', 'MAIN_Inner_Ctrl',{}]\n".format(body)
                space_switch += "    selector = pm.PyNode('"+i+"_FootIk_Ctrl')\n"
                space_switch += "    createSpaceSwitch(child, parents, selector)\n\n"      
            
            data_temp += "\n"
                   
    
    data_temp += "def _any_pre_():\n"
    data_temp += '    """\n'+"    pre-script for when any module is built\n"+'    """\n'
    data_temp += "def _any_post_():\n"
    data_temp += '    """\n'+"    post-script for when any module is built\n"+'    """\n'
    
    data_temp += "def _all_post_():\n"
    data_temp += '    """\n'+"    Script for running after all modules are built\n"+'    """\n'
    data_temp += "    import chimera_rig.chimera_rig_model\n"
    data_temp += "    import mantlib.rig.attributes as mant_attributes\n\n"
    
    data_temp += "    ctrls = CHARNODE.get_controllers()\n"
    data_temp += "    if pm.objExists('BodyControls'):\n"
    data_temp += "        pm.delete('BodyControls')\n"
    data_temp += "    pm.sets(ctrls, name='BodyControls')\n\n"
    
    data_temp += "    pw = []\n"
    data_temp += "    #pw = [[ctrl,[down,up,left,right]]]\n\n"
    data_temp += "    for node, tgts in pw:\n"
    data_temp += "        node = pm.PyNode(node)\n"
    data_temp += "        mant_attributes.add_set_attrs(node, attrs=[{'name': 'downMove', 'type': 'node', 'val': pm.PyNode(tgts[0])},{'name': 'upMove', 'type': 'node', 'val': pm.PyNode(tgts[1])},{'name': 'leftMove', 'type': 'node', 'val': pm.PyNode(tgts[2])},{'name': 'rightMove', 'type': 'node', 'val': pm.PyNode(tgts[3])}])\n\n"
    
    data_temp += "    def createSpaceSwitch(child, parents, selector):\n"
    data_temp += "        en = ''\n"
    data_temp += "        for i in parents:\n"
    data_temp += "            en += '{}:'.format(i)\n"
    data_temp += "        en = en[:len(en) - 1]\n"
    data_temp += "        selector.addAttr('SpaceSwitch', at='enum', en=en, keyable=True)\n"
    data_temp += "        tgt = list(parents)\n"
    data_temp += "        tgt.append(child)\n"
    data_temp += "        const = pm.parentConstraint(tgt, maintainOffset=True)\n"
    data_temp += "        for i, pt in enumerate(parents):\n"
    data_temp += "            cnd = pm.createNode('condition', name='{}_{}_cnd'.format(child, pt))\n"
    data_temp += "            selector.SpaceSwitch.connect(cnd.firstTerm)\n"
    data_temp += "            cnd.secondTerm.set(i)\n"
    data_temp += "            cnd.colorIfTrueR.set(1)\n"
    data_temp += "            cnd.colorIfFalseR.set(0)\n"
    data_temp += "            cnd.outColorR.connect(const.getWeightAliasList()[i])\n\n"
    
    data_temp += space_switch    
    
    data_temp += "    # Start Display Layers\n"    
    data_temp += "    LayerName = 'RigSkeletonLayer'\n"
    data_temp += "    if pm.objExists(LayerName):\n"
    data_temp += "        pm.delete(LayerName)\n"
    data_temp += "    DisplayLayer = pm.createDisplayLayer(name=LayerName, empty=True)\n"
    data_temp += "    pm.editDisplayLayerMembers(DisplayLayer, 'RootSHJnt', noRecurse=True)\n"
    data_temp += "    DisplayLayer.color.set(9)\n"
    data_temp += "    DisplayLayer.displayType.set(2)\n"
    data_temp += "    DisplayLayer.visibility.set(0)\n\n"
    
    data_temp += "    LayerName = 'ControlsLayer'\n"
    data_temp += "    if pm.objExists(LayerName):\n"
    data_temp += "        pm.delete(LayerName)\n"
    data_temp += "    DisplayLayer = pm.createDisplayLayer(name=LayerName, empty=True)\n"
    data_temp += "    pm.editDisplayLayerMembers(DisplayLayer, 'ControlRig', noRecurse=True)\n"
    data_temp += "    DisplayLayer.color.set(29)\n\n"    
    
    mesh_parent = []
    for a in cmds.ls(type="skinCluster"):
        mesh_parent.append("'"+cmds.listConnections(a, s=False, d=True,type="mesh")[0]+"'")
                
    data_temp += "    LayerName = 'GeoLayer'\n"
    data_temp += "    if pm.objExists(LayerName):\n"
    data_temp += "        pm.delete(LayerName)\n"
    data_temp += "    DisplayLayer = pm.createDisplayLayer(name=LayerName, empty=True)\n"
    data_temp += "    pm.editDisplayLayerMembers(DisplayLayer,("+",".join(mesh_parent)+"), noRecurse=True)\n"
    data_temp += "    DisplayLayer.displayType.set(2)\n"
    data_temp += "    DisplayLayer.visibility.set(1)\n\n"
    	
    add_postScript = folder_temp+"/add_"+character_name+"_postscript.py"
    if not os.path.exists(add_postScript):
        with open(add_postScript,"w") as txt_file:
            txt_file.write("")
    else:
        filePath = cmds.encodeString(add_postScript)
        myFile =  open(filePath,'r')
        myObject = myFile.read()
        myFile.close()
        data_temp += myObject
          
    file_path = folder_temp+"/"+character_name+"_postscript.py"
    with open(file_path,"w") as txt_file:
    	txt_file.write(data_temp)

def exportUE(*arr):
    exportNode = cmds.ls(type="ExportNode")
    rootJoint = []
    joints = cmds.ls(type="joint")[::-1]
    for aJoint in joints:
        if not cmds.listRelatives(aJoint,parent=True,type="joint"):
            rootJoint.append(aJoint)

    filePath = pm.sceneName()
    folder = os.path.dirname(pm.sceneName())
    folderExport =  folder + "/folderExport"
    if not os.path.exists(folderExport):
        os.makedirs(folderExport)    
    for node in exportNode:
        cmds.file(filePath,open=True,force=True)
        cmds.parent(rootJoint,node)
        meshs =  cmds.listRelatives(node,ad=True,type="mesh",path=True)
        jointBindArray = []
        meshTransform = []
        for mesh in meshs:
            meshTransform.append(cmds.listRelatives(mesh,parent=True,path=True)[0])
        meshTransform = list(set(meshTransform))
        for transform in meshTransform:
            skinCluster = pm.mel.eval('findRelatedSkinCluster '+transform)
            if skinCluster:
                jointBindArray.extend(cmds.skinCluster(skinCluster,query=True,inf=True))        
        jointBindArray.extend(["L_Arm_ShoulderPadSHJnt","R_Arm_ShoulderPadSHJnt"])
        jointBindArray = list(set(jointBindArray))
        jointDelete = []
        for joint in joints:
            print(joint)
            if joint not in jointBindArray:
                allChildren = cmds.listRelatives(joint,ad=True)
                if allChildren:
                    flag = 0
                    for children in allChildren:
                        if children in jointBindArray:
                            flag = 1
                    if flag == 0:
                        jointDelete.append(joint)
                else:
                    jointDelete.append(joint)
        cmds.delete(jointDelete)
        for nodeDelete in exportNode:
            if nodeDelete != node:
                cmds.delete(nodeDelete)
        cmds.file(rename=folderExport+'/'+(node.replace("_export",""))+'.ma')
        cmds.file(save=True,force=True,options="v=0;",typ="mayaAscii")
        


    
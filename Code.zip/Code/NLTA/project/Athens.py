import json,os,general,NLTA_setup,A_skinning
import pymel.core as pm
import maya.cmds as cmds
import xml.dom.minidom as xd
import A_skinning,general,NLTA_setup

def createLayout(*arr):
    name = "Athens"
    cmds.window(name+"Window", title = name+" tool")
    cmds.rowColumnLayout(numberOfColumns=4)
    cmds.button(label="Exports",width=100,c=ExportFiles)
    cmds.button(label="Modify Scene",width=100,c=ModifyScene)
    cmds.button(label="Modify Orient",width=100,c=ModifyOrient)
    cmds.button(label="Repath",width=100,c=Repath)
    cmds.setParent("..")
    cmds.showWindow()

def Repath(*arr):
    general.Repath("C:\\Users\\an.nguyen_g\\Documents\\maya\\projects\\Athens")

def ClearPlugin(*arr):
    listUnknownPlugin = pm.unknownPlugin(q=True, l=True)
    if listUnknownPlugin:
        for i in listUnknownPlugin:
            try:
                pm.unknownPlugin(i, r=True)
                print("Delete Unknown Plugin: "+i)
            except RuntimeError:
                continue
    else:
        print("Scene does not  contain any custom Unknown Plugin nodes")

def ExportFiles(*arr):
    sceneName = pm.sceneName()
    scenePath = os.path.dirname(pm.sceneName())
    characterName = (sceneName.split("/")[-1]).split(".")[0]
    fbxLink = scenePath+"/"+characterName+".fbx"
    """-------"""
    #sendLink = scenePath+"/"+characterName+"_skin.ma"
    
    #Export Send File
    A_skinning.fixMaxInfluent(4)
    A_skinning.setInfluence(4)
    #cmds.file(rename=sendLink)
    #cmds.file(save=True, force=True,type="mayaBinary")
    #Export FBX File
    cmds.file(sceneName, open=True, force=True)    
    joints = cmds.ls(type="joint")[::-1]
    for joint in joints:
        newName = joint.replace("Bind_","mixamorig:")
        cmds.rename(joint,newName)
    meshs = list(set(cmds.listRelatives(cmds.ls(type="mesh"),parent=True)))
    cmds.select(cmds.ls(type="joint"))
    cmds.select(meshs,add=True)    
    general.ExportFbx(fbxLink)    

    cmds.file(sceneName, open=True, force=True)

def GetAddJoints(*arr):
    DoneJoints = cmds.sets("Bind_Joint_SelectSet",query=True)
    AllJoints = cmds.listRelatives("Bind_Joint_GRP",ad=True,type="joint")[::-1]
    AddJoints = []
    for joint in AllJoints:
        ArrayTemp = [] 
        if (joint not in DoneJoints) and joint.startswith("Bind"):
            ArrayTemp.append(joint)
            parent = cmds.listRelatives(joint,parent=True,type="joint")         
            if parent:
                ArrayTemp.append(parent[0])
            AddJoints.append(ArrayTemp)
    return(AddJoints)

def CreateControl(jointArray,*arr):
    #Parent
    MixamoPattern = {
        "Bind_Hips":{"control":"Pelvis_CTRL"},
        "Bind_Spine":{"control":"Spine_CTRL"},
        "Bind_Spine1":{"control":"Spine1_CTRL"},
        "Bind_Spine2":{"control":"Spine2_CTRL"},
        "Bind_RightShoulder":{"control":"RightShoulder_CTRL"},
        "Bind_LeftShoulder":{"control":"LeftShoulder_CTRL"},
        "Bind_Neck":{"control":"Bind_Neck"},
        "Bind_Head":{"control":"Head_CTRL"},
        "Bind_RightHandThumb1":{"control":"RightHandThumb1_CTRL"},
        "Bind_RightHandThumb2":{"control":"RightHandThumb2_CTRL"},
        "Bind_RightHandThumb3":{"control":"RightHandThumb3_CTRL"},
        "Bind_RightHandIndex1":{"control":"RightHandIndex1_CTRL"},
        "Bind_RightHandIndex2":{"control":"RightHandIndex2_CTRL"},
        "Bind_RightHandIndex3":{"control":"RightHandIndex3_CTRL"},
        "Bind_RightHandMiddle1":{"control":"RightHandMiddle1_CTRL"},
        "Bind_RightHandMiddle2":{"control":"RightHandMiddle2_CTRL"},
        "Bind_RightHandMiddle3":{"control":"RightHandMiddle3_CTRL"},
        "Bind_LeftHandThumb1":{"control":"LeftHandThumb1_CTRL"},
        "Bind_LeftHandThumb2":{"control":"LeftHandThumb2_CTRL"},
        "Bind_LeftHandThumb3":{"control":"LeftHandThumb3_CTRL"},
        "Bind_LeftHandIndex1":{"control":"LeftHandIndex1_CTRL"},
        "Bind_LeftHandIndex2":{"control":"LeftHandIndex2_CTRL"},
        "Bind_LeftHandIndex3":{"control":"LeftHandIndex3_CTRL"},
        "Bind_LeftHandMiddle1":{"control":"LeftHandMiddle1_CTRL"},
        "Bind_LeftHandMiddle2":{"control":"LeftHandMiddle2_CTRL"},
        "Bind_LeftHandMiddle3":{"control":"LeftHandMiddle3_CTRL"},
        #ARM
        "Bind_RightArm":{"parent":"RightShoulder_CTRL"},
        "Bind_RightForeArm":{"parent":"RightShoulder_CTRL"},
        "Bind_RightHand":{"parent":"RightShoulder_CTRL"},
        "Bind_LeftArm":{"parent":"LeftShoulder_CTRL"},
        "Bind_LeftForeArm":{"parent":"LeftShoulder_CTRL"},
        "Bind_LeftHand":{"parent":"LeftShoulder_CTRL"},
        #LEG
        "Bind_RightUpLeg":{"parent":"Root_CTRL"},
        "Bind_RightLeg":{"parent":"Root_CTRL"},
        "Bind_RightFoot":{"parent":"Root_CTRL"},
        "Bind_RightToeBase":{"parent":"Root_CTRL"},
        "Bind_RightToe_End":{"parent":"Root_CTRL"},
        "Bind_LeftUpLeg":{"parent":"Root_CTRL"},
        "Bind_LeftLeg":{"parent":"Root_CTRL"},
        "Bind_LeftFoot":{"parent":"Root_CTRL"},
        "Bind_LeftToeBase":{"parent":"Root_CTRL"},
        "Bind_LeftToe_End":{"parent":"Root_CTRL"},
    }
    #CreateControl
    joint = jointArray[0]
    translation = cmds.xform(joint,query=True,t=True,worldSpace=True)
    rotation =  cmds.xform(joint,query=True,ro=True,worldSpace=True)    
    groupZero = cmds.group(em=True, name=joint+'_zero_Grp')
    groupSDK = cmds.group(em=True, name=joint+'_SDK_Grp')
    curve = cmds.circle(radius=1, name=joint+'_CTRL')[0]    
    cmds.scale(.1,.1,.1,curve)
    cmds.rotate(90,0,0,curve)
    cmds.makeIdentity(curve, apply=True,rotate=True,scale=True)
    cmds.parent(curve,groupSDK)
    cmds.parent(groupSDK,groupZero)

    #Solve Parent
    if jointArray[1]:
        parentJointName = jointArray[1]     
        if parentJointName in MixamoPattern:
            if "control" in MixamoPattern[parentJointName]:
                contain = MixamoPattern[parentJointName]["control"]
                constraint = None
            elif "parent" in MixamoPattern[parentJointName]:
                contain = MixamoPattern[parentJointName]["parent"]
                constraint = parentJointName
            if constraint:
                groupConstraint =  cmds.group(em=True, name=joint+'_constraint_Grp')
                cmds.parent(groupZero,groupConstraint)
                cmds.xform(groupConstraint,t=translation,worldSpace=True)
                cmds.xform(groupConstraint,ro=rotation,worldSpace=True)
                cmds.parent(groupConstraint,contain)
                cmds.parentConstraint(parentJointName,groupConstraint, maintainOffset=True)
            else:
                cmds.xform(groupZero,t=translation,worldSpace=True)
                cmds.xform(groupZero,ro=rotation,worldSpace=True)
                cmds.parent(groupZero,contain)
        else:
            parentControlName =  jointArray[1]+"_CTRL"
            if cmds.objExists(parentControlName):
                cmds.xform(groupZero,t=translation,worldSpace=True)
                cmds.xform(groupZero,ro=rotation,worldSpace=True)
                cmds.parent(groupZero,parentControlName)        
    else:
        cmds.xform(groupZero,t=translation,worldSpace=True)
        cmds.xform(groupZero,ro=rotation,worldSpace=True)
    cmds.parentConstraint(curve,joint)
    cmds.sets(curve, add="Controls_SelectSet")
    cmds.sets(joint, add="Bind_Joint_SelectSet")

def ModifyOrient(*arr):
    #Create group "LeftFoot_IK_CTRL_offset_GRP"
    #Match offset group vafo "LeftFoot_IK_CTRL_Reorient_GRP"
    #transfer attr from LeftFoot_IK_CTRL_Reorient_GRP into LeftFoot_IK_CTRL_offset_GRP

    for side in ["Left","Right"]:
        control = side + "Foot_IK_CTRL"
        groupParent = side+"Foot_IK_CTRL_Reorient_GRP"
        groupOffset = cmds.group(em=True, name=side+'Foot_IK_CTRL_offset_Grp')
        animGroup = side+"_Toe_IK_AnimData_GRP"
        cmds.matchTransform(groupOffset,groupParent)
        cmds.parent(groupOffset,control)
        cmds.parent(animGroup,groupOffset)        
        for attr in ["tx","ty","tz","rx","ry","rz"]:
            cmds.setAttr(groupParent+"."+attr, lock=False)
            cmds.setAttr(groupOffset+"."+attr,cmds.getAttr(groupParent+"."+attr))
            cmds.setAttr(groupParent+"."+attr,0)

def ModifyScene(*arr):
    ClearPlugin()
    AddJoints = GetAddJoints()
    for joint in AddJoints:
        CreateControl(joint)
    cmds.parent("Pelvis_CTRL_POS_GRP","Root_CTRL")
    cmds.parent("AnimData_Hips","AnimData_Root")
    cmds.pointConstraint("Root_CTRL","Bind_Root", maintainOffset=True)
    cmds.pointConstraint("Pelvis_CTRL","Bind_Hips", maintainOffset=True)

    for t in ["tx","ty","tz"]:
        cmds.setAttr("Pelvis_CTRL."+t,k=True)
        cmds.setAttr("Pelvis_CTRL."+t,lock=False)
    A_skinning.fixMaxInfluent(4)
    A_skinning.setInfluence(4)
    NLTA_setup.importCurveShapeNew()
    ModifyOrient()
    general.runPostScript()
    general.ClearScene()


    
    #Add control to Controls_SelectSet
    #Add bind joint to Bind_Joint_SelectSet
    #Change control Name to *Bind_Tail_CTRL
    #Two group Bind_*_zero_Grp - > Bind_*_SDK_Grp
    #Delete layer
    #Check set max infulence to 4

import json,os,general,NLTA_setup,A_skinning
import pymel.core as pm
import maya.cmds as cmds
import xml.dom.minidom as xd

def createLayout(*arr):
	name = "MSV"
	cmds.window(name+"Window", title = name+" tool")

	cmds.rowColumnLayout(numberOfColumns=4)
	cmds.button(label="Merge OBJ",width=100,c=mergeObj)
	cmds.button(label="Merge Center",width=100,c=mergeCenter)
	cmds.button(label="Delete Keyframe",width=100,c=deleteKeyframe)
	cmds.button(label="Copy Keyframe",width=100,c=copyKeyframe)
	cmds.button(label="Past Keyframe",width=100,c=pastKeyframe)
	cmds.button(label="Match Position",width=100,c=matchPosition)
	cmds.button(label="Create camera",width=100,c=createCamera)
	cmds.button(label="Show Texture",width=100,c=showTexture)
	cmds.setParent("..")
	cmds.showWindow()

def mergeCenter(*arr):
	print("")

def deleteKeyframe(*arr):
	pm.mel.eval("timeSliderClearKey;")

def copyKeyframe(*arr):
	pm.mel.eval("timeSliderCopyKey;")

def pastKeyframe(*arr):
	pm.mel.eval("timeSliderPasteKey false;")

def matchPosition(*arr):
	pm.mel.eval("MatchTransform;")

def hideColision(*arr):
	print("")

def showColision(*arr):
	print("")

def showTexture(*arr):
	pm.mel.eval("""
	{
	$objName = `ls -sl`;
	string $myShapeNode[] = `listRelatives -children -shapes $objName`;
	string $mySGs[] = `listConnections -type shadingEngine $myShapeNode[0]`;
	string $surfaceShader[] = `listConnections ($mySGs[0] + ".surfaceShader")`;
	setAttr ($surfaceShader[0]+".ambientColor") -type double3 8 8 8 ;
	$textures =`substitute "lambert" $surfaceShader[0] "textureFile"`;
	select($textures+".fileTextureName");
	DisplayShadedAndTextured;
	AttributeEditor;
	}
	""")
	

def createFlat(*arr):
	print("")

def createPoint(*arr):
	print("")

def createLine(*arr):
	print("")

def createCamera(*arr):
	cameraName = pm.mel.eval('camera -centerOfInterest 5 -focalLength 35 -lensSqueezeRatio 1 -cameraScale 1 -horizontalFilmAperture 1.41732 -horizontalFilmOffset 0 -verticalFilmAperture 0.94488 -verticalFilmOffset 0 -filmFit Fill -overscan 1 -motionBlur 0 -shutterAngle 144 -nearClipPlane 0.1 -farClipPlane 10000 -orthographic 0 -orthographicWidth 30 -panZoomEnabled 0 -horizontalPan 0 -verticalPan 0 -zoom 1; objectMoveCommand; cameraMakeNode 2 "";') 
	cmds.setAttr(cameraName+".translateX",0)
	cmds.setAttr(cameraName+".translateY",1800)
	cmds.setAttr(cameraName+".translateZ",2000)
	cmds.setAttr(cameraName+"_aim.translateX",0)
	cmds.setAttr(cameraName+"_aim.translateY",300)
	cmds.setAttr(cameraName+"_aim.translateZ",0)
	locator = pm.mel.eval("spaceLocator -p 0 0 0;")[0]
	cmds.parent(cameraName+"_group",locator)
	minTime = cmds.playbackOptions(q=True, min=True)
	maxTime = cmds.playbackOptions(q=True, max=True)
	cmds.currentTime(minTime)
	cmds.setAttr(locator+".ry",0)
	pm.mel.eval('setKeyframe "'+locator+'.ry";')
	cmds.currentTime(maxTime)	
	cmds.setAttr(locator+".ry",-360)
	pm.mel.eval('setKeyframe "'+locator+'.ry";')

def mergeObj(*arr):
	url = cmds.fileDialog2(fileMode=2)
	if url:
		folderParent = ("/".join(url[0].split("/")[0:-1]))
		folderMerge =  folderParent+"/merge"
		folderOrigin = folderParent+"/origin"
		folderSave = folderParent+"/saves"
		folderExport = folderParent+"/export"

		if os.path.exists(folderOrigin):
			for folderContent in ["merge","saves","export"]:
				folderContentLink =   folderParent+"/"+folderContent             
				if not os.path.exists(folderContentLink):
					os.makedirs(folderContentLink)

			objs = cmds.getFileList(folder=folderOrigin)
			for obj in objs:
				if obj.endswith(".obj"):
					defaults = ['UI', 'shared']
					namespaces = (ns for ns in pm.namespaceInfo(lon=True) if ns not in defaults)
					for ns in namespaces:
						cmds.namespace( removeNamespace = ":"+ns)
					fileName = obj.split(".")[0]
					nameSpace = fileName.replace("-","_")
					fileUrl = folderOrigin+"/"+obj
					pm.mel.eval('file -import -type "OBJ"  -ignoreVersion -ra true -mergeNamespacesOnClash false -namespace "'+nameSpace+'" -options "mo=1"  -pr  -importFrameRate true  -importTimeRange "override" "'+fileUrl+'";')                
					cmds.select(nameSpace+":Mesh.vtx[*]")
					pm.mel.eval('polyMergeVertex  -d 0.01 -am 1 -ch 1 '+cmds.ls(selection=True)[0]+';')
					cmds.rename(nameSpace+":Mesh","Mesh")
					pm.mel.eval('file -force -options "groups=1;ptgroups=1;materials=1;smoothing=1;normals=1" -typ "OBJexport" -pr -es "'+folderMerge+'/'+obj+'.obj";')
					cmds.delete("Mesh")
			mtls = cmds.getFileList(folder=folderMerge) 
			for mtl in mtls:
				if mtl.endswith(".mtl"):
					cmds.sysFile(folderMerge+"/"+mtl,delete=True)
			pngs = cmds.getFileList(folder=folderOrigin)
			for png in pngs:
				if png.endswith(".png"):           
					fromFile = folderOrigin+"/"+png
					toFile = folderMerge+"/"+png
					cmds.sysFile(fromFile,copy=toFile)


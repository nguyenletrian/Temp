import json,os,general,NLTA_setup,A_skinning
import pymel.core as pm
import maya.cmds as cmds
import xml.dom.minidom as xd

#preFix = "Rig_Imp_"
def createLayout(*arr):
	name = "RGI"
	cmds.window(name+"Window", title = name+" tool")

	cmds.rowColumnLayout(numberOfColumns=1)
	cmds.optionMenu("characterType",label='Character Type')
	cmds.menuItem(label="Musc")
	cmds.menuItem(label="Imp")
	cmds.menuItem(label="Fem")
	cmds.menuItem(label="Male")
	cmds.menuItem(label="WereWolf")
	cmds.menuItem(label="Giant")
	cmds.setParent("..")

	cmds.rowColumnLayout(numberOfColumns=1)
	cmds.textField(text="Space Num",editable=False)
	cmds.scrollField("spaceNumText",wordWrap=True,width=400,height=50,fns=8)
	cmds.textField(text="Space Float",editable=False)
	cmds.scrollField("spaceFloatText",wordWrap=True,width=400,height=50,fns=8)
	cmds.setParent("..")

	cmds.rowColumnLayout(numberOfColumns=4)
	cmds.button(label="Quick Import",width=100,c=quickImport)
	cmds.button(label="Export",width=100,c=exportData)
	cmds.button(label="Back Origin File",width=100,c = backOriginFile)
	cmds.button(label="Complete Scene",width=100,c = completeScene)
	cmds.setParent("..")

	cmds.showWindow()


def importData(url,*arr):
	dataTemp = general.readJsonFile(url)
	cmds.optionMenu("characterType",edit=True,value=dataTemp["characterType"]),
	cmds.scrollField("spaceNumText",edit=True,text=dataTemp["spaceNumText"]),
	cmds.scrollField("spaceFloatText",edit=True,text=dataTemp["spaceFloatText"])

def exportData(*arr):
	url = os.path.dirname(pm.sceneName())+"/"+os.path.basename(pm.sceneName()).split(".")[0]+"_project.txt"
	data = {
		"characterType":cmds.optionMenu("characterType",q=True,value=True),
		"spaceNumText":cmds.scrollField("spaceNumText",query=True,text=True),
		"spaceFloatText":cmds.scrollField("spaceFloatText",query=True,text=True)
	}
	general.writeJsonFile(url,data)

def quickImport(*arr):
	url = os.path.dirname(pm.sceneName())+"/"+os.path.basename(pm.sceneName()).split(".")[0]+"_project.txt" 
	importData(url)

			
def connect(*arr):	
	cmds.select(clear=True)
	preFix = "Rig_"+ cmds.optionMenu("characterType",q=True,value=True)+"_"
	group_content = cmds.group(n="connectGroupContent",em=True)
	for a in cmds.listRelatives("DeformationSystem",ad=True,pa=True):
		setup.connectSingle({"content":group_content,"source":a,"dest":preFix + a})		
	cmds.parent(group_content,cmds.listRelatives("DeformationSystem",parent=True)[0])
	pm.mel.eval("connectAttr -f MainExtra1.scale connectGroupContent.scale;")

def restoreASName (*arr):
	for a in cmds.listRelatives("DeformationSystem",ad=True,pa=True):
		cmds.rename(a,cmds.getAttr(a+".originName"))

def renameASJoint(*arr):
	preFix = "Rig_"+ cmds.optionMenu("characterType",q=True,value=True)+"_"
	if cmds.objExists(preFix+"DeformationSystem"):
		cmds.delete(preFix+"DeformationSystem")
	for a in cmds.listRelatives("DeformationSystem",ad=True,pa=True):
		if preFix not in a:
			if cmds.attributeQuery("originName",node=a,ex=True) != True:
				pm.mel.eval('addAttr -ln "originName"  -dt "string"  '+a+';') 
			pm.mel.eval('setAttr -type "string" '+a+'.originName "'+a+'";')  
			cmds.rename(a,preFix+a)

def createJointBind(*arr):
	preFix = "Rig_"+ cmds.optionMenu("characterType",q=True,value=True)+"_"
	renameASJoint()
	A_skinning.exportAllSkin()
	pm.mel.eval('select -r DeformationSystem;')
	pm.mel.eval('duplicate -rr;')
	pm.mel.eval('parent -w;')
	pm.mel.eval('rename "DeformationSystem1" "'+preFix+'DeformationSystem";')
	restoreASName()

def createSpace(*arr):
	spaceText = cmds.scrollField("spaceNumText",query=True,text=True)
	if spaceText!="":
		spaceText = spaceText.strip().split("\n")
		for a in spaceText:
			dataTemp = a.split(",")
			constraintName = NLTA_setup.spaceNum(dataTemp)
			cmds.parent(constraintName,"connectGroupContent")

	spaceText = cmds.scrollField("spaceFloatText",query=True,text=True)
	if spaceText!="":
		spaceText = spaceText.strip().split("\n")
		for a in spaceText:
			dataTemp = a.split(",")
			constraintName = NLTA_setup.spaceFloat(dataTemp)
			cmds.parent(constraintName,"connectGroupContent")

def backOriginFile(*arr):
	preFix = "Rig_"+ cmds.optionMenu("characterType",q=True,value=True)+"_"
	A_skinning.ExportAllSkin()	
	A_skinning.clearSkin()
	for a in ["connectGroupContent",preFix+"DeformationSystem"]:
		if cmds.objExists(a):
			cmds.delete(a)
	renameASJoint()
	cmds.select(clear=True)
	A_skinning.importAllSkin()
	restoreASName()

	cmds.setAttr("DeformationSystem.v",1)
	#A_skinning.maintainOff(1)

def completeScene(*arr):
	preFix = "Rig_"+ cmds.optionMenu("characterType",q=True,value=True)+"_"
	createJointBind()
	A_skinning.importAllSkin()
	connect()
	createSpace()
	cmds.setAttr("DeformationSystem.v",0)
	NLTA_setup.modifyLayer()
	pm.editDisplayLayerMembers("JointBindLayer",preFix+'DeformationSystem', noRecurse=True)
	A_skinning.maintainOff(1)
	A_skinning.fixMaxInfluentAll(4)
	A_skinning.maintainOff(4)
	for a in cmds.listRelatives(preFix+"DeformationSystem",ad=True,pa=True):
		pm.mel.eval('setAttr "'+a+'.segmentScaleCompensate" 0;')



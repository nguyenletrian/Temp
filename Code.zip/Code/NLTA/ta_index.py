import sys,os
import maya.cmds as cmds
import importlib
cmds.selectPref( trackSelectionOrder=1 )

def run(*arr):
    li = {}
    user = os.environ.get("USERNAME")
    li["sever"] = "C:/Users/"+user+"/Documents/maya/scripts/NLTA/"
    data = ["Project","function","user","collection","collection/icon","collection/json"]
    for a in data:
        link  = li["sever"] + a + "/"
        if link not in sys.path:
            sys.path.append(link)
    import createForm
    if int(cmds.about(version=True)) < 2022:
        reload(createForm)
    else:
        importlib.reload(createForm)
    createForm.makeForm(li)
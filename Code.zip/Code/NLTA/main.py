import maya.cmds as cmds

def GetTexturePath(*arr):
    obj = cmds.ls(selection=True)[0]
    meshs = cmds.listRelatives(obj,ad=True,type='mesh')
    for mesh in meshs:
        shadings = cmds.listConnections(mesh, type='shadingEngine')
        for shading in shadings:
            materials = cmds.ls(cmds.listConnections(shading), materials=True)
            for material in materials:
                files = cmds.listConnections(material, type='file')
                for file_ in files:
                    print(cmds.getAttr(file_ + '.fileTextureName'))

def GetFaceShading(obj,*arr):
    dataReturn = {}
    faces = cmds.ls(obj+'.f[*]', flatten=True)
    #for face in faces:
        #shading = 
        
    print(faces)
    """
    selected_faces = cmds.ls(selection=True, flatten=True)
    # Get the shading groups connected to the selected faces
    shading_groups = cmds.listSets(object=selected_faces[0])
    
    # Get the materials connected to the shading groups
    materials = cmds.ls(cmds.listConnections(shading_groups), materials=True)
    
    print("Selected Faces:", selected_faces)
    print("Shading Groups:", shading_groups)
    print("Materials:", materials)
    """
    
def ConvertPhongToStandard():
    materials = cmds.ls(materials=True)
    for material in materials:
        if cmds.objectType(material) == 'phong':
            standard = cmds.shadingNode('aiStandardSurface',asShader=True,name=material+'_standardSurface')
            color = cmds.getAttr(material+'.color')
            cmds.setAttr(standard+'.baseColor',color[0][0],color[0][1],color[0][2],type='double3')
            #destinationPlugs = cmds.listConnections(cmds.ls(selection=True),d=False,p=True,scn=True)
            #sourcePlugs = cmds.listConnections(cmds.ls(selection=True),s=False,p=True,scn=True)
            allPlugs = cmds.listConnections(material,c=True,p=True,scn=True)
            for i in range(0,len(allPlugs),2):
                plugArray = ((allPlugs[i]).split("."))[1:]
                plug = ".".join(plugArray)
                if plug == 'color':
                    standardPlug = standard+".baseColor"
                else:                    
                    standardPlug = standard+"."+plug
                try:
                    cmds.connectAttr(standardPlug,allPlugs[i+1],force=True)
                except:pass                
                try:
                    cmds.connectAttr(allPlugs[i+1],standardPlug,force=True)
                except:pass                
            cmds.delete(material)

def ReplaceTextureType(old,new):#ReplaceTextureType('.jpg','.png')
    files = cmds.ls(type='file')
    for file_ in files:
        oldFile = cmds.getAttr(file_ + '.fileTextureName')
        newFile = oldFile.replace(old,new)
        cmds.setAttr(file_+'.fileTextureName',newFile,type='string')


#print(cmds.objectType(cmds.ls(selection=True)[0]))


def NLTA_Script():
    currentTexture = cmds.getAttr('myFileNode.fileTextureName')
    currentNumber = currentTexture.split(".")[0]
    currentNumber = currentNumber.split("/")[-1]    
    currentValue = cmds.getAttr("nurbsCircle1.sssss")
    print(currentTexture)
    print(currentValue)
    newPath = currentTexture.replace(str(currentNumber),str(currentValue))
    print(newPath)
    cmds.setAttr('file4.fileTextureName',newPath,type='string')
    
def ClearScriptJob(*arr):
    jobs = cmds.scriptJob(listJobs=True)
    for job in jobs:
        jobArray = job.split(":") 
        jobNumber = int(jobArray[0])
        jobContent = jobArray[1]
        if 'NLTA' in jobContent:
            cmds.scriptJob(kill=jobNumber, force=True)
ClearScriptJob()
#cmds.scriptJob(event=["timeChanged",NLTA_Script])
#cmds.scriptJob(conditionTrue=["playingBack",NLTA_Script])
cmds.scriptJob(attributeChange=["nurbsCircle1.sssss",NLTA_Script])



script_content = """python()"""

script_node = cmds.scriptNode(
    name='sceneOpenScriptNode',
    scriptType=2,  # 2 means the script runs when the scene is opened
    beforeScript=script_content
)


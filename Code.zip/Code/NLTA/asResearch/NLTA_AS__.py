#From Sparx* Rigging: Jordan Sukaria, Nguyen Quang Trieu, Nguyen Le Tri an
import os, sys , json , math, random, general
from maya import mel
import maya.cmds as cmds
import pymel.all as pm
import math
from functools import partial

requireTab = "NLTA_AS"
variableTemp = {}
toolSetting = {
    "pattern":[
        "biped.ma","bipedBendy.ma","bipedGame.ma","bird.ma","bug.ma","cat.ma","dinosaur.ma","dragon.ma","fish.ma","gorilla.ma","horse.ma","metahuman.ma","previs.ma"
    ],
    "patternInput":{
        ###BIPED
        "biped":{
            "order":[
                "Root","Chest","Neck","Head","HeadEnd","Scapula","Shoulder","Elbow","Wrist",    
                "ThumbFinger1","IndexFinger1","MiddleFinger1","RingFinger1","PinkyFinger1",
                "Hip","Knee","Ankle","Toes","ToesEnd","FootSideOuter","FootSideInner","Heel"
            ],
            "vertex":[
                "ToesEnd","FootSideOuter","FootSideInner","Heel"
            ],
            "jointBetween":[
                ["Root","Chest","Spine"],
                ["Neck","Head","Neck"]
            ],           
            "twistBetween":[                
                ["Shoulder","Elbow"],
                ["Elbow","Wrist"],
                ["Hip","Knee"],
                ["Knee","Ankle"]
            ],
            "ikControl":{
                "Ankle":"IKLeg",
                "Wrist":"IKArm"
            },
            "poleControl":{
                "Knee":"PoleLeg",
                "Elbow":"PoleArm"
            },
            "sdkFinger":[
                "FKThumbFinger2_R","FKThumbFinger3_R",
                "FKIndexFinger1_R","FKIndexFinger2_R","FKIndexFinger3_R",
                "FKMiddleFinger1_R","FKMiddleFinger2_R","FKMiddleFinger3_R",
                "FKRingFinger1_R","FKRingFinger2_R","FKRingFinger3_R",
                "FKPinkyFinger1_R","FKPinkyFinger2_R","FKPinkyFinger3_R",
                
                "FKThumbFinger2_L","FKThumbFinger3_L",
                "FKIndexFinger1_L","FKIndexFinger2_L","FKIndexFinger3_L",
                "FKMiddleFinger1_L","FKMiddleFinger2_L","FKMiddleFinger3_L",
                "FKRingFinger1_L","FKRingFinger2_L","FKRingFinger3_L",
                "FKPinkyFinger1_L","FKPinkyFinger2_L","FKPinkyFinger3_L",       
            ],
            "sdkSpread":[
                "FKIndexFinger1_R","FKRingFinger1_R","FKPinkyFinger1_R",
                "FKIndexFinger1_L","FKRingFinger1_L","FKPinkyFinger1_L"
            ],
            "attribute":{
                "global":["Spine","spine","Chest","Neck","Scapula","Shoulder"],
                "ikLocal":["Wrist"],
                "worldOrientForward":["Ankle"],
                "control":["Head","HeadEnd"],
                "bendyJoints":["Hip","Shoulder","Elbow"],
                "freeOrient":["Finger"]
            }
        },
        
        ###CAT
        "cat":{
            "order":[
                "Root","Chest","Neck","Head","HeadEnd","Scapula","Shoulder","Elbow","Wrist",
                "Fingers1","Fingers2","frontFootSideOuter","frontFootSideInner","frontHeel",
                "IndexFinger1","MiddleFinger1","RingFinger1","PinkyFinger1",
                "Hip","Knee","Ankle","Toes1","Toes2","backFootSideOuter","backFootSideInner","backHeel",
                "IndexToe1","MiddleToe1","RingToe1","PinkyToe1",
                "Tail0","Tail6",
            ],
            "vertex":[
                "Fingers2","frontFootSideOuter","frontFootSideInner","frontHeel",
                "Toes2","backFootSideOuter","backFootSideInner","backHeel",   
            ],
            "jointBetween":[
                ["Root","Chest","Spine"],
                ["Neck","Head","Neck"],
                ["Tail0","Tail6","Tail"]
            ],           
            "twistBetween":[                
                ["Shoulder","Elbow"],
                ["Elbow","Wrist"],
                ["Hip","Knee"],
                ["Knee","Ankle"]
            ],
            "ikControl":{
                "Fingers1":"IKLegFront",
                "Toes1":"IKLegBack"
            },
            "poleControl":{
                "Knee":"PoleLegBack",
                "Elbow":"PoleLegFront"
            },
            "sdkFinger":[
                "FKIndexFinger1_R","FKIndexFinger2_R","FKIndexFinger3_R",
                "FKMiddleFinger1_R","FKMiddleFinger2_R","FKMiddleFinger3_R",
                "FKRingFinger1_R","FKRingFinger2_R","FKRingFinger3_R",
                "FKPinkyFinger1_R","FKPinkyFinger2_R","FKPinkyFinger3_R",

                "FKIndexFinger1_L","FKIndexFinger2_L","FKIndexFinger3_L",
                "FKMiddleFinger1_L","FKMiddleFinger2_L","FKMiddleFinger3_L",
                "FKRingFinger1_L","FKRingFinger2_L","FKRingFinger3_L",
                "FKPinkyFinger1_L","FKPinkyFinger2_L","FKPinkyFinger3_L",
                
                "FKIndexToe1_R","FKIndexToe2_R","FKIndexToe3_R",
                "FKMiddleToe1_R","FKMiddleToe2_R","FKMiddleToe3_R",
                "FKRingToe1_R","FKRingToe2_R","FKRingToe3_R",
                "FKPinkyToe1_R","FKPinkyToe2_R","FKPinkyToe3_R",

                "FKIndexToe1_L","FKIndexToe2_L","FKIndexToe3_L",
                "FKMiddleToe1_L","FKMiddleToe2_L","FKMiddleToe3_L",
                "FKRingToe1_L","FKRingToe2_L","FKRingToe3_L",
                "FKPinkyToe1_L","FKPinkyToe2_L","FKPinkyToe3_L",      
            ],
            "sdkSpread":[
                "FKIndexFinger1_R","FKRingFinger1_R","FKPinkyFinger1_R",
                "FKIndexFinger1_L","FKRingFinger1_L","FKPinkyFinger1_L",
                "FKIndexToe1_R","FKRingToe1_R","FKPinkyToe1_R",
                "FKIndexToe1_L","FKRingToe1_L","FKPinkyToe1_L",
            ],
            "attribute":{
                "global":["Spine","spine","Chest","Neck","Scapula","Shoulder"],
                "worldOrientForward":["Fingers1","Toes1"],
                "control":["Head","HeadEnd"],
                "bendyJoints":["Hip","Shoulder","Elbow"],
                "orientJoint":["Ankle"]
            }
        }
        
    },
    "patternData":{
        "order":[],
        "pair":[],
        "prefix":[],
        "maxParent":[],
        "match":{},
        "exceptJoint":[],
        "as_dict":{},
        "max_dict":{},
        "twist_dict":{},
        "constraint_pair":[],
        "connectScale":False,
        "vertexPosition":{}
    }
}
dataSession = {}

def createLayout(per,lib,*arr):
    """
    #Import Advance Sleketon
    if not ("%s/studio/python"%os.getenv("VSTOOLS")) in sys.path:
        sys.path.append("%s/studio/python"%os.getenv("VSTOOLS"))
    sys.path.append("C:/vsTools2/library/python_module/AdvancedSkeleton5/")
    from robust import svn_kit
    svn_kit.addsitedir('python_module/AdvancedSkeleton5')
    
    AS_path = "C:/vsTools2/library/python_module/AdvancedSkeleton5/"
    AS_path = os.path.join(os.path.join(os.environ["VSTOOLS"], 'library'), 'python_module/AdvancedSkeleton5').replace("\\", "/")
    
    if not AS_path in os.environ["MAYA_SCRIPT_PATH"]:
        #os.environ["MAYA_SCRIPT_PATH"] += ";{}".format(AS_path)
    """
    #CREATE DEFAULT LAYOUT
    if per == "NLTA_AS":
        cmds.rowColumnLayout(numberOfColumns=2,parent="NLTA_AS")
        cmds.optionMenu("patternAS",label='Pattern',width=320,cc=changePattern)
        for a in toolSetting["pattern"]:
            name = a.split(".")[0]
            cmds.menuItem(label=name)

        cmds.button(label="Load",width=70,c = changePattern)
        cmds.setParent("..")
        cmds.setParent("..")

        cmds.rowColumnLayout(numberOfColumns=3,parent="NLTA_AS")
        cmds.textField(text="Side",width=43,editable=False)
        cmds.textField("prefixRight",pht="right",width=174)
        cmds.textField("prefixLeft",pht="left",width=174)
        cmds.setParent("..")

        cmds.scrollLayout(horizontalScrollBarThickness=16,verticalScrollBarThickness=16,height=603,width=390,parent="NLTA_AS")#open scroll
     
        cmds.frameLayout(label='Script',cl=True,cll=True,width=370)#open frame
        cmds.rowColumnLayout(numberOfColumns=1,width=390)#open right

        cmds.rowColumnLayout(numberOfColumns=2)
        cmds.textField(text="Before match",width=338,editable=False)
        cmds.button(label="+",width=30,c = beforeMatchScriptLink)
        cmds.setParent("..") 
        cmds.rowColumnLayout(numberOfColumns=1)
        cmds.scrollField("beforeMatchScript",wordWrap=True,width=370,height=50,fns=8)
        cmds.setParent("..")
        
        cmds.rowColumnLayout(numberOfColumns=2)
        cmds.textField(text="After match",width=338,editable=False)
        cmds.button(label="+",width=30,c = afterMatchScriptLink)
        cmds.setParent("..") 
        cmds.rowColumnLayout(numberOfColumns=1)
        cmds.scrollField("afterMatchScript",wordWrap=True,width=370,height=50,fns=8)
        cmds.setParent("..")
        
        cmds.rowColumnLayout(numberOfColumns=2)
        cmds.textField(text="Before build",width=338,editable=False)
        cmds.button(label="+",width=30,c = beforeBuildScriptLink)
        cmds.setParent("..") 
        cmds.rowColumnLayout(numberOfColumns=1)
        cmds.scrollField("beforeBuildScript",wordWrap=True,width=370,height=50,fns=8)
        cmds.setParent("..")
        
        cmds.rowColumnLayout(numberOfColumns=2)
        cmds.textField(text="After build",width=338,editable=False)
        cmds.button(label="+",width=30,c = afterBuildScriptLink)
        cmds.setParent("..") 
        cmds.rowColumnLayout(numberOfColumns=1)
        cmds.scrollField("afterBuildScript",wordWrap=True,width=370,height=50,fns=8)
        cmds.setParent("..")
        
        cmds.setParent("..")#close right
        cmds.setParent("..")#close frame
          
        cmds.rowColumnLayout("inputJoint",numberOfColumns=1)#
        cmds.setParent("..")    
        cmds.frameLayout("inputVertex",label='Extra',cl=True,cll=True,width=370)#
        cmds.setParent("..")    
        cmds.setParent("..")#close scroll
        
        exportImportRow = cmds.rowColumnLayout(nc=3,parent="NLTA_AS")       
        cmds.button("importData",label="Import Data",c = partial(importData,["new",exportImportRow]),width=389)
        cmds.setParent("..")
        cmds.rowColumnLayout(nc=2,width=390) 
        cmds.button(label="Match",c = matchJoint,width=195) 
        cmds.button(label="Build/Rebuild AS",c = buildAS,width=195)    
        cmds.button(label="Connect AS - FBX",c = connectAsFbx,width=195)
        cmds.button(label="Disconnect AS - FBX",c = partial(disconnect,"groupConstraintAsFbx"),width=195)        
        cmds.setParent("..")
        cmds.rowColumnLayout(numberOfColumns=3)
        cmds.checkBox("oldGuideCheckbox",label="oldGuide",width=195)    
        cmds.button("exportData",label="Export Data",c = exportData,width=194)        
        cmds.setParent("..")

        cmds.frameLayout(label='Other',cl=True,cll=True,width=390,parent="NLTA_AS")
        cmds.rowColumnLayout(numberOfColumns=4)
        cmds.button(label="Connect Single",c = connectSingle,width=98)
        cmds.button(label="Clear Offset",c = clearOffset,width=98)
        cmds.button(label="Restore Offset",c = restoreClearOffset,width=98) 
        cmds.setParent("..")
        cmds.setParent("..")
        
        cmds.setParent("..")

def clearForm(*arr):
    dataClear = [
        ["textField","prefixRight"],
        ["textField","prefixLeft"],
        ["textField","matchOldCtrlUrl"],
        ["scrollField","beforeMatchScript"],
        ["scrollField","afterMatchScript"],
        ["scrollField","beforeBuildScript"],
        ["scrollField","afterBuildScript"],
        ["intField","maxInfluences"],
    ]
    for a in range(len(dataClear)):
        if dataClear[a][0] == "textField":
            if cmds.textField(dataClear[a][1],query=True,exists=True):
                cmds.textField(dataClear[a][1],edit=True,text="")
        elif dataClear[a][0] == "scrollField": 
            if cmds.scrollField(dataClear[a][1],query=True,exists=True):
                cmds.scrollField(dataClear[a][1],edit=True,text="")
        elif dataClear[a][0] == "intField":  
            if cmds.intField(dataClear[a][1],query=True,exists=True):
                cmds.intField(dataClear[a][1],edit=True,value=0)
            """    
            cmds.textField("prefixRight",edit=True,text="")
            cmds.textField("prefixLeft",edit=True,text="")
            cmds.scrollField("beforeMatchScript",edit=True,text="")
            cmds.scrollField("afterMatchScript",edit=True,text="")
            cmds.scrollField("beforeBuildScript",edit=True,text="")
            cmds.scrollField("afterBuildScript",edit=True,text="")
            cmds.textField("matchOldCtrlUrl",edit=True,text="")    
            cmds.intField("maxInfluences",edit=True,value=0)
            """

def changePattern(*arr):
    pm.mel.eval('source "C:/vsTools2/library/python_module/AdvancedSkeleton5/AdvancedSkeleton5.mel";AdvancedSkeleton5;')
    user = os.environ.get("USERNAME")
    global dataSession
    pattern = cmds.optionMenu("patternAS",q=True,value=True)
    
    #DELETE AS EXIST
    for a in cmds.ls("FitSkeleton",ap=True):
        if not cmds.listRelatives(a,p=True):
            cmds.delete(a)
            
    #IMPORT PATTERN FILE
    pm.mel.eval('file -import -type "mayaAscii"  -ignoreVersion -ra true -mergeNamespacesOnClash true -namespace ":" -options "v=0;"  -pr  -importTimeRange "combine" "C:/Users/'+user+'/Documents/maya/scripts/NLTA/collection/ASpattern/'+pattern+'.ma";')    
         
    #SOLVE DATASESSION["PAIR"]
    dataSession = {}
    for a in toolSetting["patternData"]:
        dataSession[a] = toolSetting["patternData"][a]
    
    for a in toolSetting["patternInput"][pattern]:
        dataSession[a] = toolSetting["patternInput"][pattern][a]
        
    dataSession["pair"] = []    
    for a in toolSetting["patternInput"][pattern]["order"]:
        exist = general.checkOnly([a,"FitSkeleton"])
        dataSession["pair"].append([exist])
    
    #DELETE ALL INPUT JOINTS
    input = cmds.rowColumnLayout("inputJoint", q = True, ca= True)
    if input:
        for a in input:
            try:
                cmds.deleteUI(a)
            except:pass
            
    #DELETE ALL INPUT VERTEX
    input = cmds.frameLayout("inputVertex", q = True, ca= True)
    if input:
        for a in input:
            try:
                cmds.deleteUI(a)
            except:pass
    
    #CREATE NEW INPUT JOINT           
    input_data = dataSession["order"]
    for a in range(len(input_data)):
        cmds.rowColumnLayout("input"+str(a),numberOfColumns=3,parent = "inputJoint")
        cmds.textField(text=input_data[a],width=170,editable=False)
        cmds.button(label=">",width=30,c=partial(set_pair,input_data[a]))
        cmds.textField(input_data[a],width=170,editable=False,pht="Joint only.")
        cmds.setParent("..")
        
    #CREATE NEW INPUT VERTEX   
    cmds.rowColumnLayout(numberOfColumns=2,parent="inputVertex")
    cmds.textField(text="Connect Scale",width=100,editable=False)
    cmds.checkBox("connectScale",label="",cc=connectScale)
    cmds.setParent("..")
    input_data = dataSession["vertex"]
    for a in range(len(input_data)):
        cmds.rowColumnLayout(numberOfColumns=3,parent="inputVertex")
        cmds.textField(text="* "+input_data[a]+" Vtx",width=171,editable=False)
        cmds.button(label=">",width=30,c=partial(positionVtx,input_data[a]+"Vtx"))
        cmds.textField(input_data[a]+"Vtx",width=180,editable=False,pht="Vertex only.")
        cmds.setParent("..")
    addMinus = [
        ["exceptJoint","Except joint (Ctrl)"],
        ["exceptJointSkin","Except joint (Skin)"],
    ]
    for a in range(len(addMinus)):
        dataTemp = addMinus[a]
        name = dataTemp[0]
        title = dataTemp[1]
        cmds.rowColumnLayout(numberOfColumns=4,parent="inputVertex")    
        cmds.textField(text=title,width=141,editable=False)
        cmds.button(label="+",width=30,c=partial(addMinusAdd,name))
        cmds.button(label="-",width=30,c=partial(addMinusMinus,name))
        cmds.scrollField(name,wordWrap=True,width=179,height=100,editable=False)
        cmds.setParent("..")
    cmds.rowColumnLayout(numberOfColumns=4,parent="inputVertex")
    cmds.textField(text="Max Influences",width=200,editable=False)
    cmds.intField("maxInfluences",width=180,value=0)
    cmds.setParent("..")
    cmds.rowColumnLayout(numberOfColumns=4,parent="inputVertex")
    cmds.textField(text="Ctrl match",width=170,editable=False)
    cmds.button(label=">",width=30,c = matchOldCtrlLink)
    cmds.textField("matchOldCtrlUrl",pht="Maya old file url",width=180)
    cmds.setParent("..") 
    clearForm()     

def MirrorJoint(lefRefix,rightRefix,jointName):
    if lefRefix in jointName:
        mirrorJoint = ""
        if "prefixPosition" in dataSession:
            if jointName.endswith(lefRefix):
                mirrorJoint = jointName[0:-(len(lefRefix))]+rightRefix
        else:           
            mirrorJoint = jointName.replace(lefRefix,rightRefix)    
        #1. HAS MIRROR NAME IN MATCHED
        if cmds.objExists(mirrorJoint):
            if(mirrorJoint in max_joint_matched):
                array_except_temp.append(i)                     
        #2. HAS MIRROR NAME IN UNMATCH AND SAME PARENT NAME (REPLACE SIDE) IN MATCHED 
        if cmds.objExists(mirror_joint):
            mirror_parent = cmds.listRelatives(mirror_joint,p=True)
            if mirror_parent:
                if (mirror_parent[0] in max_joint_matched) and (mirror_joint in max_joint_unMatched):
                    array_except_temp.append(i) 
                
def matchJoint(*arr):

    general.runScript("beforeMatchScript")
    global dataSession    
    right_refix = cmds.textField("prefixRight",query=True,text=True)
    left_refix = cmds.textField("prefixLeft",query=True,text=True)
    if right_refix == "" or left_refix == "":
        cmds.confirmDialog(title="Confirm",message="Please fill Prefix right and left!",button=["Yes"],defaultButton="Yes",cancelButton="Yes")  
    else:

        #SOLVE PREFIX
        dataSession["prefix"] = [right_refix,left_refix]       
        for a in range(len(dataSession["pair"])):
            if len(dataSession["pair"][a])>1:                
                if dataSession["pair"][a][1].endswith(right_refix):
                    dataSession["prefixPosition"]="end"
                    break 

        #CREATE DATA
        allData = {
            "maxJoint":{},    
            "orderFlag":[],
            "maxJointOrder":[],
            "vertexPosition":dataSession["vertexPosition"]
        }

        for a in range(len(dataSession["order"])):
            if len(dataSession["pair"][a]) > 1:
                if dataSession["order"][a] == "Root":                    
                    asRoot = dataSession["pair"][a][0]
                    maxRoot = dataSession["pair"][a][1]
        maxRootChilren = cmds.listRelatives(maxRoot,ad=True,path=True)
        maxRootChilren.append(maxRoot)
        maxRootChilren = maxRootChilren[::-1]
        for a in range(len(maxRootChilren)):
            if cmds.listRelatives(maxRootChilren[a],parent=True):
                parent = cmds.listRelatives(maxRootChilren[a],parent=True)[0]
            else:
                parent = ""
            allData["maxJoint"][maxRootChilren[a]] = {
                "parent":parent
            }
            allData["maxJointOrder"].append(maxRootChilren[a])
            for attr in ["rx","ry","rz","tx","ty","tz"]:
                pm.mel.eval('CBunlockAttr "'+maxRootChilren[a]+'.'+attr+'";')

        for a in range(len(dataSession["order"])):
            if len(dataSession["pair"][a]) > 1:
                allData["maxJoint"][dataSession["pair"][a][1]]["asGuide"] = dataSession["pair"][a][0]
                allData["maxJoint"][dataSession["pair"][a][1]]["label"] = dataSession["order"][a]
                allData["orderFlag"].append(dataSession["order"][a])
                mirrorMaxJoint = 
                


                       
            




        #SCALE FITSKELETON    
        maxRootY = cmds.xform(maxRoot, query=True, worldSpace=True, translation=True)[1]
        asRootY = cmds.xform(asRoot, query=True, worldSpace=True, translation=True)[1]
        cmds.setAttr("FitSkeleton.scaleX",maxRootY/asRootY)
        cmds.setAttr("FitSkeleton.scaleY",maxRootY/asRootY)
        cmds.setAttr("FitSkeleton.scaleZ",maxRootY/asRootY)
        pm.mel.eval('makeIdentity -apply true  -t 0 -r 0 -s 1 -n 0 -pn 1 "FitSkeleton";')
        cmds.makeIdentity("FitSkeleton")
        
        
        #CUSTROM JOINT CHAIN ARRAY
        jointChain = []
        for a in range(len(dataSession["jointBetween"])):            
            source = dataSession["jointBetween"][a][0]
            dest = dataSession["jointBetween"][a][1]
            namePattern = dataSession["jointBetween"][a][2]
            if source in allData["orderFlag"] and dest in allData["orderFlag"]:
                for b in allData["maxJoint"]:
                    if ("label" in allData["maxJoint"][b]) and (allData["maxJoint"][b]["label"] == source):
                        asSource = general.checkOnly([allData["maxJoint"][b]["asGuide"],"FitSkeleton"])
                        maxSource = b
                    if ("label" in allData["maxJoint"][b]) and (allData["maxJoint"][b]["label"] == dest):
                        asDest = general.checkOnly([allData["maxJoint"][b]["asGuide"],"FitSkeleton"])
                        maxDest = b
                jointChain.append([
                    asSource,
                    asDest,
                    maxSource,
                    maxDest,
                    namePattern
                ])

        #SOLVE JOINT CHAIN
        for a in range(len(jointChain)):
            create_info = []
            create_info.append(jointChain[a][0])
            create_info.append(jointChain[a][1])
            create_info.append(jointChain[a][2])
            create_info.append(jointChain[a][3])
            create_info.append(jointChain[a][4])
            array_result = general.matchJoint(create_info)
            for b in array_result:
                allData["maxJoint"][b[1]]["asGuide"] = b[0]
        
        
        #SOLVE TWIST JOINT 
        twistJoint = []
        for a in range(len(dataSession["twistBetween"])):
            pair = dataSession["twistBetween"][a]
            for b in allData["maxJoint"]:
                if ("label" in allData["maxJoint"][b]) and (allData["maxJoint"][b]["label"] == pair[0]):
                    asSource = allData["maxJoint"][b]["asGuide"]
                    maxSource = b
                if ("label" in allData["maxJoint"][b]) and (allData["maxJoint"][b]["label"] == pair[1]):
                    asDest = allData["maxJoint"][b]["asGuide"]
                    maxDest = b

            if maxSource and maxDest:
                jointBetween = general.hierachyBetween([maxSource,maxDest])
                if len(jointBetween) > 2:                  
                    if pair[0] == "Knee":
                        try:
                            pm.mel.eval('addAttr -ln "twistJoints"  -at long -dv 0 '+asSource+';')
                            pm.mel.eval('setAttr -e-keyable true '+asSource+'.twistJoints;')
                            pm.mel.eval('addAttr -ln "bendyJoints" -at bool '+asSource+';')
                            pm.mel.eval('setAttr -e-keyable true '+asSource+'.bendyJoints;')
                        except (Exception,):pass
                    pm.mel.eval('setAttr "'+asSource+'.twistJoints" '+str(len(jointBetween) - 2)+';')
                    pm.mel.eval('setAttr "'+asSource+'.bendyJoints" 1;')
                    stt = 1
                    for c in jointBetween[1:-1]:
                        allData["maxJoint"][c]["twistJoint"] = pair[0]+"Part"+str(stt)+"R"
                         
                        mirrorJoint = c.replace(right_refix,left_refix)
                        if "prefixPosition" in dataSession:
                            if c.endswith(left_refix):
                                mirrorJoint = c[0:-(len(right_refix))]+left_refix          
                        if cmds.objExists(mirrorJoint):
                            allData["maxJoint"][mirrorJoint]["twistJoint"] = pair[0]+"Part"+str(stt)+"L"
                        stt+=1
                else:
                    if pair[0] != "Knee":
                        try:
                            pm.mel.eval('setAttr "'+asSource+'.twistJoints" 0;')
                            pm.mel.eval('setAttr "'+asSource+'.bendyJoints" 0;')
                        except (Exception,):pass


        #MATCH JOINT       
        for a in allData["maxJointOrder"]:
            if "asGuide" in allData["maxJoint"][a]:
                asJoint = allData["maxJoint"][a]["asGuide"]
                if "label" in allData["maxJoint"][a]:
                    asPattern = allData["maxJoint"][a]["label"]
                else:
                    asPattern = ""
                maxJoint = a
                if general.checkSubString([asPattern,["Wrist","Finger"]]):
                    cmds.matchTransform(asJoint,maxJoint,pos=True,rot=True)
                    if general.checkSubString([asPattern,["Finger"]]):                           
                        if cmds.listRelatives(asJoint,ad=True):
                            maxJointChildren = cmds.listRelatives(maxJoint,ad=True)[::-1]
                            asJointChildren = cmds.listRelatives(asJoint,ad=True)[::-1]
                            for b in range(len(asJointChildren)):
                                try:
                                    cmds.matchTransform(asJointChildren[b],maxJointChildren[b],pos=True,rot=True)
                                    allData["maxJoint"][maxJointChildren[b]]["asGuide"] = asJointChildren[b]
                                except (Exception,):pass                                
                                try:
                                    cmds.addAttr(asJointChildren[b],longName='control', attributeType='bool', keyable=True, defaultValue=True)
                                except:pass 
                else:
                    cmds.matchTransform(asJoint,maxJoint,pos=True)
                    if general.checkSubString([asPattern,["Ankle"]]):
                        pm.mel.eval('hilite '+asJoint+';')
                        pm.mel.eval('select -r '+asJoint+'.rotateAxis ;')
                        pm.mel.eval('rotate -r -os -fo 0 0 -90 ;')
                        pm.mel.eval('hilite -u '+asJoint+' ;')
                    allData["maxJoint"][maxJoint]["asGuide"] = asJoint

        for a in allData["vertexPosition"]:
            jointName = a.replace("Vtx","")
            cmds.xform(jointName,worldSpace=True,translation = allData["vertexPosition"][a])

            
        #CUSTOM ATTRIBUTE
        asJoint = cmds.listRelatives(asRoot,ad=True,path=True)
        asJoint.insert(0,asRoot) 
        for a in asJoint:
            if general.checkSubString([a,["Root"]]):
                try:
                    pm.mel.eval('setAttr "Root.numMainExtras" 1;')
                except:pass                
            try:
                cmds.setAttr(a+".inbetweenJoints",0)
            except:pass
            
            if cmds.listRelatives(a,parent=True)[0]=="Cup":
               cupParent = cmds.listRelatives("Cup",parent=True)
               cmds.parent(a,cupParent)
            if "attribute" in dataSession:
                for b in dataSession["attribute"]:
                    if b == "global":
                        if general.checkSubString([a,dataSession["attribute"][b]]):
                            try:
                                pm.mel.eval('addAttr -ln "global"  -at double  -min 0 -max 10 -dv 0 '+a+';')
                                pm.mel.eval('setAttr -e-keyable true '+a+'.global;')
                            except (Exception,):pass
                    if b == "ikLocal":
                        if general.checkSubString([a,dataSession["attribute"][b]]):
                            try:
                                pm.mel.eval('addAttr -ln "ikLocal"  -at "enum" -en "addCtrl:nonZero:localOrient"  '+a+';')
                                pm.mel.eval('setAttr -e-keyable true '+a+'.ikLocal;')
                                pm.mel.eval('setAttr "'+a+'.ikLocal" 2;')
                            except (Exception,):pass   
                    if b == "worldOrientForward":
                        if general.checkSubString([a,dataSession["attribute"][b]]):                            
                            try:
                                pm.mel.eval('addAttr -ln "worldOrientForward"  -at "enum" -en "xForward:yForward:zForward:xBackward:yBackward:zBackward:free"  '+a+';')
                                pm.mel.eval('setAttr -e-keyable true '+a+'.worldOrientForward;')
                            except (Exception,):pass
                            try:             
                                pm.mel.eval('setAttr "'+a+'.worldOrientUp" 1;')
                                pm.mel.eval('setAttr "'+a+'.worldOrientForward" 0;')
                            except:pass
                    if b == "control":
                        if general.checkSubString([a,dataSession["attribute"][b]]):
                            try:
                                cmds.addAttr(a,longName='control', attributeType='bool', keyable=True, defaultValue=True)
                            except:pass
                    if b == "freeOrient":
                        if general.checkSubString([a,dataSession["attribute"][b]]):
                            try:
                                cmds.addAttr(a,longName='freeOrient', attributeType='bool', keyable=True, defaultValue=True)
                            except (Exception,):pass
                    if b == "orientJoint":
                        if general.checkSubString([a,dataSession["attribute"][b]]):  
                            cmds.select(a)
                            pm.mel.eval('joint -e  -oj xyz -secondaryAxisOrient zup -ch -zso;')

        #GET ASJOINT MATCHED
        asJointMatched = []
        for a in allData["maxJoint"]:
            if "asGuide" in allData["maxJoint"][a]:
                asJointMatched.append(allData["maxJoint"][a]["asGuide"])
        for a in asJoint:
            if a+"vtx" in allData["vertexPosition"]:
                asJointMatched.append(a)   

        #DELETE ASJOINT
        for a in asJoint:
            if a not in asJointMatched:
                jointChildren = cmds.listRelatives(a,children=True,type="joint",pa=True)
                if jointChildren:
                    jointParent = cmds.listRelatives(a,parent=True,type="joint",pa=True)
                    if jointRarent:
                        jointRarent = jointRarent[0]
                        for b in joinChildren:
                            if b in asJointMatched:
                                cmds.parent(b,jointRarent)
                cmds.delete(a)

                       
        #FREE TRANSFORM WRIST AND FINGER FREE TRANSFORM
        wristAs = general.checkOnly(["Wrist","FitSkeleton"])
        wristChildren = cmds.listRelatives(wristAs,ad=True)[::-1]
        wristChildren.insert(0,wristAs)
        for a in wristChildren:
            cmds.select(a)
            pm.mel.eval('makeIdentity -apply true -t 1 -r 1 -s 1 -n 0 -pn 1;')
            if cmds.listRelatives(a,children=True):
                if "Thumb" in a:
                    pm.mel.eval('joint -e  -oj xyz -secondaryAxisOrient xup -ch -zso;') 
                else:                    
                    pm.mel.eval('joint -e  -oj xyz -secondaryAxisOrient zup -ch -zso;') 
            else:                
                pm.mel.eval('joint -e  -oj none -ch -zso;')
        
        
        #REMOVE MIRROR JOINT
        for a in allData["maxJointOrder"]:
            if ("asGuide" in alldata["maxJoint"][a]) or ("twistJoint" in allData["maxJoint"][a]):



        """
        #REMOVE MIRROR JOINT        
        max_joint_unMatched = list(set(max_joint) - set(max_joint_matched))
        array_except_temp = []      
        for i in max_joint_unMatched:
            if left_refix in i:
                mirror_joint = ""
                if "prefixPosition" in dataSession:
                    if i.endswith(left_refix):
                        mirror_joint = i[0:-(len(left_refix))]+right_refix
                else:           
                    mirror_joint = i.replace(left_refix,right_refix)    
                #1. HAS MIRROR NAME IN MATCHED
                if cmds.objExists(mirror_joint):
                    if(mirror_joint in max_joint_matched):
                        array_except_temp.append(i)                     
                #2. HAS MIRROR NAME IN UNMATCH AND SAME PARENT NAME (REPLACE SIDE) IN MATCHED 
                if cmds.objExists(mirror_joint):
                    mirror_parent = cmds.listRelatives(mirror_joint,p=True)
                    if mirror_parent:
                        if (mirror_parent[0] in max_joint_matched) and (mirror_joint in max_joint_unMatched):
                            array_except_temp.append(i)
        max_joint_unMatched = list(set(max_joint_unMatched) - set(array_except_temp))
        max_joint_unMatched = list(set(max_joint_unMatched) - set(twistJoint))
    
        
        #ADD JOINT            
        remove_joint_temp = []
        for a in max_joint_unMatched:
            if (a not in dataSession["exceptJoint"]):
                parentJoint = cmds.listRelatives(a,parent=True,pa=True)
                #IF HAS PARENT              
                if parentJoint:
                    parent_temp = parentJoint[0]
                    children_temp = cmds.listRelatives(a,children=True,ad=True)
                    #CHECK SIDE
                    if "prefixPosition" in dataSession:
                        if a.endswith(right_refix):
                            side = "right"
                            mirror = a[0:-(len(right_refix))]+left_refix    
                        elif a.endswith(left_refix):
                            side = "left"
                            if parent_temp.endswith(left_refix):
                                parent_mirror = parent_temp[0:-(len(left_refix))]+right_refix
                            else:
                                side = "middle"
                        else:
                            side = "middle"
                            mirror = a[0:-(len(right_refix))]+left_refix                     
                    else:
                        if right_refix in a:
                            side = "right"
                            mirror = a.replace(right_refix,left_refix)
                        elif left_refix in a:
                            side = "left"
                            if left_refix in parent_temp:
                                parent_mirror = parent_temp.replace(left_refix,right_refix)
                            else:
                                side = "middle"
                        else:
                            side = "middle"
                            mirror = a[0:-(len(right_refix))]+left_refix 
                    
                    if children_temp:
                        a_hierachy = children_temp[::-1]
                        a_hierachy.insert(0,a)
                    else:
                        a_hierachy = [a]

                    #IF JOINT IN LEFT SIDE
                    if parent_temp not in max_joint_matched:
                        parent_mirror = parent_temp.replace(left_refix,right_refix)                     
                        if parent_mirror in max_joint_matched:                 

                            new_joint_uuid = cmds.ls(list(cmds.duplicate(a,renameChildren=True)),uuid=True)
                            jointNewParent = cmds.ls(new_joint_uuid[0])[0]
                           
                            if cmds.listRelatives(jointNewParent,children=True,ad=True,path=True):                                
                                new_joint_temp = cmds.listRelatives(jointNewParent,children=True,ad=True,path=True)[::-1]
                                new_joint_temp.insert(0,jointNewParent)
                            else:
                                new_joint_temp = [jointNewParent]
                            new_joint_uuid =  cmds.ls(new_joint_temp,uuid=True)
                            new_joint_temp = []

                            for b in new_joint_uuid:
                                currentName = (cmds.ls(b)[0].split("|"))[-1]                      
                                newName = currentName+"_AS"
                                cmds.rename(cmds.ls(b)[0],newName) 
                                new_joint_temp.append(newName)
                            jointNewParent = cmds.ls(new_joint_uuid[0])[0]              

                            as_index = max_joint_matched.index(parent_mirror)
                            as_name = as_joint_matched[as_index]
                            for b in new_joint_temp:
                                cmds.addAttr(b,longName='freeOrient', attributeType='bool', keyable=True, defaultValue=True)
                                cmds.addAttr(b,longName='control', attributeType='bool', keyable=True, defaultValue=True)
                                cmds.addAttr(b,longName='noMirror', attributeType='bool', keyable=True, defaultValue=True)
                                cmds.addAttr(b,longName='noMirrorLeft', attributeType='bool', keyable=True, defaultValue=True)
                                cmds.setAttr(b+".noMirrorLeft",1)

                            cmds.select(clear=True)
                            newJoint = cmds.joint()
                            cmds.parent(jointNewParent,newJoint)
                            cmds.select(jointNewParent)
                            mirrorJoint = pm.mel.eval("mirrorJoint -mirrorYZ -mirrorBehavior;")
                            cmds.delete(jointNewParent)
                            new_joint_uuid = cmds.ls(mirrorJoint,uuid=True)
                            jointNewParent = cmds.ls(new_joint_uuid[0])[0]                            
                            cmds.parent(jointNewParent,as_name)
                            cmds.delete(newJoint)
                            
                            if cmds.listRelatives(jointNewParent,children=True,ad=True,path=True):                                
                                new_joint_temp_mirror = cmds.listRelatives(jointNewParent,children=True,ad=True,path=True)[::-1]
                                new_joint_temp_mirror.insert(0,jointNewParent)
                            else:
                                new_joint_temp_mirror = [jointNewParent]

                            new_joint_uuid =  cmds.ls(new_joint_temp_mirror,uuid=True)
                            

                            for b in range(len(new_joint_temp)):
                                cmds.rename(cmds.ls(new_joint_uuid[b])[0],new_joint_temp[b])

                            jointNewParent = cmds.ls(new_joint_uuid[0])[0]
                            if cmds.listRelatives(jointNewParent,children=True,ad=True,path=True):
                                new_joint_temp = cmds.listRelatives(jointNewParent,children=True,ad=True,path=True)[::-1]
                                new_joint_temp.insert(0,jointNewParent)
                            else:
                                new_joint_temp = [jointNewParent]

                            for b in range(len(new_joint_temp)):
                                constraint_pair.append([new_joint_temp[b],a_hierachy[b]])

                    # IF JOINT IN RIGHT SIDE OR MID
                    else:
                        new_joint_uuid = cmds.ls(list(cmds.duplicate(a,renameChildren=True)),uuid=True)
                        jointNewParent = cmds.ls(new_joint_uuid[0])[0]
                       
                        if cmds.listRelatives(jointNewParent,children=True,ad=True,path=True):                                
                            new_joint_temp = cmds.listRelatives(jointNewParent,children=True,ad=True,path=True)[::-1]
                            new_joint_temp.insert(0,jointNewParent)
                        else:
                            new_joint_temp = [jointNewParent]
                        new_joint_uuid =  cmds.ls(new_joint_temp,uuid=True)
                        new_joint_temp = []

                        for b in new_joint_uuid:
                            currentName = (cmds.ls(b)[0].split("|"))[-1]                      
                            newName = currentName+"_AS"
                            cmds.rename(cmds.ls(b)[0],newName) 
                            new_joint_temp.append(newName)
                        jointNewParent = cmds.ls(new_joint_uuid[0])[0]

                        #BE CHILDREN OF AS JOINT    
                        as_index = max_joint_matched.index(parent_temp)
                        as_name = as_joint_matched[as_index]                                
                        cmds.parent(jointNewParent,w=True)
                        group_temp = cmds.listRelatives(jointNewParent,p=True)
                        if group_temp:
                            pm.mel.eval('makeIdentity -apply true  -t 1 -r 1 -s 1 -n 0 -pn 1 "'+group_temp[0]+'";')
                            cmds.parent(jointNewParent,as_name)                        
                            cmds.delete(group_temp[0])
                        else:
                            cmds.parent(jointNewParent,as_name)    
                        
                        #HANDLE JOINT LIKE CUP
                        if len(new_joint_temp) > 1:                                         
                            if a_hierachy[1] in max_joint_matched:
                                cmds.delete(new_joint_temp[1])
                                as_index = max_joint_matched.index(a_hierachy[1])
                                as_name = as_joint_matched[as_index]
                                cmds.parent(as_name,new_joint_temp[0])
                                new_joint_hierachy = [new_joint_temp[0]]
                            else:
                                new_joint_hierachy = new_joint_temp
                        else:
                            new_joint_hierachy = [new_joint_temp[0]]
                        
                        if side == "right" and mirror in max_joint_unMatched:
                            try:
                                cmds.addAttr(new_joint_hierachy[0],longName='noMirror', attributeType='bool', keyable=True, defaultValue=True)
                            except:pass
                            
                        #SET ATTRIBUTE
                        for b in new_joint_hierachy:
                            try:
                                cmds.addAttr(b,longName='freeOrient', attributeType='bool', keyable=True, defaultValue=True)
                            except:pass
                            try:
                                cmds.addAttr(b,longName='control', attributeType='bool', keyable=True, defaultValue=True)
                            except:pass
                            if side == "middle":
                                try:
                                    cmds.addAttr(b,longName='noMirror', attributeType='bool', keyable=True, defaultValue=True)
                                except:pass

                        #ADD TO REMOVE ARRAY        
                        for b in a_hierachy:
                            if b in max_joint_unMatched:
                                remove_joint_temp.append(b)
                            if side == "right":
                                if mirror in max_joint_unMatched:
                                    remove_joint_temp.append(mirror)
                        
                        #ADD TO CONSTAINT ARRAY
                        for b in range(len(new_joint_hierachy)):
                            constraint_pair.append([new_joint_hierachy[b],a_hierachy[b]])#

                   
        max_joint_unMatched = list(set(max_joint_unMatched) - set(remove_joint_temp))
        dataSession["constraint_pair"] = []
        
        for a in range(len(constraint_pair)):
            dataSession["constraint_pair"].append([cmds.ls(constraint_pair[a][0],uuid=True),cmds.ls(constraint_pair[a][1],uuid=True)])

        #Store Old guide
        if "oldGuide" in dataSession:
            for a in range(len(dataSession["oldGuide"])):
                jointName = dataSession["oldGuide"][a][0]
                jointAttr = dataSession["oldGuide"][a][1]
                if cmds.objExists(jointName):
                    if cmds.getAttr(jointName+".translateX",settable=True):
                        pm.mel.eval('setAttr "'+jointName+'.translateX" '+str(jointAttr[0])+';')
                    if cmds.getAttr(jointName+".translateY",settable=True):
                        pm.mel.eval('setAttr "'+jointName+'.translateY" '+str(jointAttr[1])+';')
                    if cmds.getAttr(jointName+".translateZ",settable=True):      
                        pm.mel.eval('setAttr "'+jointName+'.translateZ" '+str(jointAttr[2])+';')
                    if cmds.getAttr(jointName+".rotateX",settable=True):  
                        pm.mel.eval('setAttr "'+jointName+'.rotateX" '+str(jointAttr[3])+';')
                    if cmds.getAttr(jointName+".rotateY",settable=True):   
                        pm.mel.eval('setAttr "'+jointName+'.rotateY" '+str(jointAttr[4])+';')
                    if cmds.getAttr(jointName+".rotateZ",settable=True):  
                        pm.mel.eval('setAttr "'+jointName+'.rotateZ" '+str(jointAttr[5])+';')
                        
    general.runScript("afterMatchScript")
    print("Match joint done!!")
    """
   
def clearOffset(*arr):
    for a in cmds.ls(selection=True):
        groupNew = cmds.group(n=a+"_fixOffset",empty=True)
        parentName = cmds.listRelatives(a,parent=True)[0]
        cmds.matchTransform(groupNew,a,rot=True,pos=True)
        cmds.parent(groupNew,parentName)
        cmds.parent(a,groupNew)
        
def restoreClearOffset(*arr):
    fixOffset = cmds.ls("*fixOffset*",type='transform')
    for a in fixOffset:
        parentName = cmds.listRelatives(a,parent=True)[0]
        childrenName = cmds.listRelatives(a,children=True)[0]
        cmds.parent(childrenName,parentName)
        cmds.delete(a)

   
def buildAS(*arr):
    disconnect("groupConstraintAsFbx")
    restoreClearOffset() 
    mel.eval('rehash;')
    pm.mel.eval('source "C:/vsTools2/library/python_module/AdvancedSkeleton5/AdvancedSkeleton5.mel";AdvancedSkeleton5;')

    general.runScript("beforeBuildScript")
    
    cmds.lockNode('initialShadingGroup', l=0, lockUnpublished=0)
    #unload all preference        
    for RN in cmds.ls(rf = True):
        cmds.file(unloadReference = RN)
     
       
    #BUILD ADVANCE SKELETON
    pm.mel.eval('asReBuildAdvancedSkeleton;')
    
    #load all preference
    for RN in cmds.ls(rf = True):
        cmds.file(loadReference = RN)           
    
    connectAsFbxData()
    connectFbxAsData()  
    changeColorCtrl()
    matchOldCtrl()
    rotateFingerSession()
                   
    #MESH SKINED TO LAYER
    mesh_parent = []
    for a in cmds.ls(type="mesh",r=True):
        for b in cmds.listHistory(a):
            if cmds.nodeType(b)=="skinCluster":
                mesh_parent.append(a)
    LayerName = 'GeoLayer'
    if pm.objExists(LayerName):
        pm.delete(LayerName)
    DisplayLayer = pm.createDisplayLayer(name=LayerName, empty=True)
    pm.editDisplayLayerMembers(DisplayLayer,mesh_parent, noRecurse=True)
    DisplayLayer.displayType.set(2)
    DisplayLayer.visibility.set(1)
    
    #CONTROL LAYSER
    LayerName = 'ControlsLayer'
    if pm.objExists(LayerName):
        pm.delete(LayerName)
    DisplayLayer = pm.createDisplayLayer(name=LayerName, empty=True)
    pm.editDisplayLayerMembers(DisplayLayer, 'MotionSystem', noRecurse=True)
    DisplayLayer.color.set(29)      
    cmds.select(clear=True)
        
    #AS JOINT LAYER
    LayerName = 'ASJointLayer'
    if pm.objExists(LayerName):
        pm.delete(LayerName)
    DisplayLayer = pm.createDisplayLayer(name=LayerName, empty=True)
    pm.editDisplayLayerMembers(DisplayLayer,"DeformationSystem", noRecurse=True)
    DisplayLayer.displayType.set(2)
    DisplayLayer.visibility.set(0) 
    cmds.select(clear=True)
    
    #MAX JOINT LAYER
    LayerName = 'BindJointLayer'
    if pm.objExists(LayerName):
        pm.delete(LayerName)
    DisplayLayer = pm.createDisplayLayer(name=LayerName, empty=True)
    DisplayLayer.displayType.set(2)
    DisplayLayer.visibility.set(0)
    try:
        pm.editDisplayLayerMembers(DisplayLayer,dataSession["maxParent"][0], noRecurse=True)
    except:pass
        
    cmds.select(clear=True)
    general.runScript("afterBuildScript")  
    print("Build done!")
    
def changeColorCtrl(*arr):
    allAsCtrl = cmds.listRelatives("ControlSet",ad=True,type="nurbsCurve")
    for a in allAsCtrl:
        transform = cmds.listRelatives(a,parent=True)[0]
        if transform.endswith("_R"):            
            if "twist" in a:
                indexColor = "20"
            else:
                indexColor = "13"
        elif transform.endswith("_L"):
            if "twist" in a:
                indexColor = "18"
            else:
                indexColor = "6"
        elif transform == "RootX_M":
            indexColor = "23"
        elif transform.endswith("_M"):
            indexColor = "17"        
        else:
            indexColor = "9"
        for b in cmds.listRelatives(transform,ad=True,type="nurbsCurve"):
            pm.mel.eval('setAttr '+b+'.overrideColor '+indexColor+';')

                
def importData(array,*arr):
    clearForm()            
    global dataSession
    global variableTemp
    if array[0]=="new":
        url = pm.fileDialog2(fileMode=1)
        if url:     
            url = url[0]
        else:
            url = None
    else:   
        url = variableTemp["importUrl"]
    if url:     
        variableTemp["importUrl"] = url
        myFile =  open(url,'r')
        myObject = myFile.read()
        myFile.close()
        data = json.loads(myObject)        
            
        if int(cmds.about(version=True)) < 2022:
            data = json.loads(myObject,'utf-8')
        else:
            data = json.loads(myObject)
        
        if "patternAS" in data:
            cmds.optionMenu("patternAS",edit=True,value = data["patternAS"])
            changePattern()
            
        for a in data:
            dataSession[a]=data[a]
            
        nameSpace = None
        nameSpaceArray = []
        for a in range(len(data["pair"])):
            asJoint = data["pair"][a][0]            
            if len(data["pair"][a]) > 1:
                fbxJoint = data["pair"][a][1]
                joints = cmds.ls(fbxJoint,r=True,type="joint",ap=True)
                if len(joints)==1:
                    cmds.select(joints[0])
                    set_pair(asJoint)
                else:
                    joint_choiced = None             
                    if nameSpace!=None:
                        for b in joints:
                            if nameSpace in b:
                                joint_choiced = b        
                    else:
                        button_array = []
                        for b in joints:                            
                            button_array.append(b)                           
                            if ":" in b:
                                if b.split(":")[0] not in nameSpaceArray:
                                    nameSpaceArray.append(b.split(":")[0])
                        if len(nameSpaceArray)!=0:
                            for c in nameSpaceArray:
                                button_array.append("Apply all:"+c)
                            joint_choiced = cmds.confirmDialog( title='Confirm', message='Which one you choice', button=button_array)
                            if "Apply all" in joint_choiced:
                                nameSpace = joint_choiced.split(":")[1]
                                for b in joints:
                                    if nameSpace in b:
                                        joint_choiced = b
                        else:
                            cmds.confirmDialog(title="Confirm",message="Can't find joint with name: "+fbxJoint,button=["Yes"],defaultButton="Yes",cancelButton="Yes")  
                    if joint_choiced!=None:
                        cmds.select(joint_choiced)
                        set_pair(asJoint)
            else:
                cmds.select(clear=True)
                set_pair(asJoint)     
        for a in data:
            if a!="pair":
                if a == "prefix":
                    cmds.textField("prefixRight",edit=True,text=data["prefix"][0])
                    cmds.textField("prefixLeft",edit=True,text=data["prefix"][1]) 
                elif a in ["afterMatchScript","beforeMatchScript","beforeBuildScript","afterBuildScript"]:
                    cmds.scrollField(a,edit=True,text=data[a])
                elif a == "maxInfluences":    
                    cmds.intField(a,edit=True,value=data[a])
                elif a == "vertexPosition":
                    for b in data["vertexPosition"]:
                        if cmds.textField(b,q=True,ex=True):
                            cmds.textField(b,text="Established",edit=True)            
                elif a in ["exceptJoint","exceptJointSkin"]:
                    jointArray = []
                    for b in data[a]:
                        if len(cmds.ls(b,r=True,ap=True)) > 1:
                            if nameSpace!=None:
                                for c in cmds.ls(b,r=True,ap=True):
                                    if nameSpace in c:
                                        jointArray.append(c)
                            else:
                                button_array = []
                                for c in joints:                            
                                    button_array.append(c)
                                joint_choiced = cmds.confirmDialog( title='Confirm', message='Which one you choice', button=button_array)
                                jointArray.append(joint_choiced)                                
                        elif len(cmds.ls(b,r=True,ap=True)) == 1:
                            jointArray.append(cmds.ls(b,r=True,ap=True)[0])
                    dataSession[a] = jointArray
                    jointString = (";").join(jointArray)
                    cmds.scrollField(a,text=jointString,edit=True)
                elif a == "connectScale":
                    cmds.checkBox("connectScale",edit=True,value=data[a])
                else:
                    if a not in ["order"]:
                        dataSession[a] = data[a]                   
        row = array[1]
        cmds.button("importData",edit=True,width=194)
        if not cmds.button("importDataAgain",query=True,exists=True):
            cmds.button("importDataAgain",label="Re Import Data",width=195,c = partial(importData,["reImport",row]),parent=row)
            
def exportData(*arr):
    if cmds.checkBox("oldGuideCheckbox",query=True,value=True):
        saveOldGuide()
    folder_temp = os.path.dirname(pm.sceneName())
    if not folder_temp:
        folder_temp = pm.mel.eval("SaveSceneAs;")
    folder_temp = os.path.dirname(pm.sceneName())
    if folder_temp:        
        file_path = os.path.dirname(pm.sceneName())+"/"+os.path.basename(pm.sceneName()).split(".")[0]+"_asPattern.txt"
        dataExport = {}
        for a in dataSession:
            dataExport[a] = dataSession[a]
        dataExport["pair"] = []
        for a in range(len(dataSession["pair"])):
            asJoint = dataSession["pair"][a][0].split(":")[-1]
            asJoint = asJoint.split("|")[-1]
            if len(dataSession["pair"][a]) > 1:
                bindJoint = dataSession["pair"][a][1].split(":")[-1]
                bindJoint = bindJoint.split("|")[-1]
                dataExport["pair"].append([asJoint,bindJoint])
            else:            
                dataExport["pair"].append([asJoint])
        dataExport["prefix"]=[cmds.textField("prefixRight",query=True,text=True),cmds.textField("prefixLeft",query=True,text=True)]
        dataExport["matchOldCtrlUrl"] = cmds.textField("matchOldCtrlUrl",query=True,text=True)
        dataExport["patternAS"] = cmds.optionMenu("patternAS",query=True,value=True)
        dataExport["maxInfluences"] = cmds.intField("maxInfluences",query=True,value=True)
        for a in ["beforeMatchScript","afterMatchScript","beforeBuildScript","afterBuildScript"]:
            dataExport[a] = cmds.scrollField(a,query=True,text=True)    
        
        #SOLVE ROTATE FINGER
        groupSDK = "SDKFKRingFinger1_R"
        data_temp = {}
        if cmds.objExists(groupSDK):
            for b in ["rx","ry","rz"]:            
                if cmds.connectionInfo(groupSDK+"."+b, isDestination=True):
                    convertNode = cmds.connectionInfo(groupSDK+"."+b, sourceFromDestination=True)
                    data_temp["converse"+b] = convertNode.split(".")[0]
                    if  cmds.connectionInfo(data_temp["converse"+b]+".input", isDestination=True):
                        spreadNode = cmds.connectionInfo(data_temp["converse"+b]+".input", sourceFromDestination=True)
                        data_temp["bw"+b] = spreadNode.split(".")[0] 
                        if "_rotateY" in data_temp["bw"+b]:
                            if cmds.getAttr(data_temp["converse"+b]+".conversionFactor ") > 0:
                                converse = 1  
                            else:
                                converse = -1
                            data_temp["curlNode"] = data_temp["converse"+b]                        
                            if b == "rx":
                                data_temp["currentAxis"]="X"
                            elif b == "ry":
                                data_temp["currentAxis"]="Y"  
                            elif b == "rz":
                                data_temp["currentAxis"]="Z"
                           
                        if "_rotateZ" in data_temp["bw"+b]:                        
                            data_temp["spreadNode"] = data_temp["converse"+b]
                            if b == "rx":
                                data_temp["spreadAxis"]="X"
                            elif b == "ry":
                                data_temp["spreadAxis"]="Y"  
                            elif b == "rz":
                                data_temp["spreadAxis"]="Z"
            dataExport["rotateFinger"] = {
               "fingerAxis":data_temp["currentAxis"],
               "spreadAxis":data_temp["spreadAxis"],
               "converse":converse
            }
        #SAVE FILE
        with open(file_path,"w") as json_file:
            json.dump(dataExport,json_file,sort_keys=False)
        print("Url export: " + file_path)                 
                    

def set_pair(input,*arr):
    global dataSession
    if input in dataSession["order"]:
        input_index = dataSession["order"].index(input)
        selection = cmds.ls(selection=True,ap=True)
        if selection:
            if len(dataSession["pair"][input_index]) < 2:
                dataSession["pair"][input_index].append(selection[0])
            else:
                dataSession["pair"][input_index][1] = selection[0]
            joint_name = selection[0].split(":")[-1]
            joint_name = joint_name.split("|")[-1]
            cmds.textField(input,text = joint_name,edit=True,ann=str(selection[0]))
        else:
            dataSession["pair"][input_index] = [dataSession["pair"][input_index][0]]
            cmds.textField(input,text = "",edit=True)
            
def beforeMatchScriptLink(*arr):
    cmds.scrollField("beforeMatchScript",text=pm.fileDialog2(fileMode=1)[0],edit=True)
    
def afterMatchScriptLink(*arr): 
    cmds.scrollField("afterMatchScript",text=pm.fileDialog2(fileMode=1)[0],edit=True)
    
def beforeBuildScriptLink(*arr):
    cmds.scrollField("beforeBuildScript",text=pm.fileDialog2(fileMode=1)[0],edit=True)
    
def afterBuildScriptLink(*arr): 
    cmds.scrollField("afterBuildScript",text=pm.fileDialog2(fileMode=1)[0],edit=True)

def matchOldCtrlLink(*arr): 
    cmds.textField("matchOldCtrlUrl",text=pm.fileDialog2(fileMode=1)[0],edit=True)

def positionVtx(name,*arr):
    vtx = cmds.ls(selection=True)
    if vtx and "vtx" in vtx[0]:
        clusterName = cmds.cluster(vtx)[1]
        dataSession["vertexPosition"][name] = cmds.xform(clusterName,worldSpace=True,q=True,scalePivot=True)
        cmds.delete(clusterName)
        cmds.textField(name,text="Established",edit=True,ann=str(dataSession["vertexPosition"][name]))
    else:
        dataSession.pop(name)
        cmds.textField(name,text="",edit=True)
            
def addMinusAdd(name,*arr):
    global dataSession
    if name not in dataSession:
        dataSession[name]=[]
    jointArray = cmds.ls(selection=True,ap=True)
    if jointArray :     
        for a in jointArray:
            if a not in dataSession[name]:
                dataSession[name].append(a)
        joint_string = (";").join(dataSession[name])
        cmds.scrollField(name,edit=True,text=joint_string)
        
def addMinusMinus(name,*arr):
    global dataSession    
    if name not in dataSession:
        dataSession[name]=[]
    jointArray = cmds.ls(selection=True,ap=True)
    if jointArray :
        for a in jointArray:
            if a in dataSession[name]:
                dataSession[name].remove(a)
        joint_string = (";").join(dataSession[name])
        cmds.scrollField(name,edit=True,text=joint_string)

def connectScale(*arr):
    dataSession["connectScale"] = cmds.checkBox("connectScale",value=True,query=True)
            
def disconnect(groupName,*arr):
    cmds.currentTime(0)
    try:
        cmds.delete(groupName)
    except:pass    
    if groupName == "groupConstraintFbxAs":
        try:            
            cmds.delete("jointAddedGroup")
        except:pass
 
def connectMain(array,*arr):
    type = array[0]
    group_content = array[1]
    joint_source = array[2]
    joint_dest = array[3]
    if cmds.objExists(joint_source) and cmds.objExists(joint_dest):
        if cmds.objExists("grp"+type+"-"+joint_source+"-"+joint_dest+"-"+"parent"):
            cmds.delete("grp"+type+"-"+joint_source+"-"+joint_dest+"-"+"parent")
        group_parent = "grp"+type+"-"+joint_source+"-"+joint_dest+"-"+"parent"
        group_offset = "grp"+type+"-"+joint_source+"-"+joint_dest+"-"+"offset"
        locator1 = "grp"+type+"-"+joint_source+"-"+joint_dest+"-"+"loc1"
        group_parent = cmds.group(n=group_parent,empty=True)
        cmds.matchTransform(group_parent,joint_source,rot=True,pos=True)
        cmds.select(clear=True)
        locator1 = cmds.group(n=locator1,empty=True)
        group_offset = cmds.group(locator1,n=group_offset)
        cmds.matchTransform(group_offset,joint_dest,rot=True,pos=True)
        cmds.parent(group_offset,group_parent)
        cmds.parentConstraint(joint_source,group_parent,mo=True)
        if  general.checkSubString([joint_dest,["PoleArm","PoleLeg"]]):
            constaint = cmds.pointConstraint(locator1,joint_dest,mo=True)
        elif joint_dest == "Main":
            constaint = cmds.pointConstraint(locator1,joint_dest,mo=True,skip="y")
        else:           
            constaint = cmds.parentConstraint(locator1,joint_dest,mo=True)
        cmds.parent(constaint,group_parent)
        if cmds.checkBox("connectScale",query=True,value = True) == True:
            pm.mel.eval('connectAttr -f '+joint_source+'.scale '+group_parent+'.scale;')            
            cmds.setAttr(joint_dest+".sx", lock=False)
            cmds.setAttr(joint_dest+".sy", lock=False)
            cmds.setAttr(joint_dest+".sz", lock=False)
            constaintScale = cmds.scaleConstraint(locator1,joint_dest)
            cmds.parent(constaintScale,group_parent)
        try:
            cmds.parent(group_parent,group_content)        
        except:pass

def connectSingle(*arr):
    connectMain(["FbxAs","groupConstraintAsFbx",cmds.ls(selection=True)[0],cmds.ls(selection=True)[1]])

def connectAsFbxData(*arr):
    global dataSession
    data_pair = dataSession["constraint_pair"]
    right_refix = dataSession["prefix"][0]
    left_refix = dataSession["prefix"][1]
    connected = []
    for a in range(len(data_pair)):
        as_joint  = cmds.ls(data_pair[a][0])[0]
        max_joint = cmds.ls(data_pair[a][1])[0]
        side = None
        if cmds.objExists(as_joint + "_M"):
            as_joint_real = as_joint + "_M"
            side = "M"
        elif cmds.objExists(as_joint + "_R"):
            as_joint_real = as_joint + "_R"
            side = "R"
        elif cmds.objExists(as_joint + "_L"):
            as_joint_real = as_joint + "_L"
            side = "L"
        
        #RIGHT JOINT
        if side == "R":
            as_joint_right = as_joint_real              
            as_joint_left = as_joint + "_L"
            max_joint_right = max_joint
            if "prefixPosition" in dataSession:
                max_joint_left = max_joint_right[0:-(len(right_refix))]+left_refix
            else:
                max_joint_left = max_joint_right.replace(right_refix,left_refix)                                                                       
            connected.append([as_joint_right,max_joint_right])                
            #IF HAS MIRROR JOINT
            if cmds.objExists(as_joint_left) and cmds.objExists(max_joint_left):
                connected.append([as_joint_left,max_joint_left])                    
        elif side in ["L","M"]:
            if len(connected) > 0:
                jointMatchTemp = list(zip(*connected))[0]
                if as_joint_real not in jointMatchTemp:
                    connected.append([as_joint_real,max_joint])
            else:
                connected.append([as_joint_real,max_joint])                
                        
    #CONSTRAINT TWIST JOINT
    for a in range(len(dataSession["prefix"])):
        if a == 0:
            as_refix = "_R"
        else:
            as_refix = "_L"         
        for b in dataSession["twist_dict"]:
            data_temp = dataSession["twist_dict"][b]               
            twist_from = 1
            for c in data_temp:
                as_joint_twist = b+"Part"+str(twist_from)+as_refix
                if a == 0:
                    max_joint_twist = c
                else:
                    max_joint_twist = c.replace(dataSession["prefix"][0],dataSession["prefix"][1])
                connected.append([as_joint_twist,max_joint_twist])#
                twist_from = twist_from + 1                    
    dataSession["connectAsFbx"] = connected
        
def connectAsFbx(*arr):
    disconnect("groupConstraintFbxAs")
    disconnect("groupConstraintRefFbx")
    connected = []
    if cmds.objExists("DeformSet"):
        all_group_parent = cmds.group(empty=True,n="groupConstraintAsFbx")
        dataSession["groupConstraintAsFbx"] = all_group_parent
        if "connectAsFbx" in dataSession:
            for a in range(len(dataSession["connectAsFbx"])):
                as_joint = dataSession["connectAsFbx"][a][0]
                max_joint = dataSession["connectAsFbx"][a][1]
                connected.append([as_joint,max_joint])   
        else:
            connected = connectAsFbxData() 
        for a in range(len(connected)):                   
            as_joint = connected[a][0]
            max_joint = connected[a][1]
            connectMain(["AsFbx",dataSession["groupConstraintAsFbx"],as_joint,max_joint])
        
                
        #MOVE GROUP_CONTRAINT
        as_parent_group = cmds.listRelatives("FitSkeleton",parent=True)[0]
        pm.mel.eval('parent '+dataSession["groupConstraintAsFbx"]+' '+as_parent_group+' ;')
        pm.mel.eval('connectAttr -f MainExtra1.scale groupConstraintAsFbx.scale;')
        print("Connect As to Fbx done!")
     
def connectFbxAsData(*arr):
    global dataSession
    if not cmds.objExists("jointAddedGroup"):        
        jointAddedGroup = cmds.group(empty=True,n="jointAddedGroup")
    else:
        cmds.delete("jointAddedGroup")        
        jointAddedGroup = cmds.group(empty=True,n="jointAddedGroup")
    if "constraint_pair" in dataSession:
        data_pair = dataSession["constraint_pair"]
        right_refix = dataSession["prefix"][0]
        left_refix = dataSession["prefix"][1]
        connectPair = []
        jointAdded = []
        parentCons = []
        connected = {}
        for a in range(len(data_pair)):
            as_joint  = cmds.ls(data_pair[a][0])[0]
            max_joint = cmds.ls(data_pair[a][1])[0]
            max_joint_right = max_joint         
            if "prefixPosition" in dataSession:
                max_joint_left = max_joint_right[0:-(len(right_refix))]+left_refix
            else:
                max_joint_left = max_joint_right.replace(right_refix,left_refix)
            side = []
            if cmds.objExists(as_joint + "_M"):
                side.append("M")
            elif cmds.objExists(as_joint + "_R"):
                side.append("R")
            elif cmds.objExists(as_joint + "_L"):
                side.append("L")
                
            if "M" in side:
                if as_joint == "Root":
                    connectPair.append([max_joint,"FK"+as_joint+"_M"])
                    connectPair.append([max_joint,as_joint+"X_M"])
                    connectPair.append([max_joint,"Main"])
                else:
                    connectPair.append([max_joint,"FK"+as_joint+"_M"])
            elif "R" in side:
                connectPair.append([max_joint_right,"FK"+as_joint+"_R"])
                if cmds.objExists(max_joint_left) and cmds.objExists(as_joint + "_L"):
                    connectPair.append([max_joint_left,"FK"+as_joint+"_L"])
                    
                #Solve IK control
                ik_data = dataSession["ikControl"]
                for b in ik_data:
                    if as_joint == b:   
                        connectPair.append([max_joint_right,ik_data[b]+"_R"])
                        if cmds.objExists(max_joint_left) and cmds.objExists(as_joint + "_L"):
                            connectPair.append([max_joint_left,ik_data[b]+"_L"])

                #Solve point vector control
                pole_data = dataSession["poleControl"]
                for b in pole_data:
                    if as_joint == b:
                        for c in ["_R","_L"]:                           
                            if c == "_R":
                                maxJointTemp = max_joint_right          
                            elif c == "_L":
                                maxJointTemp = max_joint_left
                            
                            poleVector = pole_data[b]+c 
                            #CREATE JOINT CONTROL POLE VECTOR
                            cmds.select(clear=True)
                            jointPole = cmds.createNode("joint")
                            cmds.matchTransform(jointPole,poleVector,pos=True)
                            constraintName = cmds.parentConstraint(maxJointTemp,jointPole,mo=True)
                            cmds.parent(jointPole,"jointAddedGroup")
                            parentCons.append(constraintName)
                            connectPair.append([jointPole,poleVector])
                            jointAdded.append(jointPole)####
        ASParent = cmds.listRelatives("FitSkeleton",parent=True)
        cmds.parent("jointAddedGroup",ASParent)
        dataSession["connectFbxAs"]={
            "pair":connectPair,
            "jointAdded":jointAdded,
            "parentConstraint":parentCons
        }
        
def connectFbxAs(*arr):    
    disconnect("groupConstraintAsFbx")
    connectFbxAsData()
    #CONTRAINT MAX JOINT TO ADVANCE SKELETON
    if cmds.objExists("DeformSet"):
        all_group_parent = cmds.group(empty=True,n="groupConstraintFbxAs")
        dataSession["groupConstraintFbxAs"] = all_group_parent
        connectPair = dataSession["connectFbxAs"]["pair"]
        for a in range(len(connectPair)):           
            max_joint = connectPair[a][0]
            as_ctrl = connectPair[a][1]         
            connectMain(["FbxAs",dataSession["groupConstraintFbxAs"],max_joint,as_ctrl])
        #MOVE GROUP_CONTRAINT
        as_parent_group = cmds.listRelatives("FitSkeleton",parent=True)[0]
        pm.mel.eval('parent '+dataSession["groupConstraintFbxAs"]+' '+as_parent_group+' ;')
        print("Connect Fbx to As done!")
                
def matchFbxRef(*arr):
    refName = cmds.textField("refName",query=True,text=True)
    if ("connectFbxAs" in dataSession) and refName !="":
        pair = dataSession["connectFbxAs"]["pair"]
        jointAdded = dataSession["connectFbxAs"]["jointAdded"]
        for a in range(len(pair)):
            max_joint = pair[a][0]
            ref_joint = refName+":"+max_joint
            if max_joint not in (jointAdded):
                cmds.matchTransform(max_joint,ref_joint,rot=True,pos=True)
                
def matchRefFbx(*arr):
    refName = cmds.textField("refName",query=True,text=True)
    if ("connectFbxAs" in dataSession) and refName !="":
        pair = dataSession["connectFbxAs"]["pair"]
        jointAdded = dataSession["connectFbxAs"]["jointAdded"]
        for a in range(len(pair)):
            max_joint = pair[a][0]
            ref_joint = refName+":"+max_joint
            if max_joint not in (jointAdded):
                cmds.matchTransform(ref_joint,max_joint,rot=True,pos=True)
                          
def connectRefFbx(*arr):
    refName = cmds.textField("refName",query=True,text=True)
    if ("connectFbxAs" in dataSession) and refName !="":
        all_group_parent = cmds.group(empty=True,n="groupConstraintRefFbx")
        dataSession["groupConstraintRefFbx"] = all_group_parent
        pair = dataSession["connectFbxAs"]["pair"]        
        jointAdded = dataSession["connectFbxAs"]["jointAdded"]
        max_joint_array = []
        for a in range(len(pair)):
            if pair[a][0] not in max_joint_array:
                max_joint_array.append(pair[a][0])
        for a in max_joint_array:
            max_joint = a         
            ref_joint = refName+":"+max_joint
            if max_joint not in (jointAdded):
                connectMain(["RefFbx",dataSession["groupConstraintRefFbx"],ref_joint,max_joint])
                
def bakeAnimation(array,*arr):
    jointSourceArray = array["source"]
    jointDestArray = array["dest"]
    key_array = []
    data_animation = [] 
    for a in jointSourceArray:
        if "refName" in array:
            jointSource = array["refName"]+":"+a
        else:
            jointSource = a
        if cmds.objExists(jointSource):
            if cmds.keyframe(jointSource,query=True,timeChange=True):
                key_temp = cmds.keyframe(jointSource,query=True,timeChange=True)
                for i in key_temp:
                    if i not in key_array:
                        key_array.append(i)
    key_array = sorted(key_array)
    for a in range(len(key_array)):
        frame_data = [key_array[a],{}]      
        cmds.currentTime(key_array[a]) 
        for b in range(len(jointSourceArray)):          
            jointDest = jointDestArray[b]
            if "refName" in array:              
                jointSource = array["refName"]+":"+jointSourceArray[b]
            else:
                jointSource = jointSourceArray[b]
            if cmds.objExists(jointSource) and cmds.objExists(jointDest):
                if cmds.keyframe(jointSource,query=True,time=(key_array[a],key_array[a]),valueChange=True):
                    frame_data[1][jointDest]={
                        "translateX":cmds.getAttr(jointDest+".translateX"),
                        "translateY":cmds.getAttr(jointDest+".translateY"),
                        "translateZ":cmds.getAttr(jointDest+".translateZ"),
                        "rotateX":cmds.getAttr(jointDest+".rotateX"),
                        "rotateY":cmds.getAttr(jointDest+".rotateY"),
                        "rotateZ":cmds.getAttr(jointDest+".rotateZ"),
                        "scaleX":cmds.getAttr(jointDest+".scaleX"),
                        "scaleY":cmds.getAttr(jointDest+".scaleY"),
                        "scaleZ":cmds.getAttr(jointDest+".scaleZ"),                       
                    }
            elif not cmds.objExists(jointSource):
                if jointDest in ["PoleLeg_R","PoleLeg_L","PoleArm_R","PoleArm_L"]:
                    frame_data[1][jointDest]={
                        "translateX":cmds.getAttr(jointDest+".translateX"),
                        "translateY":cmds.getAttr(jointDest+".translateY"),
                        "translateZ":cmds.getAttr(jointDest+".translateZ"),
                        "rotateX":cmds.getAttr(jointDest+".rotateX"),
                        "rotateY":cmds.getAttr(jointDest+".rotateY"),
                        "rotateZ":cmds.getAttr(jointDest+".rotateZ"),
                        "scaleX":cmds.getAttr(jointDest+".scaleX"),
                        "scaleY":cmds.getAttr(jointDest+".scaleY"),
                        "scaleZ":cmds.getAttr(jointDest+".scaleZ"),                       
                    }   
        data_animation.append(frame_data)
    return data_animation
                                           
def bakeAnimationFbxAs(*arr):
    data =  dataSession["connectFbxAs"]["pair"]
    max_joint_array = list(zip(*data))[0]
    as_ctrl_array = list(zip(*data))[1]
    dataAnimation = bakeAnimation({
        "source":max_joint_array,
        "dest":as_ctrl_array,
    })              
    disconnect("groupConstraintFbxAs")  
    for a in range(len(dataAnimation)):
        cmds.currentTime(dataAnimation[a][0])
        data_temp = dataAnimation[a][1]
        for b in data_temp:
            for c in data_temp[b]:              
                if not cmds.getAttr(b+"."+c,lock=True) and cmds.getAttr(b+"."+c,keyable=True):
                    cmds.setAttr(b+"."+c,data_temp[b][c])
            pm.mel.eval('setKeyframe -breakdown 0 -preserveCurveShape 0 -hierarchy none -controlPoints 0 -shape 0 {"'+b+'"};')  
    cmds.currentTime(0) 
    
def bakeAnimationRefAs(*arr):
    refName = cmds.textField("refName",query=True,text=True)
    if refName!="":
        data =  dataSession["connectFbxAs"]["pair"]
        max_joint_array = list(zip(*data))[0]
        as_ctrl_array = list(zip(*data))[1]
        dataAnimation = bakeAnimation({
            "source":max_joint_array,
            "dest":as_ctrl_array,
            "refName":refName,
        })
        #   
        disconnect("groupConstraintRefFbx")
        cmds.currentTime(-1)        
        disconnect("groupConstraintFbxAs")
        #
        allCtrlArray = []
        for a in as_ctrl_array:
            allCtrlArray.append('"'+a+'"')
        pm.mel.eval('setKeyframe -breakdown 0 -preserveCurveShape 0 -hierarchy none -controlPoints 0 -shape 0 {'+",".join(allCtrlArray)+'};')
        #
        connectAsFbx()
        for a in range(len(dataAnimation)):
            cmds.currentTime(dataAnimation[a][0])
            data_temp = dataAnimation[a][1]
            stringName = []
            for b in data_temp:
                stringName.append('"'+b+'"')
                for c in data_temp[b]:              
                    if not cmds.getAttr(b+"."+c,lock=True) and cmds.getAttr(b+"."+c,keyable=True):
                        cmds.setAttr(b+"."+c,data_temp[b][c])
            pm.mel.eval('setKeyframe -breakdown 0 -preserveCurveShape 0 -hierarchy none -controlPoints 0 -shape 0 {'+",".join(stringName)+'};')  
        cmds.currentTime(-1)
    
def rotateFinger(*arr):
    ctrl = [
        "FKThumbFinger2_R","FKThumbFinger3_R",
        "FKIndexFinger1_R","FKIndexFinger2_R","FKIndexFinger3_R",
        "FKMiddleFinger1_R","FKMiddleFinger2_R","FKMiddleFinger3_R",
        "FKRingFinger1_R","FKRingFinger2_R","FKRingFinger3_R",
        "FKPinkyFinger1_R","FKPinkyFinger2_R","FKPinkyFinger3_R",
        
        "FKThumbFinger2_L","FKThumbFinger3_L",
        "FKIndexFinger1_L","FKIndexFinger2_L","FKIndexFinger3_L",
        "FKMiddleFinger1_L","FKMiddleFinger2_L","FKMiddleFinger3_L",
        "FKRingFinger1_L","FKRingFinger2_L","FKRingFinger3_L",
        "FKPinkyFinger1_L","FKPinkyFinger2_L","FKPinkyFinger3_L",       
    ]
    for a in ctrl:
        if cmds.objExists(a):
            groupSDK = "SDK"+a
            data_temp = {}     
            for b in ["rx","ry","rz"]:            
                if cmds.connectionInfo(groupSDK+"."+b, isDestination=True):
                    convertNode = cmds.connectionInfo(groupSDK+"."+b, sourceFromDestination=True)
                    data_temp["converse"+b] = convertNode.split(".")[0]
                    if  cmds.connectionInfo(data_temp["converse"+b]+".input", isDestination=True):
                        spreadNode = cmds.connectionInfo(data_temp["converse"+b]+".input", sourceFromDestination=True)
                        data_temp["bw"+b] = spreadNode.split(".")[0] 
                        if "_rotateY" in data_temp["bw"+b]:
                            data_temp["curlNode"] = data_temp["converse"+b]                        
                            if b == "rx":
                                data_temp["currentAxis"]="X"
                            elif b == "ry":
                                data_temp["currentAxis"]="Y"  
                            elif b == "rz":
                                data_temp["currentAxis"]="Z" 
                            pm.mel.eval('disconnectAttr '+data_temp["curlNode"]+'.output '+groupSDK+'.rotate'+data_temp["currentAxis"]+';')
                        if "_rotateZ" in data_temp["bw"+b]:                        
                            data_temp["spreadNode"] = data_temp["converse"+b]
                            if b == "rx":
                                data_temp["spreadAxis"]="X"
                            elif b == "ry":
                                data_temp["spreadAxis"]="Y"  
                            elif b == "rz":
                                data_temp["spreadAxis"]="Z" 
                            pm.mel.eval('disconnectAttr '+data_temp["spreadNode"]+'.output '+groupSDK+'.rotate'+data_temp["spreadAxis"]+';')  
                                                  
            axis = ["X","Y","Z"]
            for b in axis:
                try:
                    pm.mel.eval('setAttr "'+groupSDK+'.rotate'+b+'" 0;')
                except:pass
                
            currentIndex = axis.index(data_temp["currentAxis"])
            if currentIndex < (len(axis) - 1) :            
                nextIndex = currentIndex + 1                        
            else:
                nextIndex = 0
            pm.mel.eval('connectAttr -f '+data_temp["curlNode"]+'.output '+groupSDK+'.rotate'+axis[nextIndex]+';')
            
            if "spreadAxis" in data_temp:
                if data_temp["spreadAxis"]== axis[nextIndex]:
                    axis.remove(data_temp["spreadAxis"])
                    spreadAxis = axis[-1]
                    pm.mel.eval('connectAttr -f '+data_temp["spreadNode"]+'.output '+groupSDK+'.rotate'+spreadAxis+';')
                else:                
                    pm.mel.eval('connectAttr -f '+data_temp["spreadNode"]+'.output '+groupSDK+'.rotate'+data_temp["spreadAxis"]+';')

def rotateFingerSession(*arr):
    #unitConversion14.conversionFactor  
    if "rotateFinger" in dataSession:
        ctrl = dataSession["sdkFinger"]
        for a in ctrl:
            if cmds.objExists(a):
                groupSDK = "SDK"+a
                data_temp = {}     
                for b in ["rx","ry","rz"]:            
                    if cmds.connectionInfo(groupSDK+"."+b, isDestination=True):
                        convertNode = cmds.connectionInfo(groupSDK+"."+b, sourceFromDestination=True)
                        data_temp["converse"+b] = convertNode.split(".")[0]
                        pm.mel.eval('disconnectAttr '+data_temp["converse"+b]+'.output '+groupSDK+"."+b+';')
                        if  cmds.connectionInfo(data_temp["converse"+b]+".input", isDestination=True):
                            spreadNode = cmds.connectionInfo(data_temp["converse"+b]+".input", sourceFromDestination=True)
                            data_temp["bw"+b] = spreadNode.split(".")[0] 
                            if "_rotateY" in data_temp["bw"+b]:
                                data_temp["finger"]=data_temp["converse"+b]
                                cmds.setAttr(data_temp["converse"+b]+".conversionFactor",cmds.getAttr(data_temp["converse"+b]+".conversionFactor")*dataSession["rotateFinger"]["converse"])                                  
                            if "_rotateZ" in data_temp["bw"+b]:
                                data_temp["spread"]=data_temp["converse"+b]
                if "finger" in data_temp:
                    pm.mel.eval('connectAttr -f '+data_temp["finger"]+'.output '+groupSDK+'.rotate'+dataSession["rotateFinger"]["fingerAxis"]+';')
                if "spread" in data_temp:
                    pm.mel.eval('connectAttr -f '+data_temp["spread"]+'.output '+groupSDK+'.rotate'+dataSession["rotateFinger"]["spreadAxis"]+';')
        
def inverseRotateFinger(*arr):
    reverseNode = []
    ctrl = dataSession["sdkFinger"]
    for a in ctrl:
        if cmds.objExists(a):
            groupSDK = "SDK"+a
            data_temp = {}
            for b in ["rx","ry","rz"]:            
                if cmds.connectionInfo(groupSDK+"."+b, isDestination=True):
                    convertNode = cmds.connectionInfo(groupSDK+"."+b, sourceFromDestination=True)
                    data_temp["converse"+b] = convertNode.split(".")[0]
                    if  cmds.connectionInfo(data_temp["converse"+b]+".input", isDestination=True):
                        spreadNode = cmds.connectionInfo(data_temp["converse"+b]+".input", sourceFromDestination=True)
                        data_temp["bw"+b] = spreadNode.split(".")[0] 
                        if "_rotateY" in data_temp["bw"+b]:
                            reverseNode.append(data_temp["converse"+b])
    for a in reverseNode:
        pm.mel.eval('setAttr "'+a+'.conversionFactor" '+str(pm.mel.eval('getAttr "'+a+'.conversionFactor"')*(-1))+';')
        
def rotateSpread(*arr):
    ctrl = dataSession["sdkSpread"]
    for a in ctrl:
        if cmds.objExists(a):
            groupSDK = "SDK"+a
            data_temp = {}
            axis = ["X","Y","Z"]
            axisFree = []
            for b in axis:            
                if cmds.connectionInfo(groupSDK+".rotate"+b, isDestination=True):
                    convertNode = cmds.connectionInfo(groupSDK+".rotate"+b, sourceFromDestination=True)
                    data_temp["converse"+b] = convertNode.split(".")[0]                
                    if  cmds.connectionInfo(data_temp["converse"+b]+".input", isDestination=True):
                        spreadNode = cmds.connectionInfo(data_temp["converse"+b]+".input", sourceFromDestination=True)
                        data_temp["bw"+b] = spreadNode.split(".")[0]
                        if "_rotateZ" in data_temp["bw"+b]:                        
                            data_temp["spreadNode"] = data_temp["converse"+b]
                            data_temp["spreadAxis"] = b
                            pm.mel.eval('disconnectAttr '+data_temp["spreadNode"]+'.output '+groupSDK+'.rotate'+data_temp["spreadAxis"]+';')
                else:
                    axisFree.append(b)                                                               
            axis = ["X","Y","Z"]
            for b in axis:
                try:
                    pm.mel.eval('setAttr "'+groupSDK+'.rotate'+b+'" 0;')
                except:pass
            pm.mel.eval('connectAttr -f '+data_temp["spreadNode"]+'.output '+groupSDK+'.rotate'+axisFree[0]+';')

def saveOldGuide(*arr):
    global dataSession
    childrenGuide = cmds.listRelatives("FitSkeleton",ad=True,pa=True,type="joint")[::-1]
    data_temp = []
    for a in childrenGuide:
        data_temp.append([
            a,[
                pm.mel.eval('getAttr "'+a+'.translateX";'),
                pm.mel.eval('getAttr "'+a+'.translateY";'),
                pm.mel.eval('getAttr "'+a+'.translateZ";'),
                pm.mel.eval('getAttr "'+a+'.rotateX";'),
                pm.mel.eval('getAttr "'+a+'.rotateY";'),
                pm.mel.eval('getAttr "'+a+'.rotateZ";')
            ]
        ])
    dataSession["oldGuide"] = data_temp
    
def removeOldGuide(*arr):
    global dataSession
    if "oldGuide" in dataSession:
        del(dataSession["oldGuide"])
    print("Deleted Old Guide data.")
        
def matchOldCtrl(*arr):    
    oldCtrl = cmds.textField("matchOldCtrlUrl",q=True,text=True)
    if oldCtrl != "":
        cmds.file(oldCtrl, reference=True,mergeNamespacesOnClash=False,namespace="oldCtrl")
        listControl = list(zip(*dataSession["connectFbxAs"]["pair"]))[1]  
        for a in listControl:
            currentCtrl = a
            refCtrl = "oldCtrl:"+a
            cmds.matchTransform(currentCtrl,refCtrl)
        for a in listControl:
            flag = False
            for b in ["translate","rotate"]:
                for c in ["X","Y","Z"]:
                    if cmds.getAttr(a+"."+b+c) > 0.0000001 or cmds.getAttr(a+"."+b+c) < -0.0000001:
                        flag = True
            if flag == True:
                cmds.select(a)
                clearOffset()                  
        cmds.file(oldCtrl,removeReference=True)        
        



                    

                           

requireTab = "NLTA_Attr"
import os
import maya.cmds as cmds
import pymel.all as pm
import general
from functools import partial
cmds.selectPref( trackSelectionOrder=1 )

workLocation = None
def createLayout(per,lib,*arr):
    if per == "NLTA_Attr":
        cmds.rowColumnLayout(nc=4,parent="NLTA_Attr") 
        cmds.button(label="Get Attribute",width=100,)
        cmds.setParent( '..' )

def LoadItems(*arr):
    pass


def SourceFolder(*arr):
    global workLocation
    url = cmds.fileDialog2(dialogStyle=2, fileMode=3, caption="Select Source")
    if url:
        url = url[0]
        workLocation = {
            "main":url
        }

def ScreenSnapShot(*arr):
    if workLocation !=None:
        if len(cmds.ls(selection=True))!= 0 and len(cmds.listRelatives(cmds.ls(selection=True)[0],shapes=True))!=0:
            username = os.environ.get("USERNAME")
            folderTemp = "C:/Users/"+username+"/Documents/maya/scripts/nlta_folder_data"
            if not os.path.exists(folderTemp):
                os.makedirs(folderTemp)
                os.makedirs(folderTemp+"/data")
                os.makedirs(folderTemp+"/icon")
                
            sourceJson = folderTemp+"/data/control_shape.json"
            sourceIcon = folderTemp+"/icon/"
            if not os.path.exists(sourceJson):
                dataShapeTemp = {}
            else:            
                filePath = cmds.encodeString(sourceJson)
                myFile =  open(filePath,'r')
                myObject = myFile.read()
                myFile.close()
                dataShapeTemp = json.loads(myObject)     
                     
            timeString = str(cmds.date()).replace("/","_").replace(":","_").replace(" ","_")
            nameCurve = "shape_" + timeString       
            namePic = "pic_" + timeString + ".png"
            
            sourceImage = sourceIcon + "/" +  namePic
            currentFrame = int(cmds.currentTime (q=True))
            cmds.playblast(frame=currentFrame, cf=sourceImage, fmt="image",orn=0,os=1,wh=[500,500],p=100,v=False)   
            dataShapeTemp[nameCurve] = [namePic,curveShapeTemp]       
            with open(sourceJson,"w") as json_file:
                json.dump(dataShapeTemp,json_file,sort_keys=False)
            loadYourShape(gridName)
        else:
            cmds.confirmDialog(title="Confirm",message="Please choose shape",button=["Yes"],defaultButton="Yes",cancelButton="Yes")

def SaveAsset(*arr):
    pass

def LoadAsset(*arr):
    pass

import maya.cmds as cmds
source_object = 'pCube2'
from math import sqrt

def GetDistance(obj1, obj2,*arr):
    pos1 = cmds.xform(obj1, query=True, worldSpace=True, translation=True)
    pos2 = cmds.xform(obj2, query=True, worldSpace=True, translation=True)
    distance = sqrt((pos2[0] - pos1[0])**2 + (pos2[1] - pos1[1])**2 + (pos2[2] - pos1[2])**2)
    return(distance)

def CreateFrameJoints(objName,*arr):    
    bbox = cmds.exactWorldBoundingBox(source_object)
    cmds.select(clear=True)
    NegY = cmds.joint(position=(0,bbox[1], 0), name=objName+'NegY')    
    Y = cmds.group(empty=True, name=objName+'Y')
    cmds.xform(Y, worldSpace=True, translation=(0,bbox[4], 0))
    
    NegX = cmds.group(empty=True, name=objName+'NegX')
    cmds.xform(NegX, worldSpace=True, translation=(bbox[0],bbox[1], 0))
    
    X = cmds.group(empty=True, name=objName+'X')
    cmds.xform(X, worldSpace=True, translation=(bbox[3],bbox[1], 0))
    
    NegZ = cmds.group(empty=True, name=objName+'NegZ')
    cmds.xform(NegZ, worldSpace=True, translation=(0,bbox[1],bbox[2]))
    
    Z = cmds.group(empty=True, name=objName+'Z')
    cmds.xform(Z, worldSpace=True, translation=(0,bbox[1],bbox[5]))    
    
    cmds.parent(Y,NegY)
    cmds.parent(NegX,NegY)
    cmds.parent(X,NegY)
    cmds.parent(NegZ,NegY)
    cmds.parent(Z,NegY)
    cmds.parent(objName,NegY)
    cmds.xform(NegY, worldSpace=True, translation=(0,0,0))
    for obj in [Y,NegX,X,NegZ,Z]:
        cmds.setAttr('{}.hiddenInOutliner'.format(obj),True)

def MatchSide(source,target,side,*arr):
    sourcePreference = source.replace("NegY",side)
    targetPreference = target.replace("NegY",side)
    targetDistance = GetDistance(target,targetPreference)
    sourceDistance = GetDistance(source,sourcePreference)
    translation = cmds.xform(targetPreference,query=True,worldSpace=True, translation=True)    
    cmds.select(source)
    jointTemp = cmds.joint(name=source+'Temp',position=translation)
    jointTempTranslateAdd =  targetDistance + sourceDistance
    cmds.setAttr(jointTemp+".translate"+side,jointTempTranslateAdd)
    cmds.matchTransform(target,jointTemp)
    cmds.delete(jointTemp)

        
    
    

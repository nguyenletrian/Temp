"""
path = 'C:/Users/an.nguyen_g/Desktop/morph/'
mesh = 'FBX_Musky_Model_1'
zeroPos1 = {'max':1}
neg1Pos1 = {'min':-1,'max':1}
zeroPos10 = {'max':10}
neg10Pos10 = {'min':-10,'max':10}
attrArray = {
	'ctrlBrow_R':{'translateX':neg1Pos1,'translateY':neg1Pos1,'squeeze':zeroPos10 ,'outerUpDown':zeroPos10 },
	'ctrlBrow_L':{'translateX':neg1Pos1,'translateY':neg1Pos1,'squeeze':zeroPos10 ,'outerUpDown':zeroPos10 },
	'ctrlEye_R':{'translateX':neg1Pos1,'translateY':neg1Pos1,'blink':zeroPos10 ,'squint':zeroPos10 },
	'ctrlEye_L':{'translateX':neg1Pos1,'translateY':neg1Pos1,'blink':zeroPos10 ,'squint':zeroPos10 },
	'ctrlCheek_R':{'translateX':neg1Pos1,'translateY':neg1Pos1},
	'ctrlCheek_L':{'translateX':neg1Pos1,'translateY':neg1Pos1},
	'ctrlNose_L':{'translateX':neg1Pos1,'translateY':neg1Pos1},
	'ctrlNose_R':{'translateX':neg1Pos1,'translateY':neg1Pos1},
	'ctrlMouth_M':{
	    'translateX':neg1Pos1,
	    'translateY':neg1Pos1,
	    'upperPress':neg10Pos10,
	    'lowerPress':neg10Pos10,
	    'upperSqueeze':neg10Pos10,
	    'lowerSqueeze':neg10Pos10,
	    'upperRoll':neg10Pos10,
	    'lowerRoll':neg10Pos10,
	    'upperPucker':neg10Pos10,
	    'lowerPucker':neg10Pos10,
	    'jawForward':neg10Pos10,
	    'jawSide':neg10Pos10,
	    'lipSide':neg10Pos10,
	},
	'ctrlPhonemes_M':{
		'aaa':zeroPos10,
		'eh':zeroPos10,
		'ahh':zeroPos10,
		'ohh':zeroPos10,
		'uuu':zeroPos10,
		'iee':zeroPos10,
		'rrr':zeroPos10,
		'www':zeroPos10,
		'sss':zeroPos10,
		'fff':zeroPos10,
		'tth':zeroPos10,
		'mbp':zeroPos10,
		'ssh':zeroPos10,
		'schwa':zeroPos10,
		'gk':zeroPos10,
		'lntd':zeroPos10,
	},
	'ctrlMouthCorner_R':{
		'translateX':neg1Pos1,
		'translateY':neg1Pos1
	},
	'ctrlMouthCorner_L':{
		'translateX':neg1Pos1,
		'translateY':neg1Pos1
	},
	"ctrlEmotions_M":{
		'happy':zeroPos10,
		'angry':zeroPos10,
		'sad':zeroPos10,
		'surprise':zeroPos10,
		'fear':zeroPos10,
		'disgust':zeroPos10,
		'contempt':zeroPos10,
	}	
}
meshArray = []
for ctrl in attrArray:
    ctrlData = attrArray[ctrl]
    for attr in ctrlData:
        attrRange = ctrlData[attr]        
        for value in attrRange:
            fbxPath = path + ctrl+'_'+attr+"_"+ value + '.fbx'
            cmds.setAttr(ctrl+'.'+attr,attrRange[value])
            newMesh = cmds.duplicate(mesh)
            cmds.rename(newMesh,ctrl+'_'+attr+"_"+ value)
            meshArray.append(ctrl+'_'+attr+"_"+ value)
            cmds.setAttr(ctrl+'.'+attr,0)
cmds.blendShape(meshArray,mesh,name='BlendShape')[0]
cmds.delete(meshArray)
"""
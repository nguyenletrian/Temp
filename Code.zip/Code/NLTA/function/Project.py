requireTab = "Project"
import os,json,general,importlib
import maya.cmds as cmds
import pymel.core as pm
from functools import partial
import xml.dom.minidom as xd

def createLayout(per,lib,*arr):
	cmds.rowColumnLayout("ProjectListButton",numberOfColumns=4,parent="Project")
	cmds.setParent("..")
	if per == "Project":
		Project = cmds.getFileList(folder=lib["sever"] + "Project/")
		for a in Project:
			if a.endswith(".py"):
				libTemp = a.split(".")[0]
				if cmds.window(libTemp+"Window", query = True, exists = True):
					cmds.deleteUI(libTemp+"Window")

				moduleName = importlib.import_module(libTemp)
				if int(cmds.about(version=True)) < 2022:
					reload(moduleName)
				else:
					importlib.reload(moduleName)
				cmds.button(label=libTemp,width=100,parent="ProjectListButton",c=partial(openProjectLayout,[libTemp,moduleName]))

def openProjectLayout(array,*arr):
	if cmds.window(array[0]+"Window", query = True, exists = True):
		cmds.deleteUI(array[0]+"Window")
	array[1].createLayout()

   
requireTab = "NLTA_Attr"
import os
import maya.cmds as cmds
import pymel.all as pm
import general
from functools import partial
cmds.selectPref( trackSelectionOrder=1 )
def createLayout(per,lib,*arr):
	if per == "NLTA_Attr":
		cmds.rowColumnLayout(nc=4,parent="NLTA_Attr") 
		cmds.button(label="Get Attribute",width=100,c=GetAttribute)
		cmds.button(label="Direct Connect",width=100,c=partial(ConnectAttribute,"direct"))
		cmds.button(label="Smart Connect",width=100,c=partial(ConnectAttribute,"smart"))
		cmds.textField("NewAttributeName",width=100)
		cmds.button(label="Create Attribute",width=100,c=CreateAttribute)
		cmds.setParent( '..' )

def GetCurrentSelected(*arr):
	objs =  cmds.ls(selection=True)
	if objs:
		returnData = {
			"allAttr":[]
		}
		mainAttr = cmds.channelBox("mainChannelBox",query=True,sma=True)
		if mainAttr:
			returnData["main"] = mainAttr
			returnData["allAttr"].extend(mainAttr)
		shapeAttr = cmds.channelBox("mainChannelBox",query=True,ssa=True)
		if shapeAttr:
			returnData["shape"] = shapeAttr
			returnData["allAttr"].extend(shapeAttr)
		inputAttr = cmds.channelBox("mainChannelBox",query=True,sha=True)
		if inputAttr:
			returnData["input"] = inputAttr
			returnData["allAttr"].extend(inputAttr)
		outputAttr = cmds.channelBox("mainChannelBox",query=True,soa=True)
		if outputAttr:
			returnData["output"] = outputAttr
			returnData["allAttr"].extend(outputAttr)
		for obj in objs:
			maxIncrease = len(returnData["allAttr"])
			numberIncrease = 0
			for attr in returnData["allAttr"]:
				if cmds.attributeQuery(attr,node=obj,ex=True):
					numberIncrease +=1
			if maxIncrease == numberIncrease:
				returnData["obj"] = obj
		return(returnData)
	return(None)

def GetAttrSetting(data,*arr):
	returnData = {
		"obj":data["obj"],
		"attr":data["attr"],
		"key":cmds.getAttr(data["obj"]+"."+data["attr"],keyable=True),
		"hide":cmds.addAttr(data["obj"]+"."+data["attr"],query=True,hidden=True),
		"type":cmds.getAttr(data["obj"]+"."+data["attr"],typ=True),
		"defaultValue":cmds.addAttr(data["obj"]+"."+data["attr"],query=True,dv=True),
	}
	if cmds.addAttr(data["obj"]+"."+data["attr"],query=True,max=True):
		returnData["max"] = cmds.addAttr(data["obj"]+"."+data["attr"],query=True,max=True)
	if cmds.addAttr(data["obj"]+"."+data["attr"],query=True,min=True):
		returnData["min"] = cmds.addAttr(data["obj"]+"."+data["attr"],query=True,min=True)
	return(returnData)


currentAttribute = None
def GetAttribute(*arr):
	global currentAttribute
	selected = GetCurrentSelected()
	if selected:
		if selected["allAttr"]:
			currentAttribute = GetAttrSetting({
				"obj":selected["obj"],
				"attr":selected["allAttr"][0]
			})
			return(currentAttribute)
		else:
			print("No Attibute selected")

def SmartConnect(sourceSetting,targetSetting,*arr):
	if ("max" in sourceSetting) and ("max" in targetSetting) and ("min" in sourceSetting) and ("min" in targetSetting):
		if (sourceSetting["max"] != targetSetting["max"]) or (sourceSetting["min"] != targetSetting["min"]):
			remap = cmds.createNode('remapValue', name=sourceSetting["obj"]+"_"+targetSetting["obj"]+'_Remap')
			cmds.connectAttr(sourceSetting["obj"]+"."+sourceSetting["attr"],remap+".inputValue",f=True)
			cmds.setAttr(remap+".inputMin",sourceSetting["min"])
			cmds.setAttr(remap+".inputMax",sourceSetting["max"])
			cmds.setAttr(remap+".outputMin",targetSetting["min"])
			cmds.setAttr(remap+".outputMax",targetSetting["max"])
			cmds.connectAttr(remap+".outValue",targetSetting["obj"]+"."+targetSetting["attr"],f=True)
		else:
			cmds.connectAttr(sourceSetting["obj"]+"."+sourceSetting["attr"],targetSetting["obj"]+"."+tagertSetting["attr"],f=True)
	else:
		cmds.connectAttr(sourceSetting["obj"]+"."+sourceSetting["attr"],targetSetting["obj"]+"."+tagertSetting["attr"],f=True)
def DirectConnect(sourceSetting,targetSetting,*arr):
	cmds.connectAttr(sourceSetting["obj"]+"."+sourceSetting["attr"],targetSetting["obj"]+"."+targetSetting["attr"],f=True)	


def ConnectAttribute(connectType,*arr):
	if currentAttribute:
		source = currentAttribute
		target = GetAttribute()
		if connectType == "direct":
			DirectConnect(source,target)
		elif connectType == "smart":
			SmartConnect(source,target)

def CreateAttribute(*arr):
	attributeName = cmds.textField("NewAttributeName",width=100,query=True,text=True)
	selected = GetCurrentSelected()
	attributeArray = []
	if "min" in currentAttribute:
		attributeArray.append("minValue="+str(currentAttribute["min"]))
	if "max" in currentAttribute:
		attributeArray.append("maxValue="+str(currentAttribute["max"]))
	if "key" in currentAttribute:
		attributeArray.append("keyable="+str(currentAttribute["key"]))
	if "defaultValue" in currentAttribute:
		attributeArray.append("defaultValue="+str(currentAttribute["defaultValue"]))
	if "hide" in currentAttribute:
		attributeArray.append("h="+str(currentAttribute["hide"]))
	exec("cmds.addAttr('"+selected["obj"]+"',sn='"+attributeName+"',"+(",").join(attributeArray)+")")



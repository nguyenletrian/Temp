requireTab = "Scene"
import os, general, json,A_skinning
import maya.cmds as cmds
import pymel.all as pm
from functools import partial

dataSession = []
def createLayout(per,lib,*arr):
    if per == "Scene":
        cmds.rowColumnLayout(numberOfColumns=1,parent="Scene")

        cmds.rowColumnLayout(numberOfColumns=1)
        cmds.textField(text="Space Num",editable=False)
        cmds.scrollField("spaceNumText",wordWrap=True,width=400,height=50,fns=8)
        cmds.textField(text="Space Float",editable=False)
        cmds.scrollField("spaceFloatText",wordWrap=True,width=400,height=50,fns=8)
        cmds.setParent("..")

        cmds.rowColumnLayout(numberOfColumns=4,width=390)
        cmds.button(label="New",width=100,c=addNew)
        cmds.button(label="Import",width=100,c=importData)
        cmds.button(label="Quick Import",width=100,c=quickImport)
        cmds.button(label="Export",width=100,c=exportData)
        cmds.setParent("..")

        cmds.rowColumnLayout(numberOfColumns=4,width=390)
        cmds.button(label="Current P-Script",width=100,c=RunCurrentPostScript)
        cmds.button(label="Up P-Script",width=100,c=RunUpPostScript)
        cmds.button(label="Up A-Script",width=100,c=RunUpAfterScript)
        
        cmds.setParent("..")

        cmds.setParent("..")
        cmds.rowColumnLayout("scriptContainer",numberOfColumns=3,parent="Scene")
        cmds.setParent("..")

def createSpace(*arr):
    spaceText = cmds.scrollField("spaceNumText",query=True,text=True)
    if spaceText!="":
        spaceText = spaceText.strip().split("\n")
        for a in spaceText:
            dataTemp = a.split(",")
            constraintName = setup.spaceNum(dataTemp)
            cmds.parent(constraintName,"connectGroupContent")

    spaceText = cmds.scrollField("spaceFloatText",query=True,text=True)
    if spaceText!="":
        spaceText = spaceText.strip().split("\n")
        for a in spaceText:
            dataTemp = a.split(",")
            constraintName = setup.spaceFloat(dataTemp)
            cmds.parent(constraintName,"connectGroupContent")


def setMaxInfluent(maxValue,*arr):
    maxInfluent = maxValue
    if maxInfluent!=0:
        A_skinning.fixMaxInfluent(maxInfluent)
        A_skinning.setInfluence(maxInfluent)

def addNew(*arr):
    global dataSession
    result = cmds.promptDialog(
        title='Create new script',
        message='Enter name of scipt (Camel rule):',
        button=['OK', 'Cancel'],
        defaultButton='OK',
        cancelButton='Cancel',
        dismissString='Cancel')
    if result == 'OK':
        textInput = cmds.promptDialog(query=True, text=True)
        if textInput not in dataSession:
            cmds.rowColumnLayout(textInput+"_ItemContent",numberOfColumns=1,parent="scriptContainer")#OPEN ITEM
            cmds.rowColumnLayout(numberOfColumns=1)#LEFT OPEN
            cmds.textField(textInput+"_ItemName",pht="Name of script",width=390,text = textInput,editable=False) 
            cmds.setParent("..")#LEFT CLOSE

            cmds.rowColumnLayout(numberOfColumns=2,)
            cmds.scrollField(textInput+"_ItemText",wordWrap=True,width=320,height=150,fns=8)
            cmds.rowColumnLayout(numberOfColumns=1,width=70)#RIGHT OPEN
            cmds.button(label="Add Link",width=70,height=30,c=partial(addLink,textInput+"_ItemText"))
            cmds.button(label="Run",width=70,height=30,c=partial(runScript,textInput+"_ItemText"))
            cmds.button(label="Delete",width=70,height=30,c=partial(deleteScript,textInput))
            cmds.setParent("..")#RIGHT CLOSE
            cmds.setParent("..")

            cmds.setParent("..")
            dataSession.append(textInput)
        else:
            cmds.confirmDialog(title="Warning",message="The name of script already exists!",button=["Yes"],defaultButton="Yes",cancelButton="Yes")  


def addLink(inputName,*arr):
    url = pm.fileDialog2(fileMode=1)
    if url:     
        url = url[0]
        currentText = cmds.scrollField(inputName,query=True,text=True)
        newText = currentText + """
"""+url+"""
"""
        cmds.scrollField(inputName,edit=True,text=newText)

def runScript(scriptName,*arr):
    general.runScript(scriptName)

def deleteScript(scriptName,*arr):
    global dataSession
    #input = cmds.rowColumnLayout("inputJoint", q = True, ca= True)
    cmds.deleteUI(scriptName+"_ItemContent")
    dataSession.remove(scriptName)

def exportData(*arr):
    folderTemp = os.path.dirname(pm.sceneName())
    if not folderTemp:
        folderTemp = pm.mel.eval("SaveSceneAs;")
    if folderTemp:
        folderTemp = os.path.dirname(pm.sceneName())
        file_path = folderTemp+"/dataScript.json"
        dataExport = []
        for a in dataSession:
            dataExport.append({
                "name":a,
                "text":cmds.scrollField(a+"_ItemText",query=True,text=True)
            })
        with open(file_path,"w") as json_file:
            json.dump(dataExport,json_file,sort_keys=False)
            cmds.warning("Url export: " + file_path)

def importDefault(url,*arr):    
    global dataSession
    if os.path.exists(url):        
        input = cmds.rowColumnLayout("scriptContainer", q = True, ca= True)
        if input:
            for a in input:
                try:
                    cmds.deleteUI(a)
                except:pass
        data = general.readJsonFile(url)
        for a in range(len(data)):
            name = data[a]["name"]
            text = data[a]["text"]
            dataSession.append(name)
            cmds.rowColumnLayout(name+"_ItemContent",numberOfColumns=1,parent="scriptContainer")#OPEN ITEM
            cmds.rowColumnLayout(numberOfColumns=1)#LEFT OPEN
            cmds.textField(name+"_ItemName",pht="Name of script",width=390,text = name, editable=False) 
            cmds.setParent("..")#LEFT CLOSE

            cmds.rowColumnLayout(numberOfColumns=2,)
            cmds.scrollField(name+"_ItemText",wordWrap=True,width=320,height=150,fns=8,text = text)
            cmds.rowColumnLayout(numberOfColumns=1,width=70)#RIGHT OPEN
            cmds.button(label="Add Link",width=70,height=30,c=partial(addLink,name+"_ItemText"))
            cmds.button(label="Run",width=70,height=30,c=partial(runScript,name+"_ItemText"))
            cmds.button(label="Delete",width=70,height=30,c=partial(deleteScript,name))
            cmds.popupMenu()
            cmds.menuItem(label="Delete")
            cmds.setParent("..")#RIGHT CLOSE
            cmds.setParent("..")

            cmds.setParent("..")

def importData(*arr):
    url = pm.fileDialog2(fileMode=1)
    if url:
        importDefault(url[0])    

def quickImport(*arr):
    folderTemp = os.path.dirname(pm.sceneName())
    if not folderTemp:
        folderTemp = pm.mel.eval("SaveSceneAs;")
    if folderTemp:
        folderTemp = os.path.dirname(pm.sceneName())
        filePath = folderTemp+"/dataScript.json"
        if not os.path.exists(filePath):
            cmds.confirmDialog(title="Confirm",message="Dont have data!",button=["Yes"],defaultButton="Yes",cancelButton="Yes") 
        else:
            importDefault(filePath)

def RunCurrentPostScript(*arr):
    folderTemp = os.path.dirname(pm.sceneName())
    if not folderTemp:
        folderTemp = pm.mel.eval("SaveSceneAs;")
    if folderTemp:
        folderTemp = os.path.dirname(pm.sceneName())
        general.RunScriptFile(folderTemp+'/PostScript.py')

def RunUpPostScript(*arr):
    folderTemp = os.path.dirname(pm.sceneName())
    if not folderTemp:
        folderTemp = pm.mel.eval("SaveSceneAs;")
    if folderTemp:
        folderTemp = ("/").join(os.path.dirname(pm.sceneName()).split('/')[0:-1])
        general.RunScriptFile(folderTemp+'/PostScript.py')

def RunUpAfterScript(*arr):
    folderTemp = os.path.dirname(pm.sceneName())
    if not folderTemp:
        folderTemp = pm.mel.eval("SaveSceneAs;")
    if folderTemp:
        folderTemp = ("/").join(os.path.dirname(pm.sceneName()).split('/')[0:-1])
        general.RunScriptFile(folderTemp+'/AfterScript.py')

import maya.cmds as cmds
source_object = 'pCube2'
from math import sqrt,pi

cmds.selectPref( trackSelectionOrder=1 )


def ShowBoundingBox():
    object_name = 'pCube3'
    bbox = cmds.exactWorldBoundingBox(object_name)
    bbox_cube = cmds.polyCube(name='bboxCube')[0]
    center = [(bbox[0] + bbox[3]) / 2, (bbox[1] + bbox[4]) / 2, (bbox[2] + bbox[5]) / 2]
    size = [bbox[3] - bbox[0], bbox[4] - bbox[1], bbox[5] - bbox[2]]
    cmds.move(center[0], center[1], center[2], bbox_cube)
    cmds.scale(size[0], size[1], size[2], bbox_cube)

def GetDistance(obj1, obj2,*arr):
    pos1 = cmds.xform(obj1, query=True, worldSpace=True, translation=True)
    pos2 = cmds.xform(obj2, query=True, worldSpace=True, translation=True)
    distance = sqrt((pos2[0] - pos1[0])**2 + (pos2[1] - pos1[1])**2 + (pos2[2] - pos1[2])**2)
    return(distance)

def SetupObject(*arr):
    objs = cmds.ls(selection=True)
    for obj in objs:
        objName = obj
        
        bbox = cmds.exactWorldBoundingBox(objName)
        
        cmds.select(clear=True)
        NegY = cmds.joint(position=(0,bbox[1], 0), name=objName+'NegY')    
        
        contain = cmds.group(empty=True, name=objName+"contain")
        cmds.xform(contain, worldSpace=True, translation=(0,0,0))
        
        Y = cmds.group(empty=True, name=objName+'Y')
        cmds.xform(Y, worldSpace=True, translation=(0,bbox[4], 0))
        
        NegX = cmds.group(empty=True, name=objName+'NegX')
        cmds.xform(NegX, worldSpace=True, translation=(bbox[0],bbox[1], 0))
        
        X = cmds.group(empty=True, name=objName+'X')
        cmds.xform(X, worldSpace=True, translation=(bbox[3],bbox[1], 0))
        
        NegZ = cmds.group(empty=True, name=objName+'NegZ')
        cmds.xform(NegZ, worldSpace=True, translation=(0,bbox[1],bbox[2]))
        
        Z = cmds.group(empty=True, name=objName+'Z')
        cmds.xform(Z, worldSpace=True, translation=(0,bbox[1],bbox[5]))    
        
        for obj in [Y,NegX,X,NegZ,Z,contain]:
            #cmds.setAttr('{}.hiddenInOutliner'.format(obj),True)
            cmds.makeIdentity(obj, apply=True, translate=True, rotate=True, scale=True)
        cmds.makeIdentity(objName, apply=True, translate=True, rotate=True, scale=True)
           
        cmds.parent(Y,NegY)
        cmds.parent(NegX,NegY)
        cmds.parent(X,NegY)
        cmds.parent(NegZ,NegY)
        cmds.parent(Z,NegY)        
        cmds.parent(objName,NegY)
        cmds.xform(NegY, worldSpace=True, translation=(0,0,0))
        cmds.parent(objName,contain)
        cmds.parent(contain,NegY)
        """ 
        for obj in [Y,NegX,X,NegZ,Z,contain]:
            cmds.setAttr('{}.hiddenInOutliner'.format(obj),True)
            cmds.makeIdentity(obj, apply=True, translate=True, rotate=True, scale=True)
            
        cmds.makeIdentity(obj, apply=True, translate=True, rotate=True, scale=True)
        cmds.setAttr('{}.overrideEnabled'.format(objName), 1)
        cmds.setAttr('{}.overrideDisplayType'.format(objName), 2)
        cmds.select(NegY)
        """
def MatchSide(source,target,side,*arr):
    sourcePreference = source.replace("NegY",side)
    targetPreference = target.replace("NegY",side)
    targetDistance = GetDistance(target,targetPreference)
    sourceDistance = GetDistance(source,sourcePreference)
    translation = cmds.xform(targetPreference,query=True,worldSpace=True, translation=True)    
    cmds.select(source)
    jointTemp = cmds.joint(name=source+'Temp',position=translation)
    jointTempTranslateAdd =  targetDistance + sourceDistance
    for axis in ["X","Y","Z"]:
        cmds.setAttr(jointTemp+".translate"+axis,0)    
    cmds.setAttr(jointTemp+".translate"+side,jointTempTranslateAdd)
    cmds.matchTransform(target,jointTemp)
    #cmds.delete(jointTemp)
"""    


def GetWorldTransform(obj,*arr):
    sourceTemp = cmds.spaceLocator(name = source+'_GetDistance')[0]
    cmds.matchTransform(sourceTemp,source,pos=True,rot=True)
    transform = {
        "translate":cmds.xform(sourceTemp, q=True, ws=True, t=True)
"""            
    
def CreateJointChain(objs,*arr):
    joints = []
    for obj in objs:
        jointName = obj+"_Temp"
        cmds.select(clear=True)
        translate = cmds.xform(obj, q=True, ws=True, t=True)
        cmds.joint(n=jointName,p=translate)
        joints.append(jointName)
    joints = joints[::-1]
    for obj in range(len(joints) - 1):
        cmds.parent(joints[obj],joints[obj+1])
    jointStart = joints[-1]
    jointEnd = joints[0]
    cmds.joint(jointStart,edit=True,orientJoint='xyz',secondaryAxisOrient='yup',children=True,zeroScaleOrient=True)
    cmds.joint(jointEnd,edit=True,orientJoint='none',children=True,zeroScaleOrient=True)
    return(joints[::-1])
    
def CreateCurve(objs,*arr):
    returnData = []
    for obj in objs:
        curveName = obj+'Curve'
        pm.mel.eval('curve -n "'+curveName+'" -d 3 -p 0 0 -10 -p 0 0 -3.333333 -p 0 0 3.333333 -p 0 0 10 -k 0 -k 0 -k 0 -k 1 -k 1 -k 1 ;')
        cmds.matchTransform(curveName,obj,rot=True,pos=True)
        returnData.append(curveName)
    return(returnData)

def GetSurfaceUV(obj):
    if not cmds.objExists(obj):
        cmds.warning(obj+' does not exist!')
        return()
    spans_u = cmds.getAttr(obj+'.spansU')
    spans_v = cmds.getAttr(obj+'.spansV')
    edgesU = []
    edgesV = []
    for i in range(spans_u + 1):
        edgesU.append(obj+'.u['+str(i)+']')
    for i in range(spans_v + 1):
        edgesV.append(obj+'.v['+str(i)+']')
    return({
       "u":edgesU,
       "v":edgesV
    })

def GetClosestUV(objName,surfaceName,*arr):
    UVedges = GetSurfaceUV(surfaceName)
    position = cmds.xform(objName,query=True,ws=True,translation=True)
    node = cmds.createNode("closestPointOnSurface")
    cmds.connectAttr(surfaceName+'.worldSpace[0]',node+'.inputSurface',force=True)
    cmds.setAttr(node+'.inPosition',position[0],position[1],position[2],type='double3')
    u =  cmds.getAttr(node+'.parameterU')
    v =  cmds.getAttr(node+'.parameterV')
    cmds.delete(node)
    return({
       "u":u/(len(UVedges['u'])-1),
       "v":v/(len(UVedges['v'])-1)
    })

def CreateFollicle(objs,surfaceName,*arr):
    follicleContain = "NLTA_Follicle_Contain"
    if not cmds.objExists(follicleContain):
        cmds.group(name=follicleContain,empty=True)
    for obj in objs:
        objName = obj
        objParent = None
        constraintGroup = objName+'_Constraint_Grp'
        offsetGroup =  objName+'_Offset_Grp'
        for groupName in [constraintGroup,offsetGroup]:
            groupTemp = cmds.group(name=groupName,empty=True)
            cmds.matchTransform(groupTemp,objName,pos=True,rot=True)
        cmds.parent(offsetGroup,constraintGroup)
        cmds.parent(objName,offsetGroup)
        UVPosition = GetClosestUV(objName,surfaceName)
        follicleShape = cmds.createNode('follicle',name=objName+'_follicleShape')
        follicleTransform =  cmds.listRelatives(follicleShape,parent=True)[0]
        cmds.parent(follicleTransform,follicleContain)
        cmds.setAttr('{}.hiddenInOutliner'.format(follicleTransform),False)
        surfaceShape = cmds.listRelatives(surfaceName,children=True)[0]
        cmds.connectAttr(surfaceShape+'.local',follicleShape+'.inputSurface')
        cmds.connectAttr(surfaceShape+'.worldMatrix[0]',follicleShape+'.inputWorldMatrix')
        cmds.setAttr(follicleShape+".parameterU",UVPosition['u'])
        cmds.setAttr(follicleShape+".parameterV",UVPosition['v'])
        cmds.connectAttr(follicleShape+'.outRotate',follicleTransform+'.rotate')
        cmds.connectAttr(follicleShape+'.outTranslate',follicleTransform+'.translate')
        cmds.parentConstraint(follicleTransform,constraintGroup,mo=True)

def GetDistance(source,target,*arr):
    sourceTranslate = cmds.xform(source, q=True, ws=True, t=True)
    sourceTemp = cmds.spaceLocator(name = source+'_GetDistance')[0]
    cmds.matchTransform(sourceTemp,source,pos=True)
    pos1 = cmds.xform(sourceTemp, q=True, ws=True, t=True)
    targetTranslate = cmds.xform(target, q=True, ws=True, t=True)
    targetTemp = cmds.spaceLocator(name = target+'_GetDistance')[0]
    cmds.matchTransform(targetTemp,target,pos=True)
    pos2 = cmds.xform(targetTemp, q=True, ws=True, t=True)
    distance = sqrt((pos2[0] - pos1[0])**2 + (pos2[1] - pos1[1])**2 + (pos2[2] - pos1[2])**2)
    cmds.delete([sourceTemp,targetTemp])
    return(distance)

def CreateSurface(*arr):
    joints =  cmds.ls(selection=True,type='joint')
    if joints:
        jointChain = CreateJointChain(joints)
        curves = CreateCurve(jointChain)
        curveArray = []
        for curveTemp in curves:
            curveArray.append('"'+curveTemp+'"')
        curveString = (" ").join(curveArray)
        pm.mel.eval('loft -n "'+joints[0]+'_Surface" -ch 1 -u 1 -c 0 -ar 1 -d 3 -ss 1 -rn 0 -po 0 -rsn true '+curveString+' ;')
        cmds.delete(curves)
        cmds.delete(jointChain)
        CreateFollicle(joints,joints[0]+'_Surface')

    
def CreateCircleFollicle(*arr):
    objs = cmds.ls(selection=True)
    distanceTotal = 0
    distanceArray = []
    distanceTemp = None
    for i in range(len(objs)-1):
        distanceTemp = GetDistance(objs[i],objs[i+1])
        distanceArray.append(distanceTemp)
        distanceTotal = distanceTotal + distanceTemp
    distanceArray.append(distanceTemp)
    distanceTotal = distanceTotal + distanceTemp
    radius = distanceTotal/(2*pi)
    degreeUnit = 360/distanceTotal
    cmds.select(clear=True)
    centerJoint = cmds.joint(n=objs[0]+'NLTA_Center_Temp',p=[0,0,0])
    positionJoint = cmds.joint(n=objs[0]+'NLTA_Position_Temp',p=[0,0,radius])
    aimConstraintName = cmds.aimConstraint(centerJoint,positionJoint, aimVector=[0,0,1], upVector=[0, 1, 0], worldUpType='vector',worldUpVector=[0,1,0],mo=False)
    cmds.delete(aimConstraintName)
    degreeIncrease = 0
    for indexTemp in range(len(distanceArray)):        
        cmds.select(clear=True)
        cmds.matchTransform(objs[indexTemp],positionJoint)
        distance = distanceArray[indexTemp]
        degreeIncrease = degreeIncrease+(degreeUnit*distance)
        cmds.setAttr(centerJoint+".ry",degreeIncrease)
    cmds.select(objs)
    CreateSurface()
    cmds.delete(centerJoint)
    
def CreateNormalFollicle(*arr):
    objs = cmds.ls(selection=True)
    CreateSurface() 
    
#####
import random
def RandomTransform(*arr):
    inputData = {
        "tx":[-100,100],
        "ty":[-100,100],
        "tz":[-100,100],
        "rx":[0,0],
        "ry":[0,100],
        "rz":[0,0],
        "sx":[0,0],
        "sy":[0,0],
        "sz":[0,0],           
    }
    objs = cmds.ls(selection=True)
    for obj in objs:
        for key in inputData:
            randTemp = random.uniform(inputData[key][0],inputData[key][1])
            cmds.setAttr(obj+'.'+key,cmds.getAttr(obj+'.'+key)+randTemp)

def IncreaseTransform(*arr):
    inputData = {
        "tx":0,
        "ty":0,
        "tz":400,
        "rx":0,
        "ry":0,
        "rz":10,
        "sx":.1,
        "sy":.1,
        "sz":.1,
    }
    objs = cmds.ls(selection=True)
    for i in range(len(objs)):
        for key in inputData:
            valueTemp = i*inputData[key]
            cmds.setAttr(objs[i]+'.'+key,cmds.getAttr(objs[i]+'.'+key)+valueTemp)

def GetFacePivot(face,*arr):
    vertices = cmds.polyListComponentConversion(face, toVertex=True)
    vertices = cmds.filterExpand(vertices, selectionMask=31)
    clusterTemp = cmds.cluster(vertices,relative=True,name="NLTA_Cluster_Temp")[1]
    locatorTemp = cmds.spaceLocator(name="NLTA_Locator_Temp",p=(0,0,0))[0]
    cmds.matchTransform(locatorTemp,clusterTemp)
    translation = cmds.xform(locatorTemp,query=True,ws=True,t=True)
    cmds.delete([clusterTemp,locatorTemp])
    return(translation)

def SnapObjectToFace(data,*arr):
    source = data['source']
    target = data['target']
    axisArray = ["X","Y","Z","-X","-Y","-Z"]
    negArray = [1,1,1,-1,-1,-1]    
    vectorArray = []
    for vector in ["aim","up"]:   
        axis = data[vector]
        value = negArray[axisArray.index(axis)]
        vectorIndex = axisArray.index(axis.replace("-",""))
        vectorTemp = [0,0,0]
        vectorTemp[vectorIndex] = value
        vectorArray.append(vectorTemp)
    constraint = cmds.normalConstraint(source,target, aimVector=vectorArray[0], upVector=vectorArray[1])
    cmds.delete(constraint)
    translate = GetFacePivot(source)
    locatorTemp = cmds.spaceLocator(name="NLTA_Locator_Temp",p=(0,0,0))[0]
    cmds.xform(locatorTemp,ws=True,t=translate)
    cmds.matchTransform(target,locatorTemp,pos=True)
    cmds.delete(locatorTemp)
    """
    SnapObjectToFace({
        "source":'pCube1.f[0]',
        "target":'pSphere1',
        "aim":"Y",
        "up":"-Z"
    })
    """


def RandomKeyframe(*arr):
    inputData = {
        "tx":[-100,100],
        "ty":[-100,100],
        "tz":[-100,100],
        "rx":[0,0],
        "ry":[0,100],
        "rz":[0,0],
        "sx":[0,0],
        "sy":[0,0],
        "sz":[0,0],           
    }
    objs = cmds.ls(selection=True)
    for obj in objs:
        #currentPosition = 
        for key in inputData:
            currentValue = cmds.getAttr(obj+'.'+key)
            randTemp = random.uniform(inputData[key][0],inputData[key][1])
            total = inputData[key][1] - inputData[key][0]
            different = total - randTemp
            percentTemp = different/total
            
            cmds.setAttr(obj+'.'+key,cmds.getAttr(obj+'.'+key)+randTemp)



##### CODE TEMP ############
"""
def is_colliding(pos,existing_positions,min_distance):
    #Check if a new position is too close to existing objects.
    for p in existing_positions:
        if ((p[0] - pos[0]) ** 2 + (p[1] - pos[1]) ** 2 + (p[2] - pos[2]) ** 2) ** 0.5 < min_distance:
            return(True)
    return(False)

def fill_object_with_variety(containter,objects_to_fill,num_objects=50,min_distance=2.0,*arr):
    #Fill a container with different objects while preventing overlaps.
    if not objects_to_fill:
        cmds.warning("No objects provided for filling!")
        return[]
    bbox = cmds.exactWorldBoundingBox(containter)
    min_x,min_y,min_z,max_x,max_y,max_z = bbox
    
    created_objects = []
    placed_positions = []
    for _ in range(num_objects):
        attempts = 0
        max_attempts = 100 #Prevent infinite loops
        while attempts < max_attempts:
            #Generate a random position inside the bounding box
            rand_x = random.uniform(min_x,max_x)
            rand_y = random.uniform(min_y,max_y)
            rand_z = random.uniform(min_z,max_z)
            #Check for collisions
            if not is_colliding((rand_x,rand_y,rand_z),placed_positions,min_distance):
                #Choose a random object from the list
                obj_to_fill = random.choice(objects_to_fill)
                
                #Duplicate and move the objec
                new_obj = cmds.duplicate(obj_to_fill)[0]
                cmds.move(rand_x,rand_y,rand_z,new_obj)
                
                created_objects.append(new_obj)
                placed_positions.append((rand_x,rand_y,rand_y))
                break #Move to the next object
            attempts +=1 #Retry if collision detected
    print(f"Filled {container} with{len(created_objects)} unique Objects.")
    return(created_objects)
    
selection = cmds.ls(selection=True)
if len(selection) >= 2:
    print("----")
    containter = selection[0]
    objects_to_fill = selection[1:]
    fill_object_with_variety(containter,objects_to_fill,num_objects=500,min_distance=0)
else:
    cmds.warning("Select a container first,then multiple objects to fill it with.")
"""
#requireTab = "setup"
import maya.cmds as cmds
import pymel.all as pm
from functools import partial

session = {
    "driverName":"",
    "driverAttr":"",
    "drivenAttrArray":[],
    "drivenObjectArray":[],
    "infinity":["Constant","Linear","Cycle","Cycle with offset","Oscillate"],
    "key":{}
}
"""
def createLayout(per,lib,*arr):
    if per == "setupDivernKey":
        cmds.frameLayout(label='Driven Key',width=390,parent="setup")#open Frame #cl=True,cll=True,
        cmds.rowColumnLayout(nc=3)
        cmds.button(label="Set Dirver",width=195,c=setDriver)
        cmds.button(label="Set Dirven",width=95.25,c=setDriven)
        cmds.button(label="Clear Dirven",width=95.25,c=clearDriven)       
        cmds.setParent("..")

        cmds.rowColumnLayout(nc=2,width=195)
        cmds.rowColumnLayout()
        cmds.textField("drivername",width=195,editable=False)
        cmds.textField("driverAttr",width=195,editable=False)
        cmds.setParent("..")
        cmds.scrollLayout("drivenList",horizontalScrollBarThickness=16,verticalScrollBarThickness=16,borderVisible=True,height=150,width=193)#open scroll
        cmds.setParent("..")
        cmds.setParent("..")

        cmds.scrollLayout("infinityList",horizontalScrollBarThickness=16,verticalScrollBarThickness=16,borderVisible=True,height=100,width=193)
        cmds.setParent("..") 

        cmds.scrollLayout("setKeyList",horizontalScrollBarThickness=16,verticalScrollBarThickness=16,borderVisible=True,height=200,width=193)
        cmds.setParent("..") 

        cmds.rowColumnLayout(nc=3)        
        cmds.button(label="Add New",width=130,c=addKeyItem)
        cmds.button(label="Clear Key",width=130,c=clearKeyItem)
        cmds.button(label="Create Key",width=130,c=createKey)
        cmds.setParent("..")

        cmds.setParent("..") #close Frame

        cmds.frameLayout(label='Follow Path quick caculator',width=390,cl=True,cll=True,parent="setup")
        cmds.rowColumnLayout(nc=2)
        cmds.text(label="Current value:",width=80,align="left")
        cmds.textField("followCalCurrent",width=100)
        cmds.setParent("..")
        cmds.rowColumnLayout(nc=3)
        cmds.text( label="Driven:",width=80,align="left")
        cmds.textField("followCalDrivenMin",width=50,text=0)
        cmds.textField("followCalDrivenMax",width=50,text=1)
        cmds.setParent("..")
        cmds.rowColumnLayout(nc=3)
        cmds.text( label="Driver:",width=80,align="left")
        cmds.textField("followCalDriverMin",width=50,text=0)
        cmds.textField("followCalDriverMax",width=50,text=360)
        cmds.setParent("..")
        cmds.rowColumnLayout(nc=3)
        cmds.text( label="Result:",width=80,align="left")
        cmds.textField("followCalResultMin",width=50)
        cmds.textField("followCalResultMax",width=50)
        cmds.setParent("..")
        cmds.rowColumnLayout(nc=1)
        cmds.button(label="Run",width=130,c = followCalRun)
        cmds.setParent("..")

        cmds.setParent("..")
"""
def setDriver(*arr):
    global session
    selectCurrent = getSelect()
    session["driverName"] = selectCurrent["obj"][0]
    session["driverAttr"] = selectCurrent["attr"][0]
    cmds.textField("drivername",edit=True,text=session["driverName"])
    cmds.textField("driverAttr",edit=True,text=session["driverAttr"])

def addDrivenItem(*arr):
    for a in session["drivenObjectArray"]:
        cmds.rowColumnLayout("drivenItem"+a,nc=2,parent="drivenList",width=170,backgroundColor=[.3,0.3,0.3])
        cmds.text( label=a,width=140,align="left")
        cmds.button(label="X",width=30,c=partial(deleteDriven,a))
        cmds.setParent("..")
    createInfinityList()

def setDriven(*arr):
    global session  
    selectCurrent = getSelect()
    session["drivenObjectArray"] = selectCurrent["obj"]
    session["drivenAttrArray"] = selectCurrent["attr"]
    addDrivenItem()

def clearDriven(*arr):
    input = cmds.scrollLayout("drivenList",q = True, ca= True)
    if input:
        for a in input:
            try:
                cmds.deleteUI(a)
            except:pass
    session["drivenAttrArray"] = []
    session["drivenObjectArray"] = []

def deleteDriven(itemName,*arr):
    global session
    cmds.deleteUI("drivenItem"+itemName)
    session["drivenObjectArray"].remove(itemName)

def createInfinityList(*arr):
    clearInfinityList()
    for a in session["drivenAttrArray"]:
        cmds.rowColumnLayout("infinityItem"+a,nc=5,parent="infinityList",width=390)
        cmds.text( label=a+":",width=70,align="left")
        cmds.text(label="Pre Inf: ",width=50,align='right')
        cmds.optionMenu("preInfinity"+a,width=95)
        for b in session["infinity"]:
            cmds.menuItem(label=b)                
        cmds.text(label="Post Inf: ",width=50,align='right')
        cmds.optionMenu("postInfinity"+a,width=95)
        for b in session["infinity"]:
            cmds.menuItem(label=b)
        cmds.setParent("..")    

def clearInfinityList(*arr):
    input = cmds.scrollLayout("infinityList",q = True, ca= True)
    if input:
        for a in input:
            try:
                cmds.deleteUI(a)
            except:pass
    session["key"] = {}
    

def clearKeyItem(*arr):
    input = cmds.scrollLayout("setKeyList",q = True, ca= True)
    if input:
        for a in input:
            try:
                cmds.deleteUI(a)
            except:pass
    session["key"] = {}



def deleteKey(layoutName,*arr):
    cmds.deleteUI(layoutName)

def getSelect(*arr):
    gChannelBoxName = pm.mel.eval('$temp=$gChannelBoxName')
    smd = cmds.channelBox(gChannelBoxName,query=True,sma=True)#thuoc tinh chinh
    ssa = cmds.channelBox(gChannelBoxName,query=True,ssa=True)#shape
    sha = cmds.channelBox(gChannelBoxName,query=True,sha=True)#history
    data = {}

    objectAttr = []
    if smd:
        objectAttr.extend(smd)
    if ssa:
        objectAttr.extend(ssa)
    if sha:
        objectAttr.extend(sha)
    if objectAttr:
        data = {
            "obj":cmds.ls(selection=True),
            "attr":objectAttr
        }
    if cmds.channelBox(gChannelBoxName,query=True,soa=True):
        data = {        
            "obj":cmds.channelBox(gChannelBoxName,query=True,ool=True),#node
            "attr":cmds.channelBox(gChannelBoxName,query=True,soa=True)#attr of node
        }
    return(data)

def followCalRun(*arr):
    current = cmds.textField("followCalCurrent",query=True,text=True)
    drivenMin = cmds.textField("followCalDrivenMin",query=True,text=True)
    drivenMax = cmds.textField("followCalDrivenMax",query=True,text=True)
    driverMin = cmds.textField("followCalDriverMin",query=True,text=True)
    driverMax = cmds.textField("followCalDriverMax",query=True,text=True)
    resultMin = (float(driverMax)/float(drivenMax))*(float(current)*(-1))
    resultMax = (float(driverMax)/float(drivenMax))*(float(drivenMax)- float(current))
    cmds.textField("followCalResultMin",edit=True,text=resultMin)
    cmds.textField("followCalResultMax",edit=True,text=resultMax)


def addKeyItem(*arr):
    if len(session["drivenAttrArray"])!=0:
        parentName = cmds.rowColumnLayout(nc=1,parent="setKeyList")
        parentName = parentName.split("|")[-1]    
        cmds.rowColumnLayout(nc=4,width=390)
        cmds.text(label='Driver val:',width=60)
        cmds.textField(parentName+"DriverVal",width=40,text=0)
        cmds.button(label="Delete",c=partial(deleteKey,parentName))
        cmds.setParent("..")
        cmds.rowColumnLayout(nc=2,width=390)
        for a in session["drivenAttrArray"]:
            cmds.rowColumnLayout(nc=2,width=110)
            cmds.text(label=a+":  ",width=60,align='right')
            cmds.textField(parentName+"Attr"+a,width=40,text=0)

            cmds.setParent("..")           
            cmds.rowColumnLayout(nc=4,width=390)

            cmds.text(label="In Tag: ",width=50,align='right')
            cmds.optionMenu(parentName+"inTangentType"+a,width=70)
            for b in ["linear","spline","fast","slow","flat","step","stepnext","fixed","clamped","plateau","auto"]:
                cmds.menuItem(label=b)            
            
            cmds.text(label="Out tag: ",width=50,align='right')
            cmds.optionMenu(parentName+"outTangentType"+a,width=70)
            for b in ["linear","spline","fast","slow","flat","step","stepnext","fixed","clamped","plateau","auto"]:
                cmds.menuItem(label=b)            
            cmds.setParent("..")
        cmds.setParent("..")
        cmds.setParent("..")

def createKey(*arr):
    input = cmds.scrollLayout("setKeyList",q = True, ca= True)
    if input:
        for layout in input:
            driverVal = cmds.textField(layout+"DriverVal",query=True,text=True)
            cmds.setAttr(session["driverName"]+"."+session["driverAttr"],float(driverVal))
            for driven in session["drivenObjectArray"]:
                for attr in session["drivenAttrArray"]:

                    #max_joint_matched.index(parent_mirror)

                    attrVal = cmds.textField(layout+"Attr"+attr,query=True,text=True)
                    itt = cmds.optionMenu(layout+"inTangentType"+attr,query=True,value=True)
                    ott = cmds.optionMenu(layout+"outTangentType"+attr,query=True,value=True)
                    preInf = cmds.optionMenu("preInfinity"+attr,query=True,value=True)
                    postInf =cmds.optionMenu("postInfinity"+attr,query=True,value=True)
                    cmds.setAttr(driven+"."+attr,float(attrVal))
                    cmds.setDrivenKeyframe(driven+"."+attr, cd=session["driverName"]+"."+session["driverAttr"],itt=itt,ott=ott)
                    drivenKeyNode = cmds.connectionInfo(driven+"."+attr,sourceFromDestination=True)
                    if cmds.objectType(drivenKeyNode) == "animCurveUU":
                        print(driven+"."+attr)
                    #setAttr "follicleShape1_parameterU.preInfinity" 3;
                    #print(cmds.keyframe( 'loftedSurface2FollicleShape50.parameterU', query=True, keyframeCount=True ))

"""
    # Create a curve and a cone
    #
    cmds.curve(d=3,p=[(-10, 0, 0),(-6, 0, 10),(-3, 0, -10),(10, 0, 0)],k=[0, 0, 0, 1, 1, 1])
    cmds.polyCone()

    # To set the keyframe on the selected object's translateX based on
    # curve1's rotateZ:
    cmds.setDrivenKeyframe( at='translateX', cd='curve1.rz' )

    # To set the keyframe on pCone1.tx based on the value of curve1.rz:
    cmds.setDrivenKeyframe( 'pCone1.tx', cd='curve1.rz' )

    # To query the current driver of pCone1.tx:
    cmds.setDrivenKeyframe( 'pCone1.tx', q=True, cd=True )

    # To query the available drivers of pCone1.tx:
    cmds.setDrivenKeyframe( 'pCone1.tx', q=True, dr=True )

    #setDrivenKeyframe -currentDriver pCube2.translateY pCube1.translateY;
    #setAttr "follicleShape1_parameterU.preInfinity" 3;

        cmds.scrollLayout(horizontalScrollBarThickness=16,verticalScrollBarThickness=16,height=603,width=390,parent="setup")#open scroll         
        cmds.rowColumnLayout("inputJoint",numberOfColumns=1)#
        cmds.setParent("..")   
        cmds.setParent("..")#close scroll
        
        exportImportRow = cmds.rowColumnLayout(nc=3,parent="setup") 
        cmds.setParent("..")
        
        cmds.setParent("..")


paramaterU = current
setsetupframe -currentDriver pCube1.translateY pCube2.translateY;
keyTangent -itt linear -ott linear;
keyTangent -itt linear -ott linear;
setInfinity -poi cycle;
setInfinity -pri cycle;

print(cmds.ls(type="animCurveUU")[0])

import pymel.core as pm


channels = list()
if sma:
	channels.extend(sma)
if ssa:
	channels extend(ssa)
if sha:
	channels.extend(sha)




import os
import pymel.core as pm
import maya.mel as mel
import maya.cmds as cmds
from xml.dom.minidom import Document

def value_in_frame(object,time,*arr):
    cmds.currentTime(time)
    return {
        "translateX":cmds.getAttr(object+".translateX"),
        "translateY":cmds.getAttr(object+".translateY"),
        "translateZ":cmds.getAttr(object+".translateZ"),
        "rotateX":cmds.getAttr(object+".rotateX"),
        "rotateY":cmds.getAttr(object+".rotateY"),
        "rotateZ":cmds.getAttr(object+".rotateZ"),
    }
list_selected = cmds.ls(sl=True)
if not list_selected:
    list_selected = pm.ls(type='joint')        
            
folder_scene = os.path.join(os.path.dirname(pm.sceneName()), 'keyframes')
if not os.path.exists(folder_scene):
    os.makedirs(folder_scene)        
doc = Document()
root_node = doc.createElement("a")   
joint_defaut = {} 
doc.appendChild(root_node)   

key_array = []
for object in list_selected:        
    object = str(object)
    default_value = value_in_frame(object,0)
    joint_defaut[object] = default_value
    
   
    if cmds.keyframe(str(object),query=True,timeChange=True):
        key_temp = cmds.keyframe(str(object),query=True,timeChange=True)
        for i in key_temp:
            if i not in key_array:
                key_array.append(i)                    
key_array = sorted(key_array)

for x in range(len(key_array)):
    key_node = doc.createElement(str("k"))
    key_node.setAttribute("v",str(int(key_array[x])))        
    for object in list_selected:
        object = str(object)
        if cmds.keyframe(object,query=True,time=(key_array[x],key_array[x]),valueChange=True):
            node = doc.createElement(str("j"))
            node.setAttribute("n",object)
            cur_time = value_in_frame(object,key_array[x])                                          
            if cmds.keyframe(object,query=True,time=(key_array[x-1],key_array[x-1]),valueChange=True):
                old_time = value_in_frame(object,key_array[x - 1])                    
            else:
                old_time = joint_defaut[object]
            node.setAttribute("t_x",str(cur_time["translateX"] - old_time["translateX"]))
            node.setAttribute("t_y",str(cur_time["translateY"] - old_time["translateY"]))
            node.setAttribute("t_z",str(cur_time["translateZ"] - old_time["translateZ"]))
            node.setAttribute("r_x",str(cur_time["rotateX"] - old_time["rotateX"]))
            node.setAttribute("r_y",str(cur_time["rotateY"] - old_time["rotateY"]))
            node.setAttribute("r_z",str(cur_time["rotateZ"] - old_time["rotateZ"]))
            key_node.appendChild(node)
    root_node.appendChild(key_node)
xml_file = open(folder_scene+"/keyframes.xml","w")
xml_file.write(doc.toprettyxml())
xml_file.close()


import maya.cmds as cmds
import pymel.core as pymel
object = "pCube2_translateY"
for i in cmds.keyframe(object,query=True, iv=True):
    print(cmds.keyframe(object,query=True,fc=True)[i])
    pymel.mel.eval('keyframe -index '+str(i)+' -query -eval pCube2_translateY ;')
    #print(cmds.keyframe(object,query=True,eval=True,index=str(i))
    pymel.mel.eval('keyTangent -index '+str(i)+' -q -inTangentType pCube2_translateY ;')
    pymel.mel.eval('keyTangent -index '+str(i)+' -q -outTangentType pCube2_translateY ;')
"""
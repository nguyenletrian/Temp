import os,json
import maya.cmds as cmds
import pymel.core as pm

if not cmds.pluginInfo('objExport', query=True, loaded=True):
    cmds.loadPlugin('objExport')

def RunScriptFile(url,*arr):
    if os.path.exists(url):
        filePath = cmds.encodeString(url)
        myFile =  open(filePath,'r')
        myObject = myFile.read()
        myFile.close()
        exec(myObject)
        
def runScript(var,*arr):
    if cmds.scrollField(var,query=True,text=True)!="":
        script_file = cmds.scrollField(var,query=True,text=True)
        lineData = script_file.splitlines()
        for a in lineData:
            if os.path.exists(a):
                filePath = cmds.encodeString(a)
                myFile =  open(filePath,'r')
                myObject = myFile.read()
                myFile.close()
                exec(myObject)
            else:
                exec(a)    
    else:
        print("No script for "+var+".")

def runPostScript(*arr):
    folder_temp = os.path.dirname(pm.sceneName())
    if not folder_temp:
        folder_temp = pm.mel.eval("SaveSceneAs;")
    folder_temp = os.path.dirname(pm.sceneName())
    postScriptUrl = folder_temp+"/"+"postScript.py"
    if os.path.exists(postScriptUrl):
        filePath = cmds.encodeString(postScriptUrl)
        myFile =  open(filePath,'r')
        myObject = myFile.read()
        myFile.close()
        exec(myObject)
    else:
        writeTxtFile(postScriptUrl,"")


def checkNegPosAxis(obj,axis,*arr):
    cmds.select(clear=True)
    jointChild = cmds.joint()
    cmds.select(clear=True)
    jointParent = cmds.joint()
    cmds.matchTransform(jointChild,obj,position=True)
    cmds.matchTransform(jointParent,obj,position=True)
    cmds.setAttr(jointParent+".t"+axis,0)
    cmds.parent(jointChild,jointParent)
    axisValue = cmds.getAttr(jointChild+".t"+axis)
    cmds.delete(jointParent)
    if axisValue > 0:
        return("+")
    else:
        return("-")

def addMinusAdd(name,*arr):
    arrayCurrent = cmds.scrollField(name,query=True,text=True)
    arrayCurrent = arrayCurrent.split(";")
    arrayJoint = cmds.ls(selection=True,ap=True)
    jointString = ""
    if arrayJoint :     
        for a in arrayJoint:
            if a not in arrayCurrent:
                arrayCurrent.append(a)
        jointString = (";").join(arrayCurrent)
        cmds.scrollField(name,edit=True,text=jointString)
        
def addMinusMinus(name,*arr):
    arrayCurrent = cmds.scrollField(name,query=True,text=True)
    arrayCurrent = arrayCurrent.split(";")
    arrayJoint = cmds.ls(selection=True,ap=True)
    jointString = ""
    if arrayJoint :     
        for a in arrayJoint:
            if a in arrayCurrent:
                arrayCurrent.remove(a)
        jointString = (";").join(arrayCurrent)
        cmds.scrollField(name,edit=True,text=jointString)


def allParents(name,*arr):
    rootTemp = name
    arrayTemp = []
    while (True):
        parentTemp = cmds.listRelatives(rootTemp,parent=True,type='joint',path=True)
        if not parentTemp:
            break;
        rootTemp = parentTemp[0]
        arrayTemp.insert(0,parentTemp[0])
    return(arrayTemp)
    
def sortHierachy(array,*arr):
    returnArray = []
    for i in array:
        parentTemp = cmds.listRelatives(i,parent=True)[0]
        if parentTemp in returnArray:
            indexTemp = returnArray.index(parentTemp)
            returnArray.insert(0,parentTemp)
        else:
            returnArray.append(parentTemp)
    returnArray.remove(returnArray[0])
    lastChild = list(set(array) - set(returnArray))
    returnArray.append(lastChild[0])
    return(returnArray)
    
def hierachyBetween(array,*arr):
    if len(array)==2:
        obj1 = array[0]
        obj2 = array[1]
        obj1Children = cmds.listRelatives(obj1,path=True)
        if not obj1Children:
            obj1Children = []  
        obj2Children = cmds.listRelatives(obj2,path=True)
        if not obj2Children:
            obj2Children = []
        if obj1 in obj2Children:
            parentObj = obj2
            childrenObj = obj1
        else:
            parentObj = obj1
            childrenObj = obj2
        hierachyArray = []
        flag = 0
        childrenTemp = childrenObj
        while flag < 1:
            parentTemp =  cmds.listRelatives(childrenTemp,p=True,pa=True)[0]
            if parentTemp.endswith(parentObj):
                flag = 1
            else:
                hierachyArray.insert(0,parentTemp)
                childrenTemp = parentTemp
        hierachyArray.insert(0,parentObj)
        hierachyArray.append(childrenObj)
        return (hierachyArray)


def MatchJoint(array,*arr):#create a match between 2 hierachy [source_begin,source_end,destination_begin,destination_and,name]
    if array !=None:
        returnArray = []
        sourceBegin = array[2]
        sourceEnd = array[3]        
        destinationBegin = array[0]
        destinationEnd = array[1]
        sourceBeginUuid = cmds.ls(sourceBegin,uuid=True)
        sourceEndUuid = cmds.ls(sourceEnd,uuid=True)
        destinationBeginUuid = cmds.ls(destinationBegin,uuid=True)

        cmds.matchTransform(destinationBegin,sourceBegin,pos=True)
        cmds.matchTransform(destinationEnd,sourceEnd,pos=True)
        needCreate = hierachyBetween([sourceBegin,sourceEnd])
        needCreate.remove(sourceBegin)
        needCreate.remove(sourceEnd)
        needDelete = hierachyBetween([destinationBegin,destinationEnd])
        
        if len(needDelete)>2:
            destinationEnd = cmds.parent(destinationEnd,destinationBegin)[0]
            cmds.delete(needDelete[1])
            
        if len(needCreate)>0:
            parentTemp = None
            stt = 1
            for i in needCreate:
                iUuid = cmds.ls(i,uuid=True)
                cmds.ls(cmds.ls(selection=True,uuid=True))
                jntName = cmds.createNode("joint")
                if array[4]:
                    jntName = cmds.rename(jntName,array[4]+str(stt))
                else:
                    jntName = cmds.rename(jntName,i+"_copy")
                cmds.matchTransform(jntName,i,pos=True)
                cmds.matchTransform(jntName,cmds.ls(destinationBeginUuid)[0],rot=True)  
                pm.makeIdentity(jntName, apply=True, translate=True, rotate=True, scale=True)
                if parentTemp:
                    parentTemp = cmds.parent(jntName,parentTemp)[0] 
                else:
                    parentTemp = cmds.parent(jntName,destinationBegin)[0]
                returnArray.append([parentTemp,cmds.ls(iUuid)[0]])
                stt +=1

            destinationEnd = cmds.parent(destinationEnd,parentTemp)[0]
        returnArray.append([destinationEnd,cmds.ls(sourceEndUuid)[0]])
        returnArray.insert(0,[cmds.ls(destinationBeginUuid)[0],cmds.ls(sourceBeginUuid)[0]])
        return(returnArray)


def checkOnly(array,*arr):
    name = array[0]
    stringExist = array[1]
    if len(cmds.ls(name,r=True)) > 1:
        for a in cmds.ls(name,r=True):
            longPath = cmds.ls(a,long=True)[0]
            if stringExist in longPath:
                return(a)
    else:
        return(name)        
            
def checkSubString(array,*arr):
    string = array[0]
    array_temp =  array[1]
    for i in array_temp:
        if i in string:
            return(True)
    return(False)

def correctCharacter(string,*arr):
    currentString = string 
    for b in ["FBXASC046","FBXASC045","FBXASC032","[","]","."]:            
        if b in currentString:   
            currentString = currentString.replace(b,"_")
    return(currentString)

def readJsonFile(url,*arr):
    if os.path.exists(url):
        filePath = cmds.encodeString(url)
        myFile =  open(filePath,'r')
        myObject = myFile.read()
        myFile.close()
        if int(cmds.about(version=True)) < 2022:
            data = json.loads(myObject,'utf-8')
        else:
            data = json.loads(myObject)
        return(data)

    else:
        print("!: File is not exists!")

def writeJsonFile(url,data,*arr):
    with open(url,"w") as json_file:
        json.dump(data,json_file,sort_keys=False)
    print("Url export: " + url)

def readTxtFile(url,*arr):
    if os.path.exists(url):
        filePath = cmds.encodeString(url)
        myFile =  open(filePath,'r')
        myObject = myFile.read()
        myFile.close()
        return(myObject)
    else:
        print("!: File is not exists!")

def writeTxtFile(url,data,*arr):
    with open(url,"w") as text_file:
        text_file.write(data)        
    print("Url export: " + url)

def CreateNamespace(nameSpace,*arr):
    if not cmds.namespace(exists=nameSpace):
        cmds.namespace(add=nameSpace)
    objs = cmds.ls(selection=True)
    for obj in objs:
        newName = nameSpace + ":" + obj
        cmds.rename(obj,newName)

def DeleteNamespace(nameSpace,*arr):
    if cmds.namespace(exists=nameSpace):
        cmds.namespace(moveNamespace=(nameSpace, ":"), force=True)
        cmds.namespace(removeNamespace=nameSpace)

def GetFolders(url):
    stringArray = []
    for folder in sorted(os.scandir(url),key=os.path.getmtime)[::-1]:
        if folder.is_dir():
            stringArray.append(folder.path.split("\\")[-1])
    return(stringArray)

def GetFiles(url,fileType):
    files = os.listdir(url)
    nameArray = []
    for file in files:
        if file.endswith("."+fileType):
            fileName = file.split(".")[0]
            nameArray.append(fileName)
    return(nameArray)

def DeleteLayers(*arr):
    layers = cmds.ls(type='displayLayer') 
    layers = [layer for layer in layers if layer not in ['defaultLayer', 'defaultRenderLayer']]
    for layer in layers:
        objs = cmds.editDisplayLayerMembers(layer, query=True)
        cmds.select(objs)
        pm.mel.eval('layerEditorRemoveObjects '+layer+';')
        cmds.delete(layer)

def ClearScene(*arr):
    pm.mel.eval('hyperShadePanelMenuCommand("hyperShadePanel1", "deleteUnusedNodes")')
    unknown_nodes = cmds.ls(type='unknown')
    unknown_dag_nodes = cmds.ls(type='unknownDag')
    all_unknown_nodes = unknown_nodes + unknown_dag_nodes
    for node in all_unknown_nodes:
        if cmds.objExists(node):
            cmds.lockNode(node, lock=False)
            cmds.delete(node)

def ExportFbx(link,*arr):
    if not cmds.pluginInfo('fbxmaya', query=True, loaded=True):
        cmds.loadPlugin('fbxmaya')
    selected_objects = cmds.ls(selection=True)
    if not selected_objects:
        cmds.warning("No objects selected for export.")
        return
    cmds.file(link,force=True,options='v=0',typ="FBX export",pr=True,es=True)

def Repath(link,*arr):
    nodes = cmds.filePathEditor(query=True,listFiles="",unresolved=True,withAttribute=True)
    attribute = []
    if nodes:
        for i in range(len(nodes)):
            if i % 2!=0:
                node = nodes[i]
                attribute.append('"'+node+'"')
        attributeString = ",".join(attribute)
        exec('cmds.filePathEditor('+attributeString+',repath = "'+link+'",force=True,recursive=True)')


def GetDistance(obj1, obj2,*arr):
    pos1 = cmds.xform(obj1, query=True, worldSpace=True, translation=True)
    pos2 = cmds.xform(obj2, query=True, worldSpace=True, translation=True)
    distance = sqrt((pos2[0] - pos1[0])**2 + (pos2[1] - pos1[1])**2 + (pos2[2] - pos1[2])**2)
    return(distance)

"""
countries = [
    ['China', 1394015977],
    ['United States', 329877505],
    ['India', 1326093247]
]
populated = filter(lambda c: "di" in c[0], countries)
print(list(populated))


list = [i for i in range(11) if i%2==0]

list = [num for num in range(100) if num%5 == 0 if num%10 == 0]

list = [string[::-1] for string in ("Geekd","for","Geeks")]

names = ["G","G","g"]
ages = [25,30,35]
list = [(name,age) for name,age in zip(names,ages)]


def digitSum(n):
    dsum = 0
    for ele in str(n):
        dsum  += int(ele)
    return dsum
List = [367,111,562,945,6726,873]
list = [digiSum(i) for i in List if i &1]

words = ["apple","banana","cherrt","orange"]
word_lenghts = [len(word) for word in words]

tags = ["man","you","are","awesome"]
entries = [
    ["man","thats"],
    ["right","awesome"]
]
list = [entry for tag in tags for entry in entries if tag in entry]
"""


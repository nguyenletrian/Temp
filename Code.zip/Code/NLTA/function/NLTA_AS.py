#From Sparx* Rigging: Jordan Sukaria, Nguyen Quang Trieu, Nguyen Le Tri an
import os, sys , json , math, random, general
from maya import mel
import maya.cmds as cmds
import pymel.all as pm
import math
from functools import partial

requireTab = "NLTA_AS"
variableTemp = {}
toolSetting = {
	"pattern":[
		"biped.ma","bipedBendy.ma","bipedGame.ma","bird.ma","bug.ma","cat.ma","dinosaur.ma","dragon.ma","fish.ma","gorilla.ma","horse.ma","metahuman.ma","previs.ma"
	],
	"patternInput":{
		###BIPED
		"biped":{
			"order":[
				"Root","Chest","Neck","Head","HeadEnd","Scapula","Shoulder","Elbow","Wrist",    
				"ThumbFinger1","IndexFinger1","MiddleFinger1","RingFinger1","PinkyFinger1",
				"Hip","Knee","Ankle","Toes","ToesEnd","FootSideOuter","FootSideInner","Heel"
			],
			"vertex":[
				"ToesEnd","FootSideOuter","FootSideInner","Heel"
			],
			"jointBetween":[
				["Root","Chest","Spine"],
				["Neck","Head","Neck"]
			],           
			"twistBetween":[                
				["Shoulder","Elbow"],
				["Elbow","Wrist"],
				["Hip","Knee"],
				["Knee","Ankle"]
			],
			"ikControl":{
				"Ankle":"IKLeg",
				"Wrist":"IKArm"
			},
			"poleControl":{
				"Knee":"PoleLeg",
				"Elbow":"PoleArm"
			},
			"sdkFinger":[
				"FKThumbFinger2_R","FKThumbFinger3_R",
				"FKIndexFinger1_R","FKIndexFinger2_R","FKIndexFinger3_R",
				"FKMiddleFinger1_R","FKMiddleFinger2_R","FKMiddleFinger3_R",
				"FKRingFinger1_R","FKRingFinger2_R","FKRingFinger3_R",
				"FKPinkyFinger1_R","FKPinkyFinger2_R","FKPinkyFinger3_R",
				
				"FKThumbFinger2_L","FKThumbFinger3_L",
				"FKIndexFinger1_L","FKIndexFinger2_L","FKIndexFinger3_L",
				"FKMiddleFinger1_L","FKMiddleFinger2_L","FKMiddleFinger3_L",
				"FKRingFinger1_L","FKRingFinger2_L","FKRingFinger3_L",
				"FKPinkyFinger1_L","FKPinkyFinger2_L","FKPinkyFinger3_L",       
			],
			"sdkSpread":[
				"FKIndexFinger1_R","FKRingFinger1_R","FKPinkyFinger1_R",
				"FKIndexFinger1_L","FKRingFinger1_L","FKPinkyFinger1_L"
			],
			"attribute":{
				"global":["Spine","spine","Chest","Neck","Scapula","Shoulder"],
				"ikLocal":["Wrist"],
				#"worldOrientForward":["Ankle"],
				"control":["Head","HeadEnd"],
				"bendyJoints":["Hip","Shoulder","Elbow"],
				"freeOrient":["Finger"]
			}
		},
		
		###CAT
		"cat":{
			"order":[
				"Root","Chest","Neck","Head","HeadEnd","Scapula","Shoulder","Elbow","Wrist",
				"Fingers1","Fingers2","frontFootSideOuter","frontFootSideInner","frontHeel",
				"IndexFinger1","MiddleFinger1","RingFinger1","PinkyFinger1",
				"Hip","Knee","Ankle","Toes1","Toes2","backFootSideOuter","backFootSideInner","backHeel",
				"IndexToe1","MiddleToe1","RingToe1","PinkyToe1",
				"Tail0","Tail6",
			],
			"vertex":[
				"Fingers2","frontFootSideOuter","frontFootSideInner","frontHeel",
				"Toes2","backFootSideOuter","backFootSideInner","backHeel",   
			],
			"jointBetween":[
				["Root","Chest","Spine"],
				["Neck","Head","Neck"],
				["Tail0","Tail6","Tail"]
			],           
			"twistBetween":[                
				["Shoulder","Elbow"],
				["Elbow","Wrist"],
				["Hip","Knee"],
				["Knee","Ankle"]
			],
			"ikControl":{
				"Fingers1":"IKLegFront",
				"Toes1":"IKLegBack"
			},
			"poleControl":{
				"Knee":"PoleLegBack",
				"Elbow":"PoleLegFront"
			},
			"sdkFinger":[
				"FKIndexFinger1_R","FKIndexFinger2_R","FKIndexFinger3_R",
				"FKMiddleFinger1_R","FKMiddleFinger2_R","FKMiddleFinger3_R",
				"FKRingFinger1_R","FKRingFinger2_R","FKRingFinger3_R",
				"FKPinkyFinger1_R","FKPinkyFinger2_R","FKPinkyFinger3_R",

				"FKIndexFinger1_L","FKIndexFinger2_L","FKIndexFinger3_L",
				"FKMiddleFinger1_L","FKMiddleFinger2_L","FKMiddleFinger3_L",
				"FKRingFinger1_L","FKRingFinger2_L","FKRingFinger3_L",
				"FKPinkyFinger1_L","FKPinkyFinger2_L","FKPinkyFinger3_L",
				
				"FKIndexToe1_R","FKIndexToe2_R","FKIndexToe3_R",
				"FKMiddleToe1_R","FKMiddleToe2_R","FKMiddleToe3_R",
				"FKRingToe1_R","FKRingToe2_R","FKRingToe3_R",
				"FKPinkyToe1_R","FKPinkyToe2_R","FKPinkyToe3_R",

				"FKIndexToe1_L","FKIndexToe2_L","FKIndexToe3_L",
				"FKMiddleToe1_L","FKMiddleToe2_L","FKMiddleToe3_L",
				"FKRingToe1_L","FKRingToe2_L","FKRingToe3_L",
				"FKPinkyToe1_L","FKPinkyToe2_L","FKPinkyToe3_L",      
			],
			"sdkSpread":[
				"FKIndexFinger1_R","FKRingFinger1_R","FKPinkyFinger1_R",
				"FKIndexFinger1_L","FKRingFinger1_L","FKPinkyFinger1_L",
				"FKIndexToe1_R","FKRingToe1_R","FKPinkyToe1_R",
				"FKIndexToe1_L","FKRingToe1_L","FKPinkyToe1_L",
			],
			"attribute":{
				"global":["Spine","spine","Chest","Neck","Scapula","Shoulder"],
				"worldOrientForward":["Fingers1","Toes1"],
				"control":["Head","HeadEnd"],
				"bendyJoints":["Hip","Shoulder","Elbow"],
				"orientJoint":["Ankle"]
			}
		}
		
	},
	"patternData":{
		"order":[],
		"pair":[],
		"prefix":[],
		"maxParent":[],
		"match":{},
		"exceptJoint":[],
		"as_dict":{},
		"max_dict":{},
		"twist_dict":{},
		"constraint_pair":[],
		"connectScale":False,
		"vertexPosition":{}
	}
}
dataSession = {}

def createLayout(per,lib,*arr):
	"""
	#Import Advance Sleketon
	if not ("%s/studio/python"%os.getenv("VSTOOLS")) in sys.path:
		sys.path.append("%s/studio/python"%os.getenv("VSTOOLS"))
	sys.path.append("C:/vsTools2/ALL/maya/script/AdvancedSkeleton5.850/AdvancedSkeleton5/")
	from robust import svn_kit
	svn_kit.addsitedir('python_module/AdvancedSkeleton5')
	
	AS_path = "C:/vsTools2/ALL/maya/script/AdvancedSkeleton5.850/AdvancedSkeleton5/"
	AS_path = os.path.join(os.path.join(os.environ["VSTOOLS"], 'library'), 'python_module/AdvancedSkeleton5').replace("\\", "/")
	
	if not AS_path in os.environ["MAYA_SCRIPT_PATH"]:
		#os.environ["MAYA_SCRIPT_PATH"] += ";{}".format(AS_path)
	"""
	#CREATE DEFAULT LAYOUT
	if per == "NLTA_AS":
		cmds.rowColumnLayout(numberOfColumns=2,parent="NLTA_AS")
		cmds.optionMenu("patternAS",label='Pattern',width=320,cc=changePattern)
		for a in toolSetting["pattern"]:
			name = a.split(".")[0]
			cmds.menuItem(label=name)

		cmds.button(label="Load",width=70,c = changePattern)
		cmds.setParent("..")
		cmds.setParent("..")

		cmds.rowColumnLayout(numberOfColumns=3,parent="NLTA_AS")
		cmds.textField(text="Side",width=43,editable=False)
		cmds.textField("prefixRight",pht="right",width=174)
		cmds.textField("prefixLeft",pht="left",width=174)
		cmds.setParent("..")

		cmds.scrollLayout(horizontalScrollBarThickness=16,verticalScrollBarThickness=16,height=603,width=390,parent="NLTA_AS")#open scroll
	 
		cmds.frameLayout(label='Script',cl=True,cll=True,width=370)#open frame
		cmds.rowColumnLayout(numberOfColumns=1,width=390)#open right

		cmds.rowColumnLayout(numberOfColumns=3)
		cmds.textField(text="Before match",width=308,editable=False)
		cmds.button(label="Run",width=30,c = runBeforeMatchScriptLink)
		cmds.button(label="+",width=30,c = beforeMatchScriptLink)
		cmds.setParent("..") 
		cmds.rowColumnLayout(numberOfColumns=1)
		cmds.scrollField("beforeMatchScript",wordWrap=True,width=370,height=50,fns=8)
		cmds.setParent("..")
		
		cmds.rowColumnLayout(numberOfColumns=3)
		cmds.textField(text="After match",width=308,editable=False)
		cmds.button(label="Run",width=30,c = runAfterMatchScriptLink)
		cmds.button(label="+",width=30,c = afterMatchScriptLink)
		cmds.setParent("..") 
		cmds.rowColumnLayout(numberOfColumns=1)
		cmds.scrollField("afterMatchScript",wordWrap=True,width=370,height=50,fns=8)
		cmds.setParent("..")
		
		cmds.rowColumnLayout(numberOfColumns=3)
		cmds.textField(text="Before build",width=308,editable=False)
		cmds.button(label="Run",width=30,c = runBeforeBuildScriptLink)
		cmds.button(label="+",width=30,c = beforeBuildScriptLink)
		cmds.setParent("..") 
		cmds.rowColumnLayout(numberOfColumns=1)
		cmds.scrollField("beforeBuildScript",wordWrap=True,width=370,height=50,fns=8)
		cmds.setParent("..")
		
		cmds.rowColumnLayout(numberOfColumns=3)
		cmds.textField(text="After build",width=308,editable=False)
		cmds.button(label="Run",width=30,c = runAfterBuildScriptLink)
		cmds.button(label="+",width=30,c = afterBuildScriptLink)
		cmds.setParent("..") 
		cmds.rowColumnLayout(numberOfColumns=1)
		cmds.scrollField("afterBuildScript",wordWrap=True,width=370,height=50,fns=8)
		cmds.setParent("..")

		cmds.rowColumnLayout(numberOfColumns=3)
		cmds.textField(text="After Connect",width=308,editable=False)
		cmds.button(label="Run",width=30,c = runAfterConnectScriptLink)
		cmds.button(label="+",width=30,c = afterConnectScriptLink)
		cmds.setParent("..") 
		cmds.rowColumnLayout(numberOfColumns=1)
		cmds.scrollField("afterConnectScript",wordWrap=True,width=370,height=50,fns=8)
		cmds.setParent("..")
		
		cmds.setParent("..")#close right
		cmds.setParent("..")#close frame
		  
		cmds.rowColumnLayout("inputJoint",numberOfColumns=1)#
		cmds.setParent("..")    
		cmds.frameLayout("inputVertex",label='Extra',cl=True,cll=True,width=370)#
		cmds.setParent("..")    
		cmds.setParent("..")#close scroll
		
		exportImportRow = cmds.rowColumnLayout(nc=3,parent="NLTA_AS")       
		cmds.button("importData",label="Import Data",c = partial(importData,["new",exportImportRow]),width=389)
		cmds.setParent("..")
		cmds.rowColumnLayout(nc=2,width=390) 
		cmds.button(label="Match",c = matchJoint,width=195) 
		cmds.button(label="Build/Rebuild AS",c = buildAS,width=195)    
		cmds.button(label="Connect AS - FBX",c = connectAsFbx,width=195)
		cmds.button(label="Disconnect AS - FBX",c = partial(disconnect,"groupConstraintAsFbx"),width=195)        
		cmds.setParent("..")
		cmds.rowColumnLayout(numberOfColumns=3)
		cmds.checkBox("oldGuideCheckbox",label="oldGuide",width=195)    
		cmds.button("exportData",label="Export Data",c = exportData,width=194)        
		cmds.setParent("..")

		cmds.frameLayout(label='Other',cl=True,cll=True,width=390,parent="NLTA_AS")
		cmds.rowColumnLayout(numberOfColumns=4)
		cmds.button(label="Connect Single",c = connectSingle,width=98)
		cmds.button(label="Clear Offset",c = clearOffset,width=98)
		cmds.button(label="Restore Offset",c = restoreClearOffset,width=98)
		cmds.button(label="Clear All Curve",c = clearAllCurve,width=98)
		cmds.button(label="Export Guide",c = exportGuide,width=98)
		cmds.button(label="Import Guide",c = importGuide,width=98)
	
		cmds.button(label="Export Guide Attr",c = exportGuideAttr,width=98)
		cmds.button(label="Import Guide Attr",c = importGuideAttr,width=98)
		cmds.button(label="Export Guide Hiera",c = exportGuideHierarchy,width=98)
		cmds.button(label="Import Guide Hiera",c = importGuideHierarchy,width=98)

		cmds.button(label="Fix Twist",c = FixTwist,width=98)
		cmds.button(label="Modify Layers",c =ModifyLayers,width=98)
		

		cmds.setParent("..")
		cmds.setParent("..")
		
		cmds.setParent("..")

def clearForm(*arr):
	dataClear = [
		["textField","prefixRight"],
		["textField","prefixLeft"],
		["textField","matchOldCtrlUrl"],
		["scrollField","beforeMatchScript"],
		["scrollField","afterMatchScript"],
		["scrollField","beforeBuildScript"],
		["scrollField","afterBuildScript"],
		["intField","maxInfluences"],
	]
	for a in range(len(dataClear)):
		if dataClear[a][0] == "textField":
			if cmds.textField(dataClear[a][1],query=True,exists=True):
				cmds.textField(dataClear[a][1],edit=True,text="")
		elif dataClear[a][0] == "scrollField": 
			if cmds.scrollField(dataClear[a][1],query=True,exists=True):
				cmds.scrollField(dataClear[a][1],edit=True,text="")
		elif dataClear[a][0] == "intField":  
			if cmds.intField(dataClear[a][1],query=True,exists=True):
				cmds.intField(dataClear[a][1],edit=True,value=0)
			"""    
			cmds.textField("prefixRight",edit=True,text="")
			cmds.textField("prefixLeft",edit=True,text="")
			cmds.scrollField("beforeMatchScript",edit=True,text="")
			cmds.scrollField("afterMatchScript",edit=True,text="")
			cmds.scrollField("beforeBuildScript",edit=True,text="")
			cmds.scrollField("afterBuildScript",edit=True,text="")
			cmds.textField("matchOldCtrlUrl",edit=True,text="")    
			cmds.intField("maxInfluences",edit=True,value=0)
			"""

def changePattern(*arr):
	#pm.mel.eval('source "C:/Users/an.nguyen_g/Documents/maya/scripts/NLTA/library/AdvancedSkeleton5.778/AdvancedSkeleton5/AdvancedSkeleton5.mel";AdvancedSkeleton5;')
	pm.mel.eval('source "C:/Users/an.nguyen_g/Documents/maya/scripts/NLTA/library/AdvancedSkeleton5.850/AdvancedSkeleton5.mel";AdvancedSkeleton5;')
	user = os.environ.get("USERNAME")
	global dataSession
	pattern = cmds.optionMenu("patternAS",q=True,value=True)
	
	#DELETE AS EXIST
	for a in cmds.ls("FitSkeleton",ap=True):
		if not cmds.listRelatives(a,p=True):
			cmds.delete(a)
			
	#IMPORT PATTERN FILE                                                                                                                                          
	#pm.mel.eval('file -import -type "mayaAscii"  -ignoreVersion -ra true -mergeNamespacesOnClash true -namespace ":" -options "v=0;"  -pr  -importTimeRange "combine" "C:/Users/an.nguyen_g/Documents/maya/scripts/NLTA/library/AdvancedSkeleton5.778/AdvancedSkeleton5/AdvancedSkeleton5Files/fitSkeletons/'+pattern+'.ma";')    
	pm.mel.eval('file -import -type "mayaAscii"  -ignoreVersion -ra true -mergeNamespacesOnClash true -namespace ":" -options "v=0;"  -pr  -importTimeRange "combine" "C:/Users/an.nguyen_g/Documents/maya/scripts/NLTA/library/AdvancedSkeleton5.850/AdvancedSkeleton5Files/fitSkeletons/'+pattern+'.ma";')       
	#SOLVE DATASESSION["PAIR"]
	dataSession = {}
	for a in toolSetting["patternData"]:
		dataSession[a] = toolSetting["patternData"][a]
	
	for a in toolSetting["patternInput"][pattern]:
		dataSession[a] = toolSetting["patternInput"][pattern][a]
		
	dataSession["pair"] = []    
	for a in toolSetting["patternInput"][pattern]["order"]:
		exist = general.checkOnly([a,"FitSkeleton"])
		dataSession["pair"].append([exist])
	
	#DELETE ALL INPUT JOINTS
	input = cmds.rowColumnLayout("inputJoint", q = True, ca= True)
	if input:
		for a in input:
			try:
				cmds.deleteUI(a)
			except:pass
			
	#DELETE ALL INPUT VERTEX
	input = cmds.frameLayout("inputVertex", q = True, ca= True)
	if input:
		for a in input:
			try:
				cmds.deleteUI(a)
			except:pass
	
	#CREATE NEW INPUT JOINT           
	input_data = dataSession["order"]
	for a in range(len(input_data)):
		cmds.rowColumnLayout("input"+str(a),numberOfColumns=3,parent = "inputJoint")
		cmds.textField(text=input_data[a],width=170,editable=False)
		cmds.button(label=">",width=30,c=partial(set_pair,input_data[a]))
		cmds.textField(input_data[a],width=170,editable=False,pht="Joint only.")
		cmds.setParent("..")
		
	#CREATE NEW INPUT VERTEX   
	cmds.rowColumnLayout(numberOfColumns=2,parent="inputVertex")
	cmds.textField(text="Connect Scale",width=100,editable=False)
	cmds.checkBox("connectScale",label="",cc=connectScale)
	cmds.setParent("..")
	input_data = dataSession["vertex"]
	for a in range(len(input_data)):
		cmds.rowColumnLayout(numberOfColumns=3,parent="inputVertex")
		cmds.textField(text="* "+input_data[a]+" Vtx",width=171,editable=False)
		cmds.button(label=">",width=30,c=partial(positionVtx,input_data[a]+"Vtx"))
		cmds.textField(input_data[a]+"Vtx",width=180,editable=False,pht="Vertex only.")
		cmds.setParent("..")
	addMinus = [
		["exceptJoint","Except joint (Ctrl)"],
		["exceptJointSkin","Except joint (Skin)"],
	]
	for a in range(len(addMinus)):
		dataTemp = addMinus[a]
		name = dataTemp[0]
		title = dataTemp[1]
		cmds.rowColumnLayout(numberOfColumns=4,parent="inputVertex")    
		cmds.textField(text=title,width=141,editable=False)
		cmds.button(label="+",width=30,c=partial(addMinusAdd,name))
		cmds.button(label="-",width=30,c=partial(addMinusMinus,name))
		cmds.scrollField(name,wordWrap=True,width=179,height=100,editable=False)
		cmds.setParent("..")
	cmds.rowColumnLayout(numberOfColumns=4,parent="inputVertex")
	cmds.textField(text="Max Influences",width=200,editable=False)
	cmds.intField("maxInfluences",width=180,value=0)
	cmds.setParent("..")
	cmds.rowColumnLayout(numberOfColumns=4,parent="inputVertex")
	cmds.textField(text="Ctrl match",width=170,editable=False)
	cmds.button(label=">",width=30,c = matchOldCtrlLink)
	cmds.textField("matchOldCtrlUrl",pht="Maya old file url",width=180)
	cmds.setParent("..") 
	clearForm()     
				
def matchJoint(*arr):
	general.runScript("beforeMatchScript")
	global dataSession    
	right_refix = cmds.textField("prefixRight",query=True,text=True)
	left_refix = cmds.textField("prefixLeft",query=True,text=True)
	if right_refix == "" or left_refix == "":
		cmds.confirmDialog(title="Confirm",message="Please fill Prefix right and left!",button=["Yes"],defaultButton="Yes",cancelButton="Yes")  
	else:
		
		joint_matched = []
		joint_not_match = []
		constraint_pair = []
				
		#SOLVE PREFIX
		dataSession["prefix"] = [right_refix,left_refix]       
		for a in range(len(dataSession["pair"])):
			if len(dataSession["pair"][a])>1:                
				if dataSession["pair"][a][1].endswith(right_refix):
					dataSession["prefixPosition"]="end"
					break 
			
		#CREATE DICTS
		modifyParent = {}
		for a in range(len(dataSession["order"])):
			if len(dataSession["pair"][a]) > 1:
				dataSession["as_dict"][dataSession["order"][a]] = dataSession["pair"][a][0]
				dataSession["max_dict"][dataSession["order"][a]] = dataSession["pair"][a][1]
				if cmds.listRelatives(dataSession["pair"][a][1],parent=True):
					modifyParent[cmds.listRelatives(dataSession["pair"][a][1],parent=True)[0]] = dataSession["pair"][a][0]
		
		#GET MAX JOINT
		pelvis = dataSession["max_dict"]["Root"]
		pelvis_hierachy = cmds.listRelatives(pelvis,ad=True,path=True)
		pelvis_hierachy.append(pelvis)
		for jointTemp in pelvis_hierachy:            
			cmds.transformLimits(jointTemp, enableRotationX=[False, False])
			cmds.transformLimits(jointTemp, enableRotationY=[False, False])
			cmds.transformLimits(jointTemp, enableRotationZ=[False, False])
			
			for attr in ["rx","ry","rz","tx","ty","tz","sx","sy","sz"]:
				cmds.setAttr(jointTemp+'.'+attr,lock=False)

			cmds.makeIdentity(jointTemp,apply=True,s=1,n=0)
			
		max_joint = pelvis_hierachy[::-1]
		dataSession["max_joint"] = max_joint

		#scale FitSkeleton
		as_root = dataSession["as_dict"]["Root"]        
		pelvis_y = cmds.xform(pelvis, query=True, worldSpace=True, translation=True)[1]
		root_y = cmds.xform(as_root, query=True, worldSpace=True, translation=True)[1]
		cmds.setAttr("FitSkeleton.scaleX",pelvis_y/root_y)
		cmds.setAttr("FitSkeleton.scaleY",pelvis_y/root_y)
		cmds.setAttr("FitSkeleton.scaleZ",pelvis_y/root_y)
		pm.mel.eval('makeIdentity -apply true  -t 0 -r 0 -s 1 -n 0 -pn 1 "FitSkeleton";')
		cmds.makeIdentity("FitSkeleton")
		
		#CUSTROM JOINT CHAIN ARRAY
		jointChain = []
		for a in range(len(dataSession["jointBetween"])):            
			source = dataSession["jointBetween"][a][0]
			dest = dataSession["jointBetween"][a][1]
			namePattern = dataSession["jointBetween"][a][2]
			if source in dataSession["max_dict"] and dest in dataSession["max_dict"]:
				jointChain.append([
					general.checkOnly([dataSession["as_dict"][source],"FitSkeleton"]),
					general.checkOnly([dataSession["as_dict"][dest],"FitSkeleton"]),
					dataSession["max_dict"][source],
					dataSession["max_dict"][dest],
					namePattern
				])
				
		#SOLVE JOINT CHAIN
		for a in range(len(jointChain)):
			create_info = []
			create_info.append(jointChain[a][0])
			create_info.append(jointChain[a][1])
			create_info.append(jointChain[a][2])
			create_info.append(jointChain[a][3])
			create_info.append(jointChain[a][4])
			array_result = general.MatchJoint(create_info)
			joint_matched.extend(array_result)
			constraint_pair.extend(array_result)
		
		#SOLVE TWIST JOINT 
		twist_joint = []
		for a in range(len(dataSession["twistBetween"])):
			pair = dataSession["twistBetween"][a]
			if pair[0] in dataSession["max_dict"] and pair[1] in dataSession["max_dict"]:
				joint_between = general.hierachyBetween([dataSession["max_dict"][pair[0]],dataSession["max_dict"][pair[1]]])
				if len(joint_between) > 2:                  
					if pair[0] == "Knee":
						try:
							pm.mel.eval('addAttr -ln "twistJoints"  -at long -dv 0 '+pair[0]+';')
							pm.mel.eval('setAttr -e-keyable true '+pair[0]+'.twistJoints;')
							pm.mel.eval('addAttr -ln "bendyJoints" -at bool '+pair[0]+';')
							pm.mel.eval('setAttr -e-keyable true '+pair[0]+'.bendyJoints;')
						except (Exception,):pass
					dataSession["twist_dict"][pair[0]] = joint_between[1:-1]
					twist_joint.extend(joint_between[1:-1])
					pm.mel.eval('setAttr "'+dataSession["as_dict"][pair[0]]+'.twistJoints" '+str(len(joint_between) - 2)+';')
					pm.mel.eval('setAttr "'+dataSession["as_dict"][pair[0]]+'.bendyJoints" 1;')
				else:
					if pair[0] != "Knee":
						try:
							pm.mel.eval('setAttr "'+dataSession["as_dict"][pair[0]]+'.twistJoints" 0;')
							pm.mel.eval('setAttr "'+dataSession["as_dict"][pair[0]]+'.bendyJoints" 0;')
						except (Exception,):pass
		twist_joint_left = []

		for a in twist_joint:
			name_temp = a.replace(right_refix,left_refix)
			if "prefixPosition" in dataSession:
				if a.endswith(left_refix):
					name_temp = a[0:-(len(right_refix))]+left_refix          
			if cmds.objExists(name_temp):
				twist_joint_left.append(name_temp)

		twist_joint.extend(twist_joint_left)
		

		max_joint_matched = list(zip(*joint_matched))[0]        

		#MATCH JOINT
		for a in range(len(dataSession["order"])):            
			if len(dataSession["pair"][a])>1:
				as_pattern = dataSession["order"][a]               
				as_joint_temp = general.checkOnly([dataSession["pair"][a][0],"FitSkeleton"])
				max_joint_temp = general.checkOnly([dataSession["pair"][a][1],max_joint[0]])
				if as_joint_temp not in max_joint_matched:
					if general.checkSubString([as_pattern,["Wrist","Finger"]]):                        
					#if general.checkSubString([as_pattern,["Finger"]]):

						cmds.matchTransform(as_joint_temp,max_joint_temp,pos=True,rot=True)
						constraint_pair.append([as_joint_temp,max_joint_temp])#
						if general.checkSubString([as_pattern,["Finger"]]):                           
							if cmds.listRelatives(as_joint_temp,ad=True):
								max_joint_children = cmds.listRelatives(max_joint_temp,ad=True)[::-1]
								as_joint_children = cmds.listRelatives(as_joint_temp,ad=True)[::-1]
								for b in range(len(as_joint_children)):
									try:
										cmds.matchTransform(as_joint_children[b],max_joint_children[b],pos=True,rot=True)
										joint_matched.append([as_joint_children[b],max_joint_children[b]])
										constraint_pair.append([as_joint_children[b],max_joint_children[b]])#
									except (Exception,):pass                                
									try:
										cmds.addAttr(as_joint_children[b],longName='control', attributeType='bool', keyable=True, defaultValue=True)
									except:pass                               
					else:
						cmds.matchTransform(as_joint_temp,max_joint_temp,pos=True)
						if general.checkSubString([as_pattern,["Ankle"]]):
							pm.mel.eval('hilite '+as_joint_temp+';')
							pm.mel.eval('select -r '+as_joint_temp+'.rotateAxis ;')
							pm.mel.eval('rotate -r -os -fo 0 0 -90 ;')
							pm.mel.eval('hilite -u '+as_joint_temp+' ;')
						constraint_pair.append([as_joint_temp,max_joint_temp])#             
					joint_matched.append([as_joint_temp,max_joint_temp])

		#CUSTOM ATTRIBUTE
		as_joint = cmds.listRelatives(as_root,ad=True,path=True)
		as_joint.insert(0,as_root)
		for a in as_joint:
			if general.checkSubString([a,["Root"]]):
				try:
					pm.mel.eval('setAttr "Root.numMainExtras" 1;')
				except:pass                
			try:
				cmds.setAttr(a+".inbetweenJoints",0)
			except:pass
			
			if cmds.listRelatives(a,parent=True)[0]=="Cup":
			   cup_parent = cmds.listRelatives("Cup",parent=True)
			   cmds.parent(a,cup_parent)
			if "attribute" in dataSession:
				for b in dataSession["attribute"]:
					if b == "global":
						if general.checkSubString([a,dataSession["attribute"][b]]):
							try:
								pm.mel.eval('addAttr -ln "global"  -at double  -min 0 -max 10 -dv 0 '+a+';')
								pm.mel.eval('setAttr -e-keyable true '+a+'.global;')
							except (Exception,):pass
					if b == "ikLocal":
						if general.checkSubString([a,dataSession["attribute"][b]]):
							try:
								pm.mel.eval('addAttr -ln "ikLocal"  -at "enum" -en "addCtrl:nonZero:localOrient"  '+a+';')
								pm.mel.eval('setAttr -e-keyable true '+a+'.ikLocal;')
								pm.mel.eval('setAttr "'+a+'.ikLocal" 2;')
							except (Exception,):pass   
					if b == "worldOrientForward":
						if general.checkSubString([a,dataSession["attribute"][b]]):
							if not cmds.attributeQuery("worldOrientUp", exists=True, node=a):                        
								pm.mel.eval('addAttr -ln "worldOrientUp"  -at "enum" -en "xUp:yUp:zUp:xDown:yDown:zDown"  '+a+';')
								pm.mel.eval('setAttr -e -keyable true '+a+'.worldOrientUp;')
							if not cmds.attributeQuery("worldOrient", exists=True, node=a):                                
								pm.mel.eval('addAttr -ln "worldOrient"  -at "enum" -en "xUp:yUp:zUp:xDown:yDown:zDown"  '+a+';')
								pm.mel.eval('setAttr -e -keyable true '+a+'.worldOrient;')
							if not cmds.attributeQuery("worldOrientForward", exists=True, node=a):
								pm.mel.eval('addAttr -ln "worldOrientForward"  -at "enum" -en "xForward:yForward:zForward:xBackward:yBackward:zBackward:free"  '+a+';')
								pm.mel.eval('setAttr -e-keyable true '+a+'.worldOrientForward;')
							try:             
								pm.mel.eval('setAttr "'+a+'.worldOrientUp" 1;')
								pm.mel.eval('setAttr "'+a+'.worldOrient" 1;')
								pm.mel.eval('setAttr "'+a+'.worldOrientForward" 0;')
							except:pass
					if b == "control":
						if general.checkSubString([a,dataSession["attribute"][b]]):
							try:
								cmds.addAttr(a,longName='control', attributeType='bool', keyable=True, defaultValue=True)
							except:pass
					if b == "freeOrient":
						if general.checkSubString([a,dataSession["attribute"][b]]):
							try:
								cmds.addAttr(a,longName='freeOrient', attributeType='bool', keyable=True, defaultValue=True)
							except (Exception,):pass
					if b == "orientJoint":
						if general.checkSubString([a,dataSession["attribute"][b]]):  
							cmds.select(a)
							pm.mel.eval('joint -e  -oj xyz -secondaryAxisOrient zup -ch -zso;')
		#DELTE AS_JOINT            
		max_joint_matched = list(zip(*joint_matched))[1]        
		as_joint_matched = list(zip(*joint_matched))[0]
		for a in as_joint:
			if a not in as_joint_matched:
				if a+"Vtx" in dataSession["vertexPosition"]:
					cmds.xform(a,worldSpace=True,translation=dataSession["vertexPosition"][a+"Vtx"])                   
				else:
					joint_children_temp = cmds.listRelatives(a,children=True,type="joint",pa=True)
					if joint_children_temp:
						joint_parent_temp = cmds.listRelatives(a,parent=True,type="joint",pa=True)
						if joint_parent_temp:
							joint_parent_temp = joint_parent_temp[0]
							for b in joint_children_temp:
								if b in as_joint_matched:
									cmds.parent(b,joint_parent_temp)
					cmds.delete(a)
							
		#Free transform wrist and finger
		wristAs = general.checkOnly(["Wrist","FitSkeleton"])
		wristChildren = cmds.listRelatives(wristAs,ad=True)[::-1]
		wristChildren.insert(0,wristAs)
		for a in wristChildren:
			cmds.select(a)
			pm.mel.eval('makeIdentity -apply true -t 1 -r 1 -s 1 -n 0 -pn 1;')
			if cmds.listRelatives(a,children=True):
				if "Thumb" in a:
					pm.mel.eval('joint -e  -oj xyz -secondaryAxisOrient xup -ch -zso;') 
				else:                    
					pm.mel.eval('joint -e  -oj xyz -secondaryAxisOrient zup -ch -zso;') 
			else:                
				pm.mel.eval('joint -e  -oj none -ch -zso;')
					   
		#REMOVE MIRROR JOINT        
		max_joint_unMatched = list(set(max_joint) - set(max_joint_matched))
		array_except_temp = []      
		for i in max_joint_unMatched:
			if left_refix in i:
				mirror_joint = ""
				if "prefixPosition" in dataSession:
					if i.endswith(left_refix):
						mirror_joint = i[0:-(len(left_refix))]+right_refix
				else:           
					mirror_joint = i.replace(left_refix,right_refix)    
				#1. HAS MIRROR NAME IN MATCHED
				if cmds.objExists(mirror_joint):
					if(mirror_joint in max_joint_matched):
						array_except_temp.append(i)                     
				#2. HAS MIRROR NAME IN UNMATCH AND SAME PARENT NAME (REPLACE SIDE) IN MATCHED 
				if cmds.objExists(mirror_joint):
					mirror_parent = cmds.listRelatives(mirror_joint,p=True)
					if mirror_parent:
						if (mirror_parent[0] in max_joint_matched) and (mirror_joint in max_joint_unMatched):
							array_except_temp.append(i)
		max_joint_unMatched = list(set(max_joint_unMatched) - set(array_except_temp))
		max_joint_unMatched = list(set(max_joint_unMatched) - set(twist_joint))
	
		#ADD JOINT            
		remove_joint_temp = []
		for a in max_joint_unMatched:
			if (a not in dataSession["exceptJoint"]):
				parentJoint = cmds.listRelatives(a,parent=True,pa=True)
				#IF HAS PARENT              
				if parentJoint:
					parent_temp = parentJoint[0]
					children_temp = cmds.listRelatives(a,children=True,ad=True)
					#CHECK SIDE
					if "prefixPosition" in dataSession:
						if a.endswith(right_refix):
							side = "right"
							mirror = a[0:-(len(right_refix))]+left_refix    
						elif a.endswith(left_refix):
							side = "left"
							if parent_temp.endswith(left_refix):
								parent_mirror = parent_temp[0:-(len(left_refix))]+right_refix
							else:
								side = "middle"
						else:
							side = "middle"
							mirror = a[0:-(len(right_refix))]+left_refix                     
					else:
						if right_refix in a:
							side = "right"
							mirror = a.replace(right_refix,left_refix)
						elif left_refix in a:
							side = "left"
							if left_refix in parent_temp:
								parent_mirror = parent_temp.replace(left_refix,right_refix)
							else:
								side = "middle"
						else:
							side = "middle"
							mirror = a[0:-(len(right_refix))]+left_refix 
					
					if children_temp:
						a_hierachy = children_temp[::-1]
						a_hierachy.insert(0,a)
					else:
						a_hierachy = [a]
						
					#IF JOINT IN LEFT SIDE
					if parent_temp not in max_joint_matched:
						parent_mirror = parent_temp.replace(left_refix,right_refix)                     
						if parent_mirror in max_joint_matched:                 

							new_joint_uuid = cmds.ls(list(cmds.duplicate(a,renameChildren=True)),uuid=True)
							jointNewParent = cmds.ls(new_joint_uuid[0])[0]
						   
							if cmds.listRelatives(jointNewParent,children=True,ad=True,path=True):                                
								new_joint_temp = cmds.listRelatives(jointNewParent,children=True,ad=True,path=True)[::-1]
								new_joint_temp.insert(0,jointNewParent)
							else:
								new_joint_temp = [jointNewParent]
							new_joint_uuid =  cmds.ls(new_joint_temp,uuid=True)
							new_joint_temp = []

							for b in new_joint_uuid:
								currentName = (cmds.ls(b)[0].split("|"))[-1]                      
								newName = currentName+"_AS"
								cmds.rename(cmds.ls(b)[0],newName) 
								new_joint_temp.append(newName)
							jointNewParent = cmds.ls(new_joint_uuid[0])[0]              

							as_index = max_joint_matched.index(parent_mirror)
							as_name = as_joint_matched[as_index]
							for b in new_joint_temp:
								cmds.addAttr(b,longName='freeOrient', attributeType='bool', keyable=True, defaultValue=True)
								cmds.addAttr(b,longName='control', attributeType='bool', keyable=True, defaultValue=True)
								cmds.addAttr(b,longName='noMirror', attributeType='bool', keyable=True, defaultValue=True)
								cmds.addAttr(b,longName='noMirrorLeft', attributeType='bool', keyable=True, defaultValue=True)
								cmds.setAttr(b+".noMirrorLeft",1)

							cmds.select(clear=True)
							newJoint = cmds.joint()
							cmds.parent(jointNewParent,newJoint)
							cmds.select(jointNewParent)
							mirrorJoint = pm.mel.eval("mirrorJoint -mirrorYZ -mirrorBehavior;")
							cmds.delete(jointNewParent)
							new_joint_uuid = cmds.ls(mirrorJoint,uuid=True)
							jointNewParent = cmds.ls(new_joint_uuid[0])[0]                            
							cmds.parent(jointNewParent,as_name)
							cmds.delete(newJoint)
							
							if cmds.listRelatives(jointNewParent,children=True,ad=True,path=True):                                
								new_joint_temp_mirror = cmds.listRelatives(jointNewParent,children=True,ad=True,path=True)[::-1]
								new_joint_temp_mirror.insert(0,jointNewParent)
							else:
								new_joint_temp_mirror = [jointNewParent]

							new_joint_uuid =  cmds.ls(new_joint_temp_mirror,uuid=True)
							

							for b in range(len(new_joint_temp)):
								cmds.rename(cmds.ls(new_joint_uuid[b])[0],new_joint_temp[b])

							jointNewParent = cmds.ls(new_joint_uuid[0])[0]
							if cmds.listRelatives(jointNewParent,children=True,ad=True,path=True):
								new_joint_temp = cmds.listRelatives(jointNewParent,children=True,ad=True,path=True)[::-1]
								new_joint_temp.insert(0,jointNewParent)
							else:
								new_joint_temp = [jointNewParent]

							for b in range(len(new_joint_temp)):
								constraint_pair.append([new_joint_temp[b],a_hierachy[b]])

					# IF JOINT IN RIGHT SIDE OR MID
					else:
						new_joint_uuid = cmds.ls(list(cmds.duplicate(a,renameChildren=True)),uuid=True)
						jointNewParent = cmds.ls(new_joint_uuid[0])[0]
					   
						if cmds.listRelatives(jointNewParent,children=True,ad=True,path=True):                                
							new_joint_temp = cmds.listRelatives(jointNewParent,children=True,ad=True,path=True)[::-1]
							new_joint_temp.insert(0,jointNewParent)
						else:
							new_joint_temp = [jointNewParent]
						new_joint_uuid =  cmds.ls(new_joint_temp,uuid=True)
						new_joint_temp = []

						for b in new_joint_uuid:
							currentName = (cmds.ls(b)[0].split("|"))[-1]                      
							newName = currentName+"_AS"
							cmds.rename(cmds.ls(b)[0],newName) 
							new_joint_temp.append(newName)
						jointNewParent = cmds.ls(new_joint_uuid[0])[0]

						#BE CHILDREN OF AS JOINT    
						as_index = max_joint_matched.index(parent_temp)
						as_name = as_joint_matched[as_index]                                
						cmds.parent(jointNewParent,w=True)
						group_temp = cmds.listRelatives(jointNewParent,p=True)
						if group_temp:
							pm.mel.eval('makeIdentity -apply true  -t 1 -r 1 -s 1 -n 0 -pn 1 "'+group_temp[0]+'";')
							cmds.parent(jointNewParent,as_name)                        
							cmds.delete(group_temp[0])
						else:
							cmds.parent(jointNewParent,as_name)    
						
						
						#HANDLE JOINT LIKE CUP
						if len(new_joint_temp) > 1:                                         
							if a_hierachy[1] in max_joint_matched:
								cmds.delete(new_joint_temp[1])
								as_index = max_joint_matched.index(a_hierachy[1])
								as_name = as_joint_matched[as_index]
								cmds.parent(as_name,new_joint_temp[0])
								new_joint_hierachy = [new_joint_temp[0]]
							else:
								new_joint_hierachy = new_joint_temp
						else:
							new_joint_hierachy = [new_joint_temp[0]]
						

						if side == "right" and mirror in max_joint_unMatched:
							try:
								cmds.addAttr(new_joint_hierachy[0],longName='noMirror', attributeType='bool', keyable=True, defaultValue=True)
							except:pass
							
						#SET ATTRIBUTE
						for b in new_joint_hierachy:
							try:
								cmds.addAttr(b,longName='freeOrient', attributeType='bool', keyable=True, defaultValue=True)
							except:pass
							try:
								cmds.addAttr(b,longName='control', attributeType='bool', keyable=True, defaultValue=True)
							except:pass
							if side == "middle":
								try:
									cmds.addAttr(b,longName='noMirror', attributeType='bool', keyable=True, defaultValue=True)
								except:pass

						#ADD TO REMOVE ARRAY        
						for b in a_hierachy:
							if b in max_joint_unMatched:
								remove_joint_temp.append(b)
							if side == "right":
								if mirror in max_joint_unMatched:
									remove_joint_temp.append(mirror)
						
						#ADD TO CONSTAINT ARRAY
						for b in range(len(new_joint_hierachy)):
							constraint_pair.append([new_joint_hierachy[b],a_hierachy[b]])#

				   
		max_joint_unMatched = list(set(max_joint_unMatched) - set(remove_joint_temp))
		dataSession["constraint_pair"] = []
		
		for a in range(len(constraint_pair)):
			dataSession["constraint_pair"].append([cmds.ls(constraint_pair[a][0],uuid=True),cmds.ls(constraint_pair[a][1],uuid=True)])

		#Store Old guide
		if "oldGuide" in dataSession:
			for a in range(len(dataSession["oldGuide"])):
				jointName = dataSession["oldGuide"][a][0]
				jointAttr = dataSession["oldGuide"][a][1]
				if cmds.objExists(jointName):
					if cmds.getAttr(jointName+".translateX",settable=True):
						pm.mel.eval('setAttr "'+jointName+'.translateX" '+str(jointAttr[0])+';')
					if cmds.getAttr(jointName+".translateY",settable=True):
						pm.mel.eval('setAttr "'+jointName+'.translateY" '+str(jointAttr[1])+';')
					if cmds.getAttr(jointName+".translateZ",settable=True):      
						pm.mel.eval('setAttr "'+jointName+'.translateZ" '+str(jointAttr[2])+';')
					if cmds.getAttr(jointName+".rotateX",settable=True):  
						pm.mel.eval('setAttr "'+jointName+'.rotateX" '+str(jointAttr[3])+';')
					if cmds.getAttr(jointName+".rotateY",settable=True):   
						pm.mel.eval('setAttr "'+jointName+'.rotateY" '+str(jointAttr[4])+';')
					if cmds.getAttr(jointName+".rotateZ",settable=True):  
						pm.mel.eval('setAttr "'+jointName+'.rotateZ" '+str(jointAttr[5])+';')
						
	general.runScript("afterMatchScript")
	print("Match joint done!!")
   
def clearOffset(*arr):
	for a in cmds.ls(selection=True):
		groupNew = cmds.group(n=a+"_fixOffset",empty=True)
		parentName = cmds.listRelatives(a,parent=True)[0]
		cmds.matchTransform(groupNew,a,rot=True,pos=True)
		cmds.parent(groupNew,parentName)
		cmds.parent(a,groupNew)
		
def restoreClearOffset(*arr):
	fixOffset = cmds.ls("*fixOffset*",type='transform')
	for a in fixOffset:
		parentName = cmds.listRelatives(a,parent=True)[0]
		childrenName = cmds.listRelatives(a,children=True)[0]
		cmds.parent(childrenName,parentName)
		cmds.delete(a)
		for attr in ["rx","ry","rz","tx","ty","tz"]:
			cmds.setAttr(childrenName+"."+attr,0)

   
def buildAS(*arr):
	disconnect("groupConstraintAsFbx")
	restoreClearOffset() 
	mel.eval('rehash;')
	#pm.mel.eval('source "C:/Users/an.nguyen_g/Documents/maya/scripts/NLTA/library/AdvancedSkeleton5.778/AdvancedSkeleton5/AdvancedSkeleton5.mel";AdvancedSkeleton5;')
	pm.mel.eval('source "C:/Users/an.nguyen_g/Documents/maya/scripts/NLTA/library/AdvancedSkeleton5.850/AdvancedSkeleton5.mel";AdvancedSkeleton5;')
	general.runScript("beforeBuildScript")
	
	cmds.lockNode('initialShadingGroup', l=0, lockUnpublished=0)
	#unload all preference        
	for RN in cmds.ls(rf = True):
		cmds.file(unloadReference = RN)
	 
	   
	#BUILD ADVANCE SKELETON
	pm.mel.eval('asReBuildAdvancedSkeleton;')
	
	#load all preference
	for RN in cmds.ls(rf = True):
		cmds.file(loadReference = RN)           
	
	connectAsFbxData()
	connectFbxAsData()
	ModifyControl()
	changeColorCtrl()
	matchOldCtrl()
	rotateFingerSession()
				   
	#MESH SKINED TO LAYER
	mesh_parent = []
	for a in cmds.ls(type="mesh",r=True):
		for b in cmds.listHistory(a):
			if cmds.nodeType(b)=="skinCluster":
				mesh_parent.append(a)
	LayerName = 'GeoLayer'
	if pm.objExists(LayerName):
		pm.delete(LayerName)
	DisplayLayer = pm.createDisplayLayer(name=LayerName, empty=True)
	pm.editDisplayLayerMembers(DisplayLayer,mesh_parent, noRecurse=True)
	DisplayLayer.displayType.set(2)
	DisplayLayer.visibility.set(1)
	
	#CONTROL LAYSER
	LayerName = 'ControlsLayer'
	if pm.objExists(LayerName):
		pm.delete(LayerName)
	DisplayLayer = pm.createDisplayLayer(name=LayerName, empty=True)
	pm.editDisplayLayerMembers(DisplayLayer, 'MotionSystem', noRecurse=True)
	DisplayLayer.color.set(29)      
	cmds.select(clear=True)
		
	#AS JOINT LAYER
	LayerName = 'ASJointLayer'
	if pm.objExists(LayerName):
		pm.delete(LayerName)
	DisplayLayer = pm.createDisplayLayer(name=LayerName, empty=True)
	pm.editDisplayLayerMembers(DisplayLayer,"DeformationSystem", noRecurse=True)
	DisplayLayer.displayType.set(2)
	DisplayLayer.visibility.set(0) 
	cmds.select(clear=True)
	
	#MAX JOINT LAYER
	LayerName = 'BindJointLayer'
	if pm.objExists(LayerName):
		pm.delete(LayerName)
	DisplayLayer = pm.createDisplayLayer(name=LayerName, empty=True)
	DisplayLayer.displayType.set(2)
	DisplayLayer.visibility.set(0)
	try:
		pm.editDisplayLayerMembers(DisplayLayer,dataSession["maxParent"][0], noRecurse=True)
	except:pass
		
	cmds.select(clear=True)
	general.runScript("afterBuildScript")  
	print("Build done!")
	
def changeColorCtrl(*arr):
	allAsCtrl = cmds.listRelatives("ControlSet",ad=True,type="nurbsCurve")
	for a in allAsCtrl:
		transform = cmds.listRelatives(a,parent=True)[0]
		if transform.endswith("_R"):            
			if "twist" in a:
				indexColor = "20"
			else:
				indexColor = "13"
		elif transform.endswith("_L"):
			if "twist" in a:
				indexColor = "18"
			else:
				indexColor = "6"
		elif transform == "RootX_M":
			indexColor = "23"
		elif transform.endswith("_M"):
			indexColor = "17"        
		else:
			indexColor = "9"
		for b in cmds.listRelatives(transform,ad=True,type="nurbsCurve"):
			pm.mel.eval('setAttr '+b+'.overrideColor '+indexColor+';')

				
def importData(array,*arr):
	clearForm()            
	global dataSession
	global variableTemp
	if array[0]=="new":
		url = pm.fileDialog2(fileMode=1)
		if url:     
			url = url[0]
		else:
			url = None
	else:   
		url = variableTemp["importUrl"]
	if url:     
		variableTemp["importUrl"] = url
		myFile =  open(url,'r')
		myObject = myFile.read()
		myFile.close()
		data = json.loads(myObject)        
			
		if int(cmds.about(version=True)) < 2022:
			data = json.loads(myObject,'utf-8')
		else:
			data = json.loads(myObject)
		
		if "patternAS" in data:
			cmds.optionMenu("patternAS",edit=True,value = data["patternAS"])
			changePattern()
			
		for a in data:
			dataSession[a]=data[a]
			
		nameSpace = None
		nameSpaceArray = []
		for a in range(len(data["pair"])):
			asJoint = data["pair"][a][0]            
			if len(data["pair"][a]) > 1:
				fbxJoint = data["pair"][a][1]
				joints = cmds.ls(fbxJoint,r=True,type="joint",ap=True)
				if len(joints)==1:
					cmds.select(joints[0])
					set_pair(asJoint)
				else:
					joint_choiced = None             
					if nameSpace!=None:
						for b in joints:
							if nameSpace in b:
								joint_choiced = b        
					else:
						button_array = []
						for b in joints:                            
							button_array.append(b)                           
							if ":" in b:
								if b.split(":")[0] not in nameSpaceArray:
									nameSpaceArray.append(b.split(":")[0])
						if len(nameSpaceArray)!=0:
							for c in nameSpaceArray:
								button_array.append("Apply all:"+c)
							joint_choiced = cmds.confirmDialog( title='Confirm', message='Which one you choice', button=button_array)
							if "Apply all" in joint_choiced:
								nameSpace = joint_choiced.split(":")[1]
								for b in joints:
									if nameSpace in b:
										joint_choiced = b
						else:
							cmds.confirmDialog(title="Confirm",message="Can't find joint with name: "+fbxJoint,button=["Yes"],defaultButton="Yes",cancelButton="Yes")  
					if joint_choiced!=None:
						cmds.select(joint_choiced)
						set_pair(asJoint)
			else:
				cmds.select(clear=True)
				set_pair(asJoint)     
		for a in data:
			if a!="pair":
				if a == "prefix":
					cmds.textField("prefixRight",edit=True,text=data["prefix"][0])
					cmds.textField("prefixLeft",edit=True,text=data["prefix"][1]) 
				elif a in ["afterMatchScript","beforeMatchScript","beforeBuildScript","afterBuildScript","afterConnectScript"]:
					cmds.scrollField(a,edit=True,text=data[a])
				elif a == "maxInfluences":    
					cmds.intField(a,edit=True,value=data[a])
				elif a == "vertexPosition":
					for b in data["vertexPosition"]:
						if cmds.textField(b,q=True,ex=True):
							cmds.textField(b,text="Established",edit=True)            
				elif a in ["exceptJoint","exceptJointSkin"]:
					jointArray = []
					for b in data[a]:
						if len(cmds.ls(b,r=True,ap=True)) > 1:
							if nameSpace!=None:
								for c in cmds.ls(b,r=True,ap=True):
									if nameSpace in c:
										jointArray.append(c)
							else:
								button_array = []
								for c in joints:                            
									button_array.append(c)
								joint_choiced = cmds.confirmDialog( title='Confirm', message='Which one you choice', button=button_array)
								jointArray.append(joint_choiced)                                
						elif len(cmds.ls(b,r=True,ap=True)) == 1:
							jointArray.append(cmds.ls(b,r=True,ap=True)[0])
					dataSession[a] = jointArray
					jointString = (";").join(jointArray)
					cmds.scrollField(a,text=jointString,edit=True)
				elif a == "connectScale":
					cmds.checkBox("connectScale",edit=True,value=data[a])
				else:
					if a not in ["order"]:
						dataSession[a] = data[a]                   
		row = array[1]
		cmds.button("importData",edit=True,width=194)
		if not cmds.button("importDataAgain",query=True,exists=True):
			cmds.button("importDataAgain",label="Re Import Data",width=195,c = partial(importData,["reImport",row]),parent=row)
			
def exportData(*arr):
	if cmds.checkBox("oldGuideCheckbox",query=True,value=True):
		saveOldGuide()
	folder_temp = os.path.dirname(pm.sceneName())
	if not folder_temp:
		folder_temp = pm.mel.eval("SaveSceneAs;")
	folder_temp = os.path.dirname(pm.sceneName())
	if folder_temp:        
		file_path = os.path.dirname(pm.sceneName())+"/"+os.path.basename(pm.sceneName()).split(".")[0]+"_asPattern.txt"
		dataExport = {}
		for a in dataSession:
			dataExport[a] = dataSession[a]
		dataExport["pair"] = []
		for a in range(len(dataSession["pair"])):
			asJoint = dataSession["pair"][a][0].split(":")[-1]
			asJoint = asJoint.split("|")[-1]
			if len(dataSession["pair"][a]) > 1:
				bindJoint = dataSession["pair"][a][1].split(":")[-1]
				bindJoint = bindJoint.split("|")[-1]
				dataExport["pair"].append([asJoint,bindJoint])
			else:            
				dataExport["pair"].append([asJoint])
		dataExport["prefix"]=[cmds.textField("prefixRight",query=True,text=True),cmds.textField("prefixLeft",query=True,text=True)]
		dataExport["matchOldCtrlUrl"] = cmds.textField("matchOldCtrlUrl",query=True,text=True)
		dataExport["patternAS"] = cmds.optionMenu("patternAS",query=True,value=True)
		dataExport["maxInfluences"] = cmds.intField("maxInfluences",query=True,value=True)
		for a in ["beforeMatchScript","afterMatchScript","beforeBuildScript","afterBuildScript","afterConnectScript"]:
			dataExport[a] = cmds.scrollField(a,query=True,text=True)    
		
		#SOLVE ROTATE FINGER
		groupSDK = "SDKFKRingFinger1_R"
		data_temp = {}
		if cmds.objExists(groupSDK):
			for b in ["rx","ry","rz"]:            
				if cmds.connectionInfo(groupSDK+"."+b, isDestination=True):
					convertNode = cmds.connectionInfo(groupSDK+"."+b, sourceFromDestination=True)
					data_temp["converse"+b] = convertNode.split(".")[0]
					if  cmds.connectionInfo(data_temp["converse"+b]+".input", isDestination=True):
						spreadNode = cmds.connectionInfo(data_temp["converse"+b]+".input", sourceFromDestination=True)
						data_temp["bw"+b] = spreadNode.split(".")[0] 
						if "_rotateY" in data_temp["bw"+b]:
							if cmds.getAttr(data_temp["converse"+b]+".conversionFactor ") > 0:
								converse = 1  
							else:
								converse = -1
							data_temp["curlNode"] = data_temp["converse"+b]                        
							if b == "rx":
								data_temp["currentAxis"]="X"
							elif b == "ry":
								data_temp["currentAxis"]="Y"  
							elif b == "rz":
								data_temp["currentAxis"]="Z"
						   
						if "_rotateZ" in data_temp["bw"+b]:                        
							data_temp["spreadNode"] = data_temp["converse"+b]
							if b == "rx":
								data_temp["spreadAxis"]="X"
							elif b == "ry":
								data_temp["spreadAxis"]="Y"  
							elif b == "rz":
								data_temp["spreadAxis"]="Z"
			dataExport["rotateFinger"] = {
			   "fingerAxis":data_temp["currentAxis"],
			   "spreadAxis":data_temp["spreadAxis"],
			   "converse":converse
			}
		#SAVE FILE
		with open(file_path,"w") as json_file:
			json.dump(dataExport,json_file,sort_keys=False)
		print("Url export: " + file_path)                 
					

def set_pair(input,*arr):
	global dataSession
	if input in dataSession["order"]:
		input_index = dataSession["order"].index(input)
		selection = cmds.ls(selection=True,ap=True)
		if selection:
			if len(dataSession["pair"][input_index]) < 2:
				dataSession["pair"][input_index].append(selection[0])
			else:
				dataSession["pair"][input_index][1] = selection[0]
			joint_name = selection[0].split(":")[-1]
			joint_name = joint_name.split("|")[-1]
			cmds.textField(input,text = joint_name,edit=True,ann=str(selection[0]))
		else:
			dataSession["pair"][input_index] = [dataSession["pair"][input_index][0]]
			cmds.textField(input,text = "",edit=True)
			
def beforeMatchScriptLink(*arr):
	cmds.scrollField("beforeMatchScript",text=pm.fileDialog2(fileMode=1)[0],edit=True)
def runBeforeMatchScriptLink(*arr):
	general.runScript("beforeMatchScript")
 
def afterMatchScriptLink(*arr): 
	cmds.scrollField("afterMatchScript",text=pm.fileDialog2(fileMode=1)[0],edit=True)
def runAfterMatchScriptLink(*arr):
	general.runScript("afterMatchScript")
   
def beforeBuildScriptLink(*arr):
	cmds.scrollField("beforeBuildScript",text=pm.fileDialog2(fileMode=1)[0],edit=True)
def runBeforeBuildScriptLink(*arr):
	general.runScript("beforeBuildScript")
  
def afterBuildScriptLink(*arr): 
	cmds.scrollField("afterBuildScript",text=pm.fileDialog2(fileMode=1)[0],edit=True)
def runAfterBuildScriptLink(*arr):
	general.runScript("afterBuildScript")

def afterConnectScriptLink(*arr): 
	cmds.scrollField("afterConnectScript",text=pm.fileDialog2(fileMode=1)[0],edit=True)
def runAfterConnectScriptLink(*arr):
	general.runScript("afterConnectScript")

def matchOldCtrlLink(*arr): 
	cmds.textField("matchOldCtrlUrl",text=pm.fileDialog2(fileMode=1)[0],edit=True)

def positionVtx(name,*arr):
	vtx = cmds.ls(selection=True)
	if vtx and "vtx" in vtx[0]:
		clusterName = cmds.cluster(vtx)[1]
		dataSession["vertexPosition"][name] = cmds.xform(clusterName,worldSpace=True,q=True,scalePivot=True)
		cmds.delete(clusterName)
		cmds.textField(name,text="Established",edit=True,ann=str(dataSession["vertexPosition"][name]))
	else:
		dataSession.pop(name)
		cmds.textField(name,text="",edit=True)
			
def addMinusAdd(name,*arr):
	global dataSession
	if name not in dataSession:
		dataSession[name]=[]
	jointArray = cmds.ls(selection=True,ap=True)
	if jointArray :     
		for a in jointArray:
			if a not in dataSession[name]:
				dataSession[name].append(a)
		joint_string = (";").join(dataSession[name])
		cmds.scrollField(name,edit=True,text=joint_string)
		
def addMinusMinus(name,*arr):
	global dataSession    
	if name not in dataSession:
		dataSession[name]=[]
	jointArray = cmds.ls(selection=True,ap=True)
	if jointArray :
		for a in jointArray:
			if a in dataSession[name]:
				dataSession[name].remove(a)
		joint_string = (";").join(dataSession[name])
		cmds.scrollField(name,edit=True,text=joint_string)

def connectScale(*arr):
	dataSession["connectScale"] = cmds.checkBox("connectScale",value=True,query=True)
			
def disconnect(groupName,*arr):
	cmds.currentTime(0)
	try:
		cmds.delete(groupName)
	except:pass    
	if groupName == "groupConstraintFbxAs":
		try:            
			cmds.delete("jointAddedGroup")
		except:pass
 
def connectMain(array,*arr):
	type = array[0]
	group_content = array[1]
	joint_source = array[2]
	joint_dest = array[3]
	if cmds.objExists(joint_source) and cmds.objExists(joint_dest):
		if cmds.objExists("grp"+type+"-"+joint_source+"-"+joint_dest+"-"+"parent"):
			cmds.delete("grp"+type+"-"+joint_source+"-"+joint_dest+"-"+"parent")
		group_parent = "grp"+type+"-"+joint_source+"-"+joint_dest+"-"+"parent"
		group_offset = "grp"+type+"-"+joint_source+"-"+joint_dest+"-"+"offset"
		locator1 = "grp"+type+"-"+joint_source+"-"+joint_dest+"-"+"loc1"
		group_parent = cmds.group(n=group_parent,empty=True)
		cmds.matchTransform(group_parent,joint_source,rot=True,pos=True)
		cmds.select(clear=True)
		locator1 = cmds.group(n=locator1,empty=True)
		group_offset = cmds.group(locator1,n=group_offset)
		cmds.matchTransform(group_offset,joint_dest,rot=True,pos=True)
		cmds.parent(group_offset,group_parent)
		cmds.parentConstraint(joint_source,group_parent,mo=True)
		if  general.checkSubString([joint_dest,["PoleArm","PoleLeg"]]):
			constaint = cmds.pointConstraint(locator1,joint_dest,mo=True)
		elif joint_dest == "Main":
			constaint = cmds.pointConstraint(locator1,joint_dest,mo=True,skip="y")
		else:           
			constaint = cmds.parentConstraint(locator1,joint_dest,mo=True)
		cmds.parent(constaint,group_parent)

		try:
			connectScaleCheckbox = cmds.checkBox("connectScale", query=True, value=True)
			if connectScaleCheckbox ==  True:
				pm.mel.eval('connectAttr -f '+joint_source+'.scale '+group_parent+'.scale;')            
				cmds.setAttr(joint_dest+".sx", lock=False)
				cmds.setAttr(joint_dest+".sy", lock=False)
				cmds.setAttr(joint_dest+".sz", lock=False)
				constaintScale = cmds.scaleConstraint(locator1,joint_dest)
				cmds.parent(constaintScale,group_parent)
		except:
			pm.mel.eval('connectAttr -f '+joint_source+'.scale '+group_parent+'.scale;')            
			cmds.setAttr(joint_dest+".sx", lock=False)
			cmds.setAttr(joint_dest+".sy", lock=False)
			cmds.setAttr(joint_dest+".sz", lock=False)
			constaintScale = cmds.scaleConstraint(locator1,joint_dest)
			cmds.parent(constaintScale,group_parent)
		try:
			cmds.parent(group_parent,group_content)        
		except:pass

def connectSingle(*arr):
	connectMain(["FbxAs","groupConstraintAsFbx",cmds.ls(selection=True)[0],cmds.ls(selection=True)[1]])

def connectAsFbxData(*arr):
	global dataSession
	data_pair = dataSession["constraint_pair"]
	right_refix = dataSession["prefix"][0]
	left_refix = dataSession["prefix"][1]
	connected = []
	for a in range(len(data_pair)):
		if cmds.ls(data_pair[a][0]) and cmds.ls(data_pair[a][1]):
			as_joint  = cmds.ls(data_pair[a][0])[0]
			max_joint = cmds.ls(data_pair[a][1])[0]
			side = None
			if cmds.objExists(as_joint + "_M"):
				as_joint_real = as_joint + "_M"
				side = "M"
			elif cmds.objExists(as_joint + "_R"):
				as_joint_real = as_joint + "_R"
				side = "R"
			elif cmds.objExists(as_joint + "_L"):
				as_joint_real = as_joint + "_L"
				side = "L"
			
			#RIGHT JOINT
			if side == "R":
				as_joint_right = as_joint_real              
				as_joint_left = as_joint + "_L"
				max_joint_right = max_joint
				if "prefixPosition" in dataSession:
					max_joint_left = max_joint_right[0:-(len(right_refix))]+left_refix
				else:
					max_joint_left = max_joint_right.replace(right_refix,left_refix)                                                                       
				connected.append([as_joint_right,max_joint_right])                
				#IF HAS MIRROR JOINT
				if cmds.objExists(as_joint_left) and cmds.objExists(max_joint_left):
					connected.append([as_joint_left,max_joint_left])                    
			elif side in ["L","M"]:
				if len(connected) > 0:
					jointMatchTemp = list(zip(*connected))[0]
					if as_joint_real not in jointMatchTemp:
						connected.append([as_joint_real,max_joint])
				else:
					connected.append([as_joint_real,max_joint])                
						
	#CONSTRAINT TWIST JOINT
	for a in range(len(dataSession["prefix"])):
		if a == 0:
			as_refix = "_R"
		else:
			as_refix = "_L"         
		for b in dataSession["twist_dict"]:
			data_temp = dataSession["twist_dict"][b]               
			twist_from = 1
			for c in data_temp:
				as_joint_twist = b+"Part"+str(twist_from)+as_refix
				if a == 0:
					max_joint_twist = c
				else:
					max_joint_twist = c.replace(dataSession["prefix"][0],dataSession["prefix"][1])
				connected.append([as_joint_twist,max_joint_twist])#
				twist_from = twist_from + 1                    
	dataSession["connectAsFbx"] = connected
		
def connectAsFbx(*arr):
	disconnect("groupConstraintFbxAs")
	disconnect("groupConstraintRefFbx")
	connected = []
	if cmds.objExists("DeformSet"):
		all_group_parent = cmds.group(empty=True,n="groupConstraintAsFbx")
		dataSession["groupConstraintAsFbx"] = all_group_parent
		if "connectAsFbx" in dataSession:
			for a in range(len(dataSession["connectAsFbx"])):
				as_joint = dataSession["connectAsFbx"][a][0]
				max_joint = dataSession["connectAsFbx"][a][1]
				connected.append([as_joint,max_joint])   
		else:
			connected = connectAsFbxData() 
		if connected:
			for a in range(len(connected)):                   
				as_joint = connected[a][0]
				max_joint = connected[a][1]
				connectMain(["AsFbx",dataSession["groupConstraintAsFbx"],as_joint,max_joint])
		
				
		#MOVE GROUP_CONTRAINT
		as_parent_group = cmds.listRelatives("FitSkeleton",parent=True)[0]
		pm.mel.eval('parent '+dataSession["groupConstraintAsFbx"]+' '+as_parent_group+' ;')
		pm.mel.eval('connectAttr -f MainExtra1.scale groupConstraintAsFbx.scale;')
		general.runScript("afterConnectScript")
		print("Connect As to Fbx done!")
	 
def connectFbxAsData(*arr):
	global dataSession
	if not cmds.objExists("jointAddedGroup"):        
		jointAddedGroup = cmds.group(empty=True,n="jointAddedGroup")
	else:
		cmds.delete("jointAddedGroup")        
		jointAddedGroup = cmds.group(empty=True,n="jointAddedGroup")
	if "constraint_pair" in dataSession:
		data_pair = dataSession["constraint_pair"]
		right_refix = dataSession["prefix"][0]
		left_refix = dataSession["prefix"][1]
		connectPair = []
		jointAdded = []
		parentCons = []
		connected = {}
		for a in range(len(data_pair)):
			if cmds.ls(data_pair[a][0]) and cmds.ls(data_pair[a][1]):
				as_joint  = cmds.ls(data_pair[a][0])[0]
				max_joint = cmds.ls(data_pair[a][1])[0]
				max_joint_right = max_joint         
				if "prefixPosition" in dataSession:
					max_joint_left = max_joint_right[0:-(len(right_refix))]+left_refix
				else:
					max_joint_left = max_joint_right.replace(right_refix,left_refix)
				side = []
				if cmds.objExists(as_joint + "_M"):
					side.append("M")
				elif cmds.objExists(as_joint + "_R"):
					side.append("R")
				elif cmds.objExists(as_joint + "_L"):
					side.append("L")
					
				if "M" in side:
					if as_joint == "Root":
						connectPair.append([max_joint,"FK"+as_joint+"_M"])
						connectPair.append([max_joint,as_joint+"X_M"])
						connectPair.append([max_joint,"Main"])
					else:
						connectPair.append([max_joint,"FK"+as_joint+"_M"])
				elif "R" in side:
					connectPair.append([max_joint_right,"FK"+as_joint+"_R"])
					if cmds.objExists(max_joint_left) and cmds.objExists(as_joint + "_L"):
						connectPair.append([max_joint_left,"FK"+as_joint+"_L"])
						
					#Solve IK control
					ik_data = dataSession["ikControl"]
					for b in ik_data:
						if as_joint == b:   
							connectPair.append([max_joint_right,ik_data[b]+"_R"])
							if cmds.objExists(max_joint_left) and cmds.objExists(as_joint + "_L"):
								connectPair.append([max_joint_left,ik_data[b]+"_L"])

					#Solve point vector control
					pole_data = dataSession["poleControl"]
					for b in pole_data:
						if as_joint == b:
							for c in ["_R","_L"]:                           
								if c == "_R":
									maxJointTemp = max_joint_right          
								elif c == "_L":
									maxJointTemp = max_joint_left
								
								poleVector = pole_data[b]+c
								if cmds.objExists(poleVector):
								#CREATE JOINT CONTROL POLE VECTOR
									cmds.select(clear=True)
									jointPole = cmds.createNode("joint")
									cmds.matchTransform(jointPole,poleVector,pos=True)
									constraintName = cmds.parentConstraint(maxJointTemp,jointPole,mo=True)
									cmds.parent(jointPole,"jointAddedGroup")
									parentCons.append(constraintName)
									connectPair.append([jointPole,poleVector])
									jointAdded.append(jointPole)####
		ASParent = cmds.listRelatives("FitSkeleton",parent=True)
		cmds.parent("jointAddedGroup",ASParent)
		dataSession["connectFbxAs"]={
			"pair":connectPair,
			"jointAdded":jointAdded,
			"parentConstraint":parentCons
		}
		
def connectFbxAs(*arr):    
	disconnect("groupConstraintAsFbx")
	connectFbxAsData()
	#CONTRAINT MAX JOINT TO ADVANCE SKELETON
	if cmds.objExists("DeformSet"):
		all_group_parent = cmds.group(empty=True,n="groupConstraintFbxAs")
		dataSession["groupConstraintFbxAs"] = all_group_parent
		connectPair = dataSession["connectFbxAs"]["pair"]
		for a in range(len(connectPair)):           
			max_joint = connectPair[a][0]
			as_ctrl = connectPair[a][1]         
			connectMain(["FbxAs",dataSession["groupConstraintFbxAs"],max_joint,as_ctrl])
		#MOVE GROUP_CONTRAINT
		as_parent_group = cmds.listRelatives("FitSkeleton",parent=True)[0]
		pm.mel.eval('parent '+dataSession["groupConstraintFbxAs"]+' '+as_parent_group+' ;')
		print("Connect Fbx to As done!")
				
def matchFbxRef(*arr):
	refName = cmds.textField("refName",query=True,text=True)
	if ("connectFbxAs" in dataSession) and refName !="":
		pair = dataSession["connectFbxAs"]["pair"]
		jointAdded = dataSession["connectFbxAs"]["jointAdded"]
		for a in range(len(pair)):
			max_joint = pair[a][0]
			ref_joint = refName+":"+max_joint
			if max_joint not in (jointAdded):
				cmds.matchTransform(max_joint,ref_joint,rot=True,pos=True)
				
def matchRefFbx(*arr):
	refName = cmds.textField("refName",query=True,text=True)
	if ("connectFbxAs" in dataSession) and refName !="":
		pair = dataSession["connectFbxAs"]["pair"]
		jointAdded = dataSession["connectFbxAs"]["jointAdded"]
		for a in range(len(pair)):
			max_joint = pair[a][0]
			ref_joint = refName+":"+max_joint
			if max_joint not in (jointAdded):
				cmds.matchTransform(ref_joint,max_joint,rot=True,pos=True)
						  
def connectRefFbx(*arr):
	refName = cmds.textField("refName",query=True,text=True)
	if ("connectFbxAs" in dataSession) and refName !="":
		all_group_parent = cmds.group(empty=True,n="groupConstraintRefFbx")
		dataSession["groupConstraintRefFbx"] = all_group_parent
		pair = dataSession["connectFbxAs"]["pair"]        
		jointAdded = dataSession["connectFbxAs"]["jointAdded"]
		max_joint_array = []
		for a in range(len(pair)):
			if pair[a][0] not in max_joint_array:
				max_joint_array.append(pair[a][0])
		for a in max_joint_array:
			max_joint = a         
			ref_joint = refName+":"+max_joint
			if max_joint not in (jointAdded):
				connectMain(["RefFbx",dataSession["groupConstraintRefFbx"],ref_joint,max_joint])
				
def bakeAnimation(array,*arr):
	jointSourceArray = array["source"]
	jointDestArray = array["dest"]
	key_array = []
	data_animation = [] 
	for a in jointSourceArray:
		if "refName" in array:
			jointSource = array["refName"]+":"+a
		else:
			jointSource = a
		if cmds.objExists(jointSource):
			if cmds.keyframe(jointSource,query=True,timeChange=True):
				key_temp = cmds.keyframe(jointSource,query=True,timeChange=True)
				for i in key_temp:
					if i not in key_array:
						key_array.append(i)
	key_array = sorted(key_array)
	for a in range(len(key_array)):
		frame_data = [key_array[a],{}]      
		cmds.currentTime(key_array[a]) 
		for b in range(len(jointSourceArray)):          
			jointDest = jointDestArray[b]
			if "refName" in array:              
				jointSource = array["refName"]+":"+jointSourceArray[b]
			else:
				jointSource = jointSourceArray[b]
			if cmds.objExists(jointSource) and cmds.objExists(jointDest):
				if cmds.keyframe(jointSource,query=True,time=(key_array[a],key_array[a]),valueChange=True):
					frame_data[1][jointDest]={
						"translateX":cmds.getAttr(jointDest+".translateX"),
						"translateY":cmds.getAttr(jointDest+".translateY"),
						"translateZ":cmds.getAttr(jointDest+".translateZ"),
						"rotateX":cmds.getAttr(jointDest+".rotateX"),
						"rotateY":cmds.getAttr(jointDest+".rotateY"),
						"rotateZ":cmds.getAttr(jointDest+".rotateZ"),
						"scaleX":cmds.getAttr(jointDest+".scaleX"),
						"scaleY":cmds.getAttr(jointDest+".scaleY"),
						"scaleZ":cmds.getAttr(jointDest+".scaleZ"),                       
					}
			elif not cmds.objExists(jointSource):
				if jointDest in ["PoleLeg_R","PoleLeg_L","PoleArm_R","PoleArm_L"]:
					frame_data[1][jointDest]={
						"translateX":cmds.getAttr(jointDest+".translateX"),
						"translateY":cmds.getAttr(jointDest+".translateY"),
						"translateZ":cmds.getAttr(jointDest+".translateZ"),
						"rotateX":cmds.getAttr(jointDest+".rotateX"),
						"rotateY":cmds.getAttr(jointDest+".rotateY"),
						"rotateZ":cmds.getAttr(jointDest+".rotateZ"),
						"scaleX":cmds.getAttr(jointDest+".scaleX"),
						"scaleY":cmds.getAttr(jointDest+".scaleY"),
						"scaleZ":cmds.getAttr(jointDest+".scaleZ"),                       
					}   
		data_animation.append(frame_data)
	return data_animation
										   
def bakeAnimationFbxAs(*arr):
	data =  dataSession["connectFbxAs"]["pair"]
	max_joint_array = list(zip(*data))[0]
	as_ctrl_array = list(zip(*data))[1]
	dataAnimation = bakeAnimation({
		"source":max_joint_array,
		"dest":as_ctrl_array,
	})              
	disconnect("groupConstraintFbxAs")  
	for a in range(len(dataAnimation)):
		cmds.currentTime(dataAnimation[a][0])
		data_temp = dataAnimation[a][1]
		for b in data_temp:
			for c in data_temp[b]:              
				if not cmds.getAttr(b+"."+c,lock=True) and cmds.getAttr(b+"."+c,keyable=True):
					cmds.setAttr(b+"."+c,data_temp[b][c])
			pm.mel.eval('setKeyframe -breakdown 0 -preserveCurveShape 0 -hierarchy none -controlPoints 0 -shape 0 {"'+b+'"};')  
	cmds.currentTime(0) 
	
def bakeAnimationRefAs(*arr):
	refName = cmds.textField("refName",query=True,text=True)
	if refName!="":
		data =  dataSession["connectFbxAs"]["pair"]
		max_joint_array = list(zip(*data))[0]
		as_ctrl_array = list(zip(*data))[1]
		dataAnimation = bakeAnimation({
			"source":max_joint_array,
			"dest":as_ctrl_array,
			"refName":refName,
		})
		#   
		disconnect("groupConstraintRefFbx")
		cmds.currentTime(-1)        
		disconnect("groupConstraintFbxAs")
		#
		allCtrlArray = []
		for a in as_ctrl_array:
			allCtrlArray.append('"'+a+'"')
		pm.mel.eval('setKeyframe -breakdown 0 -preserveCurveShape 0 -hierarchy none -controlPoints 0 -shape 0 {'+",".join(allCtrlArray)+'};')
		#
		connectAsFbx()
		for a in range(len(dataAnimation)):
			cmds.currentTime(dataAnimation[a][0])
			data_temp = dataAnimation[a][1]
			stringName = []
			for b in data_temp:
				stringName.append('"'+b+'"')
				for c in data_temp[b]:              
					if not cmds.getAttr(b+"."+c,lock=True) and cmds.getAttr(b+"."+c,keyable=True):
						cmds.setAttr(b+"."+c,data_temp[b][c])
			pm.mel.eval('setKeyframe -breakdown 0 -preserveCurveShape 0 -hierarchy none -controlPoints 0 -shape 0 {'+",".join(stringName)+'};')  
		cmds.currentTime(-1)
	
def rotateFinger(*arr):
	ctrl = [
		"FKThumbFinger2_R","FKThumbFinger3_R",
		"FKIndexFinger1_R","FKIndexFinger2_R","FKIndexFinger3_R",
		"FKMiddleFinger1_R","FKMiddleFinger2_R","FKMiddleFinger3_R",
		"FKRingFinger1_R","FKRingFinger2_R","FKRingFinger3_R",
		"FKPinkyFinger1_R","FKPinkyFinger2_R","FKPinkyFinger3_R",
		
		"FKThumbFinger2_L","FKThumbFinger3_L",
		"FKIndexFinger1_L","FKIndexFinger2_L","FKIndexFinger3_L",
		"FKMiddleFinger1_L","FKMiddleFinger2_L","FKMiddleFinger3_L",
		"FKRingFinger1_L","FKRingFinger2_L","FKRingFinger3_L",
		"FKPinkyFinger1_L","FKPinkyFinger2_L","FKPinkyFinger3_L",       
	]
	for a in ctrl:
		if cmds.objExists(a):
			groupSDK = "SDK"+a
			data_temp = {}     
			for b in ["rx","ry","rz"]:            
				if cmds.connectionInfo(groupSDK+"."+b, isDestination=True):
					convertNode = cmds.connectionInfo(groupSDK+"."+b, sourceFromDestination=True)
					data_temp["converse"+b] = convertNode.split(".")[0]
					if  cmds.connectionInfo(data_temp["converse"+b]+".input", isDestination=True):
						spreadNode = cmds.connectionInfo(data_temp["converse"+b]+".input", sourceFromDestination=True)
						data_temp["bw"+b] = spreadNode.split(".")[0] 
						if "_rotateY" in data_temp["bw"+b]:
							data_temp["curlNode"] = data_temp["converse"+b]                        
							if b == "rx":
								data_temp["currentAxis"]="X"
							elif b == "ry":
								data_temp["currentAxis"]="Y"  
							elif b == "rz":
								data_temp["currentAxis"]="Z" 
							pm.mel.eval('disconnectAttr '+data_temp["curlNode"]+'.output '+groupSDK+'.rotate'+data_temp["currentAxis"]+';')
						if "_rotateZ" in data_temp["bw"+b]:                        
							data_temp["spreadNode"] = data_temp["converse"+b]
							if b == "rx":
								data_temp["spreadAxis"]="X"
							elif b == "ry":
								data_temp["spreadAxis"]="Y"  
							elif b == "rz":
								data_temp["spreadAxis"]="Z" 
							pm.mel.eval('disconnectAttr '+data_temp["spreadNode"]+'.output '+groupSDK+'.rotate'+data_temp["spreadAxis"]+';')  
												  
			axis = ["X","Y","Z"]
			for b in axis:
				try:
					pm.mel.eval('setAttr "'+groupSDK+'.rotate'+b+'" 0;')
				except:pass
				
			currentIndex = axis.index(data_temp["currentAxis"])
			if currentIndex < (len(axis) - 1) :            
				nextIndex = currentIndex + 1                        
			else:
				nextIndex = 0
			pm.mel.eval('connectAttr -f '+data_temp["curlNode"]+'.output '+groupSDK+'.rotate'+axis[nextIndex]+';')
			
			if "spreadAxis" in data_temp:
				if data_temp["spreadAxis"]== axis[nextIndex]:
					axis.remove(data_temp["spreadAxis"])
					spreadAxis = axis[-1]
					pm.mel.eval('connectAttr -f '+data_temp["spreadNode"]+'.output '+groupSDK+'.rotate'+spreadAxis+';')
				else:                
					pm.mel.eval('connectAttr -f '+data_temp["spreadNode"]+'.output '+groupSDK+'.rotate'+data_temp["spreadAxis"]+';')

def rotateFingerSession(*arr):
	#unitConversion14.conversionFactor  
	if "rotateFinger" in dataSession:
		ctrl = dataSession["sdkFinger"]
		for a in ctrl:
			if cmds.objExists(a) and cmds.objExists("SDK"+a):
				groupSDK = "SDK"+a
				data_temp = {}     
				for b in ["rx","ry","rz"]:            
					if cmds.connectionInfo(groupSDK+"."+b, isDestination=True):
						convertNode = cmds.connectionInfo(groupSDK+"."+b, sourceFromDestination=True)
						data_temp["converse"+b] = convertNode.split(".")[0]
						pm.mel.eval('disconnectAttr '+data_temp["converse"+b]+'.output '+groupSDK+"."+b+';')
						if  cmds.connectionInfo(data_temp["converse"+b]+".input", isDestination=True):
							spreadNode = cmds.connectionInfo(data_temp["converse"+b]+".input", sourceFromDestination=True)
							data_temp["bw"+b] = spreadNode.split(".")[0] 
							if "_rotateY" in data_temp["bw"+b]:
								data_temp["finger"]=data_temp["converse"+b]
								cmds.setAttr(data_temp["converse"+b]+".conversionFactor",cmds.getAttr(data_temp["converse"+b]+".conversionFactor")*dataSession["rotateFinger"]["converse"])                                  
							if "_rotateZ" in data_temp["bw"+b]:
								data_temp["spread"]=data_temp["converse"+b]
				if "finger" in data_temp:
					pm.mel.eval('connectAttr -f '+data_temp["finger"]+'.output '+groupSDK+'.rotate'+dataSession["rotateFinger"]["fingerAxis"]+';')
				if "spread" in data_temp:
					pm.mel.eval('connectAttr -f '+data_temp["spread"]+'.output '+groupSDK+'.rotate'+dataSession["rotateFinger"]["spreadAxis"]+';')
		
def inverseRotateFinger(*arr):
	reverseNode = []
	ctrl = dataSession["sdkFinger"]
	for a in ctrl:
		if cmds.objExists(a):
			groupSDK = "SDK"+a
			data_temp = {}
			for b in ["rx","ry","rz"]:            
				if cmds.connectionInfo(groupSDK+"."+b, isDestination=True):
					convertNode = cmds.connectionInfo(groupSDK+"."+b, sourceFromDestination=True)
					data_temp["converse"+b] = convertNode.split(".")[0]
					if  cmds.connectionInfo(data_temp["converse"+b]+".input", isDestination=True):
						spreadNode = cmds.connectionInfo(data_temp["converse"+b]+".input", sourceFromDestination=True)
						data_temp["bw"+b] = spreadNode.split(".")[0] 
						if "_rotateY" in data_temp["bw"+b]:
							reverseNode.append(data_temp["converse"+b])
	for a in reverseNode:
		pm.mel.eval('setAttr "'+a+'.conversionFactor" '+str(pm.mel.eval('getAttr "'+a+'.conversionFactor"')*(-1))+';')
		
def rotateSpread(*arr):
	ctrl = dataSession["sdkSpread"]
	for a in ctrl:
		if cmds.objExists(a):
			groupSDK = "SDK"+a
			data_temp = {}
			axis = ["X","Y","Z"]
			axisFree = []
			for b in axis:            
				if cmds.connectionInfo(groupSDK+".rotate"+b, isDestination=True):
					convertNode = cmds.connectionInfo(groupSDK+".rotate"+b, sourceFromDestination=True)
					data_temp["converse"+b] = convertNode.split(".")[0]                
					if  cmds.connectionInfo(data_temp["converse"+b]+".input", isDestination=True):
						spreadNode = cmds.connectionInfo(data_temp["converse"+b]+".input", sourceFromDestination=True)
						data_temp["bw"+b] = spreadNode.split(".")[0]
						if "_rotateZ" in data_temp["bw"+b]:                        
							data_temp["spreadNode"] = data_temp["converse"+b]
							data_temp["spreadAxis"] = b
							pm.mel.eval('disconnectAttr '+data_temp["spreadNode"]+'.output '+groupSDK+'.rotate'+data_temp["spreadAxis"]+';')
				else:
					axisFree.append(b)                                                               
			axis = ["X","Y","Z"]
			for b in axis:
				try:
					pm.mel.eval('setAttr "'+groupSDK+'.rotate'+b+'" 0;')
				except:pass
			pm.mel.eval('connectAttr -f '+data_temp["spreadNode"]+'.output '+groupSDK+'.rotate'+axisFree[0]+';')

def saveOldGuide(*arr):
	global dataSession
	childrenGuide = cmds.listRelatives("FitSkeleton",ad=True,pa=True,type="joint")[::-1]
	data_temp = []
	for a in childrenGuide:
		data_temp.append([
			a,[
				pm.mel.eval('getAttr "'+a+'.translateX";'),
				pm.mel.eval('getAttr "'+a+'.translateY";'),
				pm.mel.eval('getAttr "'+a+'.translateZ";'),
				pm.mel.eval('getAttr "'+a+'.rotateX";'),
				pm.mel.eval('getAttr "'+a+'.rotateY";'),
				pm.mel.eval('getAttr "'+a+'.rotateZ";')
			]
		])
	dataSession["oldGuide"] = data_temp
	
def removeOldGuide(*arr):
	global dataSession
	if "oldGuide" in dataSession:
		del(dataSession["oldGuide"])
	print("Deleted Old Guide data.")
		
def matchOldCtrl(*arr):    
	oldCtrl = cmds.textField("matchOldCtrlUrl",q=True,text=True)
	if oldCtrl != "":
		cmds.file(oldCtrl, reference=True,mergeNamespacesOnClash=False,namespace="oldCtrl")
		listControl = list(zip(*dataSession["connectFbxAs"]["pair"]))[1]  
		for a in listControl:
			currentCtrl = a
			refCtrl = "oldCtrl:"+a
			cmds.matchTransform(currentCtrl,refCtrl)
		for a in listControl:
			flag = False
			for b in ["translate","rotate"]:
				for c in ["X","Y","Z"]:
					if cmds.getAttr(a+"."+b+c) > 0.0000001 or cmds.getAttr(a+"."+b+c) < -0.0000001:
						flag = True
			if flag == True:
				cmds.select(a)
				clearOffset()                  
		cmds.file(oldCtrl,removeReference=True)

def clearAllCurve(*arr): 
	cmds.delete(cmds.ls(type=["animCurveUA","animCurveUU",'animCurveTA','animCurveTL','animCurveTU',"animCurveUL"]))


def exportGuide(*arr):
	folderTemp = os.path.join(os.path.dirname(pm.sceneName()), 'NltaAsData')
	folderTemp = cmds.encodeString(folderTemp)
	if not os.path.exists(folderTemp):
		os.makedirs(folderTemp)
	filePath = os.path.dirname(pm.sceneName())+"/NltaAsData/"+"asGuide.fbx"
	pm.mel.eval('file -force -options "fbx" -typ "FBX export" -pr -es "'+filePath+'";')    

def importGuide(*arr):
	filePath = os.path.dirname(pm.sceneName())+"/NltaAsData/"+"asGuide.fbx"
	pm.mel.eval('file -import -type "FBX"  -ignoreVersion -ra true -mergeNamespacesOnClash false -namespace "asGuide" -options "fbx"  -pr  -importTimeRange "combine" "'+filePath+'";')


def exportGuideAttr(*arr):
	data = {}
	for joint in cmds.listRelatives("FitSkeleton",ad=True):
		data[joint] = {}
		for attr in ["control","worldOrientUp","worldOrientForward","noMirror","noMirrorLeft","global",'globalTranslate','twistJoints','bendyJoints']:
			if cmds.attributeQuery(attr, exists=True, node=joint):
				attrValue =  cmds.getAttr(joint+'.'+attr)
				if attrValue == True:
					attrValue = 1
				elif attrValue == False:
					attrValue = 0
				data[joint][attr] = attrValue
	
	filePath = os.path.dirname(pm.sceneName())+"/"+"asGuideAttr.txt"
	general.writeJsonFile(filePath,data)

def importGuideAttr(*arr):
	filePath = os.path.dirname(pm.sceneName())+"/"+"asGuideAttr.txt"
	data = general.readJsonFile(filePath)
	for jointName in data:
		#attrArray =  data[jointName]
		if cmds.ls(general.checkOnly([jointName,"FitSkeleton"]),long=True):
			joint =  cmds.ls(general.checkOnly([jointName,"FitSkeleton"]),long=True)[0]
			attrData = data[jointName]
			for attr in attrData:
				attrValue = attrData[attr]
				if attr in ['control','bendyJoints','globalTranslate','noMirror',"noMirrorLeft"]:
					if not cmds.attributeQuery(attr, exists=True, node=joint):
						pm.mel.eval('addAttr -ln "'+attr+'"  -at bool  '+joint+';')
						pm.mel.eval('setAttr -e -keyable true '+joint+'.'+attr+';')
					pm.mel.eval('setAttr "'+joint+'.'+attr+'" '+str(attrValue)+';')
				elif attr in ['global','twistJoints']:
					if not cmds.attributeQuery(attr, exists=True, node=joint):
						pm.mel.eval('addAttr -ln "'+attr+'" -at double  -min 0 -max 10 -dv 0 '+joint+';')
						pm.mel.eval('setAttr -e -keyable true '+joint+'.'+attr+';')
					pm.mel.eval('setAttr "'+joint+'.'+attr+'" '+str(attrValue)+';')
				elif attr in ["worldOrient","worldOrientUp"]:
					if not cmds.attributeQuery(attr, exists=True, node=joint):
						pm.mel.eval('addAttr -ln "'+attr+'"  -at "enum" -en "xUp:yUp:zUp:xDown:yDown:zDown"  '+joint+';')
						pm.mel.eval('setAttr -e -keyable true '+joint+'.'+attr+';')
					pm.mel.eval('setAttr "'+joint+'.'+attr+'" '+str(attrValue)+';')	
				elif attr in ["worldOrientForward"]:
					if not cmds.attributeQuery(attr, exists=True, node=joint):
						pm.mel.eval('addAttr -ln "'+attr+'"  -at "enum" -en "xForward:yForward:zForward:xBackward:yBackward:zBackward" '+joint+';')
						pm.mel.eval('setAttr -e -keyable true '+joint+'.'+attr+';')
					pm.mel.eval('setAttr "'+joint+'.'+attr+'" '+str(attrValue)+';')

def exportGuideHierarchy(*arr):
	data = []
	for jointName in cmds.listRelatives("FitSkeleton",ad=True,type="joint"):
		if cmds.listRelatives(jointName,p=True):
			data.append([jointName,cmds.listRelatives(jointName,p=True)[0]])
	filePath = os.path.dirname(pm.sceneName())+"/"+"asGuideParent.txt"
	general.writeJsonFile(filePath,data)

def importGuideHierarchy(*arr):
	joints = cmds.listRelatives("FitSkeleton",ad=True,type="joint",pa=True)
	cmds.select("FitSkeleton")
	jointTemp = cmds.joint()
	for joint in joints:
		for attr in ["tx","ty","tz"]:
			cmds.setAttr(joint+'.'+attr,lock=False)
		cmds.parent(joint,jointTemp)

	filePath = os.path.dirname(pm.sceneName())+"/"+"asGuideParent.txt"
	data = general.readJsonFile(filePath)
	for a in range(len(data)):
		joint = general.checkOnly([data[a][0],"FitSkeleton"])
		parent =  general.checkOnly([data[a][1],"FitSkeleton"])
		if cmds.objExists(joint) and cmds.objExists(parent):
			cmds.parent(joint,parent)
	cmds.delete(jointTemp)

def ModifyControl(*arr):
	for a in cmds.listRelatives("ControlSet",ad=True,type="nurbsCurve"):
		transform = cmds.listRelatives(a,parent=True)[0]
		if transform not in ["IKSpineCurve_M"]:
			if transform.startswith("FKIK"):
				data = [[
					"-21.98197939 0.3645214191 2.475835978e-11;","-19.7951938 0.3645214191 2.475835978e-11;","-19.7951938 2.551307007 2.475884539e-11;","-19.06633337 2.551307007 2.475884539e-11;","-19.06633337 0.3645214191 2.475835978e-11;",
					"-16.87954778 0.3645214191 2.475835978e-11;","-16.87954778 -0.3643390179 2.475819794e-11;","-19.06633337 -0.3643390179 2.475819794e-11;","-19.06633337 -2.551124605 2.475771233e-11;","-19.7951938 -2.551124605 2.475771233e-11;",
					"-19.7951938 -0.3643390179 2.475819794e-11;","-21.98197939 -0.3643390179 2.475819794e-11;","-21.98197939 0.3645214191 2.475835978e-11;"
				]]
			elif transform == "RootX_M":
				data = [
					["-22.8745898 0 -2.221976651;","-26.09658094 0 -2.221976651;","-26.09658094 0 -6.200864915;","-32.29744586 0 0;","-26.09658094 0 6.200864915;","-26.09658094 0 2.221976651;","-22.8745898 0 2.221976651;","-22.8745898 0 -2.221976651;"],
					["-2.221976651 0 22.8745898;","-2.221976651 0 26.09658094;","-6.200864915 0 26.09658094;","-7.171473605e-15 0 32.29744586;","6.200864915 0 26.09658094;","2.221976651 0 26.09658094;","2.221976651 0 22.8745898;","-2.221976651 0 22.8745898;"],
					["22.8745898 0 2.221976651;","26.09658094 0 2.221976651;","26.09658094 0 6.200864915;","32.29744586 0 1.434294721e-14;","26.09658094 0 -6.200864915;","26.09658094 0 -2.221976651;","22.8745898 0 -2.221976651;","22.8745898 0 2.221976651;"],
					["2.221976651 0 -22.8745898;","2.221976651 0 -26.09658094;","6.200864915 0 -26.09658094;","2.151442082e-14 0 -32.29744586;","-6.200864915 0 -26.09658094;","-2.221976651 0 -26.09658094;","-2.221976651 0 -22.8745898;","2.221976651 0 -22.8745898;"],   
				]
			elif transform.startswith("IKSpine2") or transform.startswith("IKSplineNeck2") or transform.startswith("IKSplineTail2_M"):
				data = [[            
					"25.41618506 -0.1990015685 -25.20816609;","1.018208204e-14 -0.2814307171 -35.64973036;","-25.41618506 -0.1990015685 -25.20816609;","-35.94391362 1.192741494e-16 -1.011025384e-14;",
					"-25.41618506 0.1990015685 25.20816609;","-1.158167851e-14 0.2814307171 35.64973036;","25.41618506 0.1990015685 25.20816609;","35.94391362 -9.548495991e-17 1.312370666e-14;",
					"25.41618506 -0.1990015685 -25.20816609;","1.018208204e-14 -0.2814307171 -35.64973036;","-25.41618506 -0.1990015685 -25.20816609;",
				]]
			elif transform.startswith("FKSpine") or transform.startswith("FKChest"):
				data = [[
					"0 -15.84580247 -15.84580247;","0 2.556684062e-15 -22.40934876;","0 15.84580247 -15.84580247;","-8.980149957e-15 22.40934876 -6.984725267e-15;",
					"0 15.84580247 15.84580247;","0 7.545984639e-15 22.40934876;","0 -15.84580247 15.84580247;","8.980149957e-15 -22.40934876 1.203605962e-14;",
					"0 -15.84580247 -15.84580247;","0 2.556684062e-15 -22.40934876;","0 15.84580247 -15.84580247;"
				]]
			elif transform.startswith("IKSpine") or transform.startswith("IKSpline"):
				data = [[
					"27.77590498 -0.3957547216 -27.11518464;","27.77590498 2.485646942 -27.13045847;","27.77590498 2.94890933 27.8762325;","-27.77590498 2.94890933 27.8762325;","-27.77590498 2.485646942 -27.13045847;",
					"-27.77590498 -0.3957547216 -27.11518464;","-27.77590498 0.0675076659 27.89150634;","27.77590498 0.0675076659 27.89150634;","27.77590498 -0.3957547216 -27.11518464;","-27.77590498 -0.3957547216 -27.11518464;",
					"-27.77590498 0.0675076659 27.89150634;","-27.77590498 2.94890933 27.8762325;","-27.66116752 2.484968976 -27.12885505;","27.66116752 2.484968976 -27.12885505;","27.77590498 2.94890933 27.8762325;",
					"27.77590498 0.0675076659 27.89150634;",
				]]
			elif transform.startswith("Roll"):
				data = [[
					"1.078001709e-13 -4.006898375 0.000490389601;","1.084750881e-13 -3.971092156 -2.675600608;","1.101204398e-13 -0.2651239898 -4.73779832;", "1.114644505e-13 3.144889841 -3.144889841;",
					"1.118044893e-13 4.447545865 2.615314965e-13;","1.109533156e-13 3.144889841 3.144889841;","1.094095354e-13 -0.4235899955 4.605234265;","1.080356507e-13 -3.713865601 2.547040733;",
					"1.078001709e-13 -4.006898375 0.000490389601;","1.078001709e-13 -4.006898375 0.000490389601;","1.078001709e-13 -4.006898375 0.000490389601;","1.077380209e-13 -4.317824365 0.4519016901;",
					"1.077380209e-13 -4.317824365 0.4519016901;","1.078001709e-13 -4.006898375 0.000490389601;","1.078001709e-13 -4.006898375 0.000490389601;","1.078966215e-13 -3.693484337 0.4786712064;",
				]]
			elif transform.startswith("IKhybrid"):
				data = [[
					"-4.19923097 31.67969652 -13.36764231;","-2.474816666 18.67042835 4.471270751e-13;","-4.19923097 31.67969652 13.36764231;","-1.749959647 13.20198649 13.4489622;","-1.739378419 13.12215995 32.27234337;",
					"7.797183828e-15 1.083476169e-15 19.01970475;","1.739378419 -13.12215995 32.27234337;","1.749959647 -13.20198649 13.4489622;","4.19923097 -31.67969652 13.36764231;","2.474816666 -18.67042835 4.488603467e-13;",
					"4.19923097 -31.67969652 -13.36764231;","1.749959647 -13.20198649 -13.4489622;","1.739378419 -13.12215995 -32.27234337;","-8.289315218e-15 2.62924485e-15 -19.01970475;","-1.739378419 13.12215995 -32.27234337;",
					"-1.749959647 13.20198649 -13.4489622;","-4.19923097 31.67969652 -13.36764231;","-2.474816666 18.67042835 4.471270751e-13;","-4.19923097 31.67969652 13.36764231;",
				]]
			elif transform == "Main":
				data = [[
					"28.68018547 1.756154867e-15 -28.68018547;","-4.627400442e-15 2.48357803e-15 -40.55990726;","-28.68018547 1.756154867e-15 -28.68018547;","-40.55990726 7.19678779e-31 -1.17532464e-14;",
					"-28.68018547 -1.756154867e-15 28.68018547;","-1.222149163e-14 -2.48357803e-15 40.55990726;","28.68018547 -1.756154867e-15 28.68018547;","40.55990726 -1.333934605e-30 2.178480531e-14;",
					"28.68018547 1.756154867e-15 -28.68018547;","-4.627400442e-15 2.48357803e-15 -40.55990726;","-28.68018547 1.756154867e-15 -28.68018547;"
				]]
			elif transform == "MainExtra1":
				data = [[
					"41.37926182 -1.454321801e-07 41.37926306;","-4.68111998e-07 -1.767798339e-07 58.51911569;","-41.37926347 -1.265392321e-07 41.37926476;","-58.51911613 -2.414066003e-08 2.47258603e-06;",
					"-41.37926518 7.043219497e-08 -41.37926053;","-2.894685126e-06 1.017798339e-07 -58.51911316;","41.37926009 5.153921867e-08 -41.37926223;","58.51911275 -5.085934007e-08 4.60126517e-08;",
					"41.37926182 -1.454321801e-07 41.37926306;","-4.68111998e-07 -1.767798339e-07 58.51911569;","-41.37926347 -1.265392321e-07 41.37926476;",
				]]
			elif transform.startswith("IKLeg"):
				data = [[
					"7.463105675 -11.41593837 23.74823558;","-6.078764257 -11.41593843 23.68888328;","-6.003449795 6.77099998 6.505058311;","-5.944097487 6.770999973 -7.036811622;",
					"-5.94409741 -11.41593845 -7.036811612;","7.597772524 -11.41593839 -6.977459305;","7.597772447 6.77100003 -6.977459316;","7.538420139 6.771000038 6.564410619;",
					"7.463105675 -11.41593837 23.74823558;","7.597772524 -11.41593839 -6.977459305;","7.597772447 6.77100003 -6.977459316;","-5.944097487 6.770999973 -7.036811622;",
					"-5.916250437 -11.41593845 -7.008719466;","-6.050794695 -11.41593843 23.68900586;","-6.003449795 6.77099998 6.505058311;","7.538420139 6.771000038 6.564410619;",
				]]
			elif transform.startswith("IKArm"):
				data = [[            
					"-5.49111267 -5.49111267 5.49111267;","5.49111267 -5.49111267 5.49111267;","5.49111267 5.49111267 5.49111267;","5.49111267 5.49111267 -5.49111267;",
					"5.49111267 -5.49111267 -5.49111267;","-5.49111267 -5.49111267 -5.49111267;","-5.49111267 5.49111267 -5.49111267;","-5.49111267 5.49111267 5.49111267;",
					"-5.49111267 -5.49111267 5.49111267;","-5.49111267 -5.49111267 -5.49111267;","-5.49111267 5.49111267 -5.49111267;","5.49111267 5.49111267 -5.49111267;",
					"5.468429834 -5.49111267 -5.468429834;","5.468429834 -5.49111267 5.468429834;","5.49111267 5.49111267 5.49111267;","-5.49111267 5.49111267 5.49111267;",
				]]
			elif transform.startswith("FKScapula"):
				data = [[             
					"-1.661775296 -16.61775296 5.424493832e-15;","-1.661775296 -16.61775296 4.239559161;","-1.661775296 -13.0218644 13.07239555;","-1.661775296 -4.942360303e-13 18.39043167;","-1.661775296 13.0218644 13.07239555;",
					"-1.661775296 16.61775296 4.239559161;","-1.661775296 16.61775296 1.411972649e-15;","-1.661775296 16.61775296 1.411972649e-15;","-1.661775296 16.61775296 1.411972649e-15;","1.661775296 16.61775296 1.955270951e-15;",
					"1.661775296 16.61775296 1.955270951e-15;","1.661775296 16.61775296 1.955270951e-15;","1.661775296 16.61775296 4.239559161;","1.661775296 13.0218644 13.07239555;","1.661775296 -4.782572639e-13 18.39043167;",
					"1.661775296 -13.0218644 13.07239555;","1.661775296 -16.61775296 4.239559161;","1.661775296 -16.61775296 5.967792133e-15;","1.661775296 -16.61775296 5.967792133e-15;","1.661775296 -16.61775296 5.967792133e-15;",
					"-1.661775296 -16.61775296 5.424493832e-15;",
				]]
			elif transform.startswith("Fingers"):
				data = [[             
					"-6.123233996e-17 1 0;","0.1300602147 1 0;","0.3930278173 0.9479318716 0;","0.7254129115 0.7255156445 0;","0.9479612239 0.3926462374 0;","1.026019388 -4.819673449e-17 0;",
					"0.9479612239 -0.3926462374 0;","0.7254129115 -0.7255156445 0;","0.3930278173 -0.9479318716 0;","0.1300602147 -1 0;","-1.053011137e-16 -1 0;",
				]]
			elif transform.startswith("HipSwinger"):
				data = [[
					"-8.440767652 1.213684281e-14 8.440767652;","-1.702343069e-15 1.35673575e-14 -14.92131011;","8.440767652 1.213684281e-14 8.440767652;","-14.92131011 1.265369077e-14 -4.323822369e-15;",
					"8.440767652 1.317053872e-14 -8.440767652;","-4.496081943e-15 1.174002404e-14 14.92131011;","-8.440767652 1.317053872e-14 -8.440767652;","14.92131011 1.265369077e-14 8.014264769e-15;",
					"-8.440767652 1.213684281e-14 8.440767652;","-1.702343069e-15 1.35673575e-14 -14.92131011;","8.440767652 1.213684281e-14 8.440767652;",
				]]
			elif transform.startswith("FK"):  
				data = [[
					"0.0004744713985 3.273856944 3.273785839;","0.0004407343993 -7.737903503e-05 4.629914346;","0.0004914328662 -3.274026203 3.273820848;","0.000596868325 -4.63015471 -0.0001134739932;",
					"0.0006952781137 -3.274061213 -3.274062298;","0.000729015113 -0.0001268899694 -4.630190805;","0.0006783166461 3.273821934 -3.274097307;","0.0005728811873 4.629950441 -0.0001629850968;",
					"0.0004744713985 3.273856944 3.273785839;","0.0004407343993 -7.737903503e-05 4.629914346;","0.0004914328662 -3.274026203 3.273820848;",
				]]
			elif transform.startswith("Pole"):
				data = [["7.18641 0 0;","-7.18641 0 0;","0 0 0;","0 7.18641 0;","0 -7.18641 0;","0 0 0;","0 0 -7.18641;","0 0 7.18641;"]]
					
			else:
				data = [[
					"1.579007858e-08 2.262028431 2.262028444;","4.713773194e-08 2.905240854e-08 3.198991341;","-3.102869073e-09 -2.262028412 2.262028537;","-1.055014422e-07 -3.19899131 1.351657695e-07;",
					"-2.000742967e-07 -2.262028506 -2.262028306;","-2.314219358e-07 -1.035980311e-07 -3.198991203;","-1.811813206e-07 2.262028337 -2.262028399;","-7.878276165e-08 3.198991235 2.515316109e-09;",
					"1.579007858e-08 2.262028431 2.262028444;","4.713773194e-08 2.905240854e-08 3.198991341;","-3.102869073e-09 -2.262028412 2.262028537;"
				]]
				
			for b in range(len(data)):
				if b == 0:
					stt = ""
				else:
					stt = b
				for c in range(len(data[b])):
					try:
						pm.mel.eval('setAttr '+transform+'Shape'+str(stt)+'.controlPoints['+str(c)+'] '+data[b][c])
					except:pass

#### FIX TWIST JOINT
			   
fixTwistSession = {
	'setting':{},
	'pairs':{
		'Elbow':['Elbow','Wrist'],
		'Shoulder':['Shoulder','Elbow'],
		'Hip':['Hip','Knee'],
		'Knee':['Knee','Ankle'],
	},
	'nodeType':{
		'BM':'blendMatrix',
		'MMTwist':'multMatrix',
		'DMTwist':'decomposeMatrix',
		'QTETwist':'quatToEuler',
		'twistAmountDivide':'multDoubleLinear',
		'twistAmountParentSubtract':'multDoubleLinear',
		'upTwistAmountDivide':'multDoubleLinear',
		'twistAddition':'plusMinusAverage',
	}
}

def GetTwistSetup():
	global fixTwistSession
	guideJnts = ['Elbow','Shoulder','Hip','Knee']
	for jnt in guideJnts:
		fixTwistSession['setting'][jnt] = cmds.getAttr(jnt+'.twistJoints')

def CheckExistNodes(data):
	for pair in fixTwistSession['pairs'][data['type']]:
		if data['index'] == 1:
			for concat in ['BM','MMTwist','DMTwist','QTETwist']:
				nodeName = pair+concat+data['side']
				if not cmds.objExists(nodeName):
					cmds.shadingNode(fixTwistSession['nodeType'][concat],name=data['type']+concat+data['side'],asUtility=True)
			concatArray = ['twistAmountDivide','upTwistAmountDivide']
			for concat in concatArray:
				nodeName = concat+pair+'Part'+str(data['index'])+data['side']
				if not cmds.objExists(nodeName):
					cmds.shadingNode(fixTwistSession['nodeType'][concat],name=nodeName,asUtility=True)
		else:
			concatArray = ['twistAmountDivide','twistAmountParentSubtract','upTwistAmountDivide']
			for concat in concatArray:
				nodeName = concat+pair+'Part'+str(data['index'])+data['side']
				if not cmds.objExists(nodeName):
					cmds.shadingNode(fixTwistSession['nodeType'][concat],name=nodeName,asUtility=True)
	additionNode = 'twistAddition'+data['type']+'Part'+str(data['index'])+data['side']
	if not cmds.objExists(additionNode):
		cmds.shadingNode(fixTwistSession['nodeType'][concat],name=additionNode,asUtility=True)

def ConnectNodes(data):
	pairs = fixTwistSession['pairs'][data['type']]
	arrayObject = []
	if data['index'] ==1:
		for pair in pairs:
			cmds.connectAttr('FKX'+pair+data['side']+'.worldMatrix[0]',pair+"BM"+data['side']+'.inputMatrix',f=True)
			cmds.connectAttr('IKX'+pair+data['side']+'.worldMatrix[0]',pair+'BM'+data['side']+'.target[0].targetMatrix',f=True)
			cmds.connectAttr(pair+'BM'+data['side']+'.outputMatrix',pair+'MMTwist'+data['side']+'.matrixIn[1]',f=True)
			cmds.connectAttr(pair+'XformReverter'+data['side']+'.worldInverseMatrix[0]',pair+'MMTwist'+data['side']+'.matrixIn[2]',f=True)
			cmds.connectAttr(pair+'MMTwist'+data['side']+'.matrixSum',pair+'DMTwist'+data['side']+'.inputMatrix',f=True)
			cmds.connectAttr(pair+'DMTwist'+data['side']+'.outputQuatX',pair+'QTETwist'+data['side']+'.inputQuatX',f=True)
			cmds.connectAttr(pair+'DMTwist'+data['side']+'.outputQuatW',pair+'QTETwist'+data['side']+'.inputQuatW',f=True)
			if pairs.index(pair)==0:
				cmds.connectAttr(pair+'QTETwist'+data['side']+'.outputRotateX','twistAmountDivide'+pair+'Part'+str(data['index'])+data['side']+'.input1',f=True)
				cmds.connectAttr('twistAmountDivide'+pair+'Part'+str(data['index'])+data['side']+'.output','twistAddition'+pairs[0]+'Part'+str(data['index'])+data['side']+'.input1D[0]',f=True)
				cmds.connectAttr('twistAddition'+pairs[0]+'Part'+str(data['index'])+data['side']+'.output1D',pair+'Part'+str(data['index'])+data['side']+'.rotateX',f=True)
				cmds.connectAttr(pair+'Part'+str(data['index'])+data['side']+'.twistAddition','twistAddition'+pairs[0]+'Part'+str(data['index'])+data['side']+'.input1D[1]',f=True)
				cmds.connectAttr(pair+'part'+str(data['index'])+data['side']+'.twistAmount','twistAmountDivide'+pair+'Part'+str(data['index'])+data['side']+'.input2',f=True)
				cmds.connectAttr(pair+'part'+str(data['index'])+data['side']+'.twistAmount','upTwistAmountDivide'+pair+'Part'+str(data['index'])+data['side']+'.input2',f=True)
			else:
				cmds.connectAttr(pair+'QTETwist'+data['side']+'.outputRotateX','upTwistAmountDivide'+pair+'Part'+str(data['index'])+data['side']+'.input1',f=True)
				cmds.connectAttr('upTwistAmountDivide'+pair+'Part'+str(data['index'])+data['side']+'.output','twistAddition'+pairs[0]+'Part'+str(data['index'])+data['side']+'.input1D[2]',f=True)
	else:
		source = pairs[0]
		destination = pairs[1]
		cmds.connectAttr('twistAddition'+source+'Part'+str(data['index'] - 1)+data['side']+'.output1D','twistAmountParentSubtract'+source+'Part'+str(data['index'])+data['side']+'.input1',f=True)
		cmds.connectAttr(source+'QTETwist'+data['side']+'.outputRotateX','twistAmountDivide'+source+'Part'+str(data['index'])+data['side']+'.input1',f=True)
		cmds.connectAttr(destination+'QTETwist'+data['side']+'.outputRotateX','upTwistAmountDivide'+destination+'Part'+str(data['index'])+data['side']+'.input1',f=True)
		cmds.connectAttr('twistAmountDivide'+destination+'Part'+str(data['index'])+data['side']+'.output','twistAddition'+source+'Part'+str(data['index'])+data['side']+'.input1D[0]',f=True)
		cmds.connectAttr('twistAmountParentSubtract'+destination+'Part'+str(data['index'])+data['side']+'.output','twistAddition'+source+'Part'+str(data['index'])+data['side']+'.input1D[2]',f=True)
		cmds.connectAttr('upTwistAmountDivide'+destination+'Part'+str(data['index'])+data['side']+'.output','twistAddition'+source+'Part'+str(data['index'])+data['index']+'.input1D[3]',f=True)
		cmds.connectAttr(source+'Part'+str(data['index'])+data['side']+'.twistAddition','twistAddition'+source+'Part'+str(data['index'])+data['side']+'input1D[1]',f=True)
		cmds.connectAttr('twistAddition'+source+'Part'+str(data['index'])+data['side']+'.output1D',source+'Part'+str(data['index'])+data['side']+'.rotateX',f=True)
		cmds.connectAttr(source+'Part'+str(data['index'])+data['side']+'.twistAmount','twistAmountDivide'+source+'Part'+str(data['index'])+data['side']+'.input2',f=True)
		cmds.connectAttr(source+'part'+str(data['index'])+data['side']+'.twistAmount','upTwistAmountDivide'+destination+'Part'+str(data['index'])+data['side']+'.input2',f=True)

def FixSingleTwist(data):
	CheckExistNodes(data)
	ConnectNodes(data)

def FixTwist(*arr):
	GetTwistSetup()
	for key in fixTwistSession['setting']:
		type_ = key
		twistAmount = fixTwistSession['setting'][key]
		for side in ['_R','_L']:
			for index in range(1,twistAmount+1):
				FixSingleTwist({
					'index':index,
					'type':type_,
					'side':side
				})

def ModifyLayers(*arr):
	#MESH SKINED TO LAYER
	mesh_parent = []
	for a in cmds.ls(type="mesh",r=True):
		for b in cmds.listHistory(a):
			if cmds.nodeType(b)=="skinCluster":
				mesh_parent.append(a)
	LayerName = 'GeoLayer'
	if pm.objExists(LayerName):
		pm.delete(LayerName)
	DisplayLayer = pm.createDisplayLayer(name=LayerName, empty=True)
	pm.editDisplayLayerMembers(DisplayLayer,mesh_parent, noRecurse=True)
	DisplayLayer.displayType.set(2)
	DisplayLayer.visibility.set(1)
	
	#CONTROL LAYSER
	LayerName = 'ControlsLayer'
	if pm.objExists(LayerName):
		pm.delete(LayerName)
	DisplayLayer = pm.createDisplayLayer(name=LayerName, empty=True)
	pm.editDisplayLayerMembers(DisplayLayer, 'MotionSystem', noRecurse=True)
	DisplayLayer.color.set(29)      
	cmds.select(clear=True)
		
	#AS JOINT LAYER
	LayerName = 'ASJointLayer'
	if pm.objExists(LayerName):
		pm.delete(LayerName)
	DisplayLayer = pm.createDisplayLayer(name=LayerName, empty=True)
	pm.editDisplayLayerMembers(DisplayLayer,"DeformationSystem", noRecurse=True)
	DisplayLayer.displayType.set(2)
	DisplayLayer.visibility.set(0) 
	cmds.select(clear=True)
	
	#MAX JOINT LAYER
	LayerName = 'BindJointLayer'
	if pm.objExists(LayerName):
		pm.delete(LayerName)
	DisplayLayer = pm.createDisplayLayer(name=LayerName, empty=True)
	DisplayLayer.displayType.set(2)
	DisplayLayer.visibility.set(0)
	try:
		pm.editDisplayLayerMembers(DisplayLayer,dataSession["maxParent"][0], noRecurse=True)
	except:pass

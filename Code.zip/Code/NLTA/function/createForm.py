import maya.cmds as cmds
import os,json,general,importlib
from hashlib import md5

def formPattern(lib,*arr):
    model = []
    function = cmds.getFileList(folder=lib["sever"] + "function/")
    for a in function:
        if a.endswith(".py"):
            libTemp = a.split(".")[0]
            moduleName = importlib.import_module(libTemp)
            if int(cmds.about(version=True)) < 2022:
                reload(moduleName)
            else:
                importlib.reload(moduleName)
            lib[libTemp] = moduleName
            model.append(libTemp)
    tabArray = []
    for a in model:        
        if hasattr(lib[a],"requireTab"):
            tabArray.append(lib[a].requireTab)
                
    form_width = 400
    cmds.window("nltaForm", title = "NLTA tool")
    form = cmds.formLayout(w=410,height=850)   

    tabs = cmds.tabLayout(innerMarginWidth=5, innerMarginHeight=5)
    cmds.formLayout( form, edit=True, attachForm=((tabs, 'top', 0), (tabs, 'left', 0), (tabs, 'bottom', 0), (tabs, 'right', 0)) )

    tabArrayOutput = []
    for a in tabArray:
        if not cmds.scrollLayout(a,query=True,exists=True):        
            layoutTemp = cmds.scrollLayout(a)
            cmds.columnLayout( adjustableColumn=True )
            cmds.setParent( '..' )
            cmds.setParent( '..' )
            tabArrayOutput.append([layoutTemp,a])
        
    cmds.setParent( '..' )
    cmds.setParent( ".." )
    cmds.tabLayout( tabs, edit=True, tabLabel=tabArrayOutput)

    for a in model:    
        print(a)
        if hasattr(lib[a],"createLayout"):
            lib[a].createLayout(a,lib)    
    cmds.showWindow()


def closeAllForm(*arr):
    form_array = ["nltaForm"]
    for i in form_array:        
        if cmds.window(i, query = True, exists = True):
            cmds.deleteUI(i)
    
def makeForm(lib,*arr):
    closeAllForm()
    formPattern(lib)

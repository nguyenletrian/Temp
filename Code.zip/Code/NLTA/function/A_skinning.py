requireTab = "A_skinning"
import os, json, maya.utils, general, shutil
import maya.cmds as cmds
import pymel.core as pm
from functools import partial
from math import pow,sqrt
import xml.dom.minidom as xd

cmds.selectPref( trackSelectionOrder=1 )

def createLayout(per,lib,*arr):
    if not cmds.rowColumnLayout("A_skinningButton",query=True,exists=True):        
        cmds.rowColumnLayout("A_skinningButton",nc=5,parent="A_skinning")
    if per == "A_skinning":
        cmds.rowColumnLayout( numberOfColumns=5,parent="A_skinning")
        cmds.button(label="Miror +X ",width=80,c=partial(mirrorSkin,"x","+"),parent="A_skinningButton")     
        cmds.button(label="Miror -X ",width=80,c=partial(mirrorSkin,"x","-"),parent="A_skinningButton")               
        cmds.button(label='Import Skin', width=80, command = importAllSkin,parent="A_skinningButton")
        cmds.button(label='Export Skin', width=80, command = ExportAllSkin,parent="A_skinningButton")
        cmds.button(label="Clear Skins",width=80,c=clearSkin,parent="A_skinningButton")
        cmds.button(label='Component', width=80, command = component,parent="A_skinningButton")                
        cmds.button(label="Proxy X",width=80,c=partial(createProxy,"x"),parent="A_skinningButton")
        cmds.button(label="Proxy",width=80,c=singleProxy,parent="A_skinningButton")
        cmds.button(label="Copy Proxy",width=80,c=copyProxy,parent="A_skinningButton")
        cmds.button(label="Past Proxy",width=80,c=pastProxy,parent="A_skinningButton")
        cmds.button(label="Copy Jnt Wei",width=80,c=copyJointWeight,parent="A_skinningButton")
        cmds.button(label="Past Jnt Wei",width=80,c=pastJointWeight,parent="A_skinningButton") 
        cmds.button(label="Bind Skin",width=80,c=bindSkin,parent="A_skinningButton")
        cmds.button(label="Load UI",width=80,c=loadUi,parent="A_skinningButton")
        cmds.button(label='Bind pose', width=80, command = goToBindPose,parent="A_skinningButton")   
        cmds.button(label="Prune",width=80,c=pruneSmallWeights,parent="A_skinningButton") 
        cmds.button(label="Fix Quad",width=80,c=showQuardraw,parent="A_skinningButton")
        cmds.button(label="Compare Mesh",width=80,c=compareMesh,parent="A_skinningButton") 
        cmds.button(label="Copy Skin",width=80,c=copyJointBind,parent="A_skinningButton")
        cmds.button(label="Copy Mirr Skin",width=80,c=copyMirrorSkin,parent="A_skinningButton")
        cmds.button(label="Past Mirr Skin",width=80,c=pastMirrorSkin,parent="A_skinningButton")
        cmds.button(label="Middle Weight",width=80,c=setMiddleWeight,parent="A_skinningButton")
        cmds.button(label="Face Side",width=80,c=partial(createFaceSide,[0,0,5],"z"),parent="A_skinningButton")        
        cmds.button(label="Middle Weight",width=80,c=faceSideBottomVertex,parent="A_skinningButton")
        cmds.button(label="Clr Unneed jnt",width=80,c=removeUnneedJoint,parent="A_skinningButton")
        cmds.button(label="Add joint",width=80,c=AddJoint,parent="A_skinningButton")
        cmds.button(label="Add Mesh jnt",width=80,c=AddMeshJoint,parent="A_skinningButton")
        cmds.button(label="Import Folder",width=80,c=ImportFolderSkin,parent="A_skinningButton")
        cmds.button(label="Export Folder",width=80,c=ExportFolderSkin,parent="A_skinningButton")
        cmds.setParent("..")

        cmds.separator(height=20, style='in')

        #Keyframe
        cmds.rowColumnLayout( numberOfColumns=4,parent="A_skinning")

        cmds.rowColumnLayout( numberOfColumns=1,width=100)
        cmds.button( label='Unlock',width=100,command = unlock)    
        cmds.button( label='Add unlock',width=100,command = addUnlock)
        cmds.button( label='Unlock all',width=100,command = unlockAll)
        cmds.button( label='Pick value',width=100,command = pickValue)
        cmds.button( label='Switch Joint',width=100,command = switchJoint)
        cmds.setParent("..")
        
        #######################      
        cmds.rowColumnLayout( numberOfColumns=1,width=100)
        cmds.textField(text="Local",width=100,editable=False)
        cmds.button( label='Rotate',width=100, command = partial(CreateKeyframe,{'space':'local','type':'rotate','inturn':True}))
        cmds.button( label='Translate',width=100,command = partial(CreateKeyframe,{'space':'local','type':'translate','inturn':True}))
        cmds.button( label='Rotate Together',width=100,command = partial(CreateKeyframe,{'space':'local','type':'rotate','inturn':False}))
        cmds.button( label='Translate Together',width=100,command = partial(CreateKeyframe,{'space':'local','type':'translate','inturn':False}))
        cmds.setParent("..")
        cmds.rowColumnLayout( numberOfColumns=1,width=100)
        cmds.textField(text="Global",width=100,editable=False)
        cmds.button( label='Rotate',width=100,command = partial(CreateKeyframe,{'space':'world','type':'rotate','inturn':True}))
        cmds.button( label='Translate',width=100,command = partial(CreateKeyframe,{'space':'world','type':'translate','inturn':True}))
        cmds.button( label='Rotate Together',width=100,command = partial(CreateKeyframe,{'space':'world','type':'rotate','inturn':False}))
        cmds.button( label='Translate Together',width=100,command = partial(CreateKeyframe,{'space':'world','type':'translate','inturn':False}))   
        cmds.setParent("..")

        cmds.rowColumnLayout( numberOfColumns=1,width=100)        
        cmds.button( label='Zoom Range',width=100,command = ZoomRangeAnim)
        cmds.button( label='Fit Range',width=100,command = FitRangeAnim)
        cmds.button( label='Delete Sence',width=100,command = deleteSenceKeyframe)
        cmds.setParent("..")

        cmds.setParent("..")
        ##########################

        cmds.separator(height=20, style='in')

        cmds.rowColumnLayout( numberOfColumns=4,parent="A_skinning")
        cmds.button(label="Light",width=100, command = partial(smooth,"gaussian"))
        cmds.button(label="Heavy",width=100, command = partial(smooth,"solid"))
        cmds.button(label="Flood",width=100, command = flood)
        cmds.button(label="Clear Select",width=100, command = clearSelect)
        cmds.setParent("..")
        cmds.rowColumnLayout( numberOfColumns=7,parent="A_skinning")
        cmds.button(label="0",width=57, command = partial(replaceWeight,0))
        cmds.button(label="0.125",width=57, command = partial(replaceWeight,0.125))
        cmds.button(label="0.25",width=57, command = partial(replaceWeight,0.25))
        cmds.button(label="0.5",width=57, command = partial(replaceWeight,0.5))
        cmds.button(label="0.75",width=57, command = partial(replaceWeight,0.75))
        cmds.button(label="0.875",width=57, command = partial(replaceWeight,0.875))
        cmds.button(label="1",width=58, command = partial(replaceWeight,1))
        cmds.setParent("..")

        cmds.rowColumnLayout( numberOfColumns=10,parent="A_skinning")
        cmds.button(label="-0.03",width=40, command = partial(addWeight,-0.03))
        cmds.button(label="-0.02",width=40, command = partial(addWeight,-0.02))
        cmds.button(label="-0.01",width=40, command = partial(addWeight,-0.01))
        cmds.button(label="-0.005",width=40, command = partial(addWeight,-0.005))
        cmds.button(label="-0.0025",width=40, command = partial(addWeight,-0.0025))
        cmds.button(label="0.0025",width=40, command = partial(addWeight,0.0025))
        cmds.button(label="0.005",width=40, command = partial(addWeight,0.005))
        cmds.button(label="0.01",width=40, command = partial(addWeight,0.01))
        cmds.button(label="0.02",width=40, command = partial(addWeight,0.02))
        cmds.button(label="0.03",width=40, command = partial(addWeight,0.03))
        cmds.setParent("..")

        cmds.rowColumnLayout( numberOfColumns=10,parent="A_skinning")
        cmds.button( label="Copy Weight",width=200, command = CopyWeight)
        cmds.setParent("..")

        cmds.separator(height=20, style='in')

        cmds.rowColumnLayout( numberOfColumns=4,parent="A_skinning")
        cmds.button( label="Isolate",width=100, command = IsolateObjects)
        cmds.button( label="Hide",width=100, command = HideObject)
        cmds.button( label="UnHide",width=100, command = UnhideObject)
        cmds.button( label="Unhide All",width=100, command = UnhideAll)
        cmds.setParent("..")


        cmds.rowColumnLayout( numberOfColumns=4,parent="A_skinning")
        cmds.button( label="Create Set",width=100, command = CreateSet)
        cmds.button( label="Next Set",width=100, command = NextSet)
        cmds.button( label="Back Set",width=100, command = BackSet)
        cmds.button( label="Delete Sets",width=100, command = DeleteSets)
        cmds.setParent("..")

        cmds.rowColumnLayout( numberOfColumns=4,parent="A_skinning")
        cmds.button( label="Delete Layers",width=100, command = general.DeleteLayers)
        cmds.setParent("..")

        cmds.separator(height=20, style='in')

        cmds.frameLayout(label='Advance',width=400,parent="A_skinning")#open Frame
        cmds.rowColumnLayout(numberOfColumns=2)#open container
        cmds.rowColumnLayout(numberOfColumns=1,width=10)#open tab
        cmds.setParent("..")#close tab
        cmds.rowColumnLayout(numberOfColumns=1,width=390)#open right

        cmds.rowColumnLayout(numberOfColumns=4,width=390)#item
        cmds.textField(text="Max Influent",width=100,editable=False)
        cmds.intField("maxInfluent",value=4,width=90)
        cmds.button(label="Fix",width=100, command = partial(fixMaxInfluent,cmds.intField("maxInfluent",value=True,query=True)))
        cmds.button(label="Check",width=100, command = checkMaxInfluent)
        cmds.setParent("..")#close item

        cmds.rowColumnLayout(numberOfColumns=4,width=390)#item
        cmds.textField(text="Maintain Off",width=100,editable=False)
        cmds.intField("maintainOff",value=4,width=90)
        cmds.button(label="set",width=100, command = setMaintainOff)
        cmds.setParent("..")#close item

        cmds.setParent("..")#close Right        
        cmds.setParent("..")#close container
        cmds.setParent("..")#close frame


session = {}

def getSkinData(mesh,*arr):
    skinCluster = pm.mel.eval('findRelatedSkinCluster '+mesh)
    joints = cmds.skinCluster(skinCluster,query=True,inf=True)
    jointActive = cmds.connectionInfo(skinCluster+".paintTrans",sourceFromDestination=True).split(".")[0]
    return({
        "skinCluster": skinCluster,
        "joints":joints,
        "jointActive":jointActive
    })

def clearMesh(*arr):
    for mesh in cmds.ls(selection=True):
        cmds.select(mesh)
        pm.mel.eval('DeleteHistory;')
        """
        for attr in ["tx","ty","tz","rx","ry","rz","sx","sy","sz"]:
            cmds.setAttr(mesh+"."+attr,lock=False)
        """
        cmds.setAttr(mesh+".translate",e=True,lock=0)
        cmds.setAttr(mesh+".rotate",e=True,lock=0)
        cmds.setAttr(mesh+".scale",e=True,lock=0)
        cmds.setAttr(mesh+".visibility",e=True,lock=0)
        pm.mel.eval('makeIdentity -apply true -t 1 -r 1 -s 1 -n 0 -pn 1;')
        pm.mel.eval('ResetTransformations;')

def getDistance(objA,objB):
    gObjA = cmds.xform(objA,q=True,t=True,ws=True)
    gObjB = cmds.xform(objB,q=True,t=True,ws=True)
    return(sqrt(pow(gObjA[0]-gObjB[0],2)+pow(gObjA[1]-gObjB[1],2)+pow(gObjA[2]-gObjB[2],2)))

def setMiddleWeight(*arr):
    cmds.currentTime(0)
    deleteSenceKeyframe()
    selection = cmds.ls(selection=True)
    middleJoint = selection[0]
    vertexArray = []
    jointArray = []
    for a in selection:
        if cmds.objectType(a) == "joint":
            if a != middleJoint:
                jointArray.append(a)
        elif ".vtx[" in a :
            vertexArray.append(a)
    mesh = vertexArray[0].split(".")[0]
    skinCluster = pm.mel.eval('findRelatedSkinCluster '+mesh)
    if skinCluster:
        jointBindArray = cmds.skinCluster(skinCluster,query=True,inf=True)
        for jointBind in jointBindArray:
            cmds.setAttr(jointBind+".liw",0)
        for ver in vertexArray:
            cmds.skinPercent(skinCluster,ver, transformValue=[middleJoint,1])
        for jointBind in jointBindArray:
            cmds.setAttr(jointBind+".liw",1)
    averageWeight = float(1.0/(len(jointArray)+1))
    for joint in jointArray:
        cmds.setAttr(joint+".liw",0)
        cmds.setAttr(middleJoint+".liw",0)
        for ver in vertexArray:
            cmds.skinPercent(skinCluster,ver, transformValue=[joint,averageWeight])
        cmds.setAttr(joint+".liw",1)
        cmds.setAttr(middleJoint+".liw",1)
    for joint in jointArray:
        cmds.setAttr(joint+".liw",0)
    cmds.setAttr(middleJoint+".liw",0)

    cmds.select(jointArray)
    autoKeyframe("together")
    component()
    cmds.select(vertexArray)

def copyMirrorSkin(*arr):
    global session
    cmds.currentTime(0)
    joint = None
    mesh = None
    vertexArray = []
    for a in cmds.ls(selection=True):
        if cmds.objectType(a) == "joint":
            joint = a
        else:
            mesh = a
    if joint!=None and mesh!=None:
        weightData = {}
        skinName = pm.mel.eval('findRelatedSkinCluster '+mesh)
        if skinName:
            allBoneBind = cmds.skinCluster(mesh,inf=True,q=True)
            allVertex = cmds.ls(mesh+".vtx[*]",flatten=True)   
            for vertex in allVertex:
                boneWeight = cmds.skinPercent(skinName,vertex, transform=joint, query=True )
                if boneWeight!=0:
                    vertexArray.append(vertex)
                    weightData[vertex]={"weight":boneWeight}

            cmds.select(vertexArray)
            pm.mel.eval('ConvertSelectionToFaces;')
            face = cmds.ls(selection=True)
            meshNew =  cmds.duplicate(mesh)[0]
            faceNew = cmds.ls(meshNew+".f[*]")
            arrayTemp = []
            for a in face:
                faceName = a.replace(mesh,meshNew)
                arrayTemp.append(faceName)

            cmds.select(faceNew)
            cmds.select(arrayTemp,deselect=True)
            cmds.delete()
            cmds.select(meshNew)
            clearMesh()
            pm.mel.eval('DeleteHistory;')
            pm.mel.eval('makeIdentity -apply true -t 1 -r 1 -s 1 -n 0 -pn 1;')
            pm.mel.eval('ResetTransformations;')

            meshNewVertex =  cmds.ls(meshNew+".vtx[*]",flatten=True)            
            for vertexNew in meshNewVertex:            
                for vertexOld in vertexArray:
                    if getDistance(vertexNew,vertexOld) == 0:
                        weightData[vertexOld]["vertexNew"] = vertexNew
            
            pm.mel.eval('setAttr "'+meshNew+'.scaleX" -1;')
            cmds.select(meshNew)
            clearMesh()

            meshNewVertex = cmds.ls(meshNew+".vtx[*]",flatten=True)
            for vertexNew in meshNewVertex:
                for vertexOld in allVertex:
                    if float(format(getDistance(vertexNew,vertexOld),".8f")) < 0.00001:
                        for a in weightData:
                            if 'vertexNew' in weightData[a]:
                                if weightData[a]['vertexNew'] == vertexNew:
                                    weightData[a]["vertexMirror"] = vertexOld

            cmds.delete(meshNew)
            session["copyMirrorSkin"] = weightData

def pastMirrorSkin(*arr):
    cmds.currentTime(0)
    joint = None
    mesh = None
    vertexArray = []
    for a in cmds.ls(selection=True):
        if cmds.objectType(a) == "joint":
            joint = a
        else:
            mesh = a
    data= session["copyMirrorSkin"]
    skinCluster = pm.mel.eval('findRelatedSkinCluster '+mesh)
    for a in data:
        if "vertexMirror" in data[a]:
            cmds.skinPercent(skinCluster,data[a]["vertexMirror"], transformValue=[joint, data[a]["weight"]])        

def bindSkin(*arr):
    skinCluster = pm.mel.eval('newSkinCluster "-toSelectedBones -bindMethod 0  -normalizeWeights 1 -weightDistribution 0 -mi 1  -dr 4 -rui false  , multipleBindPose, 0";')
    return(skinCluster[0])

def copyJointWeight(*arr):
    global session
    vertexArray = []
    vertexData = {}
    joint = ""
    meshTransform = ""
    selection =  cmds.ls(selection=True,flatten=True)
    for a in selection:
        if cmds.objectType(a) ==  "joint":
            joint = a
        elif "vtx[" in a:
            if meshTransform == "":
                meshTransform = a.split(".")[0]
            vertexArray.append(a)
    skinCluster = pm.mel.eval('findRelatedSkinCluster '+meshTransform)
    for a in vertexArray:
        vertexData[a] = cmds.skinPercent(skinCluster,a,query=True,transform=joint)
    session["vertexWeight"]  = vertexData
    session["mesh"] = meshTransform
    session["skinCluster"] = skinCluster


def pastJointWeight(*arr):
    joint = cmds.ls(selection=True)[0]
    for a in session["vertexWeight"]:
        vertexName = a
        vertexValue = session["vertexWeight"][a]
        cmds.skinPercent(session["skinCluster"],a, transformValue=[joint, vertexValue])

def copyProxy(*arr):
    global session
    selection = cmds.ls(selection=True)
    if cmds.objectType(selection[0]) == "mesh":
        pm.mel.eval('ConvertSelectionToVertices;')
        vertex = cmds.ls(selection=True,flatten=True)
        parentName = selection[0].split(".")[0]
        cmds.select(parentName)
    elif cmds.objectType(selection[0]) == "transform":
        vertex = cmds.ls(selection[0]+".vtx[*]",flatten=True)
        parentName = selection[0]
    session["vertex"] = vertex
    session["mesh"] = parentName

def pastProxy(*arr):
    selection = cmds.ls(selection=True)
    if cmds.objectType(selection[0]) == "mesh":
        pm.mel.eval('ConvertSelectionToVertices;')
        vertex = cmds.ls(selection=True)
        parentName = selection[0].split(".")[0]
        cmds.select(session["vertex"])
        cmds.select(vertex,add=True)
        pm.mel.eval('copySkinWeights  -noMirror -surfaceAssociation closestPoint -influenceAssociation oneToOne -influenceAssociation closestJoint -normalize;')
    elif cmds.objectType(selection[0]) == "transform":
        for aSelect in selection:
            vertex = cmds.ls(aSelect+".vtx[*]")            
            cmds.select(clear=True)
            cmds.select(session["vertex"])
            cmds.select(vertex,add=True)
            pm.mel.eval('copySkinWeights  -noMirror -surfaceAssociation closestPoint -influenceAssociation oneToOne -influenceAssociation closestJoint -normalize;')

    #pm.mel.eval('maintainActiveChangeSelectMode '+parentName+' 0;')
    #pm.mel.eval('doMenuComponentSelectionExt("'+session["mesh"]+'", "vertex", 0);')   
    cmds.select(selection)
    cmds.warning("Done!!!")

def loadUi(*arr):   
    pm.mel.eval('artAttrSkinPaintCtx -e -minvalue -1 -useColorRamp 1 -colorRamp "1,0,0,1,1,1,0.5,0,0.8,1,1,0.7,0,0.6,1,0,.5,0,0.4,1,0,0,1,0,1"  -rampMaxColor .57 .57 .57  artAttrSkinContext;')
    pm.mel.eval('setObjectPickMask "Joint" false;')
    FitRangeAnim()

def mirrorSkin(axis,neg_pos,*arr):
    selection = cmds.ls(selection=True)
    if ".vtx[" in selection[0]:
        if axis == "x":
            pm.mel.eval("reflectionSetMode objectx;")
        else:
            pm.mel.eval("reflectionSetMode objectx;")        
        pm.mel.eval("reflectionSetMode none;")

    if axis == "x":
        face = "YZ"
    if neg_pos == "-":
        pm.mel.eval("copySkinWeights -mirrorMode "+face+" -mirrorInverse -surfaceAssociation closestPoint -influenceAssociation closestJoint -influenceAssociation oneToOne;")
    elif neg_pos == "+":
        pm.mel.eval("copySkinWeights -mirrorMode "+face+" -surfaceAssociation closestPoint -influenceAssociation closestJoint -influenceAssociation oneToOne;")

def copyJointBind(*arr):
    sourceMesh = cmds.ls(selection=True)[0]
    targetMesh = cmds.ls(selection=True)[1:]
    skinCluster = pm.mel.eval('findRelatedSkinCluster '+sourceMesh)
    bindJoint = cmds.skinCluster(skinCluster,query=True,inf=True)
    for mesh in targetMesh:
        cmds.select(clear=True)
        cmds.select(mesh)
        pm.mel.eval('DeleteHistory;')
        for attr in ["tx","ty","tz","rx","ry","rz","sx","sy","sz"]:
            cmds.setAttr(mesh+"."+attr,lock=False)
        pm.mel.eval('makeIdentity -apply true -t 1 -r 1 -s 1 -n 0 -pn 1;')
        pm.mel.eval('ResetTransformations;')
        cmds.select(bindJoint,add=True)
        bindSkin()
        cmds.select(clear=True)
        cmds.select(sourceMesh)
        cmds.select(mesh,add=True)
        pm.mel.eval('copySkinWeights  -noMirror -surfaceAssociation closestPoint -influenceAssociation oneToOne -influenceAssociation closestJoint -normalize;')

def singleProxy(*arr):
    selection = cmds.ls(selection=True)
    if cmds.objectType(selection[0]) == "mesh":
        pm.mel.eval('ConvertSelectionToFaces;')
        face = cmds.ls(selection=True)
        meshTransform = selection[0].split(".")[0]
        skinCluster = pm.mel.eval('findRelatedSkinCluster '+meshTransform)
        if skinCluster:
            joint = cmds.skinCluster(skinCluster,query=True,inf=True)

        meshNew =  cmds.ls(cmds.duplicate(meshTransform)[0],uuid=True)[0]
        meshNew =  cmds.ls(meshNew,ap=True)[0]
        faceNew = cmds.ls(meshNew+".f[*]")
        arrayTemp = []
        for a in face:
            faceName = a.replace(meshTransform,meshNew)
            arrayTemp.append(faceName)

        cmds.select(faceNew)
        cmds.select(arrayTemp,deselect=True)
        cmds.delete()
        cmds.delete(meshNew,constructionHistory=True)
        if skinCluster:
            cmds.select(joint)
            cmds.select(meshNew,add=True)
            bindSkin()
            cmds.select(meshTransform)
            cmds.select(meshNew,add=True)
            pm.mel.eval('copySkinWeights  -noMirror -surfaceAssociation closestPoint -influenceAssociation oneToOne -influenceAssociation closestJoint -normalize;')
            cmds.select(meshNew)
        else:
            cmds.select(meshNew)

def createProxy(axis,*arr):
    selection = cmds.ls(selection=True)
    if cmds.objectType(selection[0]) == "mesh":
        pm.mel.eval('ConvertSelectionToFaces;')
        face = cmds.ls(selection=True)
        meshTransform = selection[0].split(".")[0]
        skinCluster = pm.mel.eval('findRelatedSkinCluster '+meshTransform)
        if skinCluster:
            joint = cmds.skinCluster(skinCluster,query=True,inf=True)

        meshNew =  cmds.ls(cmds.duplicate(meshTransform)[0],uuid=True)[0]
        meshNew =  cmds.ls(meshNew,ap=True)[0]
        faceNew = cmds.ls(meshNew+".f[*]")
        arrayTemp = []
        for a in face:
            faceName = a.replace(meshTransform,meshNew)
            arrayTemp.append(faceName)

        cluster = cmds.cluster(arrayTemp)
        axisNegPos = general.checkNegPosAxis(cluster,axis)
        if axisNegPos == "-":
            direction = str(0)
        else:
            direction = str(1)
        cmds.delete(cluster)

        axisArray = ["x","y","z"]
        axisIndex = str(axisArray.index(axis))

        cmds.select(faceNew)
        cmds.select(arrayTemp,deselect=True)
        cmds.delete()

        pm.mel.eval('polyMirrorFace  -cutMesh 1 -axis '+axisIndex+' -axisDirection '+direction+' -mergeMode 1 -mergeThresholdType 0 '+meshNew+';')#-mergeThreshold 0.001 
        cmds.delete(meshNew,constructionHistory=True)
        cmds.select(joint)
        cmds.select(meshNew,add=True)
        bindSkin()
        cmds.select(meshTransform)
        cmds.select(meshNew,add=True)
        pm.mel.eval('copySkinWeights  -noMirror -surfaceAssociation closestPoint -influenceAssociation oneToOne -influenceAssociation closestJoint -normalize;')
        cmds.select(meshNew)

def goToBindPose(*arr): 
    pm.mel.eval("GoToBindPose;")

def component(*arr):    
    pm.mel.eval("ComponentEditor;")
    
def pruneSmallWeights(*arr):    
    pm.mel.eval("artSkinLockInf artAttrSkinPaintCtx 0;")
    pm.mel.eval("artSkinInvLockInf artAttrSkinPaintCtx 0;")
    pm.mel.eval("PruneSmallWeights;")
    pm.mel.eval("artSkinLockInf artAttrSkinPaintCtx 0;")
    pm.mel.eval("artSkinInvLockInf artAttrSkinPaintCtx 1;")        
    
def replaceWeight(value,*arr):
    pm.mel.eval("artAttrSkinPaintModePaintSelect 1 artAttrSkinPaintCtx;")
    pm.mel.eval("artAttrPaintOperation artAttrSkinPaintCtx Replace;")
    pm.mel.eval("artSkinSetSelectionValue "+str(value)+" false artAttrSkinPaintCtx artAttrSkin;")
    
def addWeight(value,*arr):
    pm.mel.eval("artAttrSkinPaintModePaintSelect 1 artAttrSkinPaintCtx;")
    pm.mel.eval("artAttrPaintOperation artAttrSkinPaintCtx Add;")
    pm.mel.eval("artSkinSetSelectionValue "+str(value)+" false artAttrSkinPaintCtx artAttrSkin;")

def smooth(value,*arr):
    pm.mel.eval("artAttrSkinPaintModePaintSelect 1 artAttrSkinPaintCtx;")
    pm.mel.eval("artAttrPaintOperation artAttrSkinPaintCtx Smooth;")
    pm.mel.eval("artUpdateStampProfile "+value+" artAttrSkinPaintCtx;")
               
def unlock(value,*arr):
    pm.mel.eval("artSkinLockInf artAttrSkinPaintCtx 0;")
    pm.mel.eval("artSkinInvLockInf artAttrSkinPaintCtx 1;")
      
def addUnlock(value,*arr):
    pm.mel.eval("artSkinLockInf artAttrSkinPaintCtx 0;")    

def pickValue(*arr):
    pm.mel.eval("artAttrPaintOperation artAttrSkinPaintCtx Replace;")
    pm.mel.eval("artAttrSkinPaintCtx -e -pickValue `currentCtx`;")
           
def unlockAll(*arr):
    pm.mel.eval("artSkinInvLockInf artAttrSkinPaintCtx 0;")
    pm.mel.eval("artSkinLockInf artAttrSkinPaintCtx 0;")

def flood(*arr):
    pm.mel.eval("artAttrSkinPaintModePaintSelect 1 artAttrSkinPaintCtx;")
    pm.mel.eval('artAttrSkinPaintCtx -e -clear `currentCtx`;')

def clearSelect(*arr):
    pm.mel.eval("artAttrSkinSetPaintMode 0;")
    pm.mel.eval("select -cl  ;")
    #pm.mel.eval("artAttrSkinPaintModePaintSelect 1 artAttrSkinPaintCtx;")
    pm.mel.eval("maintainActiveChangeSelectMode meshBody 0;")
    pm.mel.eval("artAttrSkinSetPaintMode 1;")

def check_axis_max(name):
    axis_array_translate = ["X","Y","Z"]
    array_temp_translate = []
    max_index_translate = 0
    current_translate = cmds.getAttr(name+".translate")[0]    
    for i in range(0,3):        
        array_temp_translate.append(abs(current_translate[i]))       
        check_max_translate = max(array_temp_translate)
        if check_max_translate == abs(current_translate[i]):
            max_index_translate = i
    return_axis = axis_array_translate[max_index_translate] 
    return [return_axis]   

array_attribute = {
    0:["rotateX",[90,-90]],
    1:["rotateY",[90,-90]],
    2:["rotateZ",[90,-90]]
}

def FitRangeAnim(*arr):
    animCurves = cmds.ls(type="animCurve")
    last = 0
    for a in animCurves:
        if cmds.findKeyframe(a,which="last") > last:
            last =  cmds.findKeyframe(a,which="last")
    pm.mel.eval('playbackOptions -min 0 -max '+str(last)+' ;')

def GetAllKeytime(*arr):
    objs = cmds.ls(type='transform')
    keyData = []
    for obj in objs:
        keyTimes = cmds.keyframe(obj,query=True,timeChange=True) or []
        if keyTimes:
            keyData.extend(keyTimes)
    return(sorted(set(keyData)))

def ZoomRangeAnim(*arr):
    time = cmds.currentTime(query=True)
    objs = cmds.ls(selection=True)
    if objs:
        obj = objs[0]
        keyTimes = GetAllKeytime()
        if not keyTimes:
            return()
        keyTimes = sorted(set(keyTimes))
        prevKey = max([k for k in keyTimes if k < time],default=None)
        nextKey = min([k for k in keyTimes if k > time],default=None)
        pm.mel.eval('playbackOptions -min '+str(prevKey)+' -max '+str(nextKey)+' ;')

def curlKeyframe(*arr):
    attrArray = ["indexCurl","middleCurl","ringCurl","pinkyCurl","thumbCurl"]
    for a in ["Fingers_L","Fingers_R"]:
        if cmds.objExists(a):
            cmds.currentTime(0)
            for b in attrArray:
                cmds.setKeyframe(a,attribute=b,value=0)
            cmds.currentTime(30)
            for b in attrArray:
                cmds.setKeyframe(a,attribute=b,value=10)
            cmds.currentTime(60)
            for b in attrArray:
                cmds.setKeyframe(a,attribute=b,value=0)
            cmds.currentTime(0)
    FitRangeAnim()

def get_transform(obj,*arr):
    array_temp = {
        "r_x":cmds.getAttr(obj+".rotateX"),
        "r_y":cmds.getAttr(obj+".rotateY"),
        "r_z":cmds.getAttr(obj+".rotateZ"),
        "t_x":cmds.getAttr(obj+".translateX"),
        "t_y":cmds.getAttr(obj+".translateY"),
        "t_z":cmds.getAttr(obj+".translateZ")
    }
    return array_temp

"""  
   
def autoKeyframe(type,*attr):
    old_time = cmds.currentTime(query=True)
    global array_attribute 
    selection = cmds.ls(selection=True)
    for i in selection:
        if type == "single":
            current_time = cmds.currentTime(query=True)
        elif type == "together":
            current_time = 0
        data = []
        for a in array_attribute:
            data.append(cmds.getAttr(i+"."+array_attribute[a][0]))
        for a in range(len(data)):            
            key_frame_array = array_attribute[a][1]
            for b in key_frame_array:
                current_time += 30
                cmds.currentTime(current_time)              
                cmds.setKeyframe(i, attribute=array_attribute[a][0],value=data[a])
                current_time += 30
                cmds.currentTime(current_time)      
                cmds.setKeyframe(i, attribute=array_attribute[a][0],value=data[a]+b)
                current_time += 30
                cmds.currentTime(current_time) 
                cmds.setKeyframe(i, attribute=array_attribute[a][0],value=data[a])
    cmds.currentTime(old_time)
    FitRangeAnim()



              
def worldKeyframe(keyframType,*attr):
    global array_attribute
    time = cmds.currentTime(query=True)
    selection = cmds.ls(selection=True,ap=True)

    parentArray = {}
    for a in selection:
        parentArray[a]={
            "parent":"",
            "joint":""
        }
        aParent = general.allParents(a)
        for b in aParent:
            if b in selection:
                parentArray[a]["parent"] = b
    
    newJointArray = []  
    for a in selection:
        cmds.select(d=True)
        newJoint = cmds.joint(p=(0,0,0))        
        parentArray[a]["newJoint"] = newJoint
        newJointArray.append(newJoint)    
        cmds.addAttr(newJoint,longName="worldKeyframe",dt='string')                
        cmds.matchTransform(newJoint,a,pos=True)
        new_constraint = cmds.parentConstraint(newJoint,a,mo=True)        

    for a in parentArray:        
        if parentArray[a]["parent"]!="":
            jointChildren = parentArray[a]["newJoint"]
            jointParent = parentArray[parentArray[a]["parent"]]["newJoint"]
            cmds.parent(jointChildren,jointParent)

    for a in newJointArray:
        cmds.setKeyframe(newJoint)
        if keyframType == "together":
            timeTemp = time
        else:
            timeTemp = cmds.currentTime(query=True)
        data = []       
        for b in array_attribute:
            data.append(cmds.getAttr(a+"."+array_attribute[b][0]))

        for b in range(len(data)):            
            key_frame_array = array_attribute[b][1]
            for c in key_frame_array:
                timeTemp += 30
                cmds.currentTime(timeTemp)              
                cmds.setKeyframe(a, attribute=array_attribute[b][0],value=data[b])
                timeTemp += 30
                cmds.currentTime(timeTemp)      
                cmds.setKeyframe(a, attribute=array_attribute[b][0],value=data[b]+c)
                timeTemp += 30
                cmds.currentTime(timeTemp) 
                cmds.setKeyframe(a, attribute=array_attribute[b][0],value=data[b])
    FitRangeAnim()

def KeyframeTranslate(axis,trend,*arr):
    distance =  cmds.intField("KeyframeTranslateValue",value=True,query=True)
    objs = cmds.ls(selection=True)
    for obj in objs:
        currentValue = cmds.getAttr(obj+".t"+axis)
        cmds.select(d=True)
        newJoint = cmds.joint(p=(0,0,0))
        children = cmds.joint(p=(0,0,0))  
        cmds.addAttr(newJoint,longName="worldKeyframe",dt='string')                
        cmds.matchTransform(newJoint,obj,pos=True)
        cmds.parentConstraint(children,obj,mo=True)
        cmds.currentTime(0)
        cmds.setKeyframe(children,attribute="t"+axis,value=currentValue)
        cmds.currentTime(100)
        cmds.setKeyframe(children,attribute="t"+axis,value=distance*trend)
        cmds.currentTime(100)
        cmds.hide(newJoint)
    cmds.select(objs)
    FitRangeAnim()
"""

def worldMirrorKeyframe(*arr):
    obj1 = cmds.ls(selection=True)[0]
    obj2 = cmds.ls(selection=True)[1]
    cmds.select(clear=True)
    jointCenter =  cmds.joint()     
    mirrorPlane = general.checkNegPosAxis(obj1,"x")
    cmds.select(clear=True)
    jointTemp =  cmds.joint()
    cmds.matchTransform(jointTemp,obj1,pos=True) 
    cmds.parent(jointTemp,jointCenter)
    cmds.select(jointTemp)
    if  mirrorPlane == '-':     
        jointMirror = pm.mel.eval('mirrorJoint -mirrorYZ -mirrorBehavior;')[0]
    else:
        jointMirror = pm.mel.eval('mirrorJoint -mirrorYZ;')[0]
    cmds.parent(jointTemp, world=True)
    cmds.parent(jointMirror, world=True)

    newJoints = [jointTemp,jointMirror]
    oldJoints = [obj1,obj2]

    for i in range(len(newJoints)):
        cmds.addAttr(newJoints[i],longName="worldKeyframe",dt='string')
        cmds.parentConstraint(newJoints[i],oldJoints[i],mo=True)

    for a in newJoints:
        data = []
        for b in array_attribute:
            data.append(cmds.getAttr(a+"."+array_attribute[b][0]))

        for b in range(len(data)):            
            key_frame_array = array_attribute[b][1]
            for c in key_frame_array:
                timeTemp += 30
                cmds.currentTime(timeTemp)              
                cmds.setKeyframe(a, attribute=array_attribute[b][0],value=data[b])
                timeTemp += 30
                cmds.currentTime(timeTemp)      
                cmds.setKeyframe(a, attribute=array_attribute[b][0],value=data[b]+c)
                timeTemp += 30
                cmds.currentTime(timeTemp) 
                cmds.setKeyframe(a, attribute=array_attribute[b][0],value=data[b])
    FitRangeAnim()


def CreateKeyframe(keyInput,*arr):
    objs = cmds.ls(selection=True)
    if objs:
        cmds.currentTime(0)
        keySpace = keyInput['space']
        keyType = keyInput['type']
        keyInturn = keyInput['inturn']        
        currentTime = 0
        for obj in objs:
            jointAddKey = []
            cmds.select(clear=True)
            jointSpace = cmds.joint()
            cmds.addAttr(jointSpace,longName="worldKeyframe",dt='string')
            cmds.setAttr(jointSpace+'.overrideEnabled',1)
            cmds.setAttr(jointSpace+'.overrideVisibility',0)
            jointChild = cmds.joint()
            jointAddKey.append(jointChild)
            if keySpace == 'world':
                cmds.matchTransform(jointSpace,obj,pos=True)
            elif keySpace == 'local':
                cmds.matchTransform(jointSpace,obj,pos=True,rot=True)

            if keyType == 'rotate':
                keyData = {
                    "rx":[0,-90,0,90,0],
                    "ry":[0,-90,0,90,0],
                    "rz":[0,-90,0,90,0],
                }
            elif keyType == 'translate':
                keyData = {
                        "tx":[0,-100,0,100,0],
                        "ty":[0,-100,0,100,0],
                        "tz":[0,-100,0,100,0],
                }   
            constraint = cmds.parentConstraint(jointChild,obj,mo=True)
            cmds.setAttr(jointSpace+'.visibility',0)
            if keyInput['inturn'] == False:
                currentTime = 0
            for jointChild in jointAddKey:
                for key in keyData:
                        keyArray = keyData[key]
                        for keyValue in keyArray:
                            currentTime += 30
                            cmds.currentTime(currentTime)              
                            cmds.setKeyframe(jointChild, attribute=key,value=keyValue)
        FitRangeAnim()
        cmds.select(objs[0])      




def deleteSenceKeyframe(*attr):
    worldKeyframe = cmds.ls(type="joint")
    for i in worldKeyframe:
        try:
            if cmds.attributeQuery("worldKeyframe",node=i,ex=True):
                cmds.delete(i)
        except:pass

def showQuardraw(*arr):
    pm.mel.eval('lockNode -l off  -lockUnpublished off initialShadingGroup;')


def ExportAllSkinUrl(folder,*arr):
    jsonData = {}
    jsonPath = folder+'/skinData.json'
    cmds.currentTime(0)
    if len(cmds.ls(selection=True))!=0:
        meshTransform = cmds.ls(selection=True)
    else:
        meshTransform = cmds.listRelatives(cmds.ls(type = "mesh",ap=True),parent=True,pa=True)
        meshTransform = list(set(meshTransform))
    for transform in meshTransform:
        skin_name = pm.mel.eval('findRelatedSkinCluster '+transform)
        transformName = transform
        transformName = transformName.replace("|","&")
        transformName = transformName.replace(":","%")
        if skin_name:
            jsonData[transformName] = {
                'skinName':skin_name
            }
            version = cmds.about(version=True)
            if version in ["2018"]:
                pm.mel.eval('deformerWeights -export -deformer "'+skin_name+'" -path "'+folder+'" "'+transformName+'.xml";')
            else:
                pm.mel.eval('deformerWeights -export -deformer "'+skin_name+'" -format "XML" -path "'+folder+'" "'+transformName+'.xml";')
            general.writeJsonFile(jsonPath,jsonData)

def ExportAllSkin(*arr):
    folder_temp = os.path.dirname(pm.sceneName())
    if not folder_temp:
        folder_temp = pm.mel.eval("SaveSceneAs;")
    folder_temp = os.path.dirname(pm.sceneName())
    if folder_temp:
        folder_temp = os.path.join(os.path.dirname(pm.sceneName()), 'bnlta_all_skins_export')
        folder_temp = cmds.encodeString(folder_temp)
        if os.path.exists(folder_temp):
            shutil.rmtree(folder_temp)
        if not os.path.exists(folder_temp):
            os.makedirs(folder_temp)
        ExportAllSkinUrl(folder_temp)


def ExportFolderSkin(*arr):
    url = cmds.fileDialog2(dialogStyle=2, fileMode=3, caption="Select Folder")[0]
    if url:
        dataTemp = {}
        meshs = cmds.ls(selection=True)
        for mesh in meshs:
            dataTemp[mesh] = {}
            dataTemp[mesh]["uuid"] = cmds.ls(mesh,uuid=True)
            meshParent =  cmds.listRelatives(mesh,parent=True)
            if meshParent:
                dataTemp[mesh]["parent"] =  meshParent[0]
                cmds.parent(mesh, world=True)
            else:
                dataTemp[mesh]["parent"] = None
            if "NLTA_" not in mesh:
                cmds.rename(mesh,"NLTA_"+mesh)
                dataTemp[mesh]["nameTemp"] = "NLTA_"+mesh
            else:
                dataTemp[mesh]["nameTemp"] = mesh
        cmds.select(clear=True)
        for mesh in dataTemp:
            cmds.select(cmds.ls(dataTemp[mesh]["uuid"]),add=True)
        cmds.file(url +'/mesh.obj', force=True, options="groups=1;ptgroups=0;materials=0;smoothing=0;normals=1", type='OBJexport', exportSelected=True)
        ExportAllSkinUrl(url)
        for mesh in dataTemp:
            if dataTemp[mesh]["parent"]!=None:
                cmds.parent(dataTemp[mesh]["nameTemp"],dataTemp[mesh]["parent"])
            cmds.rename(cmds.ls(dataTemp[mesh]["uuid"])[0],mesh)



def ImportAllSkinUrl(folder,*arr):
    if os.path.exists(folder):
        jsonData = {}
        jsonPath = folder+'/skinData.json'
        if os.path.exists(jsonPath):
            jsonData = general.readJsonFile(jsonPath)
        cmds.currentTime(0)
        if len(cmds.ls(selection=True))!=0:
            meshTransform = cmds.ls(selection=True)
        else:
            meshTransform = cmds.listRelatives(cmds.ls(type = "mesh",ap=True),parent=True,pa=True)
            meshTransform = list(set(meshTransform))
        for transform in meshTransform:
            transformName = transform
            transformName = transformName.replace("|","&")
            transformName = transformName.replace(":","%")

            each_file = ""
            
            fileLink = cmds.encodeString(folder + "/" + transformName + ".xml")
            if os.path.exists(fileLink):
                each_file = fileLink            
            fileLinkSame = cmds.encodeString(folder + "/" + transformName + ".xml")
            if os.path.exists(fileLinkSame):
                each_file = fileLinkSame

            if each_file!="":
                joints = []
                xFile = xd.parse(each_file)
                elements = xFile.getElementsByTagName("weights")
                for e in elements:
                    attrs = e.attributes.keys()
                    for a in attrs:
                        if a == "source":
                            pair = e.attributes[a]
                            joints.append(pair.value)
                cmds.select(transform)
                pm.mel.eval('DeleteHistory;')
                for attr in ["tx","ty","tz","rx","ry","rz","sx","sy","sz"]:
                    cmds.setAttr(transform+"."+attr,lock=False)

                pm.mel.eval('makeIdentity -apply true -t 1 -r 1 -s 1 -n 0 -pn 1;')
                pm.mel.eval('ResetTransformations;')
                if len(joints)!=0:
                    cmds.select(clear=True)
                    for b in joints:
                        if len(cmds.ls(b))>1:
                            print("More than one joint name is "+b)
                        else:
                            if cmds.objExists(b):                            
                                cmds.select(b,add=True)
                            else:
                                print("Cant find joint name "+b)
                    jointSelection = cmds.ls(selection=True)
                    if jointSelection:
                        cmds.select(transform,add=True)
                        skin_name = cmds.skinCluster(cmds.ls(selection=True),toSelectedBones=True,bindMethod=0,skinMethod=0,normalizeWeights=1,maximumInfluences=1)[0]
                        pm.mel.eval('deformerWeights -import -method "index" -deformer "'+skin_name+'" -path "'+folder+'/" "'+transformName+'.xml"; skinCluster -e -forceNormalizeWeights "'+skin_name+'";')
                        if jsonData !={}:
                            cmds.rename(skin_name,jsonData[transform]['skinName'])
    else:
        cmds.confirmDialog(title="Confirm",message="Dont have data!",button=["Yes"],defaultButton="Yes",cancelButton="Yes") 

def importAllSkin(*arr):
    folder = os.path.dirname(pm.sceneName())+"/"+'bnlta_all_skins_export'
    ImportAllSkinUrl(folder)

def ImportFolderSkin(*arr):
    url = cmds.fileDialog2(dialogStyle=2, fileMode=3, caption="Select Folder")[0]
    if url:
        files = general.GetFiles(url,'obj')
        for file_ in files:
            filePath =  url+"/"+file_+".obj"
            cmds.file(filePath, i=True, type="OBJ", ignoreVersion=True, ra=True, mergeNamespacesOnClash=False, namespace=":", options="mo=1", pr=True)
    ImportAllSkinUrl(url)

def selectCorrectJoint(jointArray,*arr):
    for a in jointArray:
        if cmds.objExists(a):
            return jointArray

def fixMaxInfluent(maxValue,*arr):
    selection = cmds.ls(selection=True,type="mesh")
    if len(selection)==0:
        selection = cmds.ls(type="mesh")
    for a in selection:
        if pm.mel.eval('findRelatedSkinCluster '+a):  
            vertex = cmds.ls(a+'.vtx[*]',fl=True)
            objName = a
            skinName = pm.mel.eval('findRelatedSkinCluster '+objName)
            allJoints = cmds.skinCluster(objName,inf=True,q=True)
            allJointsLock= ""
            for b in vertex:
                joints = cmds.skinPercent(skinName,b,query=True,transform=None)
                values = cmds.skinPercent(skinName,b,query=True,value=True)
                jointsTemp = []
                valuesTemp = []
                for c in range(len(joints)):
                    if values[c] > 0:
                        jointsTemp.append(joints[c])
                        valuesTemp.append(values[c])
                if len(jointsTemp) > maxValue:
                    valuesTemp.sort()              
                    min_value = valuesTemp[(len(valuesTemp) - (maxValue + 1))] 

                    lockJoints = ""
                    for c in allJoints:
                        lockJoints += "setAttr "+c+".liw  1;"
                    pm.mel.eval(lockJoints)

                    unlockJoints = ""
                    for c in jointsTemp:
                        unlockJoints += "setAttr "+c+".liw  0;"
                    pm.mel.eval(unlockJoints) 
                    weightValue = []
                    for c in range(0,len(joints)):
                        if values[c] <= min_value:
                            weightValue.append((joints[c],0))
                    cmds.skinPercent(skinName,b, transformValue=weightValue)
    print("--Fix max influence success!--")

def fixMaxInfluentAll(maxValue,*arr):
    cmds.select(clear=True)
    for a in cmds.ls(type="mesh"):
        if a.endswith("Orig")!=True:
            for b in cmds.listHistory(a):
                if cmds.objExists(b) and cmds.objectType(b) == "skinCluster":
                    cmds.select(cmds.listRelatives(a,parent=True)[0],add=True)
    fixMaxInfluent(maxValue)

def checkMaxInfluent(*arr):
    if len(cmds.ls(sl=True)) !=0:
        maxValue = cmds.intField("maxInfluent",query=True,value=True)
        objName = cmds.ls(sl=True)[0]
        vertex = cmds.ls(objName+'.vtx[*]',fl=True)
        skinName = pm.mel.eval('findRelatedSkinCluster '+objName)
        cmds.select(clear=True)
        arrayTemp = []
        for a in vertex:
            joints = cmds.skinPercent(skinName,a,query=True,transform=None)
            values = cmds.skinPercent(skinName,a,query=True,value=True)
            jointsTemp = []
            for b in range(len(joints)):
                if values[b]>0:
                    jointsTemp.append(joints[b])
            if len(jointsTemp) > maxValue:
                arrayTemp.append(a)
        if cmds.objExists("vertexOverMaxInfluence"):
            cmds.delete("vertexOverMaxInfluence")
        cmds.select(arrayTemp)
        pm.mel.eval('sets -name "vertexOverMaxInfluence";')
        cmds.confirmDialog(title="Success!",message="Your request is done!",button=["Yes"],defaultButton="Yes",cancelButton="Yes")

def setInfluence(maxGet,*arr):
    maxGet = maxGet
    selection = cmds.ls(selection=True,type="mesh")
    if len(selection)==0:
        selection = cmds.ls(type="mesh")
    if maxGet == 0:
        for a in selection:
            for b in cmds.listHistory(a):
                if cmds.objectType(b) == "skinCluster":
                    pm.mel.eval('setAttr "'+b+'.maxInfluences" 1;')
                    pm.mel.eval('setAttr "'+b+'.maintainMaxInfluences" 0;')
    else:
        for a in selection:
            for b in cmds.listHistory(a):
                if cmds.objectType(b) == "skinCluster":
                    pm.mel.eval('setAttr "'+b+'.maxInfluences" '+str(maxGet)+';')
                    pm.mel.eval('setAttr "'+b+'.maintainMaxInfluences" 1;')
    print("--Set max influence success!--")

def switchJoint(*arr):
    objName = cmds.ls(sl=True)[0]
    skinName = pm.mel.eval('findRelatedSkinCluster '+objName)
    allJoints = cmds.skinCluster(objName,inf=True,q=True)
    jointCurrent = []
    for a in allJoints:
        if cmds.getAttr(a+".liw")!=1:
            jointCurrent.append(a)
    joint_active = cmds.connectionInfo(skinName+".paintTrans",sourceFromDestination=True).split(".")[0]
    if joint_active not in jointCurrent:
        index = 0
    else:
        index = jointCurrent.index(joint_active)
        if index < (len(jointCurrent) - 1):
            index = index + 1
        else:
            index = 0
    pm.mel.eval('setSmoothSkinInfluence '+jointCurrent[index]+';artSkinRevealSelected artAttrSkinPaintCtx;')

def createRetopology(*arr):
    mesh = cmds.ls(selection=True)[0]
    jointOld =  cmds.ls(selection=True)[1]
    jointChildren = cmds.listRelatives(jointOld,children=True)[0]
    cmds.select(mesh)
    am = pm.mel.eval("closestPointOn (1, 1);")
    node = cmds.ls(type="closestPointOnMesh")[0]
    controlLoc = cmds.connectionInfo(node+".inPosition",sourceFromDestination=True).split(".")[0]
    beControlLoc =  cmds.connectionInfo(node+".result.position",destinationFromSource=True)[0].split(".")[0]
    cmds.select(clear=True)

    jointParent = cmds.joint()
    cmds.matchTransform(jointParent,jointOld,rot=True,pos=True)
    cmds.select(jointParent)
    pm.mel.eval('makeIdentity -apply true -t 1 -r 1 -s 1 -n 0 -pn 1;')
    jointMove = cmds.duplicate(jointParent)[0]
    cmds.parent(jointMove,jointParent)
    cmds.matchTransform(jointMove,jointChildren,rot=True,pos=True)
    cmds.select(jointParent)
    pm.mel.eval('joint -e  -oj xyz -secondaryAxisOrient zup -ch -zso;')
    cmds.select(jointMove)    
    pm.mel.eval('makeIdentity -apply true -t 1 -r 1 -s 1 -n 0 -pn 1;')
    pm.mel.eval('joint -e  -oj none -ch -zso;')
    
    jointSnap = cmds.joint()
    cmds.matchTransform(controlLoc,jointSnap,rot=True,pos=True)
    cmds.select(jointSnap)
    pm.mel.eval('makeIdentity -apply true -t 1 -r 1 -s 1 -n 0 -pn 1;')
    cmds.parentConstraint(jointSnap,controlLoc)
    jointModify = cmds.duplicate(jointSnap)[0]

    distance = cmds.getAttr(jointMove+".translateX")
    axisMain = "X"
    axisSecond = "Y"
    distanceBetween1 = pm.mel.eval('shadingNode -asUtility distanceBetween;')
    pm.mel.eval('connectAttr -force '+jointMove+'.worldMatrix[0] '+distanceBetween1+'.inMatrix1;')
    pm.mel.eval('connectAttr -force '+beControlLoc+'.worldMatrix[0] '+distanceBetween1+'.inMatrix2;')
    
    distanceBetween2 = pm.mel.eval('shadingNode -asUtility distanceBetween;')
    pm.mel.eval('connectAttr -force '+jointMove+'.worldMatrix[0] '+distanceBetween2+'.inMatrix1;')
    pm.mel.eval('connectAttr -force '+controlLoc+'.worldMatrix[0] '+distanceBetween2+'.inMatrix2;')
    
    moveStep = distance/12
    cmds.setAttr(jointMove+".translate"+axisMain,0)
    a = 0
    allCurve = []
    while a < distance:
        a = a + moveStep
        cmds.setAttr(jointMove+".translate"+axisMain,a)
        cmds.setAttr(jointMove+".rotate"+axisMain,0)
        curvePoint = []
        b = 0
        while b < 360:
            cmds.setAttr(jointMove+".rotate"+axisMain,b)
            cmds.setAttr(jointModify+".translate"+axisSecond,0)
            cmds.setAttr(jointSnap+".translate"+axisSecond,0)
            c = 0
            while c < 1:
                distanceModify = cmds.getAttr(distanceBetween1+".distance")
                distanceMove = cmds.getAttr(distanceBetween2+".distance")
                if distanceMove < distanceModify:        
                    cmds.setAttr(jointModify+".translate"+axisSecond,cmds.getAttr(jointModify+".translate"+axisSecond) + 1)
                    cmds.setAttr(jointSnap+".translate"+axisSecond,cmds.getAttr(jointSnap+".translate"+axisSecond) + 1)
                else:
                    c = 1                
            curvePoint.append(cmds.xform(beControlLoc,query=True,translation=True))
            b += 30
        curve_new = cmds.curve(d=3,p=curvePoint)
        pm.mel.eval('closeCurve -ch 1 -ps 0 -rpo 1 -bb 0.5 -bki 0 -p 0.1 "'+curve_new+'";')
        allCurve.append(curve_new)

    curveString = ""
    for a in allCurve:
        curveString += ' "'+a+'"'
    loft = pm.mel.eval('loft -ch 1 -u 0 -c 0 -ar 1 -d 3 -ss 1 -rn 0 -po 3 -rsn true '+curveString+';')[0]
    pm.mel.eval('nurbsToPoly -mnd 1  -ch 1 -f 2 -pt 1 -pc 200 -chr 0.1 -ft 0.01 -mel 0.0001 -d 0.5 -ut 1 -un 15 -vt 1 -vn 12 -uch 0 -ucr 0 -cht 0.2 -es 0 -ntr 0 -mrt 0 -uss 1 "'+loft+'";')
    cmds.delete([jointParent,beControlLoc,controlLoc,distanceBetween1,distanceBetween2,loft])
    cmds.delete(allCurve)

def maintainOff(number,*arr):
    for a in cmds.ls(type="mesh"):
        if a.endswith("Orig")!=True:
            for b in cmds.listHistory(a):
                if cmds.objExists(b) and cmds.objectType(b) == "skinCluster":      
                    pm.mel.eval('setAttr "'+b+'.maxInfluences" '+str(number)+';')
                    if number!=0:
                        print("a")
                        pm.mel.eval('setAttr "'+b+'.maintainMaxInfluences" 1;')
                    else:
                        pm.mel.eval('setAttr "'+b+'.maintainMaxInfluences" 0;')
                        print("b")

def setMaintainOff(*arr):
    number = cmds.intField("maintainOff",value=True,query=True)
    maintainOff(number)

def clearSkin(*arr):
    for a in cmds.ls(type="mesh"):
        if cmds.objExists(a):
            for b in cmds.listHistory(a):
                if cmds.objExists(b) and cmds.objectType(b) == "skinCluster":
                    cmds.select(a)
                    pm.mel.eval('DeleteHistory;')
                    
def compareMesh(*arr):
    mesh1 = cmds.ls(selection =True)[0]
    mesh2 = cmds.ls(selection =True)[1]
    mesh1Vertex = cmds.ls(mesh1+".vtx[*]")
    mesh2Vertex = cmds.ls(mesh1+".vtx[*]")

def getFaceSideVertex(mesh,*arr):
    skinData = getSkinData(mesh)
    skinClusterName =  skinData["skinCluster"]
    pm.mel.eval("skinCluster -e -selectInfluenceVerts NLTAFaceSideJoint1 "+skinClusterName+";")
    pm.mel.eval('doMenuComponentSelectionExt("'+mesh+'", "vertex", 0);')
    return(cmds.ls(selection=True,flatten=True))

def createFaceSide(position,worldAxis,*arr):
    arrayAxis = ["x","y","z"]
    axisIndex =arrayAxis.index(worldAxis)
    joint1Position = [0,0,0]
    joint1Position[axisIndex] = 1
    cubePivot = ["0","0","0"]
    cubePivot[axisIndex] = "-0.5"
    cubePivotString = " ".join(cubePivot)
    cubeScale = ["100","100","100"]
    cubeScale[axisIndex] = "1"
    cubeScaleString = " ".join(cubeScale)
    
    cmds.select(d=True)
    joint1 = cmds.joint(name="NLTAFaceSideJoint1",p=(0,0,0))
    cmds.select(d=True)
    joint2 = cmds.joint(name="NLTAFaceSideJoint2",p=joint1Position)
    cmds.parent(joint2,joint1)
    cmds.setAttr(joint1+".translateX",position[0])
    cmds.setAttr(joint1+".translateY",position[1])
    cmds.setAttr(joint1+".translateZ",position[2])
    cube = cmds.polyCube(name="NLTAFaceSideCube",w=1,h=1,d=1)[0]
    pm.mel.eval('move -r '+cubePivotString+' '+cube+'.scalePivot '+cube+'.rotatePivot ;')
    pm.mel.eval('scale -r '+cubeScaleString+' ;')

    cmds.matchTransform(cube,joint1,pos=True)
    clearMesh(cube)

    cmds.select([cube,joint1,joint2])
    skinCluster = bindSkin()
    for a in range(0,4):
        cmds.skinPercent(skinCluster,cube+".vtx["+str(a)+"]", transformValue=[joint2,1])
    for a in range(4,8):
        cmds.skinPercent(skinCluster,cube+".vtx["+str(a)+"]", transformValue=[joint1,1])

def faceSideBottomVertex(*arr):
    mesh = cmds.ls(selection=True)[0]
    if cmds.objExists("NLTAFaceSideCube"):
        cmds.select("NLTAFaceSideCube")
        cmds.select(mesh,add=True)
        copyJointBind()
        cmds.select(clear=True)
        cmds.select(getFaceSideVertex(mesh))
        pm.mel.eval('polyAverageVertex -i 10 -ch 1 '+(" ").join(cmds.ls(selection=True))+';')
        cmds.select(mesh)
        clearMesh(mesh)

def removeUnneedJoint(*arr):
    cmds.currentTime(0)
    if len(cmds.ls(selection=True))!=0:
        meshTransform = cmds.ls(selection=True)
    else:
        meshTransform = cmds.listRelatives(cmds.ls(type = "mesh",ap=True),parent=True,pa=True)
        meshTransform = list(set(meshTransform))
    for transform in meshTransform:
        skinCluster = pm.mel.eval('findRelatedSkinCluster '+transform)
        if skinCluster:
            joints = cmds.skinCluster(skinCluster,query=True,inf=True)
            removeJoints = []
            for joint in joints:
                flag = False
                cmds.select(clear=True)
                pm.mel.eval('skinCluster -e -selectInfluenceVerts '+joint+' '+skinCluster+';')
                selection = cmds.ls(selection=True)
                if len(selection) == 1:
                    if '.vtx[' not in selection[0]:
                        flag = True
                if flag == True:
                    removeJoints.append(joint)            
            cmds.skinCluster(skinCluster, e=True, removeInfluence=removeJoints)
            print('Remove Joint '+ (' - ').join(removeJoints))
    cmds.select(meshTransform)

def AddMeshJoint(*arr):
    cmds.currentTime(0)
    if len(cmds.ls(selection=True)) == 2:
        selection =  cmds.ls(selection=True)
        source = selection[0]
        destination =  selection[1]
        skinClusterSource = pm.mel.eval('findRelatedSkinCluster '+ source)
        skinClusterDestination =  pm.mel.eval('findRelatedSkinCluster '+ destination)
        if skinClusterSource and skinClusterDestination:
            jointsSource = cmds.skinCluster(skinClusterSource,query=True,inf=True)
            jointsDestination =  cmds.skinCluster(skinClusterDestination,query=True,inf=True)
            jointsAdd = []
            for joint in jointsSource:
                if joint not in jointsDestination:
                    jointsAdd.append(joint)
            cmds.skinCluster(skinClusterDestination, edit=True, addInfluence=jointsAdd, weight=0)
            print('Add Joint '+ (' - ').join(jointsAdd))

def AddJoint(*arr):
    cmds.currentTime(0)
    if len(cmds.ls(selection=True)) >= 2:
        selection =  cmds.ls(selection=True)
        jnts = cmds.ls(selection=True,type="joint")
        meshs =  cmds.listRelatives(cmds.ls(type ="mesh",ap=True),parent=True,pa=True)
        meshBind = []
        for mesh in meshs:
            if (mesh in selection) and (mesh not in jnts):
                if mesh not in meshBind:
                    skinCluster =  pm.mel.eval('findRelatedSkinCluster '+mesh)
                    if skinCluster:
                        meshJoints = cmds.skinCluster(skinCluster,query=True,inf=True)
                        jointsAdd = []
                        for joint in jnts:
                            if joint not in meshJoints:
                                jointsAdd.append(joint)
                        cmds.skinCluster(skinCluster, edit=True, addInfluence=jointsAdd, weight=0)
                        print('Add Joint '+ (' - ').join(jointsAdd))
                meshBind.append(mesh)

def CopyWeight(*arr):
    selection = cmds.ls(flatten=True,os=True)
    source = selection[0]
    destination =  selection[1:]
    cmds.select(source)
    pm.mel.eval('CopyVertexSkinWeights;')
    cmds.select(destination)
    pm.mel.eval('PasteVertexSkinWeights;')


HideLayer = "NLTA_HideObject"
def CheckHideLayer(*arr):
    if not pm.objExists(HideLayer):
        pm.createDisplayLayer(name=HideLayer, empty=True)
        cmds.setAttr(HideLayer+".displayType", 2)
        cmds.setAttr(HideLayer+".visibility", 0)

def HideObject(*arr):
    CheckHideLayer()
    selection = cmds.ls(selection=True)    
    pm.editDisplayLayerMembers(HideLayer,selection, noRecurse=True)

def UnhideObject(*arr):
    selection = cmds.ls(selection=True)
    pm.mel.eval('layerEditorRemoveObjects '+HideLayer+';')

def UnhideAll(*arr):
    cmds.setAttr(HideLayer+".visibility", 0)
    pm.delete(HideLayer)

def IsolateObjects(*arr):
    CheckHideLayer()
    selection = cmds.ls(selection=True)
    rootNodes = cmds.ls(assemblies=True)
    pm.editDisplayLayerMembers(HideLayer,rootNodes, noRecurse=True)
    pm.mel.eval('layerEditorRemoveObjects '+HideLayer+';')

"""
def ShowFaces(*arr):
    selection = cmds.ls(selection=True)
    if selection:
        for obj in selection:
            cmds.showHidden(obj, below=True)
    else:
       selection = cmds.listRelatives(cmds.ls(type = "mesh",ap=True),parent=True,pa=True)
       for obj in selection:
            cmds.showHidden(obj, below=True)
"""


def GetSetPrefix(*arr):
    selection = cmds.ls(selection=True)
    selection0 = selection[0]
    setNamePrefix = selection0.split(".")[0]
    setNamePrefix = setNamePrefix.split(":")[-1]
    setNamePrefix = "NLTA"+setNamePrefix
    setNamePrefix = setNamePrefix.replace("|","_")
    setNamePrefix = setNamePrefix.replace(":","_")
    return(setNamePrefix)

def GetSameSetNumber(prefix,*arr):
    sets = cmds.ls(type='objectSet')
    returnNumber = 0
    for set_ in sets:
        if prefix in set_:
            returnNumber +=1
    return(returnNumber)

def CreateSet(*arr):
    selection = cmds.ls(selection=True)
    prefix = GetSetPrefix()
    order = []
    sets = cmds.ls(type='objectSet')
    for set_ in sets:
        if prefix in set_:
            order.append(int(set_.replace(prefix,"")))

    if len(order)!=0:
        newName = prefix+ str(max(order) + 1)        
    else:
        newName = prefix+ str(0)
    newSet = cmds.sets(name=newName, empty=True)
    cmds.sets(selection, add=newSet)
    """
    for set_ in sets:
        if NLTA_

    # Create a new set
    set_name = "myNewSet"
    new_set = cmds.sets(name=set_name, empty=True)

    # Add objects to the set
    objects_to_add = ["pSphere1", "pCube1"]
    cmds.sets(objects_to_add, add=set_name)

    members = cmds.sets(set_name, query=True)

    # Hide all members
    if members:
        cmds.hide(members)
    """
setIndex = 0
def NextSet(*arr):
    global setIndex
    prefix =  GetSetPrefix()
    maxNumber = GetSameSetNumber(prefix)
    if setIndex >= (maxNumber - 1):
        currentIndex = 0
    else:
        currentIndex = setIndex + 1
    sets = cmds.ls(type='objectSet')
    for set_ in sets:
        if prefix in set_:
            members = cmds.sets(set_, query=True)
            if members:
                cmds.showHidden(members)
    print(prefix)            
    for set_ in sets:
        if prefix in set_:          
            members = cmds.sets(set_, query=True)
            if set_ == prefix + str(currentIndex):
                if members:
                    cmds.showHidden(members)                
            else:
                if members:
                    cmds.hide(members)
    setIndex = currentIndex

def BackSet(*arr):
    global setIndex
    prefix =  GetSetPrefix()
    maxNumber = GetSameSetNumber(prefix)
    if setIndex <= 0:
        currentIndex = (maxNumber - 1)
    else:
        currentIndex = setIndex - 1
    sets = cmds.ls(type='objectSet')
    for set_ in sets:
        if prefix in set_:
            members = cmds.sets(set_, query=True)
            if members:
                cmds.showHidden(members)                
    for set_ in sets:
        if prefix in set_:
            members = cmds.sets(set_, query=True)
            if set_ == prefix + str(currentIndex):
                if members:
                    cmds.showHidden(members)
            else:
                if members:
                    cmds.hide(members)

    setIndex = currentIndex

def DeleteSets(*arr):
    sets = cmds.ls(type='objectSet')
    for set_ in sets:
        if "NLTA" in set_:
            members = cmds.sets(set_, query=True)
            cmds.showHidden(members)
            cmds.delete(set_)






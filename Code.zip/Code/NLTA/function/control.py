requireTab = "control"
import os,json,sys
import maya.cmds as cmds
import pymel.core as pm
from functools import partial
import general

for i in sys.path:
    if "NLTA/collection/json/" in i:
        url = i
        sourceJson = i + "control_shape.json"
        sourceIcon = i.replace("json","icon")

def createLayout(per,lib,*arr):
    if per == "control":
        cmds.rowColumnLayout("controlButton",numberOfColumns=2,width=400,parent="control")#OPEN LAYOUT

        cmds.rowColumnLayout(numberOfColumns=1,width=200)#OPEN LEFT
        cmds.rowColumnLayout(numberOfColumns=2,width=200)#OPEN LEFT TOP
        yourShape = cmds.button(label="Your shape",width=100)
        systemShape = cmds.button(label="Default shape",width=100) 
        cmds.button(label="Copy shape",c=partial(copyShape,"copy"),width=100)
        cmds.button(label="Mirror shape",c=partial(mirrorShape,"mirror"),width=100)
        saveShapeButton = cmds.button(label="Save shape",width=100)
        cmds.button(label="Export color",width=100,c=exportColor)
        cmds.button(label="Import color",width=100,c=importColor) 
        cmds.setParent("..")#CLOSE LEFT TOP
        cmds.rowColumnLayout( numberOfColumns=4,rowSpacing=[5,5])#OPEN LEFT BOTTOM
        cmds.button(label="",bgc=[0,0,1], width=50, command=partial(changeColor,6))
        cmds.button(label="",bgc=[0,.5,1], width=50, command=partial(changeColor,18))
        cmds.button(label="",bgc=[0.578,0,0.578], width=50, command=partial(changeColor,9))
        cmds.button(label="",bgc=[1,0,0], width=50, command=partial(changeColor,13))
        cmds.button(label="",bgc=[1,.5,.5], width=50, command=partial(changeColor,20))
        cmds.button(label="",bgc=[1,1,0], width=50, command=partial(changeColor,17))
        cmds.button(label="",bgc=[1,.5,.5], width=50, command=partial(changeColor,21)) 
        cmds.button(label='Restore', width=50, command=restoreColor)
        cmds.setParent("..")#CLOSE LEFT BOTTOM
        cmds.setParent("..")#CLOSE LEFT


        cmds.rowColumnLayout(numberOfColumns=1,width=200)#OPEN RIGHT
        cmds.radioButtonGrp("makeControlAmount",labelArray3=['Multi','Single','relative'], numberOfRadioButtons=3,select=1,columnWidth3=[60,60,60])
        cmds.textField("makeControlText",placeholderText="Control Name")
        cmds.scrollLayout(horizontalScrollBarThickness=16,verticalScrollBarThickness=16,height=230,width=200)#open scrollLayout
        gridControlIcon = cmds.gridLayout( numberOfColumns=4, cellWidthHeight=(45,45))#open gridLayout
        cmds.button(systemShape,c = partial(loadSystemShape,gridControlIcon),edit=True)
        cmds.button(yourShape,c = partial(loadYourShape,gridControlIcon),edit=True)
        cmds.button(saveShapeButton,c = partial(saveShape,gridControlIcon),edit=True)
        loadSystemShape(gridControlIcon)
        cmds.setParent("..")#CLOSE RIGHT
        """
        cmds.setParent("..")#CLOSE LAYOUT
        cmds.rowColumnLayout( numberOfColumns=1,rowSpacing=[5,5])#Open right
        cmds.radioButtonGrp("makeControlAmount",labelArray3=['Multi','Single','relative'], numberOfRadioButtons=3,select=1,columnWidth3=[60,60,60])
        cmds.textField("makeControlText",placeholderText="Control Name")
        cmds.scrollLayout(horizontalScrollBarThickness=16,verticalScrollBarThickness=16,height=190,width=200)#open scrollLayout
        gridControlIcon = cmds.gridLayout( numberOfColumns=4, cellWidthHeight=(45,45))#open gridLayout
        cmds.button(systemShape,c = partial(nlta_makeControl.loadSystemShape,gridControlIcon),edit=True)
        cmds.button(yourShape,c = partial(nlta_makeControl.loadYourShape,gridControlIcon),edit=True)
        cmds.button(saveShape,c = partial(nlta_makeControl.saveShape,gridControlIcon),edit=True)
        nlta_makeControl.loadSystemShape(gridControlIcon)
        cmds.setParent("..")#close gridLayout
        cmds.setParent("..")#close scrollLayout
        cmds.setParent("..")#close right    
        cmds.setParent("..")#close containt    
        cmds.setParent("..")#close framelayout
        """

def changeColor(color,*arr):
    list = cmds.ls(selection=True)        
    for a in list:
        objectType = cmds.objectType(a)
        if objectType == "mesh" or objectType == "nurbsCurve" or objectType == "transform":
            listTemp = cmds.listRelatives(list,shapes=True,path=True)
            for b in listTemp:
                cmds.setAttr(b+".overrideEnabled",True)
                cmds.setAttr(b+".overrideColor",color)
        elif objectType == "joint":
            cmds.setAttr(a+".overrideEnabled",True)
            cmds.setAttr(a+".overrideColor",color)
                      
def restoreColor(*arr):
    list = cmds.ls(selection=True)        
    for a in list:
        objectType = cmds.objectType(a)
        if objectType == "mesh" or objectType == "nurbsCurve" or objectType == "transform":
            listTemp = cmds.listRelatives(list,shapes=True,path=True)
            for b in listTemp:
                cmds.setAttr(b+".overrideEnabled",False)
                cmds.setAttr(b+".overrideColor",0)
        elif objectType == "joint":
            cmds.setAttr(a+".overrideEnabled",False)
            cmds.setAttr(a+".overrideColor",0)

def makeControl(type,*arr):
    multi = cmds.radioButtonGrp("makeControlAmount",q=1,select=True)
    inputText = cmds.textField("makeControlText",q=1,text=True)
    list = cmds.ls(selection=True)
    if len(list)!=0:
        if multi == 1:
            for i in range(0,len(list)):
                name_main = general.correctCharacter(list[i])
                ctrInfo = makeControlSub(type,*arr)
                cmds.parentConstraint(list[i],ctrInfo["zeroGroup"],maintainOffset=False)
                cmds.parentConstraint(list[i],ctrInfo["zeroGroup"],remove=True)
                select_curve = cmds.rename(ctrInfo["currentCurve"],name_main+"_Ctrl")
                zeroGroup = cmds.rename(ctrInfo["zeroGroup"],name_main+"_GrpZero")
                cmds.rename(ctrInfo["sdkGroup"],name_main+"_GrpSdk")
                cmds.rename(ctrInfo["offsetGroup"],name_main+"_GrpOffset")
                cmds.rename(ctrInfo["childrenGroup"],name_main+"_GrpChildren")
        elif multi == 3:
            father_children = ""
            for i in range(0,len(list)):
                name_main = general.correctCharacter(list[i])
                ctrInfo =makeControlSub(type,*arr)
                cmds.parentConstraint(list[i],ctrInfo["zeroGroup"],maintainOffset=False)
                cmds.parentConstraint(list[i],ctrInfo["zeroGroup"],remove=True)
                select_curve = cmds.rename(ctrInfo["currentCurve"],name_main+"_Ctrl")
                zeroGroup = cmds.rename(ctrInfo["zeroGroup"],name_main+"_GrpZero")
                cmds.rename(ctrInfo["sdkGroup"],name_main+"_GrpSdk")
                cmds.rename(ctrInfo["offsetGroup"],name_main+"_GrpOffset")
                father_children_temp = cmds.rename(ctrInfo["childrenGroup"],name_main+"_GrpChildren")
                if father_children !="":
                    cmds.parent(zeroGroup,father_children)
                    father_children = father_children_temp
                else:                
                    father_children = father_children_temp
        else:
            ctrInfo =makeControlSub(type,*arr)
            cmds.select(clear=True)
            for i in list:
                cmds.select(i,add=True)
            list = cmds.ls(selection=True)
            cmds.parentConstraint(list,ctrInfo["zeroGroup"],maintainOffset=False)
            cmds.parentConstraint(list,ctrInfo["zeroGroup"],remove=True)
            if inputText !="":
                select_curve = cmds.rename(ctrInfo["currentCurve"],inputText+"_Ctrl")
                zeroGroup = cmds.rename(ctrInfo["zeroGroup"],inputText+"_GrpZero")                
                cmds.rename(ctrInfo["sdkGroup"],inputText+"_GrpSdk")
                cmds.rename(ctrInfo["offsetGroup"],inputText+"_GrpOffset")
                cmds.rename(ctrInfo["childrenGroup"],inputText+"_GrpChildren")
            else:
                select_curve = ctrInfo["currentCurve"]     
    else:
        ctrInfo = makeControlSub(type,*arr)
        if inputText !="":
            select_curve = cmds.rename(ctrInfo["currentCurve"],inputText+"_Ctrl")
            zeroGroup = cmds.rename(ctrInfo["zeroGroup"],inputText+"_GrpZero")
            cmds.rename(ctrInfo["sdkGroup"],inputText+"_GrpSdk")
            cmds.rename(ctrInfo["offsetGroup"],inputText+"_GrpOffset")
            cmds.rename(ctrInfo["childrenGroup"],inputText+"_GrpChildren")
        else:
            select_curve = ctrInfo["currentCurve"]
            zeroGroup = ctrInfo["zeroGroup"]
                  
    cmds.textField("makeControlText",edit=True,text="")
    cmds.select(zeroGroup)
    return zeroGroup   

def makeControlSub(type,*arr):
    data_curve_shape = dataControlShape[type][1]
    curve_transform = []
    curve_shape = []
    curve_parent = ""
    
    #Tao curve
    for a in range(len(data_curve_shape)):
        curve_new = cmds.curve(d=data_curve_shape[a][1],p=data_curve_shape[a][2])
        curve_transform.append(curve_new) 
        if data_curve_shape[a][0]==2:
            pm.mel.eval('closeCurve -ch 1 -ps 0 -rpo 1 -bb 0.5 -bki 0 -p 0.1 "'+curve_new+'";')
        curve_shape.append(cmds.listRelatives(curve_new,shapes=True)[0])       
        if a == 0:
            curve_parent = curve_new
            curve_transform.remove(curve_new)
    cmds.select(clear=True)
    if len(data_curve_shape)>1:
        #gop shape
        for a in curve_shape:
            cmds.select(a,add=True)    
        cmds.select(curve_parent,add=True)
        pm.mel.eval('parent -r -s')
        
        #xoa transform
        for a in curve_transform:
            cmds.delete(a)
            
    currentCurve =  curve_parent
        
    zeroGroup = cmds.group( em=True) 
    sdkGroup = cmds.group( em=True)
    offsetGroup = cmds.group( em=True)
    childrenGroup = cmds.group( em=True)
    cmds.parent(currentCurve,offsetGroup)
    cmds.parent(childrenGroup,offsetGroup)
    cmds.parent(offsetGroup,sdkGroup)
    cmds.parent(sdkGroup,zeroGroup)
    cmds.connectAttr(currentCurve+'.translateX', childrenGroup+'.translateX')
    cmds.connectAttr(currentCurve+'.translateY', childrenGroup+'.translateY')
    cmds.connectAttr(currentCurve+'.translateZ', childrenGroup+'.translateZ')
    cmds.connectAttr(currentCurve+'.rotateX', childrenGroup+'.rotateX')
    cmds.connectAttr(currentCurve+'.rotateY', childrenGroup+'.rotateY')
    cmds.connectAttr(currentCurve+'.rotateZ', childrenGroup+'.rotateZ')
    cmds.connectAttr(currentCurve+'.scaleX', childrenGroup+'.scaleX')
    cmds.connectAttr(currentCurve+'.scaleY', childrenGroup+'.scaleY')
    cmds.connectAttr(currentCurve+'.scaleZ', childrenGroup+'.scaleZ')
    cmds.connectAttr(currentCurve+'.visibility', childrenGroup+'.visibility')   
    cmds.connectAttr(currentCurve+'.rotatePivot', childrenGroup+'.rotatePivot')
    cmds.connectAttr(currentCurve+'.scalePivot', childrenGroup+'.scalePivot') 
    return {
        "currentCurve":currentCurve,
        "zeroGroup":zeroGroup,
        "sdkGroup":sdkGroup,
        "offsetGroup":offsetGroup,
        "childrenGroup":childrenGroup
    }

def loadSystemShape(gridName,*arr):
    global dataControlShape
    myFile =  open(sourceJson,'r')
    myObject = myFile.read()
    myFile.close()
    data = json.loads(myObject)
    dataControlShape = data
    
    childrenButton = cmds.gridLayout(gridName,q=True,ca=True)
    if childrenButton:
        cmds.deleteUI(childrenButton,control=True)
    for i in data:
        cmds.symbolButton(command=partial(makeControl,i), image=sourceIcon + str(data[i][0]),parent=gridName,bgc=[0.3,0.3,0.3],hlc=[1,1,1])    
    #if admin:
        #for i in data:
            #cmds.symbolButton(command=partial(makeControl,i), image=sourceIcon + str(data[i][0]),parent=gridName,bgc=[0.3,0.3,0.3],hlc=[1,1,1])
            #cmds.popupMenu()
            #cmds.menuItem(label="Delete",command=partial(delete_systemShape,[gridName,i]))

        

def loadYourShape(gridName,*arr):
    global dataControlShape   
    username = os.environ.get("USERNAME")
    folder = "C:/Users/"+username+"/Documents/maya/scripts/nlta_folder_data"
    if not os.path.exists(folder):
        cmds.confirmDialog(title="Confirm",message="Dont have data!",button=["Yes"],defaultButton="Yes",cancelButton="Yes")  
    else:
        sourceJson = folder+"/data/control_shape.json"
        sourceIcon = folder+"/icon/"
        filePath = cmds.encodeString(sourceJson)
        myFile =  open(filePath,'r')
        myObject = myFile.read()
        myFile.close()
        data = json.loads(myObject)
        dataControlShape = data
        childrenButton = cmds.gridLayout(gridName,q=True,ca=True)
        if childrenButton:
            cmds.deleteUI(childrenButton,control=True)         
        for i in data:
            cmds.symbolButton(command=partial(makeControl,i), image=sourceIcon + str(data[i][0]),parent=gridName,bgc=[0.3,0.3,0.3],hlc=[1,1,1])
            cmds.popupMenu()
            cmds.menuItem(label="Delete",command=partial(deleteYourShape,[gridName,i]))

def delete_systemShape(data,*arr):
    print("b")

def deleteYourShape(data,*arr):
    global dataControlShape
    gridName = data[0]
    username = os.environ.get("USERNAME")
    sourceJson = "C:/Users/"+username+"/Documents/maya/scripts/nlta_folder_data/data/control_shape.json"    
    cmds.sysFile("C:/Users/"+username+"/Documents/maya/scripts/nlta_folder_data/icon/"+dataControlShape[data[1]][0],delete=True)
    del dataControlShape[data[1]]
    with open(sourceJson,"w") as json_file:
        json.dump(dataControlShape,json_file,sort_keys=False)
    loadYourShape(gridName)
             
def saveShape(gridName,*arr):
    global dataControlShape
    if len(cmds.ls(selection=True))!= 0 and len(cmds.listRelatives(cmds.ls(selection=True)[0],shapes=True))!=0:
        curveName = cmds.ls(selection=True)[0]
        curveShapeTemp = []
        for a in cmds.listRelatives(curveName,shapes=True):            
            pointData = []
            for b in cmds.ls(a+".cv[*]",flatten=True):
                pointData.append(cmds.xform(b,query=True,translation=True))              
            curveShapeTemp.append([cmds.getAttr(a+".form"),cmds.getAttr(a+".degree"),pointData])        
        
        username = os.environ.get("USERNAME")
        folderTemp = "C:/Users/"+username+"/Documents/maya/scripts/nlta_folder_data"
        if not os.path.exists(folderTemp):
            os.makedirs(folderTemp)
            os.makedirs(folderTemp+"/data")
            os.makedirs(folderTemp+"/icon")
            
        sourceJson = folderTemp+"/data/control_shape.json"
        sourceIcon = folderTemp+"/icon/"
        if not os.path.exists(sourceJson):
            dataShapeTemp = {}
        else:            
            filePath = cmds.encodeString(sourceJson)
            myFile =  open(filePath,'r')
            myObject = myFile.read()
            myFile.close()
            dataShapeTemp = json.loads(myObject)     
                 
        timeString = str(cmds.date()).replace("/","_").replace(":","_").replace(" ","_")
        nameCurve = "shape_" + timeString       
        namePic = "pic_" + timeString + ".png"
        
        sourceImage = sourceIcon + "/" +  namePic
        currentFrame = int(cmds.currentTime (q=True))
        cmds.playblast(frame=currentFrame, cf=sourceImage, fmt="image",orn=0,os=1,wh=[500,500],p=100,v=False)   
        dataShapeTemp[nameCurve] = [namePic,curveShapeTemp]       
        with open(sourceJson,"w") as json_file:
            json.dump(dataShapeTemp,json_file,sort_keys=False)
        loadYourShape(gridName)
    else:
        cmds.confirmDialog(title="Confirm",message="Please choose shape",button=["Yes"],defaultButton="Yes",cancelButton="Yes")   
    
    
    """my_documents_path = os.path.expanduser('~')
    user_path = os.path.dirname(my_documents_path)
    desktop_path = os.path.normpath(os.path.join(user_path,'Desktop'))
    currentFrame = int(cmds.currentTime (q=True))
    filename = 'snap_{}.png'.format(strftime("%m%d_%H%M%S",gmtime()))
    snap_output = os.path.join(desktop_path,filename)
    
    currentFrame = int(cmds.currentTime (q=True))
    cmds.playblast(frame=currentFrame, cf=sourceImage, fmt="image",orn=0,os=1,wh=[500,500],p=100,v=False) 
   
    
    
    # Create a new directory path
    cmds.sysFile( 'C:/temp/mayaStuff', makeDir=True )# Windows
    cmds.sysFile( '/tmp/mayaStuff', makeDir=True )# Unix
    
    # Move a scene to the new directory (we can rename it at the same time).
    cmds.sysFile( 'C:/maya/projects/default/scenes/myScene.mb', rename='C:/temp/mayaStuff/myScene.mb.trash' )# Windows
    
    
    # Rename the scene to "myScene.will.be.deleted"
    cmds.sysFile( 'C:/temp/mayaStuff/myScene.mb.trash', rename='C:/temp/mayaStuff/myScene.will.be.deleted' )# Windows
    
    # Copy a scene to the new directory
    destWindows = "C:/temp/mayaStuff/myScene.mb.trash"
    srcWindows = "C:/maya/projects/default/scenes/myScene.mb"
    cmds.sysFile( srcWindows, copy=destWindows )# Windows
    
    destUnix = "/tmp/mayaStuff/myScene.mb.trash"
    srcUnix = "maya/projects/default/scenes/myScene.mb"
    cmds.sysFile( srcUnix, copy=destUnix )# Unix
    
    # Delete the scene
    cmds.sysFile( 'C:/temp/mayaStuff/myScene.will.be.deleted', delete=True )# Windows
    cmds.sysFile( '/tmp/mayaStuff/myScene.will.be.deleted', delete=True )# Unix
"""
  
    

def active_change_size(*arr):
    cmds.floatSliderGrp("change_shape_size",e=1,value=1)
    variable["data_scale"]["current"] = 1
    sel = cmds.ls(sl=True)
    object_pivot = {}
    object_pivot_temp = {}
    cv_org_scale = []
    for a in sel:
        object_pivot[a] = cmds.xform(a,q = True, r = True,rp = True, ws = True)
        cv_org_scale =   cv_org_scale + cmds.ls(a + '.cv[:]',flatten=True)
        cmds.select(a+".cv[*]")
        cluster_name = cmds.cluster()
        object_pivot_temp[a] = cmds.xform(cluster_name,q = True, r = True,rp = True, ws = True)
        cmds.delete(cluster_name)                      
    variable["data_scale"]["pivot"] = object_pivot
    variable["data_scale"]["pivot_temp"] = object_pivot_temp
    variable["data_scale"]["cv"] = cv_org_scale
    variable["data_scale"]["center_pivot"]=0
            
def change_size(*arr):    
    if(variable["data_scale"]["center_pivot"]==0):
        for i in variable["data_scale"]["pivot_temp"]:
            cmds.xform(i, a = True,rp = variable["data_scale"]["pivot_temp"][i], ws = True)
        variable["data_scale"]["center_pivot"] = 1
    old_value = variable["data_scale"]["current"]
    input_value = cmds.floatSliderGrp("change_shape_size",q=1,value=True)
    for i in variable["data_scale"]["cv"]:
        cmds.xform(i,s = [1/old_value,1/old_value,1/old_value], os = True)  
        cmds.xform(i,s = [input_value,input_value,input_value], os = True)  
    variable["data_scale"]["current"] =  input_value
        
def change_shape_size_finish(*arr):
    cmds.select(clear=True)
    for i in variable["data_scale"]["pivot"]:
        cmds.xform(i, a = True,rp = variable["data_scale"]["pivot"][i], ws = True)
        cmds.select(i,add=True)
        
def back_default_shape(*arr):
    for i in variable["data_scale"]["cv"]:
        cmds.xform(i,s = [1/variable["data_scale"]["current"],1/variable["data_scale"]["current"],1/variable["data_scale"]["current"]], os = True)
    cmds.floatSliderGrp("change_shape_size",e=1,value=1)
    variable["data_scale"]["current"] = 1
    
def mirrorShape(*arr):
    sel = cmds.ls(sl = True)
     
    sel01 = cmds.listRelatives(sel[0])
    sel02 = cmds.listRelatives(sel[1])
     
    length =  len(sel02)
     
    for i in range(length):
        shape01 = cmds.ls(sel01[i] + ".cv[*]", fl = True)
        shape02 = cmds.ls(sel02[i] + ".cv[*]", fl = True)
        
        y=0
               
        for a in shape02:
            ListXYZ = cmds.pointPosition(shape01[y], w=True )
            cmds.move(-ListXYZ[0], ListXYZ[1], ListXYZ[2],a, ws= True)
            y = y+1

def copyShape(type,*arr):
    selection = cmds.ls(selection=True,allPaths=True)
    if len(selection)>1:
        shape_from = selection[0]
        shape_from_pivot = cmds.xform(shape_from,q = True, r = True,rp = True, ws = True)
        selection.remove(selection[0])
        shape_to = selection
        for i in shape_to:
            
            object_pivot = cmds.xform(i,q = True, r = True,rp = True, ws = True)
            
            cmds.select(i+".cv[*]")
            cluster_name = cmds.cluster()
            pivot_temp = cmds.xform(cluster_name,q = True, r = True,rp = True, ws = True)
            cmds.xform(i, a = True,rp =pivot_temp, ws = True)
            cmds.delete(cluster_name)
            
            copy = cmds.duplicate(shape_from,rr=True)[0]
            
            group_temp = cmds.group( em=True)
            contraint_temp = cmds.parentConstraint(i,group_temp ,mo=False)
            cmds.matchTransform(copy,i,pos=True)
            cmds.parent(copy,group_temp)
            if cmds.listRelatives(copy,ad=True,type="transform",path=True):
                cmds.delete(cmds.listRelatives(copy,ad=True,type="transform",path=True))
                
            try:
                cmds.makeIdentity(copy,apply=True,t=1,r=0,s=0,n=0)
            except (Exception):
                pass
                
            try:
                cmds.makeIdentity(copy,apply=True,t=0,r=1,s=0,n=0)
            except (Exception):
                pass
                
            try:
                cmds.makeIdentity(copy,apply=True,t=0,r=0,s=1,n=0)
            except (Exception):
                pass
                
            shape_new = cmds.listRelatives(copy,shapes=True,fullPath=True)
            for a in shape_new:
                array_connection = cmds.listConnections(a, plugs=True,connections=True)
                if array_connection:
                    b = 0
                    while (b < len(array_connection)):
                        cmds.disconnectAttr(array_connection[b],array_connection[b+1])
                        b+=2
            shape_old = cmds.listRelatives(i,shapes=True,fullPath=True)           
            cmds.select(clear=True)
            shape_new_array = []
            for b in shape_new:
                shape_new = cmds.rename(b,(i.split("|")[-1]+"_new_shape"))
                shape_new_array.append(shape_new)
            cmds.select(clear=True)
            cmds.select(shape_new_array,add=True)
            cmds.select(i,add=True)
            pm.mel.eval("parent -r -s")    
            for a in shape_old:
                cmds.setAttr(a+".visibility",False)       
            cmds.xform(i, a = True,rp =object_pivot, ws = True)
            cmds.delete(group_temp)            
            if type=="mirror":
                compare_axis = [shape_from_pivot[0]*object_pivot[0],shape_from_pivot[1]*object_pivot[1],shape_from_pivot[2]*object_pivot[2]] 
                if compare_axis[0]<0 and compare_axis[1]>=0 and compare_axis[2]>=0:
                    for c in cmds.ls(i+".cv[*]",flatten=True):
                        translate_current = cmds.xform(c,a=True,q=True,ws=True,t=True)
                        translate_new = [translate_current[0]*(-1),translate_current[1],translate_current[2]]
                        cmds.xform(c,a=True,ws=True,t=translate_new)
                elif  compare_axis[0]>=0 and compare_axis[1]<0 and compare_axis[2]>=0:
                    for c in cmds.ls(i+".cv[*]",flatten=True):
                        translate_current = cmds.xform(c,a=True,q=True,ws=True,t=True)
                        translate_new = [translate_current[0],translate_current[1]*(-1),translate_current[2]]
                        cmds.xform(c,a=True,ws=True,t=translate_new)
                elif compare_axis[0]>=0 and compare_axis[1]>=0 and compare_axis[2]<0:
                    for c in cmds.ls(i+".cv[*]",flatten=True):
                        translate_current = cmds.xform(c,a=True,q=True,ws=True,t=True)
                        translate_new = [translate_current[0],translate_current[1],translate_current[2]*(-1)]
                        cmds.xform(c,a=True,ws=True,t=translate_new)
                cmds.xform(i, a = True,rp =object_pivot, ws = True)
            cmds .select(i)
    else:
        cmds.confirmDialog(title="Confirm",message="Please more than two shape",button=["Yes"],defaultButton="Yes",cancelButton="Yes")

def exportColor(*arr):
    folder_temp = os.path.dirname(pm.sceneName())
    data_temp = "import pymel.core as pm\n"
    data_temp += "import maya.cmds as cmds\n\n"

    for a in cmds.ls(selection=True):
        children = cmds.listRelatives(a,children=True)
        for b in children:
            colorOverride = cmds.getAttr(a+"|"+b+".overrideEnabled")
            if colorOverride:
                data_temp += 'if cmds.objExists("'+a+"|"+b+'"):\n'
                data_temp += '    cmds.setAttr("'+a+"|"+b+'.overrideEnabled",1)\n'
                colorType = cmds.getAttr(a+"|"+b+".overrideRGBColors")
                if colorType:
                    data_temp += '    cmds.setAttr("'+a+"|"+b+'.overrideRGBColors",1)\n'
                    data_temp += '    cmds.setAttr("'+a+"|"+b+'.drawOverride.overrideColorR",'+str(cmds.getAttr(a+"|"+b+".drawOverride.overrideColorR"))+')\n'
                    data_temp += '    cmds.setAttr("'+a+"|"+b+'.drawOverride.overrideColorG",'+str(cmds.getAttr(a+"|"+b+".drawOverride.overrideColorG"))+')\n'
                    data_temp += '    cmds.setAttr("'+a+"|"+b+'.drawOverride.overrideColorB",'+str(cmds.getAttr(a+"|"+b+".drawOverride.overrideColorB"))+')\n\n'
                else:
                    data_temp += '    cmds.setAttr("'+a+"|"+b+'.overrideRGBColors",0)\n'
                    data_temp += '    cmds.setAttr("'+a+"|"+b+'.overrideColor",'+str(cmds.getAttr(a+"|"+b+".overrideColor"))+')\n\n'
          
    file_path = folder_temp+"/shapeColor.py"
    with open(file_path,"w") as txt_file:
        txt_file.write(data_temp)

def importColor(*arr):
    file = os.path.dirname(pm.sceneName())+"/"+'shapeColor.py'
    if not os.path.exists( file):
        cmds.confirmDialog(title="Confirm",message="Dont have data!",button=["Yes"],defaultButton="Yes",cancelButton="Yes")  
    else:
        exec(general.readTxtFile(file))

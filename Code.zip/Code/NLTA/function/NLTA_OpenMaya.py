import maya.api.OpenMaya as om
import math

def GetObjectByName(name,*arr):
	selectionList = om.MSelectionList()
	selectionList.add(name)
	return(selectionList)

def ListFromSelected(*arr):
	selectionList = om.MSelectionList() #instantiating selection list function set
	om.MGlobal.getActiveSelectionList(selectionList)#Get current selected object an put it into the selectionList
	return(selectionList)

def GetIterator(mylist,*arr):
	iterator = om.MItSelectionList(mylist) #instantiating selection list interator function set
	return(iterator)

def SelectedInfo(*arr):
	selected = ListFromSelected()
	interator = GetIterator(selected)
	dataReturn = {
		"order":[]
	}
	dagPath = om.MDagPath()#Store a dagPath
	myObject = om.MObject()#Store selected mesh
	nodeFn = om.MFnDagNode()#Create Function to work with meshes
	while not interator.isDone():
		interator.getDagPath(dagPath,myObject)
		nodeFn.setObject(dagPath)
		objName = nodeFn.name()
		objFullPath = dagPath.fullPathName()
		dataReturn['order'].append(objName)
		dataReturn[objName] = {
			"name":objName,
			"fullPath":objFullPath,
			"type":myObject.apiTypeStr()
		}
		interator.next()
	return(dataReturn)

def GetVertexPosition(objName,*arr):
	dataReturn = {
		"order":[]
	}
	selected = GetObjectByName(objName)
	dagPath = om.MDagPath()#object to store a dagPath
	myObject = om.MObject()#object to store seleted mesh
	nodeFn = om.MFnDagNode()
	nodeFn.setObject(dagPath)
	print(nodeFn.name())
	"""
	vertIterator = om.MItMeshVertex(dagPath,myObject)
	mySpace = om.MSpace.kWorld
	vec = om.MFloatVector()#Vector to store postion of vertex
	vectPos = om.MPoint(vec) #Point functionest that takes vector as an argument
	
	
	while not vertIterator.isDone():
		vertPos = vertIterator.position(mySpace)
		vertIndex = vertIterator.index()
		dataReturn["order"].append(vertIndex)
		dataReturn[vertIndex] = vertPos
		vertIterator.next()
	return(dataReturn)
	"""


def MatrixToList(inputMatrix,*arr):
	return [inputMatrix(i) for i in range(16)]

def ListToMatrix(inputList,*arr):
	if len(inputList)!=16:
		print("List must contain exactly 16 elements.")
	return(om.MMatrix(inputList))

def GetDagPath(objName,*arr):
	selection = om.MSelectionList()
	selection.add(objName)
	return(selection.getDagPath(0))

def GetObjMatrix(objName,*arr):
	try:
		dagPath = GetDagPath(objName)
		transformFn = om.MFnTransform(dagPath)
		localMatrix = ListToMatrix(transformFn.transformation().asMatrix())
		worldMatrix =dagPath.inclusiveMatrix()
		return({
			"local":localMatrix,
			"world":worldMatrix
		})
	except RuntimeError:
		print("Object not found.")
		return(None)

def TransformFromMatrix(inputMatrix,*arr):
	transform = om.MTransformationMatrix(inputMatrix)
	translation = transform.translation(om.MSpace.kWorld)
	euler = transform.rotation()
	scale = transform.scale(om.MSpace.kWorld)
	return({
		"tx":translation.x,
		"ty":translation.y,
		"tz":translation.z,
		"rx":om.MAngle(euler.x).asDegrees(),
		"ry":om.MAngle(euler.y).asDegrees(),
		"rz":om.MAngle(euler.z).asDegrees(),
		"sx":scale[0],
		"sy":scale[1],
		"sz":scale[2],
	})

def GetParentWorldMatrixNoScale(objName,*arr):
	dag = GetDagPath(objName)
	if dag.length()<2:
		return(om.MMatrix())
	dag.pop()#Get parent
	mat = dag.inclusiveMatrix()
	xform = om.MTransformationMatrix(mat)
	xform.setScale([1.0,1.0,1.0],om.MSpace.kWorld)
	return(xform.asMatrix())

def WorldToLocal(sourceMatrix,parentMatrixNoScale,*arr):
	invertParentMatrix = parentMatrixNoScale.inverse()
	return(sourceMatrix*invertParentMatrix)

def SetTransformFromMatrix(obj,matrix,*arr):
	transfrom = TransformFromMatrix(matrix)
	for key in transform:
		cmds.setAttr(obj+"."+key,transfrom[key])

def GetWorldTransform(objName,*arr):
	return(TransformFromMatrix(GetObjMatrix(objName)["world"]))

def GetObjectVector(objName,*arr):
	return(om.MVector([GetWorldTransform(objName)["tx"],GetWorldTransform(objName)["ty"],GetWorldTransform(objName)["tz"]]))

def GetDistance(obj1,obj2,*arr):
	obj1Vector = GetObjectVector(obj1)
	obj2Vector = GetObjectVector(obj2)
	return((obj1Vector - obj2Vector).length())

def GetDirection(obj1,obj2,*arr):
	obj1Vector = GetObjectVector(obj1)
	obj2Vector = GetObjectVector(obj2)
	return((obj2Vector - obj1Vector).normalize())

def MoveByDirection(obj,direction,value,*arr):
	objVector = GetObjectVector(obj)
	print(objVector)
	newVector =  objVector + direction * value
	return(newVector)

def CrossFromVectors(obj1,obj2,*arr):# Tìm vector vuông góc
	obj1Vector = GetObjectVector(obj1)
	obj2Vector = GetObjectVector(obj2)
	return(obj1Vector^obj2Vector)

def GetPositionScaledSpace(preferenceParent,preferenceChild,objParent,scaleValue,*arr):
	distance = GetDistance(preferenceParent,preferenceChild)
	direction = GetDirection(preferenceParent,preferenceChild)
	print(distance)
	print(direction)
	print(distance*scaleValue)
	return(MoveByDirection(objParent,direction,(distance*scaleValue)))
	#GetPositionScaledSpace("joint1","joint4","joint3",0.4225817344)

def GetAngleFromObjs(obj1,obj2,obj3,obj4,*arr):
	vector1 = GetDirection(obj2,obj1)
	vector2 = GetDirection(obj4,obj3)
	return(math.degrees(vector1.angle(vector2)))
	#print(GetAngleFromObjs("joint3","joint2","joint3","joint5"))

def CopyRotationByMatrix(obj1,obj2,*arr):
	sourceMatrix = GetObjMatrix(obj1)["world"]
	targetParentMatrix = GetParentWorldMatrixNoScale(obj2)
	localMatrix = sourceMatrix*targetParentMatrix.inverse()
	mTransform = om.MTransformationMatrix(localMatrix)
	rotation = mTransform.rotation()
	rotation = [om.MAngle(rotation.x).asDegrees(),om.MAngle(rotation.y).asDegrees(),om.MAngle(rotation.z).asDegrees()]
	return(rotation)

"""
#LẤY MATRIX CỦA SOURCE
sourceMatrix = GetObjMatrix("joint4")["world"]
#LẤY MATRIX CỦA TARGET PARENT KHI CHƯA SCALE
parentMatrixNoScale = GetParentWorldMatrixNoScale("joint2")
#CHUYỂN WORLD MATRIX CỦA SOURCE VÈ LOCAL CỦA TARGET
worldLocal = WorldToLocal(sourceMatrix,parentMatrixNoScale)
SetTransformFromMatrix("joint2",worldLocal)
"""

##### CHUA TEST #####
def rotate_object_to_vector(obj,direction_vector,aim_axis=om.MVector(1,0,0)):
	#Normalize vectors
	dir_vec = direction_vector.normal()
	aim_vec = aim_axis.normal()
	#Tinh quaternion xoay tuw aimVec -> dirVec
	quat = om.MQuaternion(aim_vec,dir_vec)
	euler = quat.asEulerRotation()
	#Convert 




	
import os
import json
import shutil
import importlib
import maya.utils
import maya.cmds as cmds
import maya.mel as mel
import pymel.core as pm
import maya.api.OpenMaya as om
import xml.dom.minidom as xd
import xml.etree.ElementTree as ET
from functools import partial
from math import pow,sqrt


import NLTA_General
importlib.reload(NLTA_General)


########### SCRIPT JOB
skinSession = {
    'mesh':None,
    'skinCluster':None,
    'joints':None,
} 
def DetectCurrentSkin():
    global skinSession
    selection = cmds.ls(selection=True)
    if selection:
        mesh = selection[0]
        skinCluster = cmds.ls(cmds.listHistory(mesh), type='skinCluster')
        if skinCluster:
            skinSession['mesh'] = mesh
            skinSession['skinCluster'] = skinCluster[0]
            skinSession['joints'] = cmds.skinCluster(skinCluster, query=True, influence=True)

def OpenSkinToolListen():
    jobs = cmds.scriptJob(listJobs=True)
    for job in jobs:
        if 'DetectCurrentSkin' in job:
            jobID = int(job.split(":")[0])
            cmds.scriptJob(kill=jobID, force=True)
    cmds.scriptJob(event=["ToolChanged",DetectCurrentSkin], protected=True)
    cmds.scriptJob(event=["SelectionChanged",DetectCurrentSkin], protected=True)
OpenSkinToolListen()

###################


def CreateUI(data):  
    def ModifyData(data):
        global titleFlags, layoutFlags, buttonFlags, inputFlags
        titleFlags = data.get('titleFlags', {})
        layoutFlags = data.get('layoutFlags', {})
        buttonFlags = data.get('buttonFlags', {})
        inputFlags = data.get('inputFlags', {})
    ModifyData(data) 

    titles, buttons, inputs = [], [], []
    parent = data['parent']

    layoutTempt = cmds.rowColumnLayout(data["module"],parent=parent)
    cmds.rowColumnLayout(layoutTempt,edit=True,**layoutFlags)
    cmds.rowColumnLayout(numberOfColumns=1)

    titles.append(cmds.textField(text="Keyframes",editable=False))

    # KEYFRAMES START
    cmds.rowColumnLayout(numberOfColumns=3)  
    cmds.rowColumnLayout( numberOfColumns=1)
    titles.append(cmds.textField(text="Local",editable=False))
    buttons.append(cmds.button( label='Rotate',command = partial(CreateKeyframe,{'space':'local','type':'rotate','inturn':True})))
    buttons.append(cmds.button( label='Translate',command = partial(CreateKeyframe,{'space':'local','type':'translate','inturn':True})))
    buttons.append(cmds.button( label='Rotate Together',command = partial(CreateKeyframe,{'space':'local','type':'rotate','inturn':False})))
    buttons.append(cmds.button( label='Translate Together',command = partial(CreateKeyframe,{'space':'local','type':'translate','inturn':False})))
    cmds.setParent("..")

    cmds.rowColumnLayout( numberOfColumns=1)
    titles.append(cmds.textField(text="Global",editable=False))
    buttons.append(cmds.button( label='Rotate',command = partial(CreateKeyframe,{'space':'world','type':'rotate','inturn':True})))
    buttons.append(cmds.button( label='Translate',command = partial(CreateKeyframe,{'space':'world','type':'translate','inturn':True})))
    buttons.append(cmds.button( label='Rotate Together',command = partial(CreateKeyframe,{'space':'world','type':'rotate','inturn':False})))
    buttons.append(cmds.button( label='Translate Together',command = partial(CreateKeyframe,{'space':'world','type':'translate','inturn':False})))
    cmds.setParent("..")

    cmds.rowColumnLayout( numberOfColumns=1)
    titles.append(cmds.textField(text="Other",editable=False))     
    buttons.append(cmds.button( label='Zoom Range',command = ZoomRangeAnim))
    buttons.append(cmds.button( label='Fit Range',command = FitRangeAnim))
    buttons.append(cmds.button( label='Delete Sence',command = deleteSenceKeyframe))
    buttons.append(cmds.button( label='Delete Attr Key',command = DeleteAttrKeyframes))    
    cmds.setParent("..")  
    cmds.setParent("..")
    # KEYFRAMES END

    titles.append(cmds.textField(text="Paint Skin Tools",editable=False))

    cmds.rowColumnLayout( numberOfColumns=7)# OPEN  
    cmds.rowColumnLayout( numberOfColumns=1)
    buttons.append(cmds.button(label="Copy Skin",c = copyJointBind,width=83))
    buttons.append(cmds.button(label="Proxy",c=singleProxy))
    buttons.append(cmds.button(label="Proxy X",c=partial(createProxy,"x")))
    buttons.append(cmds.button(label="Copy Proxy",c=copyProxy))
    buttons.append(cmds.button(label="Past Proxy",c=pastProxy))
    buttons.append(cmds.button(label="Closet Faces",c=SelectClosetFaces))
    
    cmds.setParent("..")
    cmds.rowColumnLayout( numberOfColumns=1)
    buttons.append(cmds.button(label="Miror +X ",c=partial(mirrorSkin,"x","+"),width=83))
    buttons.append(cmds.button(label="Miror -X ",c=partial(mirrorSkin,"x","-")))
    buttons.append(cmds.button(label="Middle Weight",c=setMiddleWeight))
    cmds.setParent("..")
    cmds.rowColumnLayout( numberOfColumns=1)
    buttons.append(cmds.button(label='Import Skin',c = ImportAllSkin,width=83))
    buttons.append(cmds.button(label='Import Skin Keep',c = ImportAllSkinKeepHistory,width=83))
    buttons.append(cmds.button(label='Export Skin',c = ExportAllSkin))
    buttons.append(cmds.button(label="Import Folder",c = ImportFolderSkin))
    buttons.append(cmds.button(label="Export Folder",c = ExportFolderSkin))
    buttons.append(cmds.button(label="Export Skin FBX",c = ExportSkinFbx))
    buttons.append(cmds.button(label="Export New Scene",c = ObjToNewScene))
    cmds.setParent("..")
    cmds.rowColumnLayout( numberOfColumns=1)
    buttons.append(cmds.button(label="Import BlendShape",c = ImportBlendShape))
    buttons.append(cmds.button(label="Export BlendShape",c = ExportBlendShape))
    buttons.append(cmds.button(label="Export BS to XML",c = ExportBSToXML))
    buttons.append(cmds.button(label="Export Vertexs Pos",c = ExportVertexsPosition))
    buttons.append(cmds.button(label="Import Vertexs Pos",c = ImportVertexsPosition))
    cmds.setParent("..")
    cmds.rowColumnLayout( numberOfColumns=1)
    buttons.append(cmds.button(label="Load UI", c = loadUi,width=83))
    buttons.append(cmds.button(label="Bind Skin",c = bindSkin))
    buttons.append(cmds.button(label='Bind pose',c = goToBindPose))
    buttons.append(cmds.button(label="Clear Skins",c = clearSkin))  
    buttons.append(cmds.button(label='Component',c = component))
    cmds.setParent("..")
    cmds.rowColumnLayout( numberOfColumns=1)
    buttons.append(cmds.button(label="Add Mesh jnt",c=AddMeshJoint,width=110))
    buttons.append(cmds.button(label="Add joint",c=AddJoint))
    buttons.append(cmds.button(label="Clr Unneed",c=removeUnneedJoint))
    buttons.append(cmds.button(label="Clr Game Unneed",c=removeUnneedJointGame))
    buttons.append(cmds.button(label="Del Unneed",c=DeleteUnneedJoint))    
    cmds.setParent("..")
    cmds.rowColumnLayout( numberOfColumns=1)
    buttons.append(cmds.button(label="Prune",c=pruneSmallWeights))
    buttons.append(cmds.button(label="Fix Quad",c=showQuardraw))
    buttons.append(cmds.button(label="Copy Jnt Wei",c=copyJointWeight))
    buttons.append(cmds.button(label="Past Jnt Wei",c=pastJointWeight))
    cmds.setParent("..")
    cmds.setParent("..")# END

    titles.append(cmds.textField(text="Paint Skin Tools",editable=False))

    cmds.rowColumnLayout( numberOfColumns=1)#Open

    cmds.rowColumnLayout( numberOfColumns=4)
    buttons.append(cmds.button( label="Isolate",width=105, command = IsolateObjects))
    buttons.append(cmds.button( label="Isolate Skined Mesh",width=105, command = IsolateSkinnedMesh))
    buttons.append(cmds.button( label="Unhide All",width=105, command = UnhideAll))
    cmds.setParent("..")

    cmds.rowColumnLayout( numberOfColumns=4)
    buttons.append(cmds.button( label="Create Set",width=105, command = CreateSet))
    buttons.append(cmds.button( label="Next Set",width=105, command = NextSet))
    buttons.append(cmds.button( label="Back Set",width=105, command = BackSet))
    buttons.append(cmds.button( label="Delete Sets",width=105, command = DeleteSets))
    cmds.setParent("..")

    cmds.separator(height=10, style='in')

    cmds.rowColumnLayout( numberOfColumns=3)
    cmds.rowColumnLayout( numberOfColumns=1)
    buttons.append(cmds.button( label='Unlock',c = unlock,width=105))
    buttons.append(cmds.button( label='Add unlock',c = addUnlock,width=105))
    buttons.append(cmds.button( label='Add Down',c = addUnlockDown,width=105))
    buttons.append(cmds.button( label='Add Up',c = addUnlockUp,width=105))
    buttons.append(cmds.button( label='Unlock all',c = unlockAll,width=105))  
    buttons.append(cmds.button( label='Switch Joint',c = switchJoint))
    cmds.setParent("..")
    cmds.rowColumnLayout( numberOfColumns=1)
    buttons.append(cmds.button( label="Clear Select", c = clearSelect))
    buttons.append(cmds.button( label='Isolate Vertexs',c = IsolateEffectVertex))
    buttons.append(cmds.button( label='Select Mesh + Jnts',c = SelectMeshAndJointsEffect))
    cmds.setParent("..")

    cmds.rowColumnLayout( numberOfColumns=1)
    cmds.rowColumnLayout( numberOfColumns=5)
    buttons.append(cmds.button(label="Light", c = partial(smooth,"gaussian"),width=84))
    buttons.append(cmds.button(label="Heavy", c = partial(smooth,"solid"),width=84))
    buttons.append(cmds.button(label="Flood", c = flood,width=84))
    buttons.append(cmds.button(label='Pick value',c = pickValue,width=84))
    buttons.append(cmds.button(label="Copy Weight",c = CopyWeight,width=84))
    cmds.setParent("..")
    cmds.rowColumnLayout( numberOfColumns=7)
    buttons.append(cmds.button(label="0",width=60, c = partial(replaceWeight,0)))
    buttons.append(cmds.button(label="0.125",width=60, c = partial(replaceWeight,0.125)))
    buttons.append(cmds.button(label="0.25",width=60, c = partial(replaceWeight,0.25)))
    buttons.append(cmds.button(label="0.5",width=60, c = partial(replaceWeight,0.5)))
    buttons.append(cmds.button(label="0.75",width=60, c = partial(replaceWeight,0.75)))
    buttons.append(cmds.button(label="0.875",width=60, c = partial(replaceWeight,0.875)))
    buttons.append(cmds.button(label="1",width=60, c = partial(replaceWeight,1)))
    cmds.setParent("..")
    cmds.rowColumnLayout( numberOfColumns=10)
    buttons.append(cmds.button(label="-0.03",width=42, c = partial(addWeight,-0.03)))
    buttons.append(cmds.button(label="-0.02",width=42, c = partial(addWeight,-0.02)))
    buttons.append(cmds.button(label="-0.01",width=42, c = partial(addWeight,-0.01)))
    buttons.append(cmds.button(label="-0.005",width=42, c = partial(addWeight,-0.005)))
    buttons.append(cmds.button(label="-0.0025",width=42, c = partial(addWeight,-0.0025)))
    buttons.append(cmds.button(label="0.0025",width=42, c = partial(addWeight,0.0025)))
    buttons.append(cmds.button(label="0.005",width=42, c = partial(addWeight,0.005)))
    buttons.append(cmds.button(label="0.01",width=42, c = partial(addWeight,0.01)))
    buttons.append(cmds.button(label="0.02",width=42, c = partial(addWeight,0.02)))
    buttons.append(cmds.button(label="0.03",width=42, c = partial(addWeight,0.03)))
    cmds.setParent("..")
    cmds.setParent("..")

    cmds.setParent("..") 


    cmds.setParent("..")#End

    cmds.rowColumnLayout(numberOfColumns=2)#OPEN
    cmds.rowColumnLayout(nc=1)
    titles.append(cmds.textField(text="Max Influent",editable=False))
    inputs.append(cmds.intField("maxInfluent",value=4,width=250))
    cmds.rowColumnLayout(nc=2)
    buttons.append(cmds.button(label="Fix",command = partial(fixMaxInfluent,cmds.intField("maxInfluent",value=True,query=True)),width=125))
    buttons.append(cmds.button(label="Check",command = checkMaxInfluent,width=125))
    cmds.setParent("..")
    cmds.setParent("..")
    cmds.rowColumnLayout(nc=1)
    titles.append(cmds.textField(text="Maintain Off",editable=False))
    inputs.append(cmds.intField("maintainOff",value=4,width=250))
    buttons.append(cmds.button(label="set",command = setMaintainOff))
    cmds.setParent("..")
    cmds.setParent("..")# END


    cmds.setParent("..")
    cmds.setParent("..")

    for title in titles:
        cmds.textField(title,edit=True,**titleFlags)
    for button in buttons:
        cmds.button(button,edit=True,**buttonFlags)
    for input_ in inputs:
        if cmds.objectTypeUI(input_) == 'textField':
            cmds.textField(input_,edit=True,**inputFlags)
        if cmds.objectTypeUI(input_) == 'intField':
            cmds.intField(input_,edit=True,**inputFlags)

def ImportBlendShape(*arr):
    folder_temp = os.path.dirname(pm.sceneName())
    if not folder_temp:
        folder_temp = pm.mel.eval("SaveSceneAs;")
    folder_temp = os.path.dirname(pm.sceneName())
    jsonPath = folder_temp+'/BlendShapeData.json'
    data = NLTA_General.readJsonFile(jsonPath)
    if data:
        for entry in data:
            base_mesh = entry["mesh"]
            targets = entry["targets"]
            target_meshes = [t["target_mesh"] for t in targets]
            bs_node = cmds.blendShape(
                target_meshes,
                base_mesh,
                name=entry["BS"]
            )[0]
            for i, t in enumerate(targets):
                alias_list = cmds.aliasAttr(bs_node, q=True) or []
                alias_dict = {alias_list[i+1]: alias_list[i] for i in range(0, len(alias_list), 2)}
                plug_name = f"weight[{i}]"
                if plug_name in alias_dict:
                    cmds.aliasAttr(bs_node+'.'+alias_dict[plug_name], remove=True)
                cmds.aliasAttr(t["name"], f"{bs_node}.w[{i}]")
                cmds.setAttr(f"{bs_node}.{t['name']}", t["value"])

def DeleteAttrKeyframes(*arr):
    sel = cmds.ls(selection=True)
    if sel:
        cmds.cutKey(sel, clear=True)

def GetBSSingle(mesh):
    history = cmds.listHistory(mesh)
    BS = cmds.ls(history, type="blendShape")
    if not BS:
        return
    BSNode = BS[0]
    attrs = cmds.listAttr(BSNode + '.w', m=True) or []
    alias_list = cmds.aliasAttr(BSNode, q=True) or []
    alias_dict = {}
    for i in range(0, len(alias_list), 2):
        name = alias_list[i]
        plug = alias_list[i+1]  # ví dụ: "weight[0]"
        index = int(plug.split("[")[1].split("]")[0])
        alias_dict[name] = index    
    data = {
        "mesh": mesh,
        "BS": BSNode,
        "targets": []
    }

    for attr in attrs:
        index = alias_dict.get(attr)
        if index is None:
            continue
        targetMeshes = cmds.blendShape(BSNode, q=True, target=True) or []
        if index >= len(targetMeshes):
            continue    
        targetMesh = targetMeshes[index]
        value = cmds.getAttr(f"{BSNode}.{attr}")
        data["targets"].append({
            "name": attr,
            "target_mesh": targetMesh,
            "value": value
        })
    return(data)

def GetAllBSData():    
    data = []    
    meshs = list(set(cmds.listRelatives(cmds.ls(type="mesh"),parent=True)))
    for mesh in meshs:
        if GetBSSingle(mesh) != None:
            data.append(GetBSSingle(mesh))
    return(data)


def ExportBlendShape(*arr):
    folder_temp = os.path.dirname(pm.sceneName())
    if not folder_temp:
        folder_temp = pm.mel.eval("SaveSceneAs;")
    folder_temp = os.path.dirname(pm.sceneName())
    if folder_temp:
        jsonPath = folder_temp+'/BlendShapeData.json'
        BSData = GetAllBSData()
        NLTA_General.writeJsonFile(jsonPath,BSData)
        cmds.warning("Done!!!")

def ExportBSToXML(*arr):
    folder_temp = os.path.dirname(pm.sceneName())
    if not folder_temp:
        folder_temp = pm.mel.eval("SaveSceneAs;")
    folder_temp = os.path.dirname(pm.sceneName())
    if folder_temp:
        jsonPath = folder_temp+'/BlendShapeData.xml'
        BSData = GetAllBSData()
        root = ET.Element("Meshes")
        for item in BSData:
            mesh_elem = ET.SubElement(root, "Mesh", name=item.get("mesh", ""), BS=item.get("BS", ""))
            for target in item.get("targets", []):
                ET.SubElement(
                    mesh_elem,
                    "Target",
                    name=target.get("name", ""),
                    target_mesh=target.get("target_mesh", ""),
                    value=str(target.get("value", "0.0"))
                )
        tree = ET.ElementTree(root)
        tree.write(jsonPath, encoding="utf-8", xml_declaration=True)
        print(f"XML file saved to: {jsonPath}")

def GetMeshDagPath(mesh):
    if cmds.nodeType(mesh) == 'transform':
        shapes = cmds.listRelatives(mesh, shapes=True, ni=True) or []
        if not shapes:
            raise RuntimeError("Transform '{}' không có shape.".format(mesh))
        mesh_shape = shapes[0]
    else:
        mesh_shape = mesh
    sel = om.MSelectionList()
    sel.add(mesh_shape)
    dag = sel.getDagPath(0)
    dag.extendToShape()
    return dag

def ExportVertexsPositionSingle(mesh, jsonPath, space='world'):
    dag = GetMeshDagPath(mesh)
    fn_mesh = om.MFnMesh(dag)

    space_enum = om.MSpace.kWorld if space == 'world' else om.MSpace.kObject
    pts = fn_mesh.getPoints(space_enum)
    positions = [[p.x, p.y, p.z] for p in pts]
    vcount = fn_mesh.numVertices
    folder = os.path.dirname(jsonPath)
    if folder and not os.path.isdir(folder):
        os.makedirs(folder)
    data = {
        "mesh": mesh,
        "space": space,
        "vertexCount": vcount,
        "positions": positions
    }
    with open(jsonPath, "w") as f:
        json.dump(data, f, indent=2)

def ExportVertexsPosition(*arr):
    folder_temp = os.path.dirname(pm.sceneName())
    if not folder_temp:
        folder_temp = pm.mel.eval("SaveSceneAs;")
    folderTemp = os.path.dirname(pm.sceneName())
    if folderTemp:
        exportPath = folderTemp+"/VertexsPosition/"
        objs = cmds.ls(selection=True)
        for obj in objs:
            ExportVertexsPositionSingle(obj,exportPath+obj+'.json')

    print("Export Vertexs Done!~")

def ImportVertexsPositionSingle(json_path, target_mesh=None, space_override=None):
    with open(json_path, "r") as f:
        data = json.load(f)

    mesh = target_mesh or data.get("mesh")
    if not mesh:
        raise RuntimeError("JSON không chứa tên mesh và bạn chưa truyền 'target_mesh'.")
    if cmds.objExists(mesh):
        dag = GetMeshDagPath(mesh)
        fn_mesh = om.MFnMesh(dag)

        positions = data.get("positions")
        vcount_json = data.get("vertexCount")
        vcount_scene = fn_mesh.numVertices

        if vcount_json != vcount_scene:
            raise RuntimeError("Vertex count không khớp: file={} vs scene={}".format(vcount_json, vcount_scene))
        if not positions or len(positions) != vcount_scene:
            raise RuntimeError("Dữ liệu 'positions' trong JSON không hợp lệ.")

        # Chọn space cho import
        file_space = data.get("space", "world")
        space = space_override or file_space
        space_enum = om.MSpace.kWorld if space == 'world' else om.MSpace.kObject

        # Tạo MPointArray và set điểm một lần
        mpoints = om.MPointArray()
        for x, y, z in positions:
            mpoints.append(om.MPoint(x, y, z))

        # Ghi điểm vào mesh
        fn_mesh.setPoints(mpoints, space_enum)

        print(">> Import xong vertex positions vào '{}' ({} space) từ {}".format(mesh, space, json_path))
        return mesh

def  ImportVertexsPosition(*arr):
    objs = cmds.ls(selection=True)
    folder = os.path.dirname(pm.sceneName())+"/"+'VertexsPosition'
    files  = NLTA_General.GetFiles(folder,'json')
    for obj in objs:
        if obj in files:
            filePath = folder+"/"+obj+".json"
            ImportVertexsPositionSingle(filePath)




#######
session = {}

### KEYFRAMES
def CreateKeyframe(keyInput,*arr):
    originTime = cmds.currentTime(query=True)
    currentTool = cmds.currentCtx()
    if currentTool == 'artAttrSkinContext':
        objs = [cmds.connectionInfo(skinSession['skinCluster']+".paintTrans",sourceFromDestination=True).split(".")[0]]
    else:
        objs = cmds.ls(selection=True)
    if objs:
        jointAddKey = []        
        keySpace = keyInput['space']
        keyType = keyInput['type']
        keyInturn = keyInput['inturn']
        cmds.select(clear=True)       
        for obj in objs:
            jointSpace = cmds.joint()
            cmds.addAttr(jointSpace,longName="NLTA_worldKeyframe",dt='string')
            cmds.setAttr(jointSpace+'.overrideEnabled',1)
            cmds.setAttr(jointSpace+'.overrideVisibility',0)
            cmds.setAttr(jointSpace+'.hiddenInOutliner',True)

            jointChild = cmds.joint()
            if not cmds.attributeQuery("NLTA_SourceJoint",node=obj, exists=True):
              cmds.addAttr(obj,longName="NLTA_SourceJoint",dt='string')
            cmds.setAttr(obj+".NLTA_SourceJoint",jointChild, type="string")
      
            jointAddKey.append(jointChild)
            if keySpace == 'world':
                cmds.matchTransform(jointSpace,obj,pos=True)
            elif keySpace == 'local':
                cmds.matchTransform(jointSpace,obj,pos=True,rot=True)
            constraint = cmds.parentConstraint(jointChild,obj,mo=True)
            cmds.setAttr(jointSpace+'.visibility',0)
            if len(objs) == 1:
                cmds.select(objs[0])
            else:
                cmds.select(jointChild)
        
        if keyType == 'rotate':
            keyData = {
                "rx":[0,-90,0,90,0],
                "ry":[0,-90,0,90,0],
                "rz":[0,-90,0,90,0],
            }
        elif keyType == 'translate':
            keyData = {
                    "tx":[0,-3000,0,3000,0],
                    "ty":[0,-3000,0,3000,0],
                    "tz":[0,-3000,0,3000,0],
            }
        currentTime = originTime
        for jointChild in jointAddKey:
            if keyInput['inturn'] == False:
                currentTime = originTime
            for key in keyData:
                keyArray = keyData[key]
                for keyValue in keyArray:
                    currentTime += 30
                    cmds.currentTime(currentTime)              
                    cmds.setKeyframe(jointChild, attribute=key,value=keyValue)
        cmds.select(jointAddKey)
        NLTA_General.FitRangeAnim()
        if currentTool == 'artAttrSkinContext':
            cmds.select(skinSession['mesh'])
        else:
            cmds.select(objs)
    cmds.currentTime(originTime)

def FitRangeAnim(*arr):    
    currentTool = cmds.currentCtx()
    if currentTool == 'artAttrSkinContext':
        objs = [cmds.connectionInfo(skinSession['skinCluster']+".paintTrans",sourceFromDestination=True).split(".")[0]]
    else:
        objs = cmds.ls(selection=True)
    sourceJnts = []
    for obj in objs:
        if cmds.attributeQuery("NLTA_SourceJoint",node=obj, exists=True):
            sourceJnts.append(cmds.getAttr(obj+'.NLTA_SourceJoint'))   
    cmds.select(sourceJnts)
    NLTA_General.FitRangeAnim()
    if currentTool == 'artAttrSkinContext':
        cmds.select(skinSession['mesh'])
        pm.mel.eval('ArtPaintSkinWeightsTool;')
    else:
        cmds.select(objs)
    
def ZoomRangeAnim(*arr):
    currentTool = cmds.currentCtx()
    if currentTool == 'artAttrSkinContext':
        objs = [cmds.connectionInfo(skinSession['skinCluster']+".paintTrans",sourceFromDestination=True).split(".")[0]]
    else:
        objs = cmds.ls(selection=True)

    time = cmds.currentTime(query=True)
    sourceJnts = []  
    for obj in objs:
        if cmds.attributeQuery("NLTA_SourceJoint",node=obj, exists=True):
            sourceJnts.append(cmds.getAttr(obj+'.NLTA_SourceJoint')) 
    if sourceJnts:
        cmds.select(sourceJnts)
        keyTimes = NLTA_General.GetAllKeytime()
        if not keyTimes:
            return()
        keyTimes = sorted(set(keyTimes))
        prevKey = max([k for k in keyTimes if k < time],default=None)
        nextKey = min([k for k in keyTimes if k > time],default=None)
        cmds.playbackOptions(min=str(prevKey), max=str(nextKey))
    if currentTool == 'artAttrSkinContext':
        cmds.select(skinSession['mesh'])
        pm.mel.eval('ArtPaintSkinWeightsTool;')
    else:
        cmds.select(objs)

def deleteSenceKeyframe(*attr):
    objs = cmds.ls()
    for i in objs:
        try:
            if cmds.attributeQuery("NLTA_SourceJoint",node=i,ex=True):
                cmds.deleteAttr(i+'.NLTA_SourceJoint')
        except:pass
        try:
            if cmds.attributeQuery("NLTA_worldKeyframe",node=i,ex=True):
                cmds.delete(i)
        except:pass
    cmds.currentTime(0)

# CLOSE KEYFRAMES
          


def getSkinData(mesh,*arr):
    skinCluster = pm.mel.eval('findRelatedSkinCluster '+mesh)
    joints = cmds.skinCluster(skinCluster,query=True,inf=True)
    jointActive = cmds.connectionInfo(skinCluster+".paintTrans",sourceFromDestination=True).split(".")[0]
    return({
        "skinCluster": skinCluster,
        "joints":joints,
        "jointActive":jointActive
    })

def clearMesh(*arr):
    for mesh in cmds.ls(selection=True):
        cmds.select(mesh)
        pm.mel.eval('DeleteHistory;')
        """
        for attr in ["tx","ty","tz","rx","ry","rz","sx","sy","sz"]:
            cmds.setAttr(mesh+"."+attr,lock=False)
        """
        cmds.setAttr(mesh+".translate",e=True,lock=0)
        cmds.setAttr(mesh+".rotate",e=True,lock=0)
        cmds.setAttr(mesh+".scale",e=True,lock=0)
        cmds.setAttr(mesh+".visibility",e=True,lock=0)
        pm.mel.eval('makeIdentity -apply true -t 1 -r 1 -s 1 -n 0 -pn 1;')
        pm.mel.eval('ResetTransformations;')

def getDistance(objA,objB):
    gObjA = cmds.xform(objA,q=True,t=True,ws=True)
    gObjB = cmds.xform(objB,q=True,t=True,ws=True)
    return(sqrt(pow(gObjA[0]-gObjB[0],2)+pow(gObjA[1]-gObjB[1],2)+pow(gObjA[2]-gObjB[2],2)))

def setMiddleWeight(*arr):
    cmds.currentTime(0)
    deleteSenceKeyframe()
    selection = cmds.ls(selection=True)
    middleJoint = selection[0]
    vertexArray = []
    jointArray = []
    for a in selection:
        if cmds.objectType(a) == "joint":
            if a != middleJoint:
                jointArray.append(a)
        elif ".vtx[" in a :
            vertexArray.append(a)
    mesh = vertexArray[0].split(".")[0]
    skinCluster = pm.mel.eval('findRelatedSkinCluster '+mesh)
    if skinCluster:
        jointBindArray = cmds.skinCluster(skinCluster,query=True,inf=True)
        for jointBind in jointBindArray:
            cmds.setAttr(jointBind+".liw",0)
        for ver in vertexArray:
            cmds.skinPercent(skinCluster,ver, transformValue=[middleJoint,1])
        for jointBind in jointBindArray:
            cmds.setAttr(jointBind+".liw",1)
    averageWeight = float(1.0/(len(jointArray)+1))
    for joint in jointArray:
        cmds.setAttr(joint+".liw",0)
        cmds.setAttr(middleJoint+".liw",0)
        for ver in vertexArray:
            cmds.skinPercent(skinCluster,ver, transformValue=[joint,averageWeight])
        cmds.setAttr(joint+".liw",1)
        cmds.setAttr(middleJoint+".liw",1)
    for joint in jointArray:
        cmds.setAttr(joint+".liw",0)
    cmds.setAttr(middleJoint+".liw",0)

    cmds.select(jointArray)
    CreateKeyframe({'space':'local','type':'rotate','inturn':False})
    component()
    cmds.select(vertexArray)

def bindSkin(*arr):
    skinCluster = pm.mel.eval('newSkinCluster "-toSelectedBones -bindMethod 0  -normalizeWeights 1 -weightDistribution 0 -mi 1  -dr 4 -rui false  , multipleBindPose, 0";')
    return(skinCluster[0])

def copyJointWeight(*arr):
    global session
    vertexArray = []
    vertexData = {}
    joint = ""
    meshTransform = ""
    selection =  cmds.ls(selection=True,flatten=True)
    for a in selection:
        if cmds.objectType(a) ==  "joint":
            joint = a
        elif "vtx[" in a:
            if meshTransform == "":
                meshTransform = a.split(".")[0]
            vertexArray.append(a)
    skinCluster = pm.mel.eval('findRelatedSkinCluster '+meshTransform)
    for a in vertexArray:
        vertexData[a] = cmds.skinPercent(skinCluster,a,query=True,transform=joint)
    session["vertexWeight"]  = vertexData
    session["mesh"] = meshTransform
    session["skinCluster"] = skinCluster


def pastJointWeight(*arr):
    joint = cmds.ls(selection=True)[0]
    for a in session["vertexWeight"]:
        vertexName = a
        vertexValue = session["vertexWeight"][a]
        cmds.skinPercent(session["skinCluster"],a, transformValue=[joint, vertexValue])

def copyProxy(*arr):
    global session
    selection = cmds.ls(selection=True)
    if cmds.objectType(selection[0]) == "mesh":
        pm.mel.eval('ConvertSelectionToVertices;')
        vertex = cmds.ls(selection=True,flatten=True)
        parentName = selection[0].split(".")[0]
        cmds.select(parentName)
    elif cmds.objectType(selection[0]) == "transform":
        vertex = cmds.ls(selection[0]+".vtx[*]",flatten=True)
        parentName = selection[0]
    session["vertex"] = vertex
    session["mesh"] = parentName

def pastProxy(*arr):
    selection = cmds.ls(selection=True)
    if cmds.objectType(selection[0]) == "mesh":
        pm.mel.eval('ConvertSelectionToVertices;')
        vertex = cmds.ls(selection=True)
        parentName = selection[0].split(".")[0]
        cmds.select(session["vertex"])
        cmds.select(vertex,add=True)
        pm.mel.eval('copySkinWeights  -noMirror -surfaceAssociation closestPoint -influenceAssociation oneToOne -influenceAssociation closestJoint -normalize;')
    elif cmds.objectType(selection[0]) == "transform":
        for aSelect in selection:
            vertex = cmds.ls(aSelect+".vtx[*]")            
            cmds.select(clear=True)
            cmds.select(session["vertex"])
            cmds.select(vertex,add=True)
            pm.mel.eval('copySkinWeights  -noMirror -surfaceAssociation closestPoint -influenceAssociation oneToOne -influenceAssociation closestJoint -normalize;')
    cmds.select(selection)
    cmds.warning("Done!!!")

def SelectClosetFaces(*arr):
    def get_mesh_fn(mesh):
        sel = om.MSelectionList()
        sel.add(mesh)
        dag = sel.getDagPath(0)
        return om.MFnMesh(dag)

    def get_face_centroids(mesh):
        fn = get_mesh_fn(mesh)
        centroids = {}
        for i in range(fn.numPolygons):
            points = fn.getPolygonVertices(i)
            verts = [om.MVector(fn.getPoint(v, om.MSpace.kWorld)) for v in points]
            c = sum(verts, om.MVector()) / len(verts)
            centroids[i] = c
        return centroids

    def FindMatchingFaces(source,target, tolerance=0.001):
        centA = get_face_centroids(source)
        centB = get_face_centroids(target)
        matches = []
        for fA, cA in centA.items():
            for fB, cB in centB.items():
                if (cA - cB).length() < tolerance:
                    matches.append(fB)
        return matches
    objs = cmds.ls(selection=True)
    source = objs[0]
    targets = objs[1:]
    faces = []
    for target in targets:
        facesID = FindMatchingFaces(source,target)
        for faceID in facesID:
            faces.append(f"{target}.f[{faceID}]")
    cmds.select(faces)    


def loadUi(*arr):   
    pm.mel.eval('artAttrSkinPaintCtx -e -minvalue -1 -useColorRamp 1 -colorRamp "1,0,0,1,1,1,0.5,0,0.8,1,1,0.7,0,0.6,1,0,.5,0,0.4,1,0,0,1,0,1"  -rampMaxColor .57 .57 .57  artAttrSkinContext;')
    pm.mel.eval('setObjectPickMask "Joint" false;')

def mirrorSkin(axis,neg_pos,*arr):
    selection = cmds.ls(selection=True)
    if ".vtx[" in selection[0]:
        if axis == "x":
            pm.mel.eval("reflectionSetMode objectx;")
        else:
            pm.mel.eval("reflectionSetMode objectx;")        
        pm.mel.eval("reflectionSetMode none;")

    if axis == "x":
        face = "YZ"
    if neg_pos == "-":
        pm.mel.eval("copySkinWeights -mirrorMode "+face+" -mirrorInverse -surfaceAssociation closestPoint -influenceAssociation closestJoint -influenceAssociation oneToOne;")
    elif neg_pos == "+":
        pm.mel.eval("copySkinWeights -mirrorMode "+face+" -surfaceAssociation closestPoint -influenceAssociation closestJoint -influenceAssociation oneToOne;")

def copyJointBind(*arr):
    currentSelection = cmds.ls(selection=True)
    sourceMesh = cmds.ls(selection=True)[0]
    targetMesh = cmds.ls(selection=True)[1:]
    skinCluster = pm.mel.eval('findRelatedSkinCluster '+sourceMesh)
    bindJoint = cmds.skinCluster(skinCluster,query=True,inf=True)
    for mesh in targetMesh:
        cmds.select(clear=True)
        cmds.select(mesh)
        pm.mel.eval('DeleteHistory;')
        for attr in ["tx","ty","tz","rx","ry","rz","sx","sy","sz"]:
            cmds.setAttr(mesh+"."+attr,lock=False)
        pm.mel.eval('makeIdentity -apply true -t 1 -r 1 -s 1 -n 0 -pn 1;')
        pm.mel.eval('ResetTransformations;')
        cmds.select(bindJoint,add=True)
        bindSkin()
        cmds.select(clear=True)
        cmds.select(sourceMesh)
        cmds.select(mesh,add=True)
        pm.mel.eval('copySkinWeights  -noMirror -surfaceAssociation closestPoint -influenceAssociation oneToOne -influenceAssociation closestJoint -normalize;')
        cmds.select(currentSelection)
        
def singleProxy(*arr):
    selection = cmds.ls(selection=True)
    if cmds.objectType(selection[0]) == "mesh":
        pm.mel.eval('ConvertSelectionToFaces;')
        face = cmds.ls(selection=True)
        meshTransform = selection[0].split(".")[0]
        skinCluster = pm.mel.eval('findRelatedSkinCluster '+meshTransform)
        if skinCluster:
            joint = cmds.skinCluster(skinCluster,query=True,inf=True)

        meshNew =  cmds.ls(cmds.duplicate(meshTransform)[0],uuid=True)[0]
        meshNew =  cmds.ls(meshNew,ap=True)[0]
        faceNew = cmds.ls(meshNew+".f[*]")
        arrayTemp = []
        for a in face:
            faceName = a.replace(meshTransform,meshNew)
            arrayTemp.append(faceName)

        cmds.select(faceNew)
        cmds.select(arrayTemp,deselect=True)
        cmds.delete()
        cmds.delete(meshNew,constructionHistory=True)
        if skinCluster:
            cmds.select(joint)
            cmds.select(meshNew,add=True)
            bindSkin()
            cmds.select(meshTransform)
            cmds.select(meshNew,add=True)
            pm.mel.eval('copySkinWeights  -noMirror -surfaceAssociation closestPoint -influenceAssociation oneToOne -influenceAssociation closestJoint -normalize;')
            cmds.select(meshNew)            
        else:
            cmds.select(meshNew)
        copyProxy()
        cmds.warning("Done!!!")

def createProxy(axis,*arr):
    selection = cmds.ls(selection=True)
    if cmds.objectType(selection[0]) == "mesh":
        pm.mel.eval('ConvertSelectionToFaces;')
        face = cmds.ls(selection=True)
        meshTransform = selection[0].split(".")[0]
        skinCluster = pm.mel.eval('findRelatedSkinCluster '+meshTransform)
        if skinCluster:
            joint = cmds.skinCluster(skinCluster,query=True,inf=True)

        meshNew =  cmds.ls(cmds.duplicate(meshTransform)[0],uuid=True)[0]
        meshNew =  cmds.ls(meshNew,ap=True)[0]
        faceNew = cmds.ls(meshNew+".f[*]")
        arrayTemp = []
        for a in face:
            faceName = a.replace(meshTransform,meshNew)
            arrayTemp.append(faceName)

        cluster = cmds.cluster(arrayTemp)
        axisNegPos = NLTA_General.checkNegPosAxis(cluster,axis)
        if axisNegPos == "-":
            direction = str(0)
        else:
            direction = str(1)
        cmds.delete(cluster)

        axisArray = ["x","y","z"]
        axisIndex = str(axisArray.index(axis))

        cmds.select(faceNew)
        cmds.select(arrayTemp,deselect=True)
        cmds.delete()

        pm.mel.eval('polyMirrorFace  -cutMesh 1 -axis '+axisIndex+' -axisDirection '+direction+' -mergeMode 1 -mergeThresholdType 0 '+meshNew+';')#-mergeThreshold 0.001 
        cmds.delete(meshNew,constructionHistory=True)
        cmds.select(joint)
        cmds.select(meshNew,add=True)
        bindSkin()
        cmds.select(meshTransform)
        cmds.select(meshNew,add=True)
        pm.mel.eval('copySkinWeights  -noMirror -surfaceAssociation closestPoint -influenceAssociation oneToOne -influenceAssociation closestJoint -normalize;')
        cmds.select(meshNew)
        copyProxy()
        cmds.warning("Done!!!")

def goToBindPose(*arr): 
    pm.mel.eval("GoToBindPose;")

def component(*arr):    
    pm.mel.eval("ComponentEditor;")
    
def pruneSmallWeights(*arr):    
    pm.mel.eval("artSkinLockInf artAttrSkinPaintCtx 0;")
    pm.mel.eval("artSkinInvLockInf artAttrSkinPaintCtx 0;")
    pm.mel.eval("PruneSmallWeights;")
    pm.mel.eval("artSkinLockInf artAttrSkinPaintCtx 0;")
    pm.mel.eval("artSkinInvLockInf artAttrSkinPaintCtx 1;")        
    
def replaceWeight(value,*arr):
    pm.mel.eval("artAttrSkinPaintModePaintSelect 1 artAttrSkinPaintCtx;")
    pm.mel.eval("artAttrPaintOperation artAttrSkinPaintCtx Replace;")
    pm.mel.eval("artSkinSetSelectionValue "+str(value)+" false artAttrSkinPaintCtx artAttrSkin;")
    
def addWeight(value,*arr):
    pm.mel.eval("artAttrSkinPaintModePaintSelect 1 artAttrSkinPaintCtx;")
    pm.mel.eval("artAttrPaintOperation artAttrSkinPaintCtx Add;")
    pm.mel.eval("artSkinSetSelectionValue "+str(value)+" false artAttrSkinPaintCtx artAttrSkin;")

def smooth(value,*arr):
    pm.mel.eval("artAttrSkinPaintModePaintSelect 1 artAttrSkinPaintCtx;")
    pm.mel.eval("artAttrPaintOperation artAttrSkinPaintCtx Smooth;")
    pm.mel.eval("artUpdateStampProfile "+value+" artAttrSkinPaintCtx;")

def unlockAll(*arr):
    pm.mel.eval("artSkinInvLockInf artAttrSkinPaintCtx 0;")
    pm.mel.eval("artSkinLockInf artAttrSkinPaintCtx 0;")

def lockAll(*arr):
    pm.mel.eval("artSkinInvLockInf artAttrSkinPaintCtx 1;")
    pm.mel.eval("artSkinLockInf artAttrSkinPaintCtx 1;")

def singleUnlock(objs,*arr):
    for joint in skinSession['joints']:
        cmds.setAttr(joint+'.liw',1)
    for obj in objs:
        cmds.setAttr(obj+'.liw',0)

def unlock(*arr):
    objs = cmds.ls(selection=True,type='joint')
    if objs:
        result = all(obj in skinSession['joints'] for obj in objs)
        if result:
            cmds.select(skinSession['mesh'])
            singleUnlock(objs)
            pm.mel.eval('ArtPaintSkinWeightsTool;')
            pm.mel.eval('setSmoothSkinInfluence '+objs[0]+';')
    else:
        pm.mel.eval("artSkinLockInf artAttrSkinPaintCtx 0;")
        pm.mel.eval("artSkinInvLockInf artAttrSkinPaintCtx 1;")
      
def addUnlock(*arr):
    pm.mel.eval("artSkinLockInf artAttrSkinPaintCtx 0;")    

def addUnlockUp(*arr):
    jointActive = cmds.connectionInfo(skinSession['skinCluster']+".paintTrans",sourceFromDestination=True).split(".")[0]
    parentJoint =  cmds.listRelatives(jointActive,parent=True)
    if parentJoint:
        parentJoint = parentJoint[0]
        singleUnlock([jointActive,parentJoint])
        pm.mel.eval('ArtPaintSkinWeightsTool;')
        pm.mel.eval('setSmoothSkinInfluence '+parentJoint+';')

def addUnlockDown(*arr):
    jointActive = cmds.connectionInfo(skinSession['skinCluster']+".paintTrans",sourceFromDestination=True).split(".")[0]
    childrenJoint =  cmds.listRelatives(jointActive,children=True)
    if childrenJoint:
        childJoint = childrenJoint[0]
        singleUnlock([jointActive,childJoint])
        pm.mel.eval('ArtPaintSkinWeightsTool;')
        pm.mel.eval('setSmoothSkinInfluence '+childJoint+';')

def pickValue(*arr):
    pm.mel.eval("artAttrPaintOperation artAttrSkinPaintCtx Replace;")
    pm.mel.eval("artAttrSkinPaintCtx -e -pickValue `currentCtx`;")

def flood(*arr):
    pm.mel.eval("artAttrSkinPaintModePaintSelect 1 artAttrSkinPaintCtx;")
    pm.mel.eval('artAttrSkinPaintCtx -e -clear `currentCtx`;')

def clearSelect(*arr):
    pm.mel.eval("artAttrSkinSetPaintMode 0;")
    pm.mel.eval("select -cl  ;")
    pm.mel.eval("maintainActiveChangeSelectMode meshBody 0;")
    pm.mel.eval("artAttrSkinSetPaintMode 1;")

def switchJoint(*arr):
    objName = cmds.ls(sl=True)[0]
    skinName = pm.mel.eval('findRelatedSkinCluster '+objName)
    allJoints = cmds.skinCluster(objName,inf=True,q=True)
    jointCurrent = []
    for a in allJoints:
        if cmds.getAttr(a+".liw")!=1:
            jointCurrent.append(a)
    joint_active = cmds.connectionInfo(skinName+".paintTrans",sourceFromDestination=True).split(".")[0]
    if joint_active not in jointCurrent:
        index = 0
    else:
        index = jointCurrent.index(joint_active)
        if index < (len(jointCurrent) - 1):
            index = index + 1
        else:
            index = 0
    pm.mel.eval('setSmoothSkinInfluence '+jointCurrent[index]+';artSkinRevealSelected artAttrSkinPaintCtx;')

def IsolateEffectVertex(*arr):
    objs = cmds.ls(selection=True,type='joint')
    if objs:
        result = all(obj in skinSession['joints'] for obj in objs)
        if result:
            cmds.select(skinSession['mesh'])
            singleUnlock(objs)            

    currentTool = cmds.currentCtx()
    if currentTool != 'artAttrSkinContext':
        pm.mel.eval('ArtPaintSkinWeightsTool;')
    jntCurrent = []
    vertexs = []
    for jnt in skinSession['joints']:
        if cmds.getAttr(jnt+".liw")!=1:
            jntCurrent.append(jnt)
            pm.mel.eval("artSkinSelectVerticesForInfluence "+jnt+" 0 0;")
            vertex = cmds.ls(selection=True)
            vertex.remove(skinSession['mesh'])
            vertexs.extend(vertex)
    pm.mel.eval('setToolTo selectSuperContext;')
    pm.mel.eval('selectMode -component;')
    cmds.select(vertexs)
    cmds.select(jntCurrent,add=True)
    panelCurrent = cmds.getPanel(withFocus=True)
    state = cmds.isolateSelect(panelCurrent, q=True, state=True)
    if state == 1:
        pm.mel.eval('ToggleIsolateSelect;')
        pm.mel.eval('ToggleIsolateSelect;')
    elif state == 0:
        pm.mel.eval('ToggleIsolateSelect;')
    cmds.select(clear=True)
    cmds.select(skinSession['mesh'])
    pm.mel.eval('selectMode -object;ArtPaintSkinWeightsTool;setSmoothSkinInfluence '+jntCurrent[0]+';')

def SelectMeshAndJointsEffect(*arr):
    objName = cmds.ls(sl=True)[0]
    skinName = pm.mel.eval('findRelatedSkinCluster '+objName)
    allJoints = cmds.skinCluster(objName,inf=True,q=True)
    cmds.select(objName)
    cmds.select(allJoints,add=True)

def check_axis_max(name):
    axis_array_translate = ["X","Y","Z"]
    array_temp_translate = []
    max_index_translate = 0
    current_translate = cmds.getAttr(name+".translate")[0]    
    for i in range(0,3):        
        array_temp_translate.append(abs(current_translate[i]))       
        check_max_translate = max(array_temp_translate)
        if check_max_translate == abs(current_translate[i]):
            max_index_translate = i
    return_axis = axis_array_translate[max_index_translate] 
    return [return_axis]   


def showQuardraw(*arr):
    pm.mel.eval('lockNode -l off  -lockUnpublished off initialShadingGroup;')


def ExportAllSkinUrl(folder,*arr):
    jsonData = {}
    jsonPath = folder+'/skinData.json'
    cmds.currentTime(0)
    if len(cmds.ls(selection=True))!=0:
        meshTransform = cmds.ls(selection=True)
    else:
        meshTransform = cmds.listRelatives(cmds.ls(type = "mesh",ap=True),parent=True,pa=True)
        meshTransform = list(set(meshTransform))
    for transform in meshTransform:
        skin_name = pm.mel.eval('findRelatedSkinCluster '+transform)
        transformName = transform
        transformName = transformName.replace("|","&")
        transformName = transformName.replace(":","%")
        if skin_name:
            jsonData[transformName] = {
                'skinName':skin_name
            }
            version = cmds.about(version=True)
            if version in ["2018"]:
                pm.mel.eval('deformerWeights -export -deformer "'+skin_name+'" -path "'+folder+'" "'+transformName+'.xml";')
            else:
                pm.mel.eval('deformerWeights -export -deformer "'+skin_name+'" -format "XML" -path "'+folder+'" "'+transformName+'.xml";')
            NLTA_General.writeJsonFile(jsonPath,jsonData)

def ExportAllSkin(*arr):
    folder_temp = os.path.dirname(pm.sceneName())
    if not folder_temp:
        folder_temp = pm.mel.eval("SaveSceneAs;")
    folder_temp = os.path.dirname(pm.sceneName())
    if folder_temp:
        folder_temp = os.path.join(os.path.dirname(pm.sceneName()), 'bnlta_all_skins_export')
        folder_temp = cmds.encodeString(folder_temp)
        if os.path.exists(folder_temp):
            shutil.rmtree(folder_temp)
        if not os.path.exists(folder_temp):
            os.makedirs(folder_temp)
        ExportAllSkinUrl(folder_temp)
        cmds.warning("Done!!!")


def ExportFolderSkin(*arr):
    url = cmds.fileDialog2(dialogStyle=2, fileMode=3, caption="Select Folder")[0]
    if url:
        dataTemp = {}
        meshs = cmds.ls(selection=True)
        for mesh in meshs:
            dataTemp[mesh] = {}
            dataTemp[mesh]["uuid"] = cmds.ls(mesh,uuid=True)
            meshParent =  cmds.listRelatives(mesh,parent=True)
            if meshParent:
                dataTemp[mesh]["parent"] =  meshParent[0]
                cmds.parent(mesh, world=True)
            else:
                dataTemp[mesh]["parent"] = None
            if "NLTA_" not in mesh:
                cmds.rename(mesh,"NLTA_"+mesh)
                dataTemp[mesh]["nameTemp"] = "NLTA_"+mesh
            else:
                dataTemp[mesh]["nameTemp"] = mesh
        cmds.select(clear=True)
        for mesh in dataTemp:
            cmds.select(cmds.ls(dataTemp[mesh]["uuid"]),add=True)
        cmds.file(url +'/mesh.obj', force=True, options="groups=1;ptgroups=0;materials=0;smoothing=0;normals=1", type='OBJexport', exportSelected=True)
        ExportAllSkinUrl(url)
        for mesh in dataTemp:
            if dataTemp[mesh]["parent"]!=None:
                cmds.parent(dataTemp[mesh]["nameTemp"],dataTemp[mesh]["parent"])
            cmds.rename(cmds.ls(dataTemp[mesh]["uuid"])[0],mesh)



def ImportAllSkinUrl(folder,keepHistory,*arr):
    if os.path.exists(folder):
        jsonData = {}
        jsonPath = folder+'/skinData.json'
        if os.path.exists(jsonPath):
            jsonData = NLTA_General.readJsonFile(jsonPath)
        cmds.currentTime(0)
        if len(cmds.ls(selection=True))!=0:
            meshTransform = cmds.ls(selection=True)
        else:
            meshTransform = cmds.listRelatives(cmds.ls(type = "mesh",ap=True),parent=True,pa=True)
            meshTransform = list(set(meshTransform))
        for transform in meshTransform:
            transformName = transform
            transformName = transformName.replace("|","&")
            transformName = transformName.replace(":","%")

            each_file = ""
            
            fileLink = cmds.encodeString(folder + "/" + transformName + ".xml")
            if os.path.exists(fileLink):
                each_file = fileLink            
            fileLinkSame = cmds.encodeString(folder + "/" + transformName + ".xml")
            if os.path.exists(fileLinkSame):
                each_file = fileLinkSame

            if each_file!="":
                joints = []
                xFile = xd.parse(each_file)
                elements = xFile.getElementsByTagName("weights")
                for e in elements:
                    attrs = e.attributes.keys()
                    for a in attrs:
                        if a == "source":
                            pair = e.attributes[a]
                            joints.append(pair.value)

                if not keepHistory:
                    cmds.select(transform)
                    pm.mel.eval('DeleteHistory;')
                    for attr in ["tx","ty","tz","rx","ry","rz","sx","sy","sz"]:
                        cmds.setAttr(transform+"."+attr,lock=False)

                    pm.mel.eval('makeIdentity -apply true -t 1 -r 1 -s 1 -n 0 -pn 1;')
                    pm.mel.eval('ResetTransformations;')
                """
                else:                    
                    mesh = transformName
                    path = folder
                    history = cmds.listHistory(mesh, pdo=True) or []
                    skinClusters = [node for node in history if cmds.nodeType(node) == "skinCluster"]
                    if skinClusters:
                        skin = skinClusters[0]
                        for j in joints:
                            if cmds.objExists(j):
                                try:
                                    cmds.skinCluster(skin, e=True, ai=j, lw=True)
                                except:pass
                        pm.mel.eval('deformerWeights -import -method "index" -deformer "'+skin+'" -path "'+folder+'/" "'+transformName+'.xml"; skinCluster -e -forceNormalizeWeights "'+skin+'";')
                    else:
                """
                if len(joints)!=0:
                    cmds.select(clear=True)
                    for b in joints:
                        if len(cmds.ls(b))>1:
                            print("More than one joint name is "+b)
                        else:
                            if cmds.objExists(b):                            
                                cmds.select(b,add=True)
                            else:
                                print("Cant find joint name "+b)
                    jointSelection = cmds.ls(selection=True)
                    shapes = cmds.listRelatives(transform,children=True,type='mesh')
                    
                    connsData = []
                    attrsReconns = ['visibility']
                    for shape in shapes:
                        for attr in attrsReconns:
                            src = cmds.connectionInfo(shape+"."+attr, sourceFromDestination=True)
                            if src:
                                connsData.append([src,shape+'.'+attr])

                    for i in range(len(connsData)):
                        conn = connsData[i]
                        cmds.disconnectAttr(conn[0],conn[1])

                    for shape in shapes:
                        cmds.setAttr(shape+'.visibility',1)
                        
                    if jointSelection:
                        cmds.select(transform,add=True)
                        skin_name = cmds.skinCluster(cmds.ls(selection=True),toSelectedBones=True,bindMethod=0,skinMethod=0,normalizeWeights=1,maximumInfluences=1)[0]
                        pm.mel.eval('deformerWeights -import -method "index" -deformer "'+skin_name+'" -path "'+folder+'/" "'+transformName+'.xml"; skinCluster -e -forceNormalizeWeights "'+skin_name+'";')
                        if jsonData !={} and (transform in jsonData):
                            cmds.rename(skin_name,jsonData[transform]['skinName'])
                    for i in range(len(connsData)):
                        conn = connsData[i]
                        cmds.connectAttr(conn[0],conn[1], force=True)



                        
    else:
        cmds.confirmDialog(title="Confirm",message="Dont have data!",button=["Yes"],defaultButton="Yes",cancelButton="Yes") 

def ImportAllSkin(*arr):
    folder = os.path.dirname(pm.sceneName())+"/"+'bnlta_all_skins_export'
    ImportAllSkinUrl(folder,False)
    cmds.warning("Done!!!")

def ImportAllSkinKeepHistory(*arr):
    folder = os.path.dirname(pm.sceneName())+"/"+'bnlta_all_skins_export'
    ImportAllSkinUrl(folder,True)
    cmds.warning("Done!!!")


def ImportFolderSkin(*arr):
    url = cmds.fileDialog2(dialogStyle=2, fileMode=3, caption="Select Folder")[0]
    if url:
        files = NLTA_General.GetFiles(url,'obj')
        for file_ in files:
            filePath =  url+"/"+file_+".obj"
            cmds.file(filePath, i=True, type="OBJ", ignoreVersion=True, ra=True, mergeNamespacesOnClash=False, namespace=":", options="mo=1", pr=True)
    ImportAllSkinUrl(url,False)
    cmds.warning("Done!!!")

def selectCorrectJoint(jointArray,*arr):
    for a in jointArray:
        if cmds.objExists(a):
            return jointArray

def fixMaxInfluent(maxValue,*arr):
    selection = cmds.ls(selection=True,type="mesh")
    if len(selection)==0:
        selection = cmds.ls(type="mesh")
    for a in selection:
        if pm.mel.eval('findRelatedSkinCluster '+a):  
            vertex = cmds.ls(a+'.vtx[*]',fl=True)
            objName = a
            skinName = pm.mel.eval('findRelatedSkinCluster '+objName)
            allJoints = cmds.skinCluster(objName,inf=True,q=True)
            allJointsLock= ""
            for b in vertex:
                joints = cmds.skinPercent(skinName,b,query=True,transform=None)
                values = cmds.skinPercent(skinName,b,query=True,value=True)
                jointsTemp = []
                valuesTemp = []
                for c in range(len(joints)):
                    if values[c] > 0:
                        jointsTemp.append(joints[c])
                        valuesTemp.append(values[c])
                if len(jointsTemp) > maxValue:
                    valuesTemp.sort()              
                    min_value = valuesTemp[(len(valuesTemp) - (maxValue + 1))] 

                    lockJoints = ""
                    for c in allJoints:
                        lockJoints += "setAttr "+c+".liw  1;"
                    pm.mel.eval(lockJoints)

                    unlockJoints = ""
                    for c in jointsTemp:
                        unlockJoints += "setAttr "+c+".liw  0;"
                    pm.mel.eval(unlockJoints) 
                    weightValue = []
                    for c in range(0,len(joints)):
                        if values[c] <= min_value:
                            weightValue.append((joints[c],0))
                    cmds.skinPercent(skinName,b, transformValue=weightValue)
    cmds.warning("Done!!!")

def fixMaxInfluentAll(maxValue,*arr):
    cmds.select(clear=True)
    for a in cmds.ls(type="mesh"):
        if a.endswith("Orig")!=True:
            for b in cmds.listHistory(a):
                if cmds.objExists(b) and cmds.objectType(b) == "skinCluster":
                    cmds.select(cmds.listRelatives(a,parent=True)[0],add=True)
    fixMaxInfluent(maxValue)
    cmds.warning("Done!!!")

def checkMaxInfluentNumber(val,*arr):
    if len(cmds.ls(sl=True)) !=0:
        maxValue = val
        objName = cmds.ls(sl=True)[0]
        vertex = cmds.ls(objName+'.vtx[*]',fl=True)
        skinName = pm.mel.eval('findRelatedSkinCluster '+objName)
        cmds.select(clear=True)
        arrayTemp = []
        for a in vertex:
            joints = cmds.skinPercent(skinName,a,query=True,transform=None)
            values = cmds.skinPercent(skinName,a,query=True,value=True)
            jointsTemp = []
            for b in range(len(joints)):
                if values[b]>0:
                    jointsTemp.append(joints[b])
            if len(jointsTemp) > maxValue:
                arrayTemp.append(a)
        if cmds.objExists("vertexOverMaxInfluence"):
            cmds.delete("vertexOverMaxInfluence")
        cmds.select(arrayTemp)
        pm.mel.eval('sets -name "vertexOverMaxInfluence";')
        cmds.confirmDialog(title="Success!",message="Your request is done!",button=["Yes"],defaultButton="Yes",cancelButton="Yes")
    cmds.warning("Done!!!")

def checkMaxInfluent(*arr):
    if len(cmds.ls(sl=True)) !=0:
        maxValue = cmds.intField("maxInfluent",query=True,value=True)
        checkMaxInfluentNumber(maxValue)

def setInfluence(maxGet,*arr):
    maxGet = maxGet
    selection = cmds.ls(selection=True,type="mesh")
    if len(selection)==0:
        selection = cmds.ls(type="mesh")
    if maxGet == 0:
        for a in selection:
            for b in cmds.listHistory(a):
                if cmds.objectType(b) == "skinCluster":
                    pm.mel.eval('setAttr "'+b+'.maxInfluences" 1;')
                    pm.mel.eval('setAttr "'+b+'.maintainMaxInfluences" 0;')
    else:
        for a in selection:
            for b in cmds.listHistory(a):
                if cmds.objectType(b) == "skinCluster":
                    pm.mel.eval('setAttr "'+b+'.maxInfluences" '+str(maxGet)+';')
                    pm.mel.eval('setAttr "'+b+'.maintainMaxInfluences" 1;')
    cmds.warning("Done!!!")

def maintainOff(number,*arr):
    for a in cmds.ls(type="mesh"):
        if a.endswith("Orig")!=True:
            for b in cmds.listHistory(a):
                if cmds.objExists(b) and cmds.objectType(b) == "skinCluster":      
                    pm.mel.eval('setAttr "'+b+'.maxInfluences" '+str(number)+';')
                    if number!=0:
                        print("a")
                        pm.mel.eval('setAttr "'+b+'.maintainMaxInfluences" 1;')
                    else:
                        pm.mel.eval('setAttr "'+b+'.maintainMaxInfluences" 0;')
                        print("b")

def setMaintainOff(*arr):
    number = cmds.intField("maintainOff",value=True,query=True)
    maintainOff(number)
    cmds.warning("Done!!!")

def clearSkin(*arr):
    for a in cmds.ls(type="mesh"):
        if cmds.objExists(a):
            for b in cmds.listHistory(a):
                if cmds.objExists(b) and cmds.objectType(b) == "skinCluster":
                    cmds.select(a)
                    pm.mel.eval('DeleteHistory;')
    cmds.warning("Done!!!")

def removeUnneedJoint(*arr):
    cmds.currentTime(0)
    if len(cmds.ls(selection=True))!=0:
        meshTransform = cmds.ls(selection=True)
    else:
        meshTransform = cmds.listRelatives(cmds.ls(type = "mesh",ap=True),parent=True,pa=True)
        meshTransform = list(set(meshTransform))
    for transform in meshTransform:
        skinCluster = pm.mel.eval('findRelatedSkinCluster '+transform)
        if skinCluster:
            joints = cmds.skinCluster(skinCluster,query=True,inf=True)
            removeJoints = []
            for joint in joints:
                flag = False
                cmds.select(clear=True)
                pm.mel.eval('skinCluster -e -selectInfluenceVerts '+joint+' '+skinCluster+';')
                selection = cmds.ls(selection=True)
                if len(selection) == 1:
                    if '.vtx[' not in selection[0]:
                        flag = True
                if flag == True:
                    removeJoints.append(joint)            
            cmds.skinCluster(skinCluster, e=True, removeInfluence=removeJoints)
            print('Remove Joint '+ (' - ').join(removeJoints))
    cmds.select(meshTransform)
    cmds.warning("Done!!!")

def removeUnneedJointGame(*arr):
    def GetParents(joint,currentParents):
        parent = cmds.listRelatives(joint,parent=True)
        if parent:
            currentParents.append(parent[0])
            GetParents(parent[0],currentParents)
        return currentParents

    cmds.currentTime(0)
    if len(cmds.ls(selection=True))!=0:
        meshTransform = cmds.ls(selection=True)
    else:
        meshTransform = cmds.listRelatives(cmds.ls(type = "mesh",ap=True),parent=True,pa=True)
        meshTransform = list(set(meshTransform))
    for transform in meshTransform:
        skinCluster = pm.mel.eval('findRelatedSkinCluster '+transform)
        if skinCluster:
            joints = cmds.skinCluster(skinCluster,query=True,inf=True)
            removeJoints = []
            for joint in joints:
                flag = False
                cmds.select(clear=True)
                pm.mel.eval('skinCluster -e -selectInfluenceVerts '+joint+' '+skinCluster+';')
                selection = cmds.ls(selection=True)
                if len(selection) == 1:
                    if '.vtx[' not in selection[0]:
                        flag = True
                if flag == True:
                    removeJoints.append(joint)            
            cmds.skinCluster(skinCluster, e=True, removeInfluence=removeJoints)
            print('Remove Joint '+ (' - ').join(removeJoints))
            jointsProtect = []
            for joint in joints:
                jointsProtect.append(joint)
                jointsProtect.extend(GetParents(joint,[]))
            jointsProtect = list(set(jointsProtect))
            for joint in jointsProtect:
                try:
                    cmds.skinCluster(skinCluster, edit=True, addInfluence=joint, weight=0)
                except:pass
    cmds.select(meshTransform)
    cmds.warning("Done!!!")

def DeleteUnneedJoint(*arr):
    def GetParents(joint,currentParents):
        parent = cmds.listRelatives(joint,parent=True)
        if parent:
            currentParents.append(parent[0])
            GetParents(parent[0],currentParents)
        return currentParents

    meshs = cmds.ls(selection=True, type='transform')
    jointsProtect = []
    for mesh in meshs:
        skin_cluster = None
        history = cmds.listHistory(mesh)
        if history:
            skin_clusters = cmds.ls(history, type='skinCluster')
            if skin_clusters:
                skin_cluster = skin_clusters[0]

        if not skin_cluster:
            cmds.warning(f"{mesh} không có skinCluster.")
            return

        # Lấy danh sách joints ảnh hưởng (influences)
        influences = cmds.skinCluster(skin_cluster, query=True, influence=True)
        if not influences:
            cmds.warning("Không tìm thấy joint nào ảnh hưởng đến mesh.")
            return

        # Tập hợp các joint ảnh hưởng và tổ tiên của chúng (không được xoá)
        SkinnedJoints = set(influences)
        
        for joint in SkinnedJoints:
            jointsProtect.append(joint)
            jointsProtect.extend(GetParents(joint,[]))
    jointsProtect = list(set(jointsProtect))
    for joint in cmds.ls(type="joint"):
        if (joint not in jointsProtect) and cmds.objExists(joint):
            cmds.delete(joint)


def AddMeshJoint(*arr):
    cmds.currentTime(0)
    if len(cmds.ls(selection=True)) == 2:
        selection =  cmds.ls(selection=True)
        source = selection[0]
        destination =  selection[1]
        skinClusterSource = pm.mel.eval('findRelatedSkinCluster '+ source)
        skinClusterDestination =  pm.mel.eval('findRelatedSkinCluster '+ destination)
        if skinClusterSource and skinClusterDestination:
            jointsSource = cmds.skinCluster(skinClusterSource,query=True,inf=True)
            jointsDestination =  cmds.skinCluster(skinClusterDestination,query=True,inf=True)
            jointsAdd = []
            for joint in jointsSource:
                if joint not in jointsDestination:
                    jointsAdd.append(joint)
            cmds.skinCluster(skinClusterDestination, edit=True, addInfluence=jointsAdd, weight=0)
            print('Add Joint '+ (' - ').join(jointsAdd))
            cmds.warning("Done!!!")

def AddJoint(*arr):
    cmds.currentTime(0)
    if len(cmds.ls(selection=True)) >= 2:
        selection =  cmds.ls(selection=True)
        jnts = cmds.ls(selection=True,type="joint")
        meshs =  cmds.listRelatives(cmds.ls(type ="mesh",ap=True),parent=True,pa=True)
        meshBind = []
        for mesh in meshs:
            if (mesh in selection) and (mesh not in jnts):
                if mesh not in meshBind:
                    skinCluster =  pm.mel.eval('findRelatedSkinCluster '+mesh)
                    if skinCluster:
                        meshJoints = cmds.skinCluster(skinCluster,query=True,inf=True)
                        jointsAdd = []
                        for joint in jnts:
                            if joint not in meshJoints:
                                jointsAdd.append(joint)
                        cmds.skinCluster(skinCluster, edit=True, addInfluence=jointsAdd, weight=0)
                        print('Add Joint '+ (' - ').join(jointsAdd))
                meshBind.append(mesh)
        cmds.warning("Done!!!")

def CopyWeight(*arr):
    selection = cmds.ls(flatten=True,os=True)
    source = selection[0]
    destination =  selection[1:]
    cmds.select(source)
    pm.mel.eval('CopyVertexSkinWeights;')
    cmds.select(destination)
    pm.mel.eval('PasteVertexSkinWeights;')

def UnhideAll(*arr):
    attr = "NLTA_VisibilityBackup"
    objs = cmds.ls(dag=True, type=['mesh','nurbsCurve', 'joint'],ap=True)
    for obj in objs:
        if cmds.attributeQuery(attr, node=obj, exists=True):
            string = cmds.getAttr(obj+'.'+attr)
            exec(string)
            cmds.deleteAttr(obj+'.'+attr)

def IsolateObjects(*arr):
    UnhideAll()
    sels = cmds.ls(selection=True)
    attr = "NLTA_VisibilityBackup"
    objs = cmds.ls(dag=True, type=['mesh','nurbsCurve', 'joint'],ap=True)
    exceptObjs = []
    for sel in sels:
        exceptObjs.append(sel)
        children = cmds.listRelatives(sel,children=True,type=['mesh','nurbsCurve'])
        if children:
            exceptObjs.extend(children)
    for obj in objs:
        if obj not in exceptObjs:
            if not cmds.attributeQuery(attr, node=obj, exists=True):
                cmds.addAttr(obj, longName=attr, dataType='string')
                cmds.setAttr(obj+'.'+attr, e=True, keyable=True)
            if cmds.objectType(obj) in ['mesh','nurbsCurve']:
                enableValue = cmds.getAttr(obj+'.overrideEnabled')
                visibleValue = cmds.getAttr(obj+'.overrideVisibility')
                string = "cmds.setAttr('"+obj+".overrideEnabled',"+str(enableValue)+");cmds.setAttr('"+obj+".overrideVisibility',"+str(visibleValue)+")"
                cmds.setAttr(obj+"."+attr,string,type="string")
                try:
                    cmds.setAttr(obj+'.overrideEnabled',1)
                    cmds.setAttr(obj+'.overrideVisibility',0)

                except:
                    cmds.setAttr(obj+"."+attr,"",type="string")
                    print("Warning: Can't hide "+obj)
            elif  cmds.objectType(obj) == 'joint':
                try:
                    visibleValue = cmds.getAttr(obj+'.drawStyle')
                    string = "cmds.setAttr('"+obj+".drawStyle',"+str(visibleValue)+")"
                    cmds.setAttr(obj+"."+attr,string,type="string")
                    cmds.setAttr(obj+'.drawStyle',2)
                except:
                    print("Warning: Can't hide "+obj)

def IsolateSkinnedMesh(*arr):
    cmds.select(clear=True)
    cmds.select(skinSession['mesh'])
    cmds.select(skinSession['joints'],add=True)
    IsolateObjects()

"""
def ShowFaces(*arr):
    selection = cmds.ls(selection=True)
    if selection:
        for obj in selection:
            cmds.showHidden(obj, below=True)
    else:
       selection = cmds.listRelatives(cmds.ls(type = "mesh",ap=True),parent=True,pa=True)
       for obj in selection:
            cmds.showHidden(obj, below=True)
"""


def GetSetPrefix(*arr):
    selection = cmds.ls(selection=True)
    selection0 = selection[0]
    setNamePrefix = selection0.split(".")[0]
    setNamePrefix = setNamePrefix.split(":")[-1]
    setNamePrefix = "NLTA"+setNamePrefix
    setNamePrefix = setNamePrefix.replace("|","_")
    setNamePrefix = setNamePrefix.replace(":","_")
    return(setNamePrefix)

def GetSameSetNumber(prefix,*arr):
    sets = cmds.ls(type='objectSet')
    returnNumber = 0
    for set_ in sets:
        if prefix in set_:
            returnNumber +=1
    return(returnNumber)

def CreateSet(*arr):
    selection = cmds.ls(selection=True)
    prefix = GetSetPrefix()
    order = []
    sets = cmds.ls(type='objectSet')
    for set_ in sets:
        if prefix in set_:
            order.append(int(set_.replace(prefix,"")))

    if len(order)!=0:
        newName = prefix+ str(max(order) + 1)        
    else:
        newName = prefix+ str(0)
    newSet = cmds.sets(name=newName, empty=True)
    cmds.sets(selection, add=newSet)
    """
    for set_ in sets:
        if NLTA_

    # Create a new set
    set_name = "myNewSet"
    new_set = cmds.sets(name=set_name, empty=True)

    # Add objects to the set
    objects_to_add = ["pSphere1", "pCube1"]
    cmds.sets(objects_to_add, add=set_name)

    members = cmds.sets(set_name, query=True)

    # Hide all members
    if members:
        cmds.hide(members)
    """
setIndex = 0
def NextSet(*arr):
    global setIndex
    prefix =  GetSetPrefix()
    maxNumber = GetSameSetNumber(prefix)
    if setIndex >= (maxNumber - 1):
        currentIndex = 0
    else:
        currentIndex = setIndex + 1
    sets = cmds.ls(type='objectSet')
    for set_ in sets:
        if prefix in set_:
            members = cmds.sets(set_, query=True)
            if members:
                cmds.showHidden(members)
    print(prefix)            
    for set_ in sets:
        if prefix in set_:          
            members = cmds.sets(set_, query=True)
            if set_ == prefix + str(currentIndex):
                if members:
                    cmds.showHidden(members)                
            else:
                if members:
                    cmds.hide(members)
    setIndex = currentIndex

def BackSet(*arr):
    global setIndex
    prefix =  GetSetPrefix()
    maxNumber = GetSameSetNumber(prefix)
    if setIndex <= 0:
        currentIndex = (maxNumber - 1)
    else:
        currentIndex = setIndex - 1
    sets = cmds.ls(type='objectSet')
    for set_ in sets:
        if prefix in set_:
            members = cmds.sets(set_, query=True)
            if members:
                cmds.showHidden(members)                
    for set_ in sets:
        if prefix in set_:
            members = cmds.sets(set_, query=True)
            if set_ == prefix + str(currentIndex):
                if members:
                    cmds.showHidden(members)
            else:
                if members:
                    cmds.hide(members)

    setIndex = currentIndex

def DeleteSets(*arr):
    sets = cmds.ls(type='objectSet')
    for set_ in sets:
        if "NLTA" in set_:
            members = cmds.sets(set_, query=True)
            cmds.showHidden(members)
            cmds.delete(set_)

def ExportSkinFbx(*arr):
    objs = cmds.ls(selection=True)
    for obj in objs:
        meshTransform = []                
        children = cmds.listRelatives(obj,ad=True,type='mesh')
        if children:
            for child in children:
                childVisAttr = child+ '.visibility'
                childVisConns = cmds.listConnections(childVisAttr, source=True, destination=False, plugs=True)
                if childVisConns:
                    for conn in childVisConns:
                        cmds.disconnectAttr(conn,childVisAttr)
                cmds.setAttr(childVisAttr,1)
                parentTransform = cmds.listRelatives(child,parent=True)
                if parentTransform:
                    parentName = parentTransform[0]
                    if parentName not in meshTransform:
                        meshTransform.append(parentName)
        for transform in meshTransform:                
            transformVisAttr = transform + '.visibility' 
            transformVisConns = cmds.listConnections(transformVisAttr, source=True, destination=False, plugs=True)
            if transformVisConns:
                for conn in transformVisConns:
                    cmds.disconnectAttr(conn,transformVisAttr)
            print(transformVisAttr)
            cmds.setAttr(transformVisAttr,1)
            
    layers = cmds.ls(type='displayLayer')
    for layer in layers:
        if layer == 'defaultLayer':
            continue
        cmds.setAttr(layer+".visibility", 1)
        cmds.setAttr(layer+".displayType", 0)
        
    
    scenePath = cmds.file(q=True, sn=True)
    sceneDir = os.path.dirname(scenePath)
    sceneName = os.path.splitext(os.path.basename(scenePath))[0]
    exportPath = sceneDir+'/'+sceneName+"_SkinFbx.fbx"

    if not cmds.pluginInfo('fbxmaya', query=True, loaded=True):
        cmds.loadPlugin('fbxmaya', quiet=True)
    mel.eval('FBXExportShapes -v false')
    mel.eval('FBXExportInputConnections -v false')
    mel.eval('FBXExportEmbeddedTextures -v false')
    mel.eval('FBXExportSkins -v true')
    mel.eval('FBXExportSmoothMesh -v true')
    mel.eval('FBXExportSmoothingGroups -v true')
    mel.eval('FBXExportConstraints -v false')    
    mel.eval(f'FBXExport -f "{exportPath}" -s')

def ObjToNewScene(*arr):
    objs = cmds.ls(selection=True)
    if objs:
        result = cmds.promptDialog(
            title='Tên File Scene Mới',
            message='Nhập tên file mới:',
            button=['OK', 'Cancel'],
            defaultButton='OK',
            cancelButton='Cancel',
            dismissString='Cancel'
        )
        if result != 'OK':            
            return
        ExportSkinFbx()
        scenePath = cmds.file(q=True, sn=True)
        sceneDir = os.path.dirname(scenePath)
        sceneName = os.path.splitext(os.path.basename(scenePath))[0]
        exportPath = sceneDir+'/'+sceneName+"_SkinFbx.fbx"
        newSceneName = cmds.promptDialog(query=True, text=True)
        if not newSceneName.strip():
            cmds.error("Tên scene không hợp lệ.")
        newScenePath = sceneDir+'/'+newSceneName+'.ma'
        cmds.file(new=True, force=True)
        cmds.file(rename=newScenePath)
        cmds.file(save=True, type='mayaAscii')
        cmds.file(exportPath, i=True, type="FBX", ignoreVersion=True, options="fbx", ra=True, mergeNamespacesOnClash=False)
    else:
        print('Nothing is selected')

import maya.cmds as cmds
import maya.mel as mel
import importlib
import math
import json
from functools import partial
import maya.api.OpenMaya as om
import NLTA_General
importlib.reload(NLTA_General)

loftAttr = 'NLTA_LoftData'

def CreateUI(data):  
    def ModifyData(data):
        global titleFlags, layoutFlags, buttonFlags, inputFlags
        titleFlags = data.get('titleFlags', {})
        layoutFlags = data.get('layoutFlags', {})
        buttonFlags = data.get('buttonFlags', {})
        inputFlags = data.get('inputFlags', {})
    ModifyData(data)
  
    titles, buttons, inputs = [], [], []
    parent = data['parent']
    layoutTempt = cmds.rowColumnLayout(data["module"],parent=parent)#*
    cmds.rowColumnLayout(layoutTempt,edit=True,**layoutFlags)
    titles.append(cmds.textField(text=data['title'],editable=False))

    cmds.rowColumnLayout(numberOfColumns=1)#+
    #titles.append(cmds.textField(text='Curve tools',editable=False))
    cmds.rowColumnLayout(numberOfColumns=1)#--

    #####
    cmds.rowColumnLayout(numberOfColumns=2)

    cmds.rowColumnLayout(numberOfColumns=1)
    cmds.rowColumnLayout(numberOfColumns=2)
    buttons.append(cmds.button(label="Curve From Edge",c=ConvertEdgeToCurve,width=160))
    buttons.append(cmds.button(label="Create Curve",c=CreateCurve,width=160))
    cmds.setParent("..")
    cmds.rowColumnLayout(numberOfColumns=4)
    buttons.append(cmds.button(label="Create Plane",c=CreatePlane,width=80))
    buttons.append(cmds.button(label="Make Live",c=MakeLive,width=80))
    buttons.append(cmds.button(label="Exit Live",c=ExitLive,width=80))
    buttons.append(cmds.button(label="Draw Curve",c=DrawCurve,width=80))
    cmds.setParent("..")
    cmds.setParent("..")
    
    cmds.rowColumnLayout(numberOfColumns=1)
    buttons.append(cmds.button(label="Close Curve",c=CloseCurve))
    cmds.separator(height=4, style='none')
    buttons.append(cmds.button(label="Correct Curve Axis",c=CorrectCurrentCurveAxis))
    cmds.setParent("..")

    cmds.setParent("..")
    #####    

    cmds.rowColumnLayout(numberOfColumns=3)
    buttons.append(cmds.button(label="Create Loft",c=CreateLoft,width=142))
    buttons.append(cmds.button(label="Add Loft Curve",c=AddLoftCurve,width=142))  
    buttons.append(cmds.button(label="Flip Loft Normal",c=FlipLoftNormal,width=142))       
    cmds.setParent("..")

    cmds.rowColumnLayout(numberOfColumns=4)
    #buttons.append(cmds.button(label="Select Vertex Near",c=SelectNearPlane))    
    buttons.append(cmds.button(label="RotateCVs +",c=RotateCVsPositive,width=142))
    buttons.append(cmds.button(label="RotateCVs -",c=RotateCVsNegative,width=142))
    buttons.append(cmds.button(label="Flip Curve Normal",c=FlipCurveNormal,width=142))
    cmds.setParent("..")

    cmds.separator(height=3, style='none')


    cmds.rowColumnLayout(numberOfColumns=4)
    cmds.rowColumnLayout(numberOfColumns=1)
    buttons.append(cmds.button(label="Lock Curves",c=partial(DisplayObjects,'curves','lock'),width=105))
    buttons.append(cmds.button(label="Lock Meshs",c=partial(DisplayObjects,'meshs','lock')))    
    cmds.setParent("..")
    cmds.rowColumnLayout(numberOfColumns=1)
    buttons.append(cmds.button(label="Unlock Curves",c=partial(DisplayObjects,'curves','unlock'),width=105))
    buttons.append(cmds.button(label="Unlock Meshs",c=partial(DisplayObjects,'meshs','unlock')))
    cmds.setParent("..")
    cmds.rowColumnLayout(numberOfColumns=1)
    buttons.append(cmds.button(label="Hide Curves",c=partial(DisplayObjects,'curves','hide'),width=105))
    buttons.append(cmds.button(label="Hide Meshs",c=partial(DisplayObjects,'meshs','hide')))    
    cmds.setParent("..")
    cmds.rowColumnLayout(numberOfColumns=1)
    buttons.append(cmds.button(label="Show Curves",c=partial(DisplayObjects,'curves','show'),width=105))
    buttons.append(cmds.button(label="Show Meshs",c=partial(DisplayObjects,'meshs','show')))
    cmds.setParent("..")
    cmds.setParent("..")

    cmds.rowColumnLayout(numberOfColumns=1)
    buttons.append(cmds.button(label="Clean Scene",c=ClearAllLoft,width=105))
    cmds.setParent("..")

    cmds.setParent("..")#--

    cmds.setParent("..")#-
    cmds.setParent("..")#*

    for title in titles:
        cmds.textField(title,edit=True,**titleFlags)
    for button in buttons:
        cmds.button(button,edit=True,**buttonFlags)
    for input_ in inputs:
        if cmds.objectTypeUI(input_) == 'textField':
            cmds.textField(input_,edit=True,**inputFlags)
        if cmds.objectTypeUI(input_) == 'intField':
            cmds.intField(input_,edit=True,**inputFlags)

def MakeLive(*arr):
    objs = cmds.ls(selection=True)
    if objs:
        cmds.makeLive(objs)

def ExitLive(*arr):
    cmds.makeLive(none=True)

def CloseCurve(*arr):
    objs = cmds.ls(selection=True)
    for obj in objs:
        dup = cmds.duplicate(obj, rr=True)[0]
        closed = cmds.closeCurve(dup, ch=False, replaceOriginal=True, preserveShape=False)[0]
        new_shape = cmds.listRelatives(closed, s=True, f=True)[0]
        old_shapes = cmds.listRelatives(obj, s=True, f=True) or []
        cmds.parent(new_shape, obj, shape=True, relative=True)
        for s in old_shapes:
            cmds.delete(s)
        if closed != obj:
            cmds.delete(closed)
        CorrectCurveAxis(obj)
    cmds.select(objs)

def DrawCurve(*arr):
    d = 3
    bez=False
    ctx_name = "myCurveEPContext"    
    if not cmds.contextInfo(ctx_name, exists=True):
        cmds.curveEPCtx(name=ctx_name, d=d, bez=bez)
    else:
        cmds.curveEPCtx(ctx_name, edit=True, d=d, bez=bez)    
    cmds.setToolTo(ctx_name)

def FlipCurveNormal(*arr):
    objs= cmds.ls(selection=True)
    if objs:
        for obj in objs:
            cmds.reverseCurve(obj, ch=False, rpo=True)
    cmds.select(objs)

def RotateCVsPositive(*arr):
    objs = cmds.ls(selection=True)
    if objs:
        obj = objs[0]
        cvs = cmds.ls(obj+".cv[*]", fl=True)
        count = len(cvs)
        originPos = [cmds.xform(cv, worldSpace=True,query=True, translation=True) for cv in cvs]
        for i in range(count):
            cmds.xform(cvs[i], ws=True, t=originPos[i-1])

def RotateCVsNegative(*arr):
    objs = cmds.ls(selection=True)
    if objs:
        obj = objs[0]
        cvs = cmds.ls(obj+".cv[*]", fl=True)
        count = len(cvs) 
        originPos = [cmds.xform(cv, worldSpace=True,query=True, translation=True) for cv in cvs]
        for i in range(len(originPos)):
            increaseI = i + 1
            if increaseI !=  len(originPos):
                cvIndex = i
                posIndex = increaseI
            else:
                cvIndex = i
                posIndex = 0
            cmds.xform(cvs[cvIndex], ws=True, t=originPos[posIndex])


def GetPositions(objs):
    return([om.MVector(cmds.pointPosition(v, w=True)) for v in objs])

def GetCenter(objs):
    positions = GetPositions(objs)
    center = sum(positions, om.MVector(0, 0, 0)) / len(positions)
    return(center)

def GetFarthest(objs):
    positions = GetPositions(objs)
    center = GetCenter(objs)
    farIndex, farDist = 0,0
    for i, pos in enumerate(positions):
        dist = (pos - center).length()
        if dist > farDist:
            farIndex,farDist = i,dist
    vertexVector = positions[farIndex]
    vectorFromCenter = (vertexVector - center).normalize()
    return({
        'vertexVector':vertexVector,
        'obj':objs[farIndex],
        'distance':farDist,
        'vectorFromCenter':vectorFromCenter,
    })

def GetPerpendicular(data):
    center = data['center']
    positions = data['positions']
    vector = data['vector']
    best_dot = float('inf')
    best_index = None
    for i, pos in enumerate(positions):
        vec = (pos - center).normalize()
        dot = abs(vec * vector)
        if dot < best_dot:
            best_dot = dot
            best_index = i
    return(positions[best_index])

def GetNormalFromVectors(data):
    vector1 = data['v1']
    vertor2 = data['v2']
    vector3 = data['v3']
    cmds.select(clear=True)
    jnt_center = cmds.joint(name="joint_center", position=(vector1.x,vector1.y,vector1.z))
    cmds.select(clear=True)
    jnt_far = cmds.joint(name="joint_far", position=(vertor2.x,vertor2.y,vertor2.z))
    cmds.select(clear=True)
    jnt_best = cmds.joint(name="joint_best", position=(vector3.x,vector3.y,vector3.z))
    cmds.aimConstraint(
        jnt_far,        
        jnt_center,     
        aimVector=[0,0, 1],         
        upVector=[1, 0, 0],          
        worldUpType="object",       
        worldUpObject=jnt_best      # hướng up theo joint_best
    )
    transform = cmds.xform(jnt_center, q=True, ws=True, m=True) 
    cmds.delete([jnt_far,jnt_center,jnt_best])
    return(transform)

def GetNormalFromObjs(verts):
    positions = GetPositions(verts)
    center = GetCenter(verts)
    farthestVertex = GetFarthest(verts)
    farVertexVector = farthestVertex['vertexVector']
    perpendicularVertexVector = GetPerpendicular({
        'vector':farthestVertex['vectorFromCenter'],
        'positions':positions,
        'center':center,
    })
    return(GetNormalFromVectors({'v1':center,'v2':farVertexVector,'v3':perpendicularVertexVector}))

def CreatePlane(*arr):
    objs = cmds.ls(selection=True)
    if objs:
        martrix = GetNormalFromObjs(objs)
        farthestVertexSource = GetFarthest(objs)['distance']
        plane, poly_node = cmds.polyPlane(name="myPlane", w=farthestVertexSource+1, h=farthestVertexSource+1, sx=1, sy=1)
        cmds.xform(plane, ws=True, matrix=martrix)
        


def CorrectCurveAxis(curve):    
    cvs = cmds.ls(curve+".cv[*]", fl=True)
    matrix = GetNormalFromObjs(cvs)
    original_positions = [cmds.xform(cv, worldSpace=True,query=True, translation=True) for cv in cvs]
    cmds.xform(curve, ws=True, m=matrix)
    for cv, pos in zip(cvs, original_positions):
        cmds.xform(cv, ws=True, t=pos)
    cmds.makeIdentity(curve, apply=True, t=True, r=False, s=False, n=0)
    return(curve)

def CorrectCurrentCurveAxis(*arr):
    objs = cmds.ls(selection=True)
    for obj in objs:
        CorrectCurveAxis(obj)
    cmds.select(objs)

def CreateCurve(*arr):
    raw_sel = cmds.ls(flatten=True, orderedSelection=True)
    objs = cmds.filterExpand(raw_sel, selectionMask=31)
    count = len(objs)
    positions = GetPositions(objs)    
    curve = cmds.circle(name='NLTA_Curve' + "#", radius=1, sections=count)[0]
    cvs = [f"{curve}.cv[{i}]" for i in range(count)]
    for i in range(count):
        cmds.xform(cvs[i], worldSpace=True, translation=positions[i])
    CorrectCurveAxis(curve)

def SetLoftData(obj,data):
    data = {
        'curves':cmds.ls(data['curves'],uuid=True),
        'loft':cmds.ls(data['loft'],uuid=True)[0],
        'poly':cmds.ls(data['poly'],uuid=True)[0],
    }
    dataStr = json.dumps(data)
    if not cmds.attributeQuery(loftAttr, node=obj, exists=True):
        cmds.addAttr(obj, longName=loftAttr, dataType="string")
    cmds.setAttr(obj+"."+loftAttr, dataStr, type="string")

def GetLoftData(obj):
    if cmds.attributeQuery(loftAttr, node=obj, exists=True):
        raw = cmds.getAttr(obj+"."+loftAttr)
        data = json.loads(raw)
        return(data)
    return(None)

def ClearLoftData(obj):
    if cmds.attributeQuery(loftAttr, node=obj, exists=True):
        cmds.deleteAttr(obj+"."+loftAttr)
        shapes = cmds.listRelatives(obj, shapes=True, fullPath=True) or []
        for shape in shapes:
            if cmds.objectType(shape) == "nurbsCurve":
                cmds.setAttr(obj + ".overrideColor",0)
                cmds.setAttr(obj+".overrideDisplayType",0)
                break

def ClearAllLoft(*arr):
    objs = cmds.ls(type='loft')
    for obj in objs:
        if cmds.attributeQuery(loftAttr, node=obj, exists=True):
            data = GetLoftData(obj)
            if cmds.ls(data['poly']) == []:
                cmds.delete(cmds.ls(data['loft'])[0])
                for curve in data['curves']:
                    if cmds.ls(curve):
                        ClearLoftData(cmds.ls(curve)[0])
            else:
                loft = cmds.ls(data['loft'])[0]
                poly = cmds.ls(data['poly'])[0] 
                curves = GetLoftInputCurves(loft)
                for objTemp in  [loft]+[poly]+curves:
                    SetLoftData(objTemp,{
                        'loft':loft,
                        'poly':poly,
                        'curves':curves
                    })




def SelectNearPlane(*arr):
    objs =  cmds.ls(selection=True)
    meshA = objs[1]
    meshB = objs[0]
    threshold=1
    close_curve=True
    # Step 1: Get vertex of meshA near meshB
    cpm = cmds.createNode("closestPointOnMesh")
    shapeB = cmds.listRelatives(meshB, shapes=True, fullPath=True)[0]
    cmds.connectAttr(f"{shapeB}.worldMesh[0]", f"{cpm}.inMesh", force=True)
    cmds.connectAttr(f"{meshB}.worldMatrix[0]", f"{cpm}.inputMatrix", force=True)

    verts = cmds.ls(f"{meshA}.vtx[*]", fl=True)
    close_verts = []

    for v in verts:
        pos = cmds.pointPosition(v, world=True)
        cmds.setAttr(f"{cpm}.inPosition", *pos, type="double3")
        closest = cmds.getAttr(f"{cpm}.position")[0]
        dist = math.sqrt(sum((pos[i] - closest[i]) ** 2 for i in range(3)))
        if dist <= threshold:
            close_verts.append((v, pos))
    
    cmds.delete(cpm)

    if len(close_verts) < 3:
        cmds.warning("Không tìm được đủ điểm giao để tạo curve.")
        return None

    # Step 2: Tính tâm & normal để sắp theo góc
    positions = [om.MVector(p[1]) for p in close_verts]
    center = sum(positions, om.MVector(0,0,0)) / len(positions)

    # Ước lượng normal từ mặt B
    shapeFn = om.MFnMesh(om.MSelectionList().add(meshB).getDagPath(0))
    normal = om.MVector(0, 0, 0)
    for p in positions:
        p = om.MPoint(p)  # ép kiểu nếu chưa phải MPoint
        point, faceId = shapeFn.getClosestPoint(p, space=om.MSpace.kWorld)
        face_normal = shapeFn.getPolygonNormal(faceId, om.MSpace.kWorld)
        normal += face_normal
    normal.normalize()

    # Xây hệ trục trên mặt phẳng
    x_axis = normal ^ om.MVector(0, 1, 0)
    if x_axis.length() < 1e-3:
        x_axis = normal ^ om.MVector(1, 0, 0)
    x_axis.normalize()
    y_axis = normal ^ x_axis
    y_axis.normalize()

    # Sắp điểm theo góc
    angle_point = []
    for v, pos in close_verts:
        vec = om.MVector(pos) - center
        x = vec * x_axis
        y = vec * y_axis
        angle = math.atan2(y, x)
        angle_point.append((angle, pos))

    angle_point.sort()
    ordered_points = [p for a, p in angle_point]

    # Step 3: Tạo curve
    curve = cmds.curve(p=[(p[0], p[1], p[2]) for p in ordered_points], d=3)
    if close_curve:
        cmds.closeCurve(curve, preserveShape=True, replaceOriginal=True)
    return curve

def ConvertEdgeToCurve(*arr):
    cmds.polyToCurve(form=0,degree=3,conformToSmoothMeshPreview=True)

def FlipLoftNormal(*arr):
    objs = cmds.ls(selection=True)
    if objs:
        lofData = GetLoftData(objs[0])
        cmds.reverseSurface(cmds.ls(lofData['loft'])[0], direction=0, ch=1)

def DisplayObjects(type,action,*arr):
    attrData = None
    if action == 'hide':
        attrData = {'visibility':0,}
    elif action == 'show':
        attrData = {'visibility':1,}
    elif action == 'lock':
        attrData = {'overrideEnabled':1,'overrideDisplayType':2}
    elif action == 'unlock':
        attrData = {'overrideEnabled':1,'overrideDisplayType':0}
    if attrData:
        objs = cmds.ls(type='loft')
        for obj in objs:
            if cmds.attributeQuery(loftAttr, node=obj, exists=True):
                data = GetLoftData(obj)
                poly = cmds.ls(data['poly'])
                curves = cmds.ls(data['curves'])
                if type == 'curves':
                    targetObjs = curves
                elif type == 'meshs':
                    targetObjs = poly
                for targetObj in targetObjs:
                    for key in attrData:
                        cmds.setAttr(targetObj+'.'+key,attrData[key])
                '''

                objs = cmds.ls(selection=True)
                if objs:
                    data = GetLoftData(objs[0])
                    if data:
                        poly = cmds.ls(data['poly'])[0]
                        curves = cmds.ls(data['curves'])
                        if type == 'Switch':
                            
                            flag = cmds.getAttr(poly+".overrideDisplayType")
                            if flag == 2:
                                cmds.setAttr(poly+".overrideEnabled",1)
                                cmds.setAttr(poly+".overrideDisplayType",0)
                                for curve in curves:
                                    cmds.setAttr(curve+".overrideEnabled",1)
                                    cmds.setAttr(curve+".overrideDisplayType",2)
                                cmds.select(poly)
                            else:
                                cmds.setAttr(poly+".overrideEnabled",1)
                                cmds.setAttr(poly+".overrideDisplayType",2)
                                for curve in curves:
                                    cmds.setAttr(curve+".overrideEnabled",1)
                                    cmds.setAttr(curve+".overrideDisplayType",0)
                                cmds.select(curves)
                        elif type == 'All':
                            cmds.setAttr(poly+".overrideEnabled",1)
                            cmds.setAttr(poly+".overrideDisplayType",0)
                            for curve in curves:
                                cmds.setAttr(curve+".overrideEnabled",1)
                                cmds.setAttr(curve+".overrideDisplayType",0)
                '''



def GetLoftNode(loft):
    history = cmds.listHistory(loft)
    node = next((h for h in history if cmds.nodeType(h) == "loft"), None)
    if node:
        return(node)
    return(None)

def GetLoftInputCurves(loft):
    node = GetLoftNode(loft)
    if node:
        curves = []
        i = 0
        while True:
            plug = node+".inputCurve["+str(i)+"]"
            conn = cmds.connectionInfo(plug,sfd=True)       
            if conn:
                shapeName = conn.split('.')[0]
                transformName = cmds.listRelatives(shapeName,parent=True)[0]
                curves.append(transformName)
            else:
                break
            i += 1
        return(curves)
    return(None)

def RebuildCurves(curves):
    spans=16
    for c in curves:
        cmds.delete(c, ch=True)  # ✅ Xóa history trước khi rebuild
        cmds.rebuildCurve(c, ch=False, rpo=True, rt=0,
                          end=1, kr=0, kcp=0, kep=1, d=3, s=spans)

def AlignCurvesDirection(curves):
    def get_tangent(curve):
        p0 = om.MVector(cmds.pointPosition(f"{curve}.cv[0]", w=True))
        p1 = om.MVector(cmds.pointPosition(f"{curve}.cv[1]", w=True))
        return (p1 - p0).normalize()
    base_vec = get_tangent(curves[0])
    for c in curves[1:]:
        this_vec = get_tangent(c)
        dot = base_vec * this_vec
        if dot < 0:
            cmds.reverseCurve(c, ch=False, rpo=True)

def CleanCurve(curves):
    RebuildCurves(curves)
    AlignCurvesDirection(curves)
    
def CreateLoft(*arr):
    ClearAllLoft()
    curves = cmds.ls(selection=True, type='transform')
    objsSave = curves.copy()
    if len(curves) < 2:
        cmds.warning("Chọn ít nhất 2 curve.")
        return
    CleanCurve(curves)
    result = cmds.loft(curves,ch=True,u=False,c=False,ar=False,d=3,ss=1,rn=False,po=0)
    surface = result[0]
    cmds.setAttr(surface+".hiddenInOutliner", 1)
    cmds.setAttr(surface+".visibility",0)
    objsSave.extend(result)
    poly = cmds.nurbsToPoly(
        surface,
        mnd=1,     # Match Normal Direction
        ch=1,      # Keep history
        f=2,       # Format: quads by number
        pt=1,      # Polygon type: quads
        pc=200,    # Polygon count target (for control)
        chr=0.99,  # chord height ratio
        ft=1,      # fit tolerance
        mel=1,     # merge edge length
        d=1,       # Use chord height
        ut=1,      # Use U divisions
        un=20,     # U number
        vt=1,      # Use V divisions
        vn=20,     # V number
        uch=0,     # use chord height in U (off)
        ucr=0,     # uniform chord ratio in U (off)
        cht=0.2,   # chord height
        es=0,      # edge swap (off)
        ntr=0,     # not trim
        mrt=0,     # merge trimmed surface (off)
        uss=1      # use surface span
    )[0]
    objsSave.append(poly) 
    data = {
        'curves':curves,
        'loft':surface,
        'poly':poly,
    }
    for curve in curves:
        cmds.setAttr(curve + ".overrideColor",17)
    for obj in objsSave:
        SetLoftData(obj,data)

    return(poly)


def AddLoftCurve(*arr):
    ClearAllLoft()    
    objs = cmds.ls(selection=True,ap=True)
    if objs:
        curveReference = None
        for obj in objs:
            if cmds.attributeQuery(loftAttr, node=obj, exists=True):
                curveReference = obj
                data = GetLoftData(curveReference)
                break
        if curveReference:
            loft = cmds.ls(data['loft'])[0]
            poly = cmds.ls(data['poly'])[0]
            curves = cmds.ls(data['curves'])
            loftNode = GetLoftNode(loft)
            
            currentIndex = objs.index(curveReference)
            oldIndex = curves.index(curveReference)             
            if currentIndex == 0:
                oldIndex = curves.index(curveReference) + 1
                addObjs = objs[1:]
            elif currentIndex == (len(objs)-1):
                oldIndex = curves.index(curveReference)
                addObjs = objs[:-1]
                if oldIndex <= 0:
                    oldIndex = 0
            CleanCurve(addObjs)
            finalOrder = curves[:oldIndex] + addObjs + curves[oldIndex:]
            i = 0
            for curve in finalOrder:
                shape = cmds.listRelatives(curve,children=True,f=True)[0]
                cmds.connectAttr(shape+'.worldSpace[0]',loftNode+'.inputCurve['+str(i)+']',f=True)
                i += 1
            data['curves'] = finalOrder
            for obj in (finalOrder+[loft]+[poly]):
                SetLoftData(obj,{
                    'curves':finalOrder,
                    'poly':poly,
                    'loft':loft
                })

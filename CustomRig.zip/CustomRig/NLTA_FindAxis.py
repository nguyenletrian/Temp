import bpy
from mathutils import Vector

def BoneGetWorldAxes(arm, boneName):
    pb = arm.pose.bones[boneName]
    m = arm.matrix_world @ pb.matrix
    xAxis = m.to_3x3() @ Vector((1, 0, 0))
    yAxis = m.to_3x3() @ Vector((0, 1, 0))
    zAxis = m.to_3x3() @ Vector((0, 0, 1))
    return {
        "X": xAxis.normalized(),
        "Y": yAxis.normalized(),
        "Z": zAxis.normalized(),
    }

def BoneResolveAxisMapping(dotResults, threshold=0.9):    
    dotResults = sorted(dotResults, key=lambda x: abs(x[2]), reverse=True)
    mapping = {}
    usedA = set()
    used_b = set()
    for aAxis, bAxis, dot in dotResults:
        if abs(dot) < threshold:
            continue
        if aAxis in usedA or bAxis in used_b:
            continue
        mapping[aAxis] = {
            "axis": bAxis,
            "sign": 1 if dot > 0 else -1
        }
        usedA.add(aAxis)
        used_b.add(bAxis)
        if len(mapping) == 3:
            break
    return mapping

def BoneFindMatchingAxes(armA,armB,boneA,boneB):
    axesA = BoneGetWorldAxes(armA, boneA)
    axesB = BoneGetWorldAxes(armB, boneB)
    matches = []
    for aName, aVec in axesA.items():
        for bName, bVec in axesB.items():
            dot = aVec.dot(bVec)
            matches.append((aName, bName, dot))
    matches.sort(key=lambda x: abs(x[2]), reverse=True)    
    return(BoneResolveAxisMapping(matches))

def BoneMatchScale(armSource,armTarget,boneSource,boneTarget):
    pattern = {"X":0,"Y":1,"Z":2}    
    pbSource = armSource.pose.bones[boneSource]
    pbTarget = armTarget.pose.bones[boneTarget]
    axisMatch = BoneFindMatchingAxes(armSource,armTarget,boneSource,boneTarget)
    for axis in axisMatch:
        sourceAxis = pattern[axis]
        targetAxis = pattern[axisMatch[axis]["axis"]]
        sourceScaleValue = pbSource.scale[sourceAxis]
        pbTarget.scale[targetAxis] = sourceScaleValue

arm = bpy.data.objects.get("metarig")
BoneMatchScale(arm,arm,"heel.02.R","heel.02.L")    

import bpy
import importlib
import json
import os
import math
from math import radians,degrees
from mathutils import Matrix,Vector


def GetArm(arm):
    if isinstance(arm, str):
        obj = bpy.data.objects.get(arm)
        if obj and obj.type == 'ARMATURE':
            return(obj)
    if isinstance(arm, bpy.types.Object) and arm.type == 'ARMATURE':
        return(arm)
    return(None)

def ArmGetIKData(arm):
    returnData = []
    for pb in arm.pose.bones:
        for c in pb.constraints:
            if c.type == "IK":
                returnData.append({
                    "boneName":pb.name,
                    "constraint":c.name,
                    "constraintNode":c,
                    "target":c.target.name if c.target else None,
                    "subtarget":c.subtarget,
                    "chain_count":c.chain_count,
                    "pole_target":c.pole_target.name if c.pole_target else None,
                    "pole_subtarget":c.pole_subtarget,
                    "pole_angle":c.pole_angle,
                    "use_tail":c.use_tail,
                    "weight":c.influence,
                    "bones":[pb.name,c.subtarget,c.pole_subtarget],
                })
    return(returnData)

def ArmGetOwnerBoneMatrix(data):
    arm = GetArm(data["arm"])
    boneName = data["boneName"]
    boneNode = arm.pose.bones[boneName]
    boneMaxtrix = arm.matrix_world @  boneNode.matrix
    returnMatrix = arm.matrix_world.inverted() @ boneMaxtrix
    return(returnMatrix)

def ArmGetConstraint(data):
    arm = GetArm(data["arm"])
    source = data["source"]
    target = data["target"]
    consType = data["type"]
    pb = arm.pose.bones.get(target)
    if not pb:
        return None
    for cons in pb.constraints:
        if cons.type == consType:#'COPY_ROTATION':
            if cons.target == arm and cons.subtarget == source:
                return cons
    return None

def ArmSelectBone(data):
    arm = GetArm(data["arm"])
    bones = data["bones"]
    for pb in arm.pose.bones:
        pb.bone.select = False
    for boneName in bones:
        pb = arm.pose.bones.get(boneName)
        if pb:
            pb.bone.select = True

def BoneSelected(arm):
    returnData = []
    selectedBones =  None
    if arm.mode == 'EDIT':
        selectedBones = [b for b in arm.data.edit_bones if b.select]
    elif arm.mode == 'POSE':
        selectedBones = [b for b in arm.pose.bones if b.bone.select]
    if selectedBones:
        for bone in selectedBones:
            returnData.append(bone.name)
    return(returnData)

def BoneGetParent(data,*arr):
    arm = GetArm(data["arm"])
    boneName = data["boneName"]
    if arm.mode == 'EDIT':
        bone = arm.data.edit_bones.get(boneName)
    elif arm.mode == 'POSE':
        bone = arm.pose.bones.get(boneName)
    else:
        bone = arm.data.bones.get(boneName)
    if bone and bone.parent:
        return(bone.parent.name)

def BoneGetChildConstraint(data,*arr):
    arm = GetArm(data["arm"])
    boneName = data["boneName"]
    returnData = []
    for pb in arm.pose.bones:
        for c in pb.constraints:
            if c.subtarget == boneName:
                returnData.append(pb.name) 
    return(returnData)

def CookIKData(data,*arr):
    arm = GetArm(data["arm"])
    IKData = data["IKData"]
    returnData = {
        "boneName":IKData["boneName"],
        "boneNode":arm.pose.bones[IKData["boneName"]],
        "boneMatrix":ArmGetOwnerBoneMatrix({"arm":arm,"boneName":IKData["boneName"]}).copy(),

        "boneParentName":BoneGetParent({"arm":arm,"boneName":IKData["boneName"]}),
        "boneParentNode":arm.pose.bones[BoneGetParent({"arm":arm,"boneName":IKData["boneName"]})],
        "boneParentMatrix":ArmGetOwnerBoneMatrix({"arm":arm,"boneName":BoneGetParent({"arm":arm,"boneName":IKData["boneName"]})}).copy(),

        "IK":IKData["subtarget"],
        "IKNode":arm.pose.bones[IKData["subtarget"]],
        "IKMatrix":ArmGetOwnerBoneMatrix({"arm":arm,"boneName":IKData["subtarget"]}).copy(),

        "IKRef":IKData["subtarget"]+"_SwitchIKFK_ref",
        "IKRefNode":arm.pose.bones[IKData["subtarget"]+"_SwitchIKFK_ref"],
        "IKRefMatrix":ArmGetOwnerBoneMatrix({"arm":arm,"boneName":IKData["subtarget"]+"_SwitchIKFK_ref"}).copy(),

        "IKSwitchName":IKData["subtarget"]+"_IKFK",
        "IKSwitchNode":arm.pose.bones[IKData["subtarget"]+"_IKFK"],
        
        "Pole":IKData["pole_subtarget"],
        "PoleNode":arm.pose.bones[IKData["pole_subtarget"]],
        "PoleMatrix":ArmGetOwnerBoneMatrix({"arm":arm,"boneName":IKData["pole_subtarget"]}).copy()
    }
    boneConstraint = None
    boneConstraints = BoneGetChildConstraint({"arm":arm,"boneName":IKData["boneName"]})
    if len(boneConstraints) == 1:        
        boneConstraint = boneConstraints[0]
    else:
        for boneTemp in boneConstraints:
            if boneTemp in ["RFoot","LFoot"]:
                boneConstraint = boneTemp
                break
    if boneConstraint:
        returnData["boneConstraint"] = boneConstraint
        returnData["boneConstraintNode"] = arm.pose.bones[boneConstraint]
        returnData["boneConstraintMatrix"] = ArmGetOwnerBoneMatrix({"arm":arm,"boneName":boneConstraint}).copy()
        returnData["consRotation"] = ArmGetConstraint({
            "arm":arm,
            "source":IK,
            "target":boneConstraint,
            "type":"COPY_ROTATION",
        })
        returnData["boneConstraintRefName"] = boneConstraint+"_BoneConsSwitchIKFK_ref"
        returnData["boneConstraintRefNode"] = arm.pose.bones[boneConstraint+"_BoneConsSwitchIKFK_ref"]
        returnData["boneConstraintRefMatrix"] = ArmGetOwnerBoneMatrix({"arm":arm,"boneName":boneConstraint+"_BoneConsSwitchIKFK_ref"}).copy()
    return(returnData)

def SwitchIKFK(context,*arr):
    arm = context.active_object
    objs = BoneSelected(arm)
    IKDatas = ArmGetIKData(arm)
    for IKData in IKDatas:
        CookIKData({
            "arm":arm,
            "IKData":IKData,
        })
        for obj in objs:
            if obj in [boneName,boneParentName,IK,Pole,boneConstraint,IKSwitchName]:
                influence = IKData["constraintNode"].influence
                if influence == 0:
                    bpy.context.view_layer.update()
                    IKNode.matrix = IKRefMatrix
                    boneConstraintNode.rotation_euler[0] = 0
                    boneConstraintNode.rotation_euler[1] = 0
                    boneConstraintNode.rotation_euler[2] = 0                    
                    # Hide/Show
                    IKNode.bone.hide=False
                    PoleNode.bone.hide=False
                    boneConstraintNode.bone.hide=True
                    boneParentNode.bone.hide=True
                    boneNode.bone.hide=True
                    #IKData["constraintNode"].influence = 1
                    IKSwitchNode["Switch"] = 1
                    ArmSelectBone({"arm":arm,"bones":[IK]})
                    #bpy.context.view_layer.update()

                else:
                    bpy.context.view_layer.update()
                    boneParentNode.matrix =  boneParentMatrix      
                    boneNode.matrix = boneMatrix
                    boneConstraintNode.matrix= boneConstraintRefMatrix 
                    boneConstraintNode.rotation_euler[0] = 0
                    boneConstraintNode.rotation_euler[1] = 0
                    boneConstraintNode.rotation_euler[2] = 0
                    # Hide/Show
                    IKNode.bone.hide=True
                    PoleNode.bone.hide=True
                    boneConstraintNode.bone.hide=False
                    boneParentNode.bone.hide=False
                    boneNode.bone.hide=False
                    #IKData["constraintNode"].influence = 0
                    IKSwitchNode["Switch"] = 0
                    ArmSelectBone({"arm":arm,"bones":[boneConstraint]})
                    #bpy.context.view_layer.update()
                break


class SwitchIKFK_OP(bpy.types.Operator):
    bl_idname = "create_global.switch_ikfk"
    bl_label = "Do Something"
    def execute(self, context):
        SwitchIKFK(context)
        return {'FINISHED'}

class MainPanel_PN(bpy.types.Panel):
    bl_label = "Switch IKFK Tool"
    bl_idname = "SwitchIKFK_PN"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'SwitchIKFK'
    def draw(self, context):
        layout = self.layout
        layout.scale_y = 1.2
        layout.scale_x = 1
        layout.split(factor=0.1)
        row = layout.row()
        row.operator("create_global.switch_ikfk", text="Switch IKFK")

classes = (
    MainPanel_PN,
    SwitchIKFK_OP,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()


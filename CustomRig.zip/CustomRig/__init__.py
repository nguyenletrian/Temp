bl_info = {
    "name": "Scene Tool",
    "author": "Nguyen Le Tri An",
    "version": (0, 1, 0),
    "blender": (3, 6, 0),
    "location": "View3D > UI",
    "description": "Addon tối giản",
    "category": "3D View",
}

from . import MainUI
import importlib

def register():
    importlib.reload(MainUI)
    MainUI.register()

def unregister():
    MainUI.unregister()

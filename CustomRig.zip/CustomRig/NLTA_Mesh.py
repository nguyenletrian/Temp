import bpy
import bmesh
def GetVertexPos(*arr):
    obj = bpy.context.object
    bm = bmesh.from_edit_mesh(obj.data)
    vertex = [v.index for v in bm.verts if v.select]
    vertexLocal = obj.data.vertices[vertex[0]].co
    vertexWorld = obj.matrix_world @ vertexLocal
    return(vertexWorld)
import maya.cmds as cmds

def FillUI(ui,value,*arr):
    ui_type = cmds.objectTypeUI(ui)
    if ui_type in ["textField", "textFieldGrp","field"]:
        cmds.textField(ui, e=True, text=value)
    elif ui_type == "cmdScrollField":
        cmds.scrollField(ui, e=True, text=value)
    elif ui_type in ["intField", "intFieldGrp"]:
        cmds.intField(ui, e=True, value=value)
    elif ui_type in ["floatField", "floatFieldGrp"]:
        cmds.floatField(ui, e=True, value=float(value))
    elif ui_type == "text":
        cmds.text(ui, e=True, label=value)
    elif ui_type == "checkBox":
        cmds.checkBox(ui, e=True, value=value)
    elif ui_type == "scrollField":
        cmds.scrollField(ui, e=True, text=value)
    else:
        print(f"UI type '{ui_type}' chưa support")

def PickObject(ui, *args):
    objs = cmds.ls(selection=True)
    if not objs:
        return
    string = "\n".join(objs)
    FillUI(ui,string)


def AddObject(ui, *args):
    objs = cmds.ls(selection=True)
    if not objs:
        return
    ui_type = cmds.objectTypeUI(ui)
    if ui_type in ["textField", "textFieldGrp", "field"]:
        current = cmds.textField(ui, q=True, text=True)
        values = [x for x in current.split("\n") if x]
        values.extend(objs)
        values = list(dict.fromkeys(values))
        cmds.textField(ui, e=True, text="\n".join(values))
    elif ui_type in ["scrollField", "cmdScrollField"]:
        current = cmds.scrollField(ui, q=True, text=True)
        values = [x for x in current.split("\n") if x]
        values.extend(objs)
        values = list(dict.fromkeys(values))
        cmds.scrollField(ui, e=True, text="\n".join(values))
    elif ui_type == "optionMenu":
        items = cmds.optionMenu(ui, q=True, itemListLong=True) or []
        values = [cmds.menuItem(item, q=True, label=True) for item in items]
        values.extend(objs)
        values = list(dict.fromkeys(values))
        for item in items:
            cmds.deleteUI(item)
        for value in values:
            cmds.menuItem(label=value, parent=ui)
        if values:
            cmds.optionMenu(ui, e=True, value=values[0])
    else:
        print("UI type '{}' chưa support".format(ui_type))

def PickNamespace(ui, *args):
    objs = cmds.ls(selection=True)
    if objs:
        obj = objs[0]
        parts = obj.split(":")
        if len(parts) <= 1:
            namespace = ""
        else:
            namespace = ":".join(parts[:-1])
        count = len(objs)
        ui_type = cmds.objectTypeUI(ui)

        if ui_type in ["textField", "textFieldGrp","field"]:
            cmds.textField(ui, e=True, text=namespace)
        elif ui_type in ["intField", "intFieldGrp"]:
            cmds.intField(ui, e=True, value=count)
        elif ui_type in ["floatField", "floatFieldGrp"]:
            cmds.floatField(ui, e=True, value=float(count))
        elif ui_type == "text":
            cmds.text(ui, e=True, label=namespace)
        elif ui_type == "optionMenu":
            items = cmds.optionMenu(ui, q=True, itemListLong=True) or []
            for item in items:
                cmds.deleteUI(item)
            namespaces = []
            for o in objs:
                p = o.split(":")
                ns = ":".join(p[:-1]) if len(p) > 1 else ""
                namespaces.append(ns)
            namespaces = list(set(namespaces))
            for ns in namespaces:
                cmds.menuItem(label=ns, parent=ui)
            if namespaces:
                cmds.optionMenu(ui, e=True, value=namespaces[0])
        elif ui_type == "checkBox":
            cmds.checkBox(ui, e=True, value=bool(namespace))
        elif ui_type == "scrollField":
            cmds.scrollField(ui, e=True, text=namespace)

        else:
            print(f"UI type '{ui_type}' chưa support")

def ClearUI(ui,*arr):
    children = cmds.rowColumnLayout(ui, q=True, childArray=True)
    if children:
        for child in children:
            cmds.deleteUI(child)

def GetData(inputDict,*arr):
    uiQuery = {
        "field": lambda ui: cmds.textField(ui, q=True, text=True),
        "textField": lambda ui: cmds.textField(ui, q=True, text=True),
        "scrollField": lambda ui: cmds.scrollField(ui, q=True, text=True),
        "cmdScrollField": lambda ui: cmds.scrollField(ui, q=True, text=True),
        "checkBox": lambda ui: cmds.checkBox(ui, q=True, value=True),
        "intField": lambda ui: cmds.intField(ui, q=True, value=True),
        "floatField": lambda ui: cmds.floatField(ui, q=True, value=True),
        "optionMenu": lambda ui: cmds.optionMenu(ui, q=True, value=True),
    }
    returnData = []
    for item in inputDict:
        itemData = {}
        for key, ui in inputDict[item].items():
            uiType = cmds.objectTypeUI(ui)
            if uiType in uiQuery:
                value = uiQuery[uiType](ui)
            else:
                print("Unsupported UI Type:", uiType)
                value = None
            itemData[key[0].lower() + key[1:]] = value
        returnData.append(itemData)
    return returnData

def GetAttributeSelected(*arr):
    objs =  cmds.ls(selection=True)
    if objs:
        returnData = {
            "allAttr":[]
        }
        mainAttr = cmds.channelBox("mainChannelBox",query=True,sma=True)
        if mainAttr:
            returnData["main"] = mainAttr
            returnData["allAttr"].extend(mainAttr)
        shapeAttr = cmds.channelBox("mainChannelBox",query=True,ssa=True)
        if shapeAttr:
            returnData["shape"] = shapeAttr
            returnData["allAttr"].extend(shapeAttr)
        inputAttr = cmds.channelBox("mainChannelBox",query=True,sha=True)
        if inputAttr:
            returnData["input"] = inputAttr
            returnData["allAttr"].extend(inputAttr)
        outputAttr = cmds.channelBox("mainChannelBox",query=True,soa=True)
        if outputAttr:
            returnData["output"] = outputAttr
            returnData["allAttr"].extend(outputAttr)
        for obj in objs:
            maxIncrease = len(returnData["allAttr"])
            numberIncrease = 0
            for attr in returnData["allAttr"]:
                if cmds.attributeQuery(attr,node=obj,ex=True):
                    numberIncrease +=1
            if maxIncrease == numberIncrease:
                returnData["obj"] = obj
        return(returnData)
    return(None)

def PickAttrs(ui,*arr):
    attrData = GetAttributeSelected()
    returnData = []
    if attrData:
        for attr in attrData["allAttr"]:
            returnData.append(attrData["obj"]+"."+attr)
        FillUI(ui,(";").join(returnData))
        


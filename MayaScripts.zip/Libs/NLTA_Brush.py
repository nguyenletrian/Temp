import maya.cmds as cmds
import pymel.core as pm
import maya.mel as mel

def loadUi(*arr):   
    mel.eval('artAttrSkinPaintCtx -e -minvalue -1 -useColorRamp 1 -colorRamp "1,0,0,1,1,1,0.5,0,0.8,1,1,0.7,0,0.6,1,0,.5,0,0.4,1,0,0,1,0,1"  -rampMaxColor .57 .57 .57  artAttrSkinContext;')
    mel.eval('setObjectPickMask "Joint" false;')

def ChangeOpacity(ui,*arr):
    value = cmds.floatSliderGrp(ui,query=True,value=True)
    ctx = cmds.currentCtx()
    try:
        cmds.artAttrSkinPaintCtx(ctx, e=True, opacity=value)
    except:pass

def ChangeOpacityValue(ui,value,*arr):
    cmds.floatSliderGrp(ui,edit=True,value=value)
    ChangeOpacity(ui)      
    
def ReplaceWeight(value,*arr):
    pm.mel.eval("artAttrSkinPaintModePaintSelect 1 artAttrSkinPaintCtx;")
    pm.mel.eval("artAttrPaintOperation artAttrSkinPaintCtx Replace;")
    pm.mel.eval("artSkinSetSelectionValue "+str(value)+" false artAttrSkinPaintCtx artAttrSkin;")
    
def addWeight(value,*arr):
    pm.mel.eval("artAttrSkinPaintModePaintSelect 1 artAttrSkinPaintCtx;")
    pm.mel.eval("artAttrPaintOperation artAttrSkinPaintCtx Add;")
    pm.mel.eval("artSkinSetSelectionValue "+str(value)+" false artAttrSkinPaintCtx artAttrSkin;")

def smooth(value,*arr):
    pm.mel.eval("artAttrSkinPaintModePaintSelect 1 artAttrSkinPaintCtx;")
    pm.mel.eval("artUpdateStampProfile "+value+" artAttrSkinPaintCtx;")
    pm.mel.eval("artAttrPaintOperation artAttrSkinPaintCtx Smooth;")

def pickValue(*arr):
    pm.mel.eval("artAttrPaintOperation artAttrSkinPaintCtx Replace;")
    pm.mel.eval("artAttrSkinPaintCtx -e -pickValue `currentCtx`;")
    ctx = cmds.currentCtx()
    cmds.artAttrSkinPaintCtx(ctx, e=True, opacity=1)   

def flood(*arr):
    pm.mel.eval("artAttrSkinPaintModePaintSelect 1 artAttrSkinPaintCtx;")
    pm.mel.eval('artAttrSkinPaintCtx -e -clear `currentCtx`;')
    
def CopyWeight(*arr):
    selection = cmds.ls(flatten=True,os=True)
    source = selection[0]
    destination =  selection[1:]
    cmds.select(source)
    pm.mel.eval('CopyVertexSkinWeights;')
    cmds.select(destination)
    pm.mel.eval('PasteVertexSkinWeights;')

def SwitchBrush(*arr):
    ctx = cmds.currentCtx()
    if cmds.contextInfo(ctx, c=True) == "artAttrSkin":
        value = cmds.artAttrSkinPaintCtx(ctx,q=True,value=True)
        newValue =  value * (-1)
        ReplaceWeight(newValue)
        cmds.artAttrSkinPaintCtx(ctx,e=True,value=newValue)        
        

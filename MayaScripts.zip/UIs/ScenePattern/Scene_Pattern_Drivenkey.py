import os
import maya.cmds as cmds
import pymel.core as pm
from functools import partial
from datetime import datetime

import NLTA_General,NLTA_UI
for module in [NLTA_General,NLTA_UI]:
    try:
        importlib.reload(module)
    except:
        from importlib import reload
        reload(module)

ITEMS = {
    "items":{},
    "order":[]
}

def DefaultSetting(*arr):
    moduleName = os.path.basename(__file__).replace(".py","")
    ext = "json"
    name = "Driven Key"
    return({
        "ext":ext,
        "path":("/").join(os.path.dirname(pm.sceneName()).split('/'))+"/"+moduleName+"."+ext,
        "moduleName":moduleName,
        "order":0,
        "title":name,
        "name":name,
        "id":datetime.now().strftime("%Y%m%d%H%M%S")
    })


def Load(data,listUI,*arr):
    newestData = NLTA_General.JsonGetByID({
        "path":data["sceneDataPath"],
        "id":data["id"]
    })
    path = newestData["path"]
    if ".json" in path:
        children = cmds.layout(listUI,q=True, ca=True) or []
        for child in children:
            if cmds.control(child, exists=True):
                cmds.deleteUI(child)        
        itemDatas = NLTA_General.readJsonFile(path)
        if itemDatas:
            for i in range(len(itemDatas)):
                Add(listUI,itemDatas[i])

def Form(data,*arr):
    def Save(data, *arr):
        itemData = NLTA_General.JsonGetByID({
            "path":data["sceneDataPath"],
            "id":data["id"]
        })          
        returnData = NLTA_UI.GetData(ITEMS['items'])
        NLTA_General.writeJsonFile(itemData["path"],returnData)

    mainForm = NLTA_General.LoadModule("Scene_Form")
    dataBack = mainForm.Create(data)
    buttonUI = dataBack["buttonUI"]
    listUI = dataBack["listUI"]

    cmds.rowColumnLayout(numberOfColumns=3,parent=buttonUI)
    cmds.button(label="Add",c=partial(Add,listUI,{}),width=200)
    cmds.button(label="Save",c=partial(Save,data),width=200)
    cmds.setParent("..")
    Load(data,listUI)

def Run(data,*arr):
    newestData = NLTA_General.JsonGetByID({
        "path":data["sceneDataPath"],
        "id":data["id"]
    })
    datas = NLTA_General.readJsonFile(newestData["path"])
    if datas:
        for i in range(len(datas)):
            itemData = datas[i]
            driver = itemData['Driver']
            driverAttr = itemData['DriverAttr']
            drivens = itemData['Drivens'].split(';')
            offsetDict = {}
            for driven in drivens:
                offsetGroup = cmds.group(em=True, name=driven+"_SDKGrp")
                cmds.delete(cmds.parentConstraint(driven,offsetGroup, mo=False))
                drivenParent =  cmds.listRelatives(driven,parent=True)
                if drivenParent:
                    cmds.parent(offsetGroup,drivenParent)
                cmds.parent(driven,offsetGroup)
                offsetDict[driven] = offsetGroup
            
            for i in range(len(itemData['keyData'])):
                keyData = itemData['keyData'][i]
                driverValue =  float(keyData['driverValue'])
                drivenData = keyData['drivenData']
                for driven in drivenData:
                    offsetGroup = offsetDict[driven]
                    attrData = drivenData[driven]
                    for attr in attrData:
                        attrValue = attrData[attr]
                        drivenAttr = offsetGroup+'.'+attr
                        cmds.setDrivenKeyframe(
                            offsetGroup+'.'+attr,
                            currentDriver=driver+"."+driverAttr,
                            driverValue=driverValue,
                            value=attrValue
                        )
                        cmds.keyTangent(drivenAttr, itt='linear', ott='linear')
            

def Add(listUI,data,*arr):
    global ITEMS
    def Delete(ui,*arr):
        global ITEMS
        cmds.deleteUI(ui)
        del ITEMS['items'][ui]
        ITEMS['order'].remove(ui)

    def AddKeyItem(itemUI,data,*arr):
        def GetValue(inputData,*arr):
            obj = cmds.ls(selection=True)
            if obj:
                obj = obj[0]
                driven = inputData['driven']
                itemUI = inputData['itemUI']
                driverValue = inputData['driverValue']
                attrs = inputData['attrs']
                for attr in attrs:
                    attrUI = SDKUis[itemUI]['keyData'][driverValue]['DrivenUIs'][driven][attr]
                    currentValue = cmds.getAttr(obj+'.'+attr)
                    cmds.floatField(attrUI,value = currentValue,edit=True)

        if 'keyData' not in SDKUis[itemUI]:
            SDKUis[itemUI]['keyData'] = {}        
        UIData = SDKUis[itemUI]
        ScrollArea = UIData['ScrollArea']
        Driver = UIData['Driver']
        DriverAttr = UIData['DriverAttr']
        Drivens =  UIData['Drivens']
        DrivenAttrs = UIData['DrivenAttrs']

        driverVal = cmds.textField(Driver,query=True,text=True)
        driverAttrVal = cmds.textField(DriverAttr,query=True,text=True)
        drivensVal = cmds.scrollField(Drivens,query=True,text=True)
        drivensAttrsVal = cmds.textField(DrivenAttrs,query=True,text=True)        
        drivens = drivensVal.split(';')
        drivensAttrs = drivensAttrsVal.split(';')        

        if data == {}:
            driverCurrentValue = cmds.getAttr(driverVal+'.'+driverAttrVal)   
            if str(driverCurrentValue) in SDKUis[itemUI]['keyData']:
                cmds.deleteUI(SDKUis[itemUI]['keyData'][str(driverCurrentValue)]['ItemUI'])
                del SDKUis[itemUI]['keyData'][str(driverCurrentValue)]

            ItemUI = cmds.frameLayout(
                label=driverCurrentValue,
                parent=ScrollArea,
                collapsable=True,
                collapse=True,width=380
            )

            cmds.rowColumnLayout(numberOfColumns=2)
            cmds.textField(text='Driver value',editable=False,width=80,bgc=(0.216, 0.216, 0.216))                  
            driverValueUI = cmds.floatField(value=driverCurrentValue,width=283)
            cmds.setParent('..')

            itemData = {'ItemUI':ItemUI,'DriverValueUI':driverValueUI,}
            cmds.rowColumnLayout(numberOfColumns=1,bgc=(0.15, 0.15, 0.15))
            itemData['DrivenUIs'] = {}
            for driven in drivens:
                
                cmds.rowColumnLayout(numberOfColumns=2)
                cmds.textField(text=driven,editable=False,height=35,width=272,bgc=(0.216, 0.216, 0.216))
                cmds.button(label="Get Current",h=buttonHeight,width=100,c=partial(GetValue,
                    {
                        'itemUI':itemUI,
                        'driverValue':str(driverCurrentValue),
                        'driven':driven,
                        'attrs':drivensAttrs,
                    }
                ))
                cmds.setParent('..')

                itemData['DrivenUIs'][driven] = {}
                cmds.rowColumnLayout(numberOfColumns=6)
                for attr in drivensAttrs:
                    cmds.rowColumnLayout(numberOfColumns=1,width=60)
                    cmds.textField(text=attr,editable=False)
                    if 'drivenData' in data:
                        attrValueUI = cmds.floatField(value = float(data['drivenData'][driven][attr]))
                    else:
                        attrValueUI = cmds.floatField(value = cmds.getAttr(driven+'.'+attr))
                    itemData['DrivenUIs'][driven][attr] = attrValueUI
                    cmds.setParent('..')
                cmds.setParent('..')
            cmds.setParent('..')
            cmds.setParent('..')
            SDKUis[itemUI]['keyData'][str(driverCurrentValue)] = itemData
        else:
            ItemUI = cmds.frameLayout(
                label=str(data['driverValue']),
                parent=ScrollArea,
                collapsable=True,
                collapse=True,width=380
            )
            cmds.rowColumnLayout(numberOfColumns=2)
            cmds.textField(text='Driver value',editable=False,width=80,bgc=(0.216, 0.216, 0.216))                  
            driverValueUI = cmds.floatField(value=float(data['driverValue']),width=283)
            cmds.setParent('..')


            itemData = {'ItemUI':ItemUI,'DriverValueUI':driverValueUI}
            cmds.rowColumnLayout(numberOfColumns=1,bgc=(0.15, 0.15, 0.15))
            itemData['DrivenUIs'] = {}
            for driven in drivens:

                cmds.rowColumnLayout(numberOfColumns=2)
                cmds.textField(text=driven,editable=False,height=35,width=272,bgc=(0.20, 0.20, 0.20))
                cmds.button(label="Get Current",h=buttonHeight,width=100,c=partial(GetValue,
                    {
                        'itemUI':itemUI,
                        'driverValue':str(data['driverValue']),
                        'driven':driven,
                        'attrs':drivensAttrs,
                    }
                ))
                cmds.setParent('..')

                itemData['DrivenUIs'][driven] = {}
                cmds.rowColumnLayout(numberOfColumns=6)
                for attr in drivensAttrs:
                    cmds.rowColumnLayout(numberOfColumns=1,width=60)
                    cmds.textField(text=attr,editable=False)
                    attrValueUI = cmds.floatField(value = float(data['drivenData'][driven][attr]))
                    itemData['DrivenUIs'][driven][attr] = attrValueUI
                    cmds.setParent('..')
                cmds.setParent('..')

            cmds.setParent('..')
            cmds.setParent('..')                
            SDKUis[itemUI]['keyData'][str(data['driverValue'])] = itemData
        cmds.separator(height=2, style='none')


    itemData = {}
    SDKUis = {}
    itemUI = cmds.rowColumnLayout(numberOfColumns=1,parent=listUI,backgroundColor=(0.15, 0.15, 0.15))

    cmds.rowColumnLayout(numberOfColumns=1)

    cmds.rowColumnLayout( numberOfColumns=3,columnWidth=[(1,80),(2,265),(3,32)]) #--

    cmds.textField(text='Driver',editable=False)
    itemData['driver'] = cmds.textField(text=data.get("driver", ""))
    cmds.button(label="+",w=30,c=partial(NLTA_UI.PickObject,itemData['driver']))


    cmds.textField(text='Driver Attrs',editable=False)
    itemData['driverAttr'] = cmds.textField(text=data.get("driverAttr", ""))
    cmds.button(label="+",w=30,c=partial(NLTA_UI.PickAttrs,itemData['driverAttr']))

    cmds.textField(text='Driven',editable=False)
    itemData['drivens'] = cmds.scrollField(wordWrap=True,height=80,text=data.get("drivens", ""))
    cmds.button(label="+",w=30,c=partial(NLTA_UI.PickObject,itemData['drivens']))

    cmds.textField(text='Driven Attrs',editable=False)
    itemData['drivenAttrs'] = cmds.textField(text=data.get("drivenAttrs", ""))
    cmds.button(label="+",w=30,c=partial(NLTA_UI.PickAttrs,itemData['drivenAttrs']))

    itemData['scrollArea'] = cmds.scrollLayout(horizontalScrollBarThickness=4,w=400,h=300)
    cmds.setParent("..")

    cmds.button(label="Add",w=190,c=partial(AddKeyItem,itemUI,{}))


    if data and ('keyData' in data):
        for i in range(len(data['keyData'])):
            AddKeyItem(itemUI,data['keyData'][i])


    cmds.setParent("..") #--

    cmds.button(label="X",w=35,backgroundColor=(.5,.2,.2),c=partial(Delete,itemUI))
    cmds.separator(height=10, style='none')

    cmds.setParent("..")    
    cmds.setParent("..")

    ITEMS['items'][itemUI] = itemData
    ITEMS['order'].append(itemUI)


"""        

def AddKeyItem(itemUI,data,*arr):
    def GetValue(inputData,*arr):
        obj = cmds.ls(selection=True)
        if obj:
            obj = obj[0]
            driven = inputData['driven']
            itemUI = inputData['itemUI']
            driverValue = inputData['driverValue']
            attrs = inputData['attrs']
            for attr in attrs:
                attrUI = SDKUis[itemUI]['keyData'][driverValue]['DrivenUIs'][driven][attr]
                currentValue = cmds.getAttr(obj+'.'+attr)
                cmds.floatField(attrUI,value = currentValue,edit=True)

    if 'keyData' not in SDKUis[itemUI]:
        SDKUis[itemUI]['keyData'] = {}        
    UIData = SDKUis[itemUI]
    ScrollArea = UIData['ScrollArea']
    Driver = UIData['Driver']
    DriverAttr = UIData['DriverAttr']
    Drivens =  UIData['Drivens']
    DrivenAttrs = UIData['DrivenAttrs']

    driverVal = cmds.textField(Driver,query=True,text=True)
    driverAttrVal = cmds.textField(DriverAttr,query=True,text=True)
    drivensVal = cmds.scrollField(Drivens,query=True,text=True)
    drivensAttrsVal = cmds.textField(DrivenAttrs,query=True,text=True)        
    drivens = drivensVal.split(';')
    drivensAttrs = drivensAttrsVal.split(';')        

    if data == {}:
        driverCurrentValue = cmds.getAttr(driverVal+'.'+driverAttrVal)   
        if str(driverCurrentValue) in SDKUis[itemUI]['keyData']:
            cmds.deleteUI(SDKUis[itemUI]['keyData'][str(driverCurrentValue)]['ItemUI'])
            del SDKUis[itemUI]['keyData'][str(driverCurrentValue)]

        ItemUI = cmds.frameLayout(
            label=driverCurrentValue,
            parent=ScrollArea,
            collapsable=True,
            collapse=True,width=380
        )

        cmds.rowColumnLayout(numberOfColumns=2)
        cmds.textField(text='Driver value',editable=False,width=80,bgc=(0.216, 0.216, 0.216))                  
        driverValueUI = cmds.floatField(value=driverCurrentValue,width=283)
        cmds.setParent('..')

        itemData = {'ItemUI':ItemUI,'DriverValueUI':driverValueUI,}
        cmds.rowColumnLayout(numberOfColumns=1,bgc=(0.15, 0.15, 0.15))
        itemData['DrivenUIs'] = {}
        for driven in drivens:
            
            cmds.rowColumnLayout(numberOfColumns=2)
            cmds.textField(text=driven,editable=False,height=35,width=272,bgc=(0.216, 0.216, 0.216))
            cmds.button(label="Get Current",h=buttonHeight,width=100,c=partial(GetValue,
                {
                    'itemUI':itemUI,
                    'driverValue':str(driverCurrentValue),
                    'driven':driven,
                    'attrs':drivensAttrs,
                }
            ))
            cmds.setParent('..')

            itemData['DrivenUIs'][driven] = {}
            cmds.rowColumnLayout(numberOfColumns=6)
            for attr in drivensAttrs:
                cmds.rowColumnLayout(numberOfColumns=1,width=60)
                cmds.textField(text=attr,editable=False)
                if 'drivenData' in data:
                    attrValueUI = cmds.floatField(value = float(data['drivenData'][driven][attr]))
                else:
                    attrValueUI = cmds.floatField(value = cmds.getAttr(driven+'.'+attr))
                itemData['DrivenUIs'][driven][attr] = attrValueUI
                cmds.setParent('..')
            cmds.setParent('..')
        cmds.setParent('..')
        cmds.setParent('..')
        SDKUis[itemUI]['keyData'][str(driverCurrentValue)] = itemData
    else:
        ItemUI = cmds.frameLayout(
            label=str(data['driverValue']),
            parent=ScrollArea,
            collapsable=True,
            collapse=True,width=380
        )
        cmds.rowColumnLayout(numberOfColumns=2)
        cmds.textField(text='Driver value',editable=False,width=80,bgc=(0.216, 0.216, 0.216))                  
        driverValueUI = cmds.floatField(value=float(data['driverValue']),width=283)
        cmds.setParent('..')


        itemData = {'ItemUI':ItemUI,'DriverValueUI':driverValueUI}
        cmds.rowColumnLayout(numberOfColumns=1,bgc=(0.15, 0.15, 0.15))
        itemData['DrivenUIs'] = {}
        for driven in drivens:

            cmds.rowColumnLayout(numberOfColumns=2)
            cmds.textField(text=driven,editable=False,height=35,width=272,bgc=(0.20, 0.20, 0.20))
            cmds.button(label="Get Current",h=buttonHeight,width=100,c=partial(GetValue,
                {
                    'itemUI':itemUI,
                    'driverValue':str(data['driverValue']),
                    'driven':driven,
                    'attrs':drivensAttrs,
                }
            ))
            cmds.setParent('..')

            itemData['DrivenUIs'][driven] = {}
            cmds.rowColumnLayout(numberOfColumns=6)
            for attr in drivensAttrs:
                cmds.rowColumnLayout(numberOfColumns=1,width=60)
                cmds.textField(text=attr,editable=False)
                attrValueUI = cmds.floatField(value = float(data['drivenData'][driven][attr]))
                itemData['DrivenUIs'][driven][attr] = attrValueUI
                cmds.setParent('..')
            cmds.setParent('..')

        cmds.setParent('..')
        cmds.setParent('..')                
        SDKUis[itemUI]['keyData'][str(data['driverValue'])] = itemData
    cmds.separator(height=2, style='none')
#itemUI = cmds.rowColumnLayout(numberOfColumns=1,parent=parentUI,backgroundColor=(0.15, 0.15, 0.15))    
itemUI = cmds.frameLayout(
    label=data.get("Driver", "")+' | '+data.get("Drivens", ""),
    parent=parentUI,
    collapsable=True,
    collapse=True,
    width=380,
    bgc=(0.4,0.4,0.0)
)
"""      











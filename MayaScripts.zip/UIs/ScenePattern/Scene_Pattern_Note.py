import os
import pymel.core as pm
from datetime import datetime
def DefaultSetting(*arr):
    moduleName = os.path.basename(__file__).replace(".py","")
    return({
        "moduleName":moduleName,
        "order":0,
        "name":"",
        "id":datetime.now().strftime("%Y%m%d%H%M%S")
    })
#Nguyen Le Tri An
import maya.cmds as cmds
import importlib
import os
import sys
import subprocess
import pymel.core as pm
from functools import partial


import NLTA_General, NLTA_UI
for module in [NLTA_General,NLTA_UI]:
    try:
        importlib.reload(module)
    except:
        reload(module)


currentFile = os.path.abspath(__file__)
currentFolder = os.path.dirname(currentFile)
scenePatternFolder = os.path.join(currentFolder, "ScenePattern")
if scenePatternFolder not in sys.path:
    sys.path.insert(0, scenePatternFolder)
projectPath =  NLTA_General.GetProjectFunctionPath()
if not projectPath:
    print("#### Please save the scene!~")

sceneDataPath = os.path.dirname(cmds.file(q=True, sn=True))+'/SceneData.json'



ITEMS_PATTERN = {"items":{},"order":[]}
ITEMS = {}
sceneData = {}




def CreateUI(data):  
    def ModifyData(data):
        global titleFlags, layoutFlags, buttonFlags, inputFlags
        titleFlags = data.get('titleFlags', {})
        layoutFlags = data.get('layoutFlags', {})
        buttonFlags = data.get('buttonFlags', {})
        inputFlags = data.get('inputFlags', {})
    ModifyData(data) 

    titles, buttons, inputs = [], [], []
    parent = data['parent']
    layoutTempt = cmds.rowColumnLayout(data["module"],parent=parent)#*
    cmds.rowColumnLayout(layoutTempt,edit=True,**layoutFlags)
    titles.append(cmds.textField(text=data['title'],editable=False))    

    cmds.rowColumnLayout(nc=2)

    cmds.rowColumnLayout(numberOfColumns=4,width=400)
    fileArrays = NLTA_General.GetFiles(projectPath,"py")
    for fileTemp in fileArrays:
        btn = cmds.button(label=fileTemp,width=120,c=partial(NLTA_General.RunScriptFile,projectPath+fileTemp+'.py'))
        popup = cmds.popupMenu(parent=btn)
        cmds.menuItem(label="Edit File", parent=popup,c=partial(NLTA_General.OpenSublime,projectPath+fileTemp+'.py'))
    cmds.setParent("..")

    cmds.rowColumnLayout(nc=1)
    #buttons.append(cmds.button(label="Create Function",c=CreateFunction))
    cmds.setParent("..")
    cmds.setParent("..")

    cmds.rowColumnLayout(numberOfColumns=1)

    cmds.scrollLayout(horizontalScrollBarThickness=4,h=500)
    mainUI = cmds.rowColumnLayout("mainUI",numberOfColumns=1)
    cmds.setParent("..")
    cmds.setParent("..")

    cmds.rowColumnLayout(numberOfColumns=4)
    for fileName in os.listdir(scenePatternFolder):
        if fileName.startswith("Scene_Pattern_") and fileName.endswith(".py"):
            moduleName = fileName.replace(".py","")
            if cmds.window(moduleName, exists=True):
                cmds.deleteUI(moduleName)
            buttonLabel = moduleName.replace("Scene_Pattern_","")
            buttons.append(cmds.button(label=buttonLabel,width=120,c=partial(AddItem,moduleName,mainUI,{})))
    cmds.setParent("..")

    cmds.setParent("..")    
    cmds.setParent("..")
    cmds.setParent("..")
      
    for title in titles:
        cmds.textField(title,edit=True,**titleFlags)
    for button in buttons:
        cmds.button(button,edit=True,**buttonFlags)
    for input_ in inputs:
        if cmds.objectTypeUI(input_) == 'textField':
            cmds.textField(input_,edit=True,**inputFlags)
        if cmds.objectTypeUI(input_) == 'intField':
            cmds.intField(input_,edit=True,**inputFlags)
    SceneLoad("mainUI")

def SceneLoad(ui,*arr):
    NLTA_UI.ClearUI(ui)
    path = cmds.file(q=True, sn=True)
    if path:
        dataTemp = NLTA_General.readJsonFile(sceneDataPath)
        if dataTemp:
            data = sorted(dataTemp, key=lambda x: x["order"])
            if data:
                for i in range(len(data)):
                    AddItem(data[i]["moduleName"],ui,data[i])

def AddItem(moduleName,ui,data,*arr):
    global sceneData

    def OpenItem(defaultSetting,*arr):
        module.Form(defaultSetting)

    def ChangeOrder(orderUI,data,*arr):
        value = cmds.intField(orderUI,query=True,value=True)
        NLTA_General.JsonUpdateByID({
            "id":data["id"],
            "path":sceneDataPath,
            "values":{
                "order":value
            }
        })

    def DeleteItem(ui, *arr):
        cmds.deleteUI(ui)
        itemID = sceneData[ui]['id']
        del sceneData[ui]
        sceneDatas = NLTA_General.readJsonFile(sceneDataPath) or []
        sceneDatas = [
            data for data in sceneDatas
            if data.get('id') != itemID
        ]
        NLTA_General.writeJsonFile(sceneDataPath, sceneDatas)

    def ChangeNote(noteUI,defaultSetting,*arr):
        value = cmds.scrollField(noteUI,query=True,text=True)
        NLTA_General.JsonUpdateByID({
            "id":defaultSetting["id"],
            "path":sceneDataPath,
            "values":{
                "name":value
            }
        })

    def RunItem(defaultSetting,*arr):
        module.Run(defaultSetting)
    
    module = NLTA_General.LoadModule(moduleName)

    if data!= {}: 
        defaultSetting = data
    else:        
        defaultSetting = module.DefaultSetting()
        NLTA_General.JsonAdd({
            "path":sceneDataPath,
            "values":defaultSetting
        })
    
    defaultSetting["sceneDataPath"] = sceneDataPath
    defaultSetting["SceneLoadFunction"] = SceneLoad
    defaultSetting["SceneLoadUI"] = ui

    if moduleName != "Scene_Pattern_Note":
        itemUI = cmds.rowColumnLayout(numberOfColumns=4,parent=ui)
        cmds.button(label="Run",c=partial(RunItem,defaultSetting),width=40,bgc=(0.0, 0.4, 0.0),height=35)    
        textShow = cmds.button(label=defaultSetting['name'],c=partial(OpenItem,defaultSetting),width=330)
        orderUI = cmds.intField(value=defaultSetting['order'],width=50)
        cmds.button(label="X",c=partial(DeleteItem,itemUI),width=40,bgc=(0.4, 0.0, 0.0))
        cmds.intField(orderUI,cc=partial(ChangeOrder,orderUI,defaultSetting),ec=partial(ChangeOrder,orderUI,defaultSetting),edit=True)    
        cmds.setParent('..')
    else: 
        itemUI = cmds.rowColumnLayout(numberOfColumns=4,parent=ui)
        cmds.textField(text="###",width=40)
        textShow = cmds.scrollField(text=defaultSetting['name'],width=330,height=60)
        orderUI = cmds.intField(value=defaultSetting['order'],width=50)
        cmds.button(label="X",c=partial(DeleteItem,itemUI),width=40,bgc=(0.4, 0.0, 0.0))
        cmds.intField(orderUI,cc=partial(ChangeOrder,orderUI,defaultSetting),ec=partial(ChangeOrder,orderUI,defaultSetting),edit=True)   
        cmds.scrollField(textShow,cc=partial(ChangeNote,textShow,defaultSetting),ec=partial(ChangeNote,textShow,defaultSetting),edit=True) 
        cmds.setParent('..')
    sceneData[itemUI] = defaultSetting






import maya.cmds as cmds
import mtoa.cmds.arnoldRender as arnoldRender

# Load Arnold plugin nếu cần
if not cmds.pluginInfo("mtoa", query=True, loaded=True):
    cmds.loadPlugin("mtoa")

# Khởi tạo Arnold render settings nếu cần
arnoldRender.loadArnold()

# Đặt Arnold làm renderer chính
cmds.setAttr("defaultRenderGlobals.currentRenderer", "arnold", type="string")

# Bật adaptive sampling và thiết lập thông số
cmds.setAttr("defaultArnoldRenderOptions.enableAdaptiveSampling", 1)
cmds.setAttr("defaultArnoldRenderOptions.adaptiveThreshold", 0.015)
cmds.setAttr("defaultArnoldRenderOptions.AASamplesMax", 8)

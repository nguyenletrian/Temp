import importlib
import maya.cmds as cmds
import maya.mel as mel

import NLTA_General,NLTA_Graph,NLTA_Mesh,NLTA_Skinning
for module in [NLTA_General,NLTA_Graph,NLTA_Mesh,NLTA_Skinning]:
    try:
        importlib.reload(module)
    except:
        reload(module)

def UpdateView(*arr):
    mesh = NLTA_Mesh.GetMesh()
    skinData = NLTA_General.GetSkinData(mesh[0])
    if skinData["skinCluster"]:
        cmds.skinCluster(skinData["skinCluster"], e=True, forceNormalizeWeights=True)
        cmds.dgdirty(mesh)
        cmds.refresh()

def LockJoint(mesh,jnts):
    skinJnts = NLTA_General.GetSkinData(mesh)["joints"]
    for jnt in skinJnts:
        if jnt in jnts:
            cmds.setAttr(jnt+".liw",0)
        else:
            cmds.setAttr(jnt+".liw",1)

def GetGradientValue(ctrl, x):
    s = cmds.gradientControlNoAttr(ctrl, q=True, asString=True)
    data = list(map(float, s.split(",")))
    points = []
    for i in range(0, len(data), 3):
        pos = data[i]
        val = data[i+1]
        interp = int(data[i+2])
        points.append((pos, val, interp))
    points.sort(key=lambda p: p[0])
    if x <= points[0][0]:
        return points[0][1]
    if x >= points[-1][0]:
        return points[-1][1]
    for i in range(len(points)-1):
        p0, v0, interp = points[i]
        p1, v1, _ = points[i+1]
        if p0 <= x <= p1:
            t = (x - p0) / (p1 - p0)
            if interp == 0:  # none
                return v0
            elif interp == 1:  # linear
                return v0 + (v1 - v0) * t
            elif interp == 2:  # smooth
                t = t * t * (3 - 2 * t)
                return v0 + (v1 - v0) * t

def GradientActiveJoint(*args):
    NLTA_Graph.Clamp()
    currentTime = cmds.currentTime(query=True)
    verts = cmds.ls(sl=True, fl=True)
    if not verts:
        cmds.warning("No vertices selected")
        return
    mesh = verts[0].split(".")[0]
    skinData = NLTA_General.GetSkinData(mesh)
    jointA = skinData["jointActive"]
    joints = skinData["jointsUnlock"]
    skinCluster = skinData["skinCluster"]
    oldEnv = cmds.getAttr(skinCluster + ".envelope")
    cmds.setAttr(skinCluster + ".envelope", 0)

    try:
        distances = []
        validVerts = []
        for v in verts:
            if ".vtx[" not in v:
                continue
            d = NLTA_General.GetDistance(v, jointA)
            if d is None:
                continue
            distances.append(d)
            validVerts.append(v)
        if not distances:
            return
        minDist = min(distances)
        maxDist = max(distances)        
        if abs(maxDist - minDist) < 1e-8:
            maxDist = minDist + 1e-8    
        for v in validVerts:
            d = NLTA_General.GetDistance(v, jointA)
            ratio = (d - minDist) / (maxDist - minDist)
            ratio = 1-(max(0.0, min(1.0, ratio)))
            val = NLTA_Graph.GetValue(ratio)
            if val is None:
                val = ratio * 100.0
            totalW = 0.0
            for j in joints:
                totalW += cmds.skinPercent(skinCluster, v, q=True, transform=j)
            if totalW == 0:
                continue
            newA = totalW * val
            cmds.skinPercent(
                skinCluster,
                v,
                transformValue=[(jointA, newA)],
                normalize=True
            )
    finally:
        cmds.setAttr(skinCluster + ".envelope", oldEnv)
    cmds.skinCluster(skinCluster, e=True, forceNormalizeWeights=True)
    UpdateView()
    cmds.currentTime(currentTime)

def CopyWeightPer(*arr):
    verts = cmds.ls(selection=True,flatten=True)
    if verts:
        mesh = verts[0].split(".")[0]
        skinData = NLTA_General.GetSkinData(mesh)
        skinCluster = skinData["skinCluster"]
        oldEnv = cmds.getAttr(skinCluster + ".envelope")
        cmds.setAttr(skinCluster + ".envelope", 0)
        data = NLTA_Mesh.ListToPerVerts(verts)
        for vert in data:
            cmds.select(vert)
            mel.eval('CopyVertexSkinWeights;')
            cmds.select(data[vert])
            mel.eval('PasteVertexSkinWeights;')
        cmds.setAttr(skinCluster + ".envelope",oldEnv)
        cmds.skinCluster(skinCluster, e=True, forceNormalizeWeights=True)
        UpdateView()
        cmds.select(verts)

def WeightFromRatio(data):
    skinCluster = data["skinCluster"]
    vert = data["vert"]
    joints = data["joints"]
    ratios = data["ratios"]
    if not joints or not ratios or len(joints) != len(ratios):
        return
    values = [
        cmds.skinPercent(skinCluster, vert, q=True, transform=j)
        for j in joints
    ]
    totalWeight = sum(values)
    if totalWeight == 0:
        return
    newWeights = [totalWeight * r for r in ratios]
    cmds.skinPercent(
        skinCluster,
        vert,
        transformValue=list(zip(joints, newWeights))
    )
    
def CopyRatioWeight(*arr):
    verts = cmds.ls(selection=True,flatten=True)
    if verts:
        mesh = verts[0].split(".")[0]
        skinData = NLTA_General.GetSkinData(mesh)
        skinCluster = skinData["skinCluster"]
        oldEnv = cmds.getAttr(skinCluster + ".envelope")
        cmds.setAttr(skinCluster + ".envelope", 0)
        data = NLTA_Mesh.ListToPerVerts(verts)

        for vert in data:
            jointsWeight = NLTA_Skinning.GetJointsWeight({
                "skinCluster":skinData["skinCluster"],
                "vert":vert,
                "joints":skinData["jointsUnlock"]
            })
            ratios = []
            for jointUnlock in skinData["jointsUnlock"]:
                ratios.append(jointsWeight[jointUnlock]["ratio"])
            verts = data[vert]
            for vertTemp in verts:
                WeightFromRatio({
                    "skinCluster":skinCluster,
                    "vert":vertTemp,
                    "joints":skinData["jointsUnlock"],
                    "ratios":ratios
                })
        cmds.setAttr(skinCluster + ".envelope",oldEnv)
        cmds.skinCluster(skinCluster, e=True, forceNormalizeWeights=True)
        UpdateView()


def WeightFromDistance(*arr):
    verts = cmds.ls(selection=True,flatten=True)
    mesh = verts[0].split(".")[0]
    data =  NLTA_General.GetSkinData(mesh)
    NLTA_Skinning.DeactiveSkin(mesh)
    for vert in verts:
        vertRatio = NLTA_Mesh.GetVertRatioBetweenJoints({
            "vert":vert,
            "joints":data["jointsUnlock"][0:2]
        })
        WeightFromRatio({
            "skinCluster":data["skinCluster"],
            "vert":vert,
            "joints":vertRatio["joints"],
            "ratios":vertRatio["ratios"]
        })
    UpdateView()
    NLTA_Skinning.ActiveSkin(mesh)

def CreatePlane(*arr):
    sel = cmds.ls(sl=True, fl=True)
    plane = cmds.polyPlane(
        name="NLTA_Plane",
        width=1,
        height=1,
        sx=1,
        sy=1
    )[0]
    if sel:
        target = sel[0]
        if "." in target:
            pos = cmds.xform(target, q=True, ws=True, t=True)
            pos = pos[:3]
            cmds.xform(
                plane,
                ws=True,
                t=pos
            )
        else:
            cmds.delete(
                cmds.parentConstraint(target, plane)
            )


def ModifyWeightWithPlane(*arr):
    mesh = NLTA_Mesh.GetMesh()[0]
    NLTA_Skinning.DeactiveSkin(mesh)
    skinData = NLTA_General.GetSkinData(mesh)
    if len(skinData["jointsUnlock"])!=2:
        NLTA_Skinning.ActiveSkin(mesh)
        return()
    planeRatios =NLTA_Mesh.RatioDistanceVertsFromPlane({
        "verts":cmds.ls(selection=True,flatten=True),
        "plane":"NLTA_Plane"
    })
    jointActive = skinData["jointActive"]
    jointRemain = [
        j for j in skinData["jointsUnlock"]
        if j != jointActive
    ][0]
    for vert in planeRatios:
        planeRatio = planeRatios[vert]
        graphRatio = NLTA_Graph.GetValue(planeRatio)        
        WeightFromRatio({
            "vert":vert,
            "skinCluster":skinData["skinCluster"],
            "joints":[jointActive,jointRemain],
            "ratios":[1-graphRatio,graphRatio]
        })
    NLTA_Skinning.ActiveSkin(mesh)
    UpdateView()


def CreateSphere(*arr):
    sels = cmds.ls(selection=True)
    if len(sels)<2:
        return()
    source = sels[0]
    targets = sels[1:]
    for target in targets:
        cmds.select(target)
        NLTA_Skinning.DeactiveSkin(target)
        vertsData = NLTA_Mesh.GetDistanceVertex({
            "source":target,
            "target":source,
            "distance":30
        })
        #cmds.polyColorPerVertex(target,remove=True)
        verts = [x["vertex"] for x in vertsData]
        skinData = NLTA_General.GetSkinData(target)
        for vertData in vertsData:
            newRatio = NLTA_Graph.GetValue(vertData["ratio"])   
            WeightFromRatio({
                "skinCluster":skinData["skinCluster"],
                "vert":vertData["vertex"],
                "joints":skinData["jointsUnlock"],
                "ratios":[1-newRatio,newRatio],
            })
        cmds.select(verts)
        NLTA_Skinning.ActiveSkin(target)
        UpdateView()
    #cmds.select(sels)
    
def GradientHierarchy(*arr):
    meshs = NLTA_Mesh.GetMesh()
    if meshs:
        mesh = meshs[0]
        skinData = NLTA_General.GetSkinData(mesh)
        joints = skinData["jointsUnlock"]
        for joint in joints:
            parents = cmds.listRelatives(joint,parent=True)
            if parents:
                parent = parents[0]
            else:
                parent = None
            children = cmds.listRelatives(joint,children=True)
            if children:
                child = children[0]
            else:
                child = None
            if parent and child:
                NLTA_Mesh.GetVertexBetweenParentChild({
                    "mesh":mesh,
                    "source":parent,
                    "destination":child
                })
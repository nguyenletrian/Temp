import importlib
import maya.cmds as cmds
import maya.api.OpenMaya as om


import NLTA_General,NLTA_Mesh,NLTA_Axis
for module in [NLTA_General,NLTA_Mesh,NLTA_Axis]:
    try:
        importlib.reload(module)
    except:
        reload(module)


def CreatePlane(size=10):
    sel = cmds.ls(sl=True)
    if not sel:
        return []
    planes = []
    for obj in sel:
        children = cmds.listRelatives(obj, c=True, type="joint") or []
        parent = cmds.listRelatives(obj, p=True)
        parent = parent[0] if parent else None
        if children:
            target = children[0]
            posA = om.MVector(cmds.xform(obj, q=True, ws=True, t=True))
            posB = om.MVector(cmds.xform(target, q=True, ws=True, t=True))
        elif parent:
            posA = om.MVector(cmds.xform(parent, q=True, ws=True, t=True))
            posB = om.MVector(cmds.xform(obj, q=True, ws=True, t=True))
        else:
            continue
        armDir = (posB - posA).normalize()
        plane = cmds.polyPlane(
            w=size,
            h=size,
            sx=1,
            sy=1,
            ch=False,
            name=obj + "_plane"
        )[0]
        cmds.delete(cmds.parentConstraint(obj, plane))

        yAxis = om.MVector(0, 1, 0)

        quat = yAxis.rotateTo(armDir)
        euler = quat.asEulerRotation()
        cmds.xform(plane, ws=True, rotation=(
            om.MAngle(euler.x).asDegrees(),
            om.MAngle(euler.y).asDegrees(),
            om.MAngle(euler.z).asDegrees()
        ))
        planes.append(plane)

def CreateCube(size=10):
    sel = cmds.ls(sl=True)
    if not sel:
        return []
    cubes = []
    for obj in sel:
        children = cmds.listRelatives(obj, c=True, type="joint") or []
        parent = cmds.listRelatives(obj, p=True)
        parent = parent[0] if parent else None
        if children:
            target = children[0]
            posA = om.MVector(cmds.xform(obj, q=True, ws=True, t=True))
            posB = om.MVector(cmds.xform(target, q=True, ws=True, t=True))
        elif parent:
            posA = om.MVector(cmds.xform(parent, q=True, ws=True, t=True))
            posB = om.MVector(cmds.xform(obj, q=True, ws=True, t=True))
        else:
            continue
        bone_vec = posB - posA
        height = bone_vec.length()
        if height < 0.0001:
            continue
        armDir = bone_vec.normal()
        # Create cube
        cube = cmds.polyCube(w=size,h=height,d=size,ch=False,name=obj + "_cube")[0]
        cmds.move(0,height * 0.5,0,cube + ".vtx[*]",r=True,os=True)
        cmds.xform(cube,ws=True,t=(posA.x, posA.y, posA.z))
        yAxis = om.MVector(0, 1, 0)
        quat = yAxis.rotateTo(armDir)
        euler = quat.asEulerRotation()
        cmds.xform(cube,ws=True,rotation=(om.MAngle(euler.x).asDegrees(),om.MAngle(euler.y).asDegrees(),om.MAngle(euler.z).asDegrees()))
        cubes.append(cube)
    return cubes

def SelectVertexIntersect(data):
    def get_mesh_fn(mesh):
        sel = om.MSelectionList()
        sel.add(mesh)
        dag = sel.getDagPath(0)
        return om.MFnMesh(dag), dag
    def is_vertex_inside_mesh(point, fnMeshB):
        direction = om.MFloatVector(1, 0.37, 0.21).normalize()
        hits = fnMeshB.allIntersections(
            om.MFloatPoint(point),
            direction,
            om.MSpace.kWorld,
            1e10,
            False
        )
        if not hits or len(hits[0]) == 0:
            return False
        hit_count = len(hits[0])
        return (hit_count % 2) == 1
    objs = cmds.ls(os=True)
    if len(objs)==2:
        meshA = objs[1]
        meshB = objs[0]
        fnA, dagA = get_mesh_fn(meshA)
        fnB, dagB = get_mesh_fn(meshB)
        it = om.MItMeshVertex(dagA)
        inside_vertices = []
        while not it.isDone():
            pos = it.position(om.MSpace.kWorld)
            if is_vertex_inside_mesh(pos, fnB):
                index = it.index()
                inside_vertices.append(meshA+(".vtx[{}]".format(index)))
            it.next()
        cmds.select(inside_vertices)

def RatioDistanceVertsFromPlane(data):
    vertices= data["verts"]
    plane_obj = data["plane"]
    def point_plane_distance(point, plane_point, plane_normal):
        v = point - plane_point
        return v * plane_normal
    m = cmds.xform(plane_obj, q=True, ws=True, m=True)
    mat = om.MMatrix(m)
    plane_point = om.MVector(mat[12], mat[13], mat[14])
    plane_normal = om.MVector(mat[4], mat[5], mat[6]).normal()
    data = []
    max_dist = 0.0
    for vtx in vertices:
        pos = cmds.pointPosition(vtx, w=True)
        pos = om.MVector(pos)
        dist = abs(point_plane_distance(
            pos,
            plane_point,
            plane_normal
        ))
        data.append([vtx, dist])
        if dist > max_dist:
            max_dist = dist
    result = {}
    for vtx, dist in data:
        ratio = 0.0
        if max_dist > 1e-8:
            ratio = dist / max_dist
        result[vtx] = ratio
    return result
"""
def SelectVertsFromPlane(*arr):
    max_distance=10
    sel = cmds.ls(sl=True, fl=True)
    if not sel or len(sel) < 2:
        cmds.warning("Select: plane first, then mesh")
        return []

    plane = sel[0]
    mesh = sel[1]

    # -------------------------
    # MESH
    # -------------------------
    msel = om.MSelectionList()
    msel.add(mesh)
    mesh_dag = msel.getDagPath(0)
    fn_mesh = om.MFnMesh(mesh_dag)

    points = fn_mesh.getPoints(om.MSpace.kWorld)

    # -------------------------
    # PLANE MESH (ALL FACES)
    # -------------------------
    msel.clear()
    msel.add(plane)
    plane_dag = msel.getDagPath(0)
    fn_plane = om.MFnMesh(plane_dag)

    # -------------------------
    # COLLECT VERTICES
    # -------------------------
    result = []

    for i, p in enumerate(points):
        wp = om.MPoint(p)

        # closest point ON ANY FACE of plane mesh
        closest_p, face_id = fn_plane.getClosestPoint(wp, om.MSpace.kWorld)
        dist = wp.distanceTo(closest_p)
        print("-----")
        print(type(dist))
        print(type(max_distance))
        print(dist <= max_distance)
        if dist <= max_distance:
            print(dist)
            result.append(f"{mesh}.vtx[{i}]")

    # -------------------------
    # SELECT RESULT
    # -------------------------
    if result:
        cmds.select(result, r=True)
    else:
        cmds.select(clear=True)
        cmds.warning("No vertices found in range")

    return result



def GetDistanceVertex(data):
    def getDag(node):
        sel = om.MSelectionList()
        sel.add(node)
        return sel.getDagPath(0)
    sourceMesh = data["source"]
    targetMesh = data["target"]
    maxDistance = data["distance"]
    sourceDag = getDag(sourceMesh)
    targetDag = getDag(targetMesh)
    sourceFn = om.MFnMesh(sourceDag)
    targetFn = om.MFnMesh(targetDag)
    result = []
    points = sourceFn.getPoints(om.MSpace.kWorld)
    for i, p in enumerate(points):
        closestPoint, normal, faceId = \
            targetFn.getClosestPointAndNormal(
                om.MPoint(p),
                om.MSpace.kWorld
            )
        vec = om.MVector(p - closestPoint)
        dot = vec * normal
        dist = vec.length()
        if dot > 0 and dist <= maxDistance:
            ratio = dist / maxDistance
            result.append({
                "vertex":
                    "%s.vtx[%s]" % (
                        sourceMesh,
                        i
                    ),
                "distance":
                    dist,
                "ratio":
                    ratio
            })
    return result
"""
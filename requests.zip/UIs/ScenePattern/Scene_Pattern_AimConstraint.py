import os
import maya.cmds as cmds
import pymel.core as pm
from functools import partial
from datetime import datetime

import NLTA_General,NLTA_UI
for module in [NLTA_General,NLTA_UI]:
    try:
        importlib.reload(module)
    except:
        from importlib import reload
        reload(module)

ITEMS = {
    "items":{},
    "order":[]
}

def DefaultSetting(path,*arr):
    moduleName = os.path.basename(__file__).replace(".py","")
    ext = "json"
    name = "Aim Constraint"
    return({
        "ext":ext,
        "path":path+moduleName+"."+ext,
        "moduleName":moduleName,
        "order":0,
        "title":name,
        "name":name,
        "id":datetime.now().strftime("%Y%m%d%H%M%S")
    })


def Load(data,listUI,*arr):
    newestData = NLTA_General.JsonGetByID({
        "path":data["sceneDataPath"],
        "id":data["id"]
    })
    path = newestData["path"]
    if ".json" in path:
        children = cmds.layout(listUI,q=True, ca=True) or []
        for child in children:
            if cmds.control(child, exists=True):
                cmds.deleteUI(child)        
        itemDatas = NLTA_General.readJsonFile(path)
        if itemDatas:
            for i in range(len(itemDatas)):
                Add(listUI,itemDatas[i])

def Form(data,*arr):
    def Save(data, *arr):
        itemData = NLTA_General.JsonGetByID({
            "path":data["sceneDataPath"],
            "id":data["id"]
        })          
        returnData = NLTA_UI.GetData(ITEMS['items'])
        NLTA_General.writeJsonFile(itemData["path"],returnData)

    mainForm = NLTA_General.LoadModule("Scene_Form")
    dataBack = mainForm.Create(data)
    buttonUI = dataBack["buttonUI"]
    listUI = dataBack["listUI"]

    cmds.rowColumnLayout(numberOfColumns=3,parent=buttonUI)
    cmds.button(label="Add",c=partial(Add,listUI,{}),width=200)
    cmds.button(label="Save",c=partial(Save,data),width=200)
    cmds.setParent("..")
    Load(data,listUI)

def Run(data,*arr):
    newestData = NLTA_General.JsonGetByID({
        "path":data["sceneDataPath"],
        "id":data["id"]
    })
    AXIS_MAP = {
        "x":  (1,0,0),
        "-x": (-1,0,0),
        "y":  (0,1,0),
        "-y": (0,-1,0),
        "z":  (0,0,1),
        "-z": (0,0,-1)
    }


    datas = NLTA_General.readJsonFile(newestData["path"])
    if datas:
        for i in range(len(datas)):
            data = datas[i]
            child = data["child"]
            parent = data["parent"]
            reference = data["reference"]
            constraintContent = data["constraintContent"]
            maintain = data["maintain"]
            aimVector = AXIS_MAP[data["mainAxis"]]
            upVector = AXIS_MAP[data["secondAxis"]]
            grpOffset = NLTA_General.CreateOffsetGroup(child,child+"_AimGrp")
            con = cmds.aimConstraint(
                parent,
                grpOffset,
                aimVector=aimVector,
                upVector=upVector,
                worldUpType="object",
                worldUpObject=reference,
                mo=maintain
            )[0]
            if constraintContent:
                cmds.parent(con,constraintContent)

def Add(listUI,data,*arr):
    global ITEMS
    def Delete(ui,*arr):
        global ITEMS
        cmds.deleteUI(ui)
        del ITEMS['items'][ui]
        ITEMS['order'].remove(ui)

    def PickChild(ui,*arr):
        NLTA_UI.PickObject(ui)
        offsetGroup = cmds.textField(itemData["Child"],query=True,text=True)+"_Offset"
        cmds.textField(itemData["OffsetName"],edit=True,text=offsetGroup)

    itemData = {}   
    itemUI = cmds.rowColumnLayout(numberOfColumns=1,parent=listUI,backgroundColor=(0.15, 0.15, 0.15))

    cmds.rowColumnLayout(numberOfColumns=1)

    cmds.rowColumnLayout( numberOfColumns=3,columnWidth=[(1,80),(2,265),(3,32)]) #--


    cmds.textField(text='Child',editable=False)
    itemData['child'] = cmds.textField(text=data.get('child', ""))
    cmds.button(label="->",w=30,c=partial(NLTA_UI.PickObject,itemData['child']))

    cmds.textField(text='Parent',editable=False)
    itemData['parent'] = cmds.textField(text=data.get('parent', ""))
    cmds.button(label="->",w=30,c=partial(NLTA_UI.PickObject,itemData['parent']))

    cmds.textField(text='Reference',editable=False)
    itemData['reference'] = cmds.textField(text=data.get('reference', ""))
    cmds.button(label="->",w=30,c=partial(NLTA_UI.PickObject,itemData['reference']))

    cmds.textField(text='Main Axis',editable=False)
    itemData["mainAxis"] = cmds.optionMenu()
    for key in ["x","y","x","-x","-y","-z"]:
        cmds.menuItem(label=key)
    cmds.optionMenu(itemData["mainAxis"], e=True, value=data.get("mainAxis","x"))
    cmds.text(label="")

    cmds.textField(text='Second Axis',editable=False)
    itemData["secondAxis"] = cmds.optionMenu()
    for key in ["x","y","x","-x","-y","-z"]:
        cmds.menuItem(label=key)
    cmds.optionMenu(itemData["secondAxis"], e=True, value=data.get("secondAxis","x"))
    cmds.text(label="")

    cmds.textField(text='Maintain',editable=False)
    itemData['Maintain'] = cmds.checkBox("Maintain", value=data.get("maintain",True))
    cmds.text(label="")

    cmds.textField(text='Cons Content',editable=False)
    itemData['constraintContent'] = cmds.textField(text=data.get('constraintContent', ""))
    cmds.button(label="->",w=30,c=partial(NLTA_UI.PickObject,itemData['constraintContent']))

    cmds.setParent("..") #--
    cmds.button(label="X",w=35,backgroundColor=(.5,.2,.2),c=partial(Delete,itemUI))
    cmds.separator(height=10, style='none')

    cmds.setParent("..")    
    cmds.setParent("..")

    ITEMS['items'][itemUI] = itemData
    ITEMS['order'].append(itemUI)










